-- Every setting the admin panel can change.
-- t = bool, int, float, string, secret, color, select, list (list of strings), objects (list of records, see `sub`)
-- Values are validated on the server with Schema.validate before they are saved.

Schema = { pages = {}, fields = {}, byKey = {} }

local function page(id, label) Schema.pages[#Schema.pages + 1] = { id = id, label = label } end

local function add(p, k, t, d, label, o)
    o = o or {}
    local f = { k = k, p = p, t = t, d = d, l = label, h = o.help, min = o.min, max = o.max, opts = o.opts, secret = (t == 'secret'),
                sub = o.sub, restart = o.restart }
    Schema.fields[#Schema.fields + 1] = f
    Schema.byKey[k] = f
end

local function sf(k, t, d, l, o)
    o = o or {}
    return { k = k, t = t, d = d, l = l, min = o.min, max = o.max, opts = o.opts, help = o.help }
end

page('general', 'General')
page('access', 'Access & Staff')
page('reporting', 'Reporting')
page('categories', 'Categories')
page('triage', 'Smart Triage')
page('recorder', 'Flight Recorder')
page('witness', 'Witnesses')
page('trust', 'Trust & Strikes')
page('verdicts', 'Verdicts')
page('macros', 'Quick Replies')
page('sla', 'SLA & Alerts')
page('fixes', 'Instant Fixes')
page('tools', 'Staff Tools')
page('integrations', 'Integrations')
page('moderation', 'Moderation')
page('logs', 'Logs & Discord')

-- ------------------------------------------------------------------ General
add('general', 'brand', 'string', 'Blackbox Reports', 'Name shown in the window', { max = 30 })
add('general', 'themeColor', 'color', '#2f6df6', 'Theme colour')
add('general', 'defaultMode', 'select', 'light', 'Default mode', { opts = { 'dark', 'light' } })
add('general', 'reportCommand', 'string', 'report', 'Report command', { max = 20, help = 'Players type /<command>.' })
add('general', 'deskCommand', 'string', 'reports', 'Staff desk command', { max = 20 })
add('general', 'dutyCommand', 'string', 'bbduty', 'Duty command', { max = 20, help = 'Staff go on and off duty. The wait estimate only counts staff on duty.' })
add('general', 'currency', 'string', '$', 'Currency symbol', { max = 4 })
add('general', 'framework', 'select', 'auto', 'Framework', { opts = { 'auto', 'esx', 'qb', 'qbox', 'standalone' }, restart = true, help = 'Applies after the next restart.' })
add('general', 'payAccount', 'select', 'cash', 'Pay rewards into', { opts = { 'cash', 'bank' } })

-- ------------------------------------------------------------------ Access
add('access', 'adminGroups', 'list', { 'admin', 'god', 'superadmin', 'owner' }, 'Admin groups', { help = 'Can open /bbadmin and use every staff tool. Framework groups.' })
add('access', 'adminRoles', 'list', {}, 'Admin Discord role IDs')
add('access', 'staffGroups', 'list', { 'admin', 'god', 'superadmin', 'owner', 'mod', 'moderator' }, 'Staff groups', { help = 'Can use the staff desk and handle cases.' })
add('access', 'staffRoles', 'list', {}, 'Staff Discord role IDs')
add('access', 'discordGuild', 'string', '', 'Discord server ID', { max = 40 })
add('access', 'discordToken', 'secret', '', 'Discord bot token', { max = 200, help = 'Used for role checks. Never leaves the server.' })
add('access', 'autoDuty', 'bool', true, 'Staff start on duty when they join')
add('access', 'seeOwnCases', 'bool', false, 'Staff cannot open cases that are about themselves', { help = 'A staff member who is reported or who reported is blocked from handling that case.' })

-- ---------------------------------------------------------------- Reporting
add('reporting', 'enabled', 'bool', true, 'Reports are open', { help = 'Turn off to stop new reports (existing ones can still be handled).' })
add('reporting', 'maxOpen', 'int', 3, 'Open reports per player', { min = 1, max = 20 })
add('reporting', 'globalCooldown', 'int', 30, 'Seconds between any two reports', { min = 0, max = 3600 })
add('reporting', 'minChars', 'int', 10, 'Minimum description length', { min = 0, max = 500 })
add('reporting', 'maxChars', 'int', 800, 'Maximum description length', { min = 50, max = 2000 })
add('reporting', 'allowAnonymous', 'bool', true, 'Reporters can hide their name from the accused', { help = 'Staff can always see who filed.' })
add('reporting', 'allowLinks', 'bool', true, 'Reporters can add proof links')
add('reporting', 'maxLinks', 'int', 3, 'Proof links per report', { min = 0, max = 6 })
add('reporting', 'accusedNotify', 'bool', false, 'Tell the accused when they are reported', { help = 'Off by default so nobody is tipped off.' })
add('reporting', 'accusedStatements', 'bool', true, 'Staff can ask the accused for their side')
add('reporting', 'closedVisibleHours', 'int', 72, 'Hours closed cases stay visible to players', { min = 1, max = 720 })
add('reporting', 'killerPrompt', 'bool', true, 'After a player dies, offer to report whoever killed them')
add('reporting', 'killerPromptSecs', 'int', 25, 'Seconds the death prompt stays', { min = 5, max = 120 })
add('reporting', 'nearbyRadius', 'int', 120, 'Nearby player list radius (m)', { min = 20, max = 500 })
add('reporting', 'panicEnabled', 'bool', true, 'Hold-to-report urgent button', { help = 'The player holds the panic key. The report is flagged urgent and files instantly.' })
add('reporting', 'panicHoldMs', 'int', 1500, 'Hold time (ms)', { min = 500, max = 5000 })
add('reporting', 'panicCategory', 'string', 'cheating', 'Panic report category', { max = 30, help = 'Category id from the Categories page.' })
add('reporting', 'ratings', 'bool', true, 'Ask players to rate how their case was handled')

-- --------------------------------------------------------------- Categories
local categoryDefaults = {
    { id = 'rdm', label = 'RDM / Random killing', color = '#ef4444', weight = 30, needsTarget = true, adminOnly = false, evidence = true, witness = true, cooldown = 0, enabled = true,
      keywords = { 'rdm', 'random', 'killed me', 'shot me', 'kos' }, questions = { 'Was there any roleplay before it happened?', 'What weapon was used?' }, fix = '' },
    { id = 'vdm', label = 'VDM / Vehicle ramming', color = '#f97316', weight = 24, needsTarget = true, adminOnly = false, evidence = true, witness = true, cooldown = 0, enabled = true,
      keywords = { 'vdm', 'ran me over', 'rammed', 'hit me with', 'drove into' }, questions = { 'What vehicle was it?' }, fix = '' },
    { id = 'cheating', label = 'Cheating / Hacking', color = '#a855f7', weight = 40, needsTarget = true, adminOnly = false, evidence = true, witness = true, cooldown = 0, enabled = true,
      keywords = { 'hack', 'cheat', 'aimbot', 'modder', 'noclip', 'godmode', 'speedhack', 'teleport', 'esp', 'wallhack' }, questions = { 'What did you see them do?' }, fix = '' },
    { id = 'harass', label = 'Harassment / Toxic behaviour', color = '#ec4899', weight = 26, needsTarget = true, adminOnly = false, evidence = false, witness = false, cooldown = 0, enabled = true,
      keywords = { 'racist', 'slur', 'harass', 'insult', 'toxic', 'threat' }, questions = { 'Where did it happen? (voice, chat, in person)' }, fix = '' },
    { id = 'failrp', label = 'Fail RP / Rule break', color = '#eab308', weight = 18, needsTarget = true, adminOnly = false, evidence = true, witness = true, cooldown = 0, enabled = true,
      keywords = { 'fail rp', 'failrp', 'metagame', 'powergame', 'combat log', 'nlr' }, questions = { 'Which rule do you think was broken?' }, fix = '' },
    { id = 'exploit', label = 'Bug abuse / Exploit', color = '#22d3ee', weight = 28, needsTarget = true, adminOnly = false, evidence = true, witness = false, cooldown = 0, enabled = true,
      keywords = { 'dupe', 'duplicate', 'glitch', 'exploit', 'bug abuse' }, questions = { 'What are they doing, step by step?' }, fix = '' },
    { id = 'stuck', label = "I'm stuck / fell under the map", color = '#38bdf8', weight = 6, needsTarget = false, adminOnly = false, evidence = false, witness = false, cooldown = 60, enabled = true,
      keywords = { 'stuck', 'under the map', 'fell through', 'cant move' }, questions = {}, fix = 'unstuck' },
    { id = 'bug', label = 'Script bug', color = '#14b8a6', weight = 10, needsTarget = false, adminOnly = false, evidence = false, witness = false, cooldown = 30, enabled = true,
      keywords = { 'bug', 'broken', 'error', 'not working' }, questions = { 'Which script or job?', 'What did you expect to happen?' }, fix = '' },
    { id = 'staff', label = 'Staff complaint', color = '#f43f5e', weight = 22, needsTarget = false, adminOnly = true, evidence = false, witness = false, cooldown = 300, enabled = true,
      keywords = {}, questions = { 'Which staff member? (name or ID)' }, fix = '' },
    { id = 'other', label = 'Something else', color = '#94a3b8', weight = 8, needsTarget = false, adminOnly = false, evidence = false, witness = false, cooldown = 0, enabled = true,
      keywords = {}, questions = {}, fix = '' },
}
add('categories', 'categories', 'objects', categoryDefaults, 'Report categories', { max = 30, help = 'Weight raises the priority. Questions are asked on the report form. "Only admins" sends the case to admins only.', sub = {
    sf('id', 'string', 'new', 'Id (no spaces)', { max = 30 }),
    sf('label', 'string', 'New category', 'Name', { max = 50 }),
    sf('color', 'color', '#94a3b8', 'Colour'),
    sf('weight', 'int', 10, 'Priority weight', { min = 0, max = 60 }),
    sf('needsTarget', 'bool', true, 'Needs an accused player'),
    sf('adminOnly', 'bool', false, 'Only admins see these cases'),
    sf('evidence', 'bool', true, 'Capture the flight recorder'),
    sf('witness', 'bool', false, 'Ask nearby witnesses'),
    sf('cooldown', 'int', 0, 'Extra cooldown (seconds)', { min = 0, max = 86400 }),
    sf('enabled', 'bool', true, 'Enabled'),
    sf('keywords', 'list', {}, 'Keywords that suggest this category'),
    sf('questions', 'list', {}, 'Questions on the form (max 4)'),
    sf('fix', 'string', '', 'Instant fix to offer first', { max = 30, help = 'Id from Instant Fixes' }),
} })

-- ------------------------------------------------------------------ Triage
add('triage', 'triageOn', 'bool', true, 'Smart triage')
add('triage', 'autoCategory', 'bool', true, 'Suggest a category from the words the player types')
add('triage', 'wTrust', 'int', 12, 'Reporter trust effect (+/-)', { min = 0, max = 40, help = 'Trusted reporters move up, distrusted ones move down.' })
add('triage', 'wPile', 'int', 10, 'Points per extra reporter on the same player', { min = 0, max = 30, help = 'Several people reporting the same player is a strong signal.' })
add('triage', 'wRisk', 'int', 18, 'Repeat offender effect', { min = 0, max = 40 })
add('triage', 'wPanic', 'int', 25, 'Urgent button', { min = 0, max = 60 })
add('triage', 'wEvidence', 'int', 8, 'Recorder shows combat between both players', { min = 0, max = 30 })
add('triage', 'wWatch', 'int', 15, 'Accused is on the watchlist', { min = 0, max = 40 })
add('triage', 'wKeyword', 'int', 6, 'Description matches the category keywords', { min = 0, max = 20 })
add('triage', 'wAge', 'float', 0.6, 'Points per minute waiting', { min = 0, max = 5, help = 'Old cases creep up so nothing is forgotten.' })
add('triage', 'wAgeCap', 'int', 20, 'Most points waiting can add', { min = 0, max = 50 })
add('triage', 'p1', 'int', 75, 'P1 starts at', { min = 1, max = 200 })
add('triage', 'p2', 'int', 55, 'P2 starts at', { min = 1, max = 200 })
add('triage', 'p3', 'int', 35, 'P3 starts at', { min = 1, max = 200 })
add('triage', 'pileWindow', 'int', 20, 'Merge reports on the same player within (minutes)', { min = 0, max = 240, help = '0 turns merging off.' })
add('triage', 'pileSameCategory', 'bool', false, 'Only merge when the category matches')

-- ---------------------------------------------------------------- Recorder
add('recorder', 'recEnabled', 'bool', true, 'Flight recorder on', { help = 'The server keeps a short trail of every player. A report copies the part that matters.' })
add('recorder', 'recSeconds', 'int', 60, 'Seconds kept', { min = 15, max = 180 })
add('recorder', 'recInterval', 'int', 2, 'Seconds between samples', { min = 1, max = 5, help = 'Lower is more exact and uses a little more memory.' })
add('recorder', 'recRadius', 'int', 120, 'Who counts as "in the scene" (m)', { min = 20, max = 500 })
add('recorder', 'recMaxActors', 'int', 12, 'Most players saved per case', { min = 2, max = 30 })
add('recorder', 'clientEvents', 'bool', true, 'Record shots, damage, deaths and vehicles from the reporter')
add('recorder', 'ghostEnabled', 'bool', true, 'In-game ghost replay', { help = 'Staff can watch the scene replayed in the real world with see-through players and cars. Uses extra server memory.' })
add('recorder', 'ghostSeconds', 'int', 45, 'Ghost replay length (seconds)', { min = 15, max = 90 })
add('recorder', 'ghostInterval', 'int', 500, 'Ghost sample every (ms)', { min = 250, max = 1000, help = 'Lower is smoother and uses more memory.' })
add('recorder', 'ghostMaxActors', 'int', 6, 'Most players in a ghost replay', { min = 2, max = 12 })
add('recorder', 'ghostTail', 'int', 4, 'Seconds kept after a death', { min = 0, max = 10, help = 'A clip is saved automatically when someone dies, so the replay still shows the hit when the report is filed later.' })
add('recorder', 'ghostClipAge', 'int', 900, 'Keep death clips for (seconds)', { min = 60, max = 3600 })
add('recorder', 'recShots', 'bool', true, 'Shots fired')
add('recorder', 'recDamage', 'bool', true, 'Damage taken')
add('recorder', 'recVehicle', 'bool', true, 'Vehicle enter and exit')
add('recorder', 'keepEvidenceDays', 'int', 30, 'Keep evidence of closed cases (days)', { min = 1, max = 365 })
add('recorder', 'mapImage', 'bool', false, 'Use a map picture (html/map.jpg)', { help = 'Optional. Put a map picture at html/map.jpg and set its bounds below.' })
add('recorder', 'mapMinX', 'float', -4100, 'Map picture: smallest X', { min = -20000, max = 20000 })
add('recorder', 'mapMaxX', 'float', 4400, 'Map picture: largest X', { min = -20000, max = 20000 })
add('recorder', 'mapMinY', 'float', -4300, 'Map picture: smallest Y', { min = -20000, max = 20000 })
add('recorder', 'mapMaxY', 'float', 8400, 'Map picture: largest Y', { min = -20000, max = 20000 })

-- ---------------------------------------------------------------- Witnesses
add('witness', 'witnessOn', 'bool', true, 'Witness program', { help = 'Players near a reported scene are asked if they saw it.' })
add('witness', 'witnessRadius', 'int', 70, 'Ask players within (m)', { min = 10, max = 300 })
add('witness', 'witnessSecs', 'int', 25, 'Seconds they have to answer', { min = 8, max = 120 })
add('witness', 'witnessMaxAsk', 'int', 6, 'Most players asked', { min = 1, max = 20 })
add('witness', 'witnessChars', 'int', 300, 'Longest statement', { min = 40, max = 1000 })
add('witness', 'witnessReward', 'int', 150, 'Reward for a statement', { min = 0, max = 100000 })
add('witness', 'witnessTrust', 'int', 2, 'Trust gained for a statement', { min = 0, max = 20 })
add('witness', 'witnessIncludeReported', 'bool', false, 'Also ask the accused', { help = 'They get the same question but their answer is filed as an accused statement.' })

-- ------------------------------------------------------------ Trust & strikes
add('trust', 'trustStart', 'int', 50, 'Starting trust', { min = 0, max = 100 })
add('trust', 'trustValid', 'int', 4, 'Trust for a report that was valid', { min = 0, max = 30 })
add('trust', 'trustFalse', 'int', 12, 'Trust lost for a false report', { min = 0, max = 60 })
add('trust', 'trustRecover', 'int', 1, 'Trust regained per day (up to the start)', { min = 0, max = 10 })
add('trust', 'trustLow', 'int', 25, 'Below this trust, cooldowns are tripled', { min = 0, max = 100 })
add('trust', 'trustBan', 'int', 5, 'At or below this trust, reporting is blocked', { min = 0, max = 100 })
add('trust', 'trustBanHours', 'int', 24, 'How long the block lasts (hours)', { min = 0, max = 720, help = '0 turns the automatic block off.' })
add('trust', 'halfLife', 'int', 30, 'Strike points halve every (days)', { min = 1, max = 365, help = 'Old strikes matter less over time.' })
add('trust', 'ladder', 'objects', {
    { risk = 0, step = 'Verbal warning' }, { risk = 10, step = 'Formal warning' }, { risk = 25, step = 'Kick and warning' },
    { risk = 45, step = '1 day ban' }, { risk = 70, step = '7 day ban' }, { risk = 100, step = 'Permanent ban review' },
}, 'Punishment ladder', { max = 12, help = 'The case shows the step that matches the accused player\'s current risk score.', sub = {
    sf('risk', 'int', 0, 'From risk score', { min = 0, max = 1000 }),
    sf('step', 'string', 'Warning', 'Suggested step', { max = 60 }),
} })

-- ---------------------------------------------------------------- Verdicts
add('verdicts', 'verdicts', 'objects', {
    { id = 'warn', label = 'Warning', color = '#eab308', action = 'warn', points = 8, reporter = 'valid', duration = 0, noteRequired = false, message = 'Thanks. Staff checked your report and warned the player.' },
    { id = 'kick', label = 'Kick', color = '#f97316', action = 'kick', points = 12, reporter = 'valid', duration = 0, noteRequired = false, message = 'Thanks. The player was removed from the server.' },
    { id = 'jail', label = 'Jail 30 min', color = '#fb923c', action = 'jail', points = 18, reporter = 'valid', duration = 30, noteRequired = false, message = 'Thanks. The player was punished.' },
    { id = 'ban1', label = 'Ban 24 hours', color = '#ef4444', action = 'ban', points = 30, reporter = 'valid', duration = 1440, noteRequired = true, message = 'Thanks. The player was banned.' },
    { id = 'ban7', label = 'Ban 7 days', color = '#dc2626', action = 'ban', points = 55, reporter = 'valid', duration = 10080, noteRequired = true, message = 'Thanks. The player was banned.' },
    { id = 'banperm', label = 'Permanent ban', color = '#991b1b', action = 'ban', points = 100, reporter = 'valid', duration = 0, noteRequired = true, message = 'Thanks. The player was banned.' },
    { id = 'verbal', label = 'No action (talked to them)', color = '#22c55e', action = 'none', points = 0, reporter = 'valid', duration = 0, noteRequired = false, message = 'Thanks. Staff handled this with the player.' },
    { id = 'insufficient', label = 'Not enough evidence', color = '#94a3b8', action = 'none', points = 0, reporter = 'neutral', duration = 0, noteRequired = false, message = 'We looked into it but could not confirm what happened.' },
    { id = 'false', label = 'False report', color = '#a1a1aa', action = 'none', points = 0, reporter = 'false', duration = 0, noteRequired = true, message = 'We checked and this report was not accurate.' },
    { id = 'duplicate', label = 'Duplicate / dismissed', color = '#64748b', action = 'none', points = 0, reporter = 'neutral', duration = 0, noteRequired = false, message = 'This was dismissed.' },
}, 'Verdicts', { max = 30, help = 'What staff can decide. Action runs through the commands on the Integrations page.', sub = {
    sf('id', 'string', 'new', 'Id (no spaces)', { max = 30 }),
    sf('label', 'string', 'New verdict', 'Name', { max = 40 }),
    sf('color', 'color', '#94a3b8', 'Colour'),
    sf('action', 'select', 'none', 'Action', { opts = { 'none', 'warn', 'kick', 'jail', 'ban' } }),
    sf('points', 'int', 0, 'Strike points', { min = 0, max = 500 }),
    sf('reporter', 'select', 'valid', 'Counts for the reporter as', { opts = { 'valid', 'neutral', 'false' } }),
    sf('duration', 'int', 0, 'Length in minutes (0 = permanent)', { min = 0, max = 5256000 }),
    sf('noteRequired', 'bool', false, 'Staff must write a note'),
    sf('message', 'string', '', 'Message to the reporter', { max = 200 }),
} })

-- ------------------------------------------------------------------ Macros
add('macros', 'macros', 'objects', {
    { label = 'Looking into it', text = 'Hi! I am looking into your report now. Please stay available.' },
    { label = 'Need more info', text = 'Can you tell me more about what happened? Anything you remember helps.' },
    { label = 'Send proof', text = 'Do you have a clip or screenshot of this? Paste a link in your next message.' },
    { label = 'Meet me', text = 'I will come to your location. Please do not move.' },
    { label = 'Resolved', text = 'This has been dealt with. Thank you for reporting.' },
    { label = 'Rules reminder', text = 'Please read the server rules again. If you need help, ask in the support channel.' },
}, 'Quick replies', { max = 30, sub = {
    sf('label', 'string', 'New reply', 'Button name', { max = 24 }),
    sf('text', 'string', '', 'Message', { max = 300 }),
} })

-- --------------------------------------------------------------------- SLA
add('sla', 'slaWarnMins', 'int', 3, 'Case turns amber after (minutes unclaimed)', { min = 1, max = 120 })
add('sla', 'slaClaimMins', 'int', 6, 'Escalate when nobody claims within (minutes)', { min = 1, max = 240, help = 'The case is marked escalated, gains priority and the Discord role is pinged.' })
add('sla', 'slaEscalatePoints', 'int', 12, 'Priority added when escalated', { min = 0, max = 60 })
add('sla', 'slaStaleMins', 'int', 15, 'Give a claimed case back after no activity for (minutes)', { min = 0, max = 240, help = '0 turns it off. Stops a case sitting with someone who left.' })
add('sla', 'autoCloseHours', 'int', 48, 'Close a case that waits on the reporter after (hours)', { min = 0, max = 720, help = '0 turns it off.' })
add('sla', 'autoCloseVerdict', 'string', 'insufficient', 'Verdict used for auto close', { max = 30 })
add('sla', 'alertBand', 'select', 'all', 'Alert on-duty staff for', { opts = { 'all', 'p1p2', 'p1', 'none' } })
add('sla', 'alertSound', 'bool', true, 'Play a sound for the alert')
add('sla', 'etaSamples', 'int', 20, 'Cases used to estimate the wait', { min = 5, max = 100 })
add('sla', 'etaDefault', 'int', 8, 'Wait shown before there is data (minutes)', { min = 1, max = 120 })

-- ------------------------------------------------------------ Instant fixes
add('fixes', 'fixesOn', 'bool', true, 'Players can fix common problems themselves')
add('fixes', 'fixes', 'objects', {
    { id = 'unstuck', label = 'Get me unstuck', kind = 'unstuck', cooldown = 180, combatLock = 30, enabled = true },
    { id = 'fixveh', label = 'Repair my vehicle', kind = 'fixveh', cooldown = 300, combatLock = 30, enabled = true },
    { id = 'clean', label = 'Clean my vehicle', kind = 'clean', cooldown = 60, combatLock = 0, enabled = true },
}, 'Instant fixes', { max = 10, help = 'Combat lock stops a fix for this many seconds after the player took damage.', sub = {
    sf('id', 'string', 'new', 'Id (no spaces)', { max = 30 }),
    sf('label', 'string', 'New fix', 'Name', { max = 40 }),
    sf('kind', 'select', 'unstuck', 'What it does', { opts = { 'unstuck', 'fixveh', 'clean' } }),
    sf('cooldown', 'int', 120, 'Cooldown (seconds)', { min = 0, max = 86400 }),
    sf('combatLock', 'int', 30, 'Combat lock (seconds)', { min = 0, max = 600 }),
    sf('enabled', 'bool', true, 'Enabled'),
} })

-- -------------------------------------------------------------- Staff tools
add('tools', 'toolGoto', 'bool', true, 'Go to scene / go to player')
add('tools', 'toolBring', 'bool', true, 'Bring player')
add('tools', 'toolSpectate', 'bool', true, 'Spectate')
add('tools', 'toolTrack', 'bool', true, 'Live tracking of the claimed case', { help = 'Map blips and name tags for the reporter and the accused, shown only to the staff member who claimed it.' })
add('tools', 'trackTags', 'bool', true, 'Name tags over tracked players')
add('tools', 'returnOnClose', 'bool', true, 'Take staff back to where they were when a case closes')

-- ------------------------------------------------------------- Integrations
add('integrations', 'warnCommand', 'string', '', 'Warn command', { max = 160, help = 'Server command. Placeholders: {id} {reason} {minutes}. Empty = built-in message only.' })
add('integrations', 'kickCommand', 'string', '', 'Kick command', { max = 160, help = 'Empty = built-in kick.' })
add('integrations', 'jailCommand', 'string', '', 'Jail command', { max = 160, help = 'Example: jail {id} {minutes}' })
add('integrations', 'banCommand', 'string', '', 'Ban command', { max = 160, help = 'Example: ban {id} {minutes} {reason}. Placeholders: {id} {minutes} {hours} {days} {reason}.' })
add('integrations', 'autoReports', 'bool', true, 'Other scripts can file reports (exports)', { help = 'exports.blackbox_reports:AutoReport(...) for anti-cheat resources.' })
add('integrations', 'digestHour', 'int', -1, 'Daily Discord summary at hour (0-23, -1 = off)', { min = -1, max = 23 })

-- --------------------------------------------------------------- Moderation
add('moderation', 'blockedWords', 'list', {}, 'Blocked words', { help = 'Checked in what players type.' })
add('moderation', 'blockMode', 'select', 'censor', 'When a blocked word is used', { opts = { 'censor', 'stop' } })
add('moderation', 'imageSites', 'list', { 'cdn.discordapp.com', 'media.discordapp.net', 'i.imgur.com', 'imgur.com', 'streamable.com', 'youtu.be', 'www.youtube.com', 'medal.tv', 'r2.fivemanage.com', 'files.fivemanage.com' }, 'Proof link sites', { help = 'Players can only paste https links from these sites.' })

-- ------------------------------------------------------------------ Logs
add('logs', 'logWebhook', 'secret', '', 'Discord webhook URL', { max = 300, help = 'Never leaves the server.' })
add('logs', 'logToWebhook', 'bool', false, 'Send to Discord')
add('logs', 'pingRole', 'string', '', 'Discord role ID to ping on escalation', { max = 30 })
add('logs', 'logNew', 'bool', true, 'New reports')
add('logs', 'logClaim', 'bool', false, 'Claims and hand-offs')
add('logs', 'logVerdict', 'bool', true, 'Verdicts')
add('logs', 'logEscalate', 'bool', true, 'Escalations')
add('logs', 'logRatings', 'bool', false, 'Ratings')
add('logs', 'logStaff', 'bool', true, 'Staff tools (teleport, spectate, bring)')
add('logs', 'logAdminChanges', 'bool', true, 'Admin panel changes (old and new value)')

-- ====================================================================== helpers

local function deepcopy(v)
    if type(v) ~= 'table' then return v end
    local out = {}
    for k, x in pairs(v) do out[k] = deepcopy(x) end
    return out
end
Schema.deepcopy = deepcopy

function Schema.defaults()
    local out = {}
    for _, f in ipairs(Schema.fields) do out[f.k] = deepcopy(f.d) end
    return out
end

-- returns ok, cleanedValue
function Schema.validate(f, v)
    local t = f.t
    if t == 'bool' then
        if type(v) ~= 'boolean' then return false end
        return true, v
    elseif t == 'int' or t == 'float' then
        v = tonumber(v)
        if not v or v ~= v or v == math.huge or v == -math.huge then return false end
        if t == 'int' then v = math.floor(v + 0.5) end
        if (f.min and v < f.min) or (f.max and v > f.max) then return false end
        return true, v
    elseif t == 'string' or t == 'secret' then
        if type(v) ~= 'string' then return false end
        v = v:gsub('[%c]', ''):sub(1, f.max or 200)
        return true, v
    elseif t == 'color' then
        if type(v) ~= 'string' then return false end
        if not v:match('^#%x%x%x%x%x%x$') then return false end
        return true, v:lower()
    elseif t == 'select' then
        for _, o in ipairs(f.opts or {}) do if o == v then return true, v end end
        return false
    elseif t == 'list' then
        if type(v) ~= 'table' or #v > 200 then return false end
        local out = {}
        for _, s in ipairs(v) do
            if type(s) ~= 'string' then return false end
            s = s:gsub('[%c]', ''):sub(1, 120)
            if s ~= '' then out[#out + 1] = s end
        end
        return true, out
    elseif t == 'objects' then
        if type(v) ~= 'table' or #v > (f.max or 100) then return false end
        local out = {}
        for _, rec in ipairs(v) do
            if type(rec) ~= 'table' then return false end
            local clean = {}
            for _, s in ipairs(f.sub) do
                local val = rec[s.k]
                if val == nil then val = deepcopy(s.d) end
                local ok, c = Schema.validate(s, val)
                if not ok then return false end
                clean[s.k] = c
            end
            out[#out + 1] = clean
        end
        return true, out
    end
    return false
end
