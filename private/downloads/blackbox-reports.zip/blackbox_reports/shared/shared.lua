Locales = Locales or {}

function L(key, ...)
    local pack = Locales[Config.Locale] or Locales.en or {}
    local s = pack[key] or (Locales.en and Locales.en[key]) or key
    if select('#', ...) > 0 then
        local ok, r = pcall(string.format, s, ...)
        if ok then return r end
    end
    return s
end

Statuses = { 'open', 'claimed', 'waiting', 'resolved', 'dismissed' }

function hexToRgb(hex)
    if type(hex) ~= 'string' then return 255, 122, 26 end
    local r, g, b = hex:match('^#(%x%x)(%x%x)(%x%x)$')
    if not r then return 255, 122, 26 end
    return tonumber(r, 16), tonumber(g, 16), tonumber(b, 16)
end
