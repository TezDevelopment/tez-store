fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'blackbox_reports'
author 'Tez Development'
description 'Report system with a flight recorder: every report captures the last minute from the server, staff replay it on a map. Smart triage, trust scores, witnesses, strikes, SLA timers, live tracking and an in-game admin panel.'
version '1.0.0'

dependencies { 'oxmysql' }

shared_scripts {
    'config.lua',
    'locales/*.lua',
    'shared/shared.lua',
    'shared/schema.lua',
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'bridge/hooks.lua',
    'server/util.lua',
    'bridge/server.lua',
    'server/db.lua',
    'server/settings.lua',
    'server/recorder.lua',
    'server/triage.lua',
    'server/cases.lua',
    'server/staff.lua',
    'server/admin.lua',
    'server/main.lua',
}

client_scripts {
    'bridge/client.lua',
    'client/main.lua',
    'client/recorder.lua',
    'client/staff.lua',
    'client/ghost.lua',
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/core.js',
    'html/overlays.js',
    'html/shell.js',
    'html/player.js',
    'html/desk.js',
    'html/replay.js',
    'html/insight.js',
    'html/admin.js',
}

provide 'blackbox_api'
