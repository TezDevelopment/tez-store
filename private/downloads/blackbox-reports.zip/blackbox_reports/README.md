# Blackbox Reports

A report system for FiveM where every report comes with a **server-side flight recorder**.
When a player files a report, the server saves the last minute of movement, health, speed and vehicles for the reporter, the accused and everyone nearby. Staff replay it on a map instead of arguing about who said what.

Works with QBCore, QBox, ESX and standalone. Needs `oxmysql`. Tables are created automatically.

## What is in it

- **Flight recorder replay.** Scrub, play at 0.5x to 4x, follow either player, see closest approach, jumps and on-foot speed hints, plus shots, hits, deaths and vehicle events from the reporter's game. The recorder runs on the server, so players cannot edit it.
- **Combat-log detection.** Players who left just before a report are still pickable and their trail is kept.
- **Smart triage.** Priority comes from category weight, reporter trust, how many people reported the same player, the accused's risk, the urgent button, combat evidence, watchlist, keywords, waiting time and SLA escalation. Staff see the reasons as bars.
- **Trust and risk.** Reporters earn or lose trust. Accused players collect strike points that decay over time and map to a punishment ladder.
- **Witness program.** Nearby players are asked for a statement and paid for it.
- **Hold-to-panic key.** Sends an urgent report and targets whoever last killed you.
- **Right to reply.** The accused gets a separate chat channel. Reporter, accused and staff chats stay separate.
- **Verdicts** run your own warn, kick, jail and ban commands.
- **SLA timers.** Unclaimed cases escalate with a Discord ping, stale claims go back to the queue, cases waiting on a reporter auto-close.
- **Staff tools.** Go to scene, reporter or accused, bring, send back, spectate, live blips.
- **Insights.** Reports per day, busiest hours against claim time, heat map of where reports happen, repeat offenders, per-staff stats and a daily Discord digest.
- **Instant fixes.** Unstuck, repair and clean vehicle, with a combat lock.
- **Live admin panel** with every setting, validation, change history and no restart.

## Install

1. Put `blackbox_reports` in your resources folder.
2. Make sure `oxmysql` starts first, then add to `server.cfg`:

```
ensure oxmysql
ensure blackbox_reports
```

3. Give yourself access (pick one):

```
add_ace group.admin blackbox.admin allow
add_ace group.moderator blackbox.staff allow
```

Framework groups and Discord roles also work. Set them on the Access page of the admin panel.

4. In game, run `/bbadmin`. Open **Integrations** and set your ban and jail commands. Placeholders are `{id}`, `{minutes}`, `{hours}`, `{days}` and `{reason}`. For example `ban {id} {minutes} {reason}`. If no ban command is set, a ban verdict only kicks and the Status page warns you.

## Commands and keys

| What | Default |
| --- | --- |
| Report window | `/report` |
| Staff desk | `/reports` |
| Duty toggle | `/bbduty` |
| Admin panel | `/bbadmin` |
| Hold to panic (urgent report) | bind in Settings > Key Bindings > FiveM |
| Answer a prompt | `Y` |

Key bindings are empty by default so they do not clash. Players choose their own.

## For developers

```lua
-- from an anti-cheat: file a report on a player
exports.blackbox_reports:AutoReport(src, 'cheating', 'Noclip detected', {})

exports.blackbox_reports:GetTrust(src)
exports.blackbox_reports:GetRisk(src)
exports.blackbox_reports:IsOnDuty(src)
```

`bridge/hooks.lua` has `onReport`, `onClaim`, `onClose`, `onPunish`, `canReport` and `notify` so you can plug in your own logging or punishments.

## Optional: a real map behind the replay

Drop a top-down image named `map.jpg` into `html/`. On the **Flight Recorder** page turn on the map image and enter its world bounds (min and max X and Y). Without it the replay uses a clean grid.

## Notes

- Players are tracked by **license**, so trust, risk and the watchlist follow the person, not the character.
- Players never receive other players' identifiers. The UI only gets short public ids.
- Secrets (webhooks, bot token) are never sent to any client.
- The recorder samples every few seconds. Raise the interval or lower the length on the Flight Recorder page if you run a very large server.

Command names can be changed on the General page of the admin panel.

## In-game ghost replay

Staff can watch a report replayed inside the real game world. Open a case, go to **Replay** and press **Watch in game**.

- Players and their cars appear as see-through ghosts and move along the recorded paths with the real car models, headings, speeds and tilt.
- The camera starts a few seconds before the first hit or death. Use the keys below to look from any angle.
- When a player dies the server saves a clip right away (plus a few seconds after). A report filed minutes later still shows the hit.
- Nothing is networked. Ghosts exist only on the staff member's screen and are removed when they leave.

| Key | Action |
| --- | --- |
| SPACE | Play / pause |
| LEFT / RIGHT | Scrub (hold) |
| UP / DOWN | Slower / faster |
| 1 / 2 | Follow the accused / the reporter (mouse to orbit, wheel to zoom) |
| 3 | Free camera (W A S D, E up, Q down, SHIFT fast) |
| 4 | Top view |
| F | Jump to the impact |
| R | Restart |
| BACKSPACE | Leave |

Settings are in the admin panel under **Recorder**: ghost replay on/off, length (default 45 s), sample rate (default 500 ms), most players per replay, seconds kept after a death and how long death clips are kept. Cases filed before this feature, or with the recorder off, have no in-game replay. The map replay still works for them.
