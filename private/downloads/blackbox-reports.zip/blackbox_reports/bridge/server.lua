-- Framework bridge (server). Edit this file to connect your own framework.

Bridge = { framework = 'standalone', ready = false }

local ESX, QBCore, Qbox

local function started(name) return GetResourceState(name) == 'started' end

function Bridge.init()
    local fw = BB.get('framework')
    if fw == 'auto' then
        for _ = 1, 40 do
            if started('es_extended') then fw = 'esx' break end
            if started('qbx_core') then fw = 'qbox' break end
            if started('qb-core') then fw = 'qb' break end
            Wait(500)
        end
        if fw == 'auto' then fw = 'standalone' end
    end
    Bridge.framework = fw
    if fw == 'esx' then
        ESX = exports['es_extended']:getSharedObject()
        Config.Accounts.cash = 'money'
    elseif fw == 'qb' then
        QBCore = exports['qb-core']:GetCoreObject()
        Config.Accounts.cash = 'cash'
    elseif fw == 'qbox' then
        Qbox = exports.qbx_core
        Config.Accounts.cash = 'cash'
    end
    Bridge.ready = true
end

function Bridge.hasMoney() return Bridge.framework ~= 'standalone' end

function Bridge.player(src)
    if Bridge.framework == 'esx' then return ESX.GetPlayerFromId(src) end
    if Bridge.framework == 'qb' then return QBCore.Functions.GetPlayer(src) end
    if Bridge.framework == 'qbox' then return Qbox:GetPlayer(src) end
    return GetPlayerName(src) and { standalone = true } or nil
end

function Bridge.identifier(src)
    local p = Bridge.player(src)
    if not p then return nil end
    if Bridge.framework == 'esx' then return p.identifier end
    if Bridge.framework == 'qb' or Bridge.framework == 'qbox' then return p.PlayerData.citizenid end
    return GetPlayerIdentifierByType(src, 'license')
end

-- the account-level id that stays the same across characters (used for bans and trust)
function Bridge.license(src)
    return GetPlayerIdentifierByType(src, 'license') or Bridge.identifier(src)
end

function Bridge.name(src)
    local p = Bridge.player(src)
    if not p then return GetPlayerName(src) or ('Player ' .. tostring(src)) end
    if Bridge.framework == 'esx' then
        local ok, n = pcall(function() return p.getName() end)
        if ok and n and n ~= '' then return n end
    elseif Bridge.framework == 'qb' or Bridge.framework == 'qbox' then
        local ci = p.PlayerData.charinfo
        if ci then return (ci.firstname or '') .. ' ' .. (ci.lastname or '') end
    end
    return GetPlayerName(src) or ('Player ' .. tostring(src))
end

function Bridge.inGroup(src, groups)
    if not groups or #groups == 0 then return false end
    if Bridge.framework == 'esx' then
        local p = Bridge.player(src)
        local g = p and p.getGroup and p.getGroup()
        for _, name in ipairs(groups) do if g == name then return true end end
    elseif Bridge.framework == 'qb' then
        for _, name in ipairs(groups) do
            if QBCore.Functions.HasPermission(src, name) then return true end
        end
    end
    for _, name in ipairs(groups) do
        if IsPlayerAceAllowed(src, 'group.' .. name) then return true end
    end
    return false
end

function Bridge.addMoney(src, acct, amount)
    local p = Bridge.player(src)
    if not p or amount <= 0 then return false end
    local a = acct == 'cash' and Config.Accounts.cash or Config.Accounts.bank
    if Bridge.framework == 'esx' then
        if a == 'money' then p.addMoney(amount) else p.addAccountMoney(a, amount) end
        return true
    elseif Bridge.framework == 'qb' then
        return QBCore.Functions.GetPlayer(src).Functions.AddMoney(a, amount, 'report-witness') and true or false
    elseif Bridge.framework == 'qbox' then
        return Qbox:AddMoney(src, a, amount, 'report-witness') and true or false
    end
    return false
end

-- Runs a server command made from a template. Every value is cleaned so nobody can chain commands.
function Bridge.runTemplate(template, vars)
    if type(template) ~= 'string' or template == '' then return false end
    local cmd = template:gsub('{(%w+)}', function(k)
        local v = tostring(vars[k] or '')
        v = v:gsub('[;\r\n"\\`$]', ' '):gsub('%s+', ' '):gsub('^%s+', ''):gsub('%s+$', '')
        return v
    end)
    ExecuteCommand(cmd)
    return true
end
