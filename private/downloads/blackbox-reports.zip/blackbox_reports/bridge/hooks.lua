-- Open hooks. Put your own code here: it runs after the matching thing happened.
-- Every function can be left empty.

Hooks = {}

-- case = { id, category, priority, reporter, target, ... } (see server/cases.lua)
function Hooks.onReport(case) end
function Hooks.onClaim(case, staffSource) end
function Hooks.onClose(case, verdict, staffSource) end

-- Runs when a verdict has an action. Return true if you handled it yourself (the built-in commands are then skipped).
-- action = 'warn' | 'kick' | 'jail' | 'ban', targetSource may be nil if the player left
function Hooks.onPunish(action, targetSource, targetIdentifier, minutes, reason, case) return false end

-- Return false to block a player from filing (for example while in a minigame)
function Hooks.canReport(player) return true end

-- Your own notification system. Return true if you showed it, false to use the built-in one.
function Hooks.notify(player, message, kind) return false end
