-- Framework bridge (client). Edit this file to connect your own framework.

Bridge = { framework = 'standalone' }

local function started(name) return GetResourceState(name) == 'started' end

local function detect()
    if started('es_extended') then return 'esx' end
    if started('qbx_core') then return 'qbox' end
    if started('qb-core') then return 'qb' end
    return 'standalone'
end

-- Waits until the player's character is loaded
function Bridge.waitLoaded()
    while not NetworkIsSessionStarted() do Wait(250) end
    for _ = 1, 20 do
        Bridge.framework = detect()
        if Bridge.framework ~= 'standalone' then break end
        Wait(500)
    end
    if Bridge.framework == 'esx' then
        local ESX = exports['es_extended']:getSharedObject()
        while not ESX.IsPlayerLoaded() do Wait(500) end
    elseif Bridge.framework == 'qb' or Bridge.framework == 'qbox' then
        while not LocalPlayer.state.isLoggedIn do Wait(500) end
    end
end

function Bridge.isDead()
    local ped = PlayerPedId()
    if IsEntityDead(ped) or IsPedFatallyInjured(ped) then return true end
    local st = LocalPlayer.state
    return (st.dead or st.isDead or st.is_dead or st.isLastStand or st.inLastStand) and true or false
end
