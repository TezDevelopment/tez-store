-- The reporter's own flight recorder: shots, hits, damage, deaths and vehicles.
-- The server records positions on its own; this adds what only the player's game can see.

Rec = { events = {} }

local weaponNames = {}
for _, n in ipairs({
    'weapon_unarmed', 'weapon_knife', 'weapon_nightstick', 'weapon_hammer', 'weapon_bat', 'weapon_crowbar', 'weapon_golfclub', 'weapon_bottle',
    'weapon_dagger', 'weapon_hatchet', 'weapon_machete', 'weapon_pistol', 'weapon_combatpistol', 'weapon_appistol', 'weapon_pistol50', 'weapon_snspistol',
    'weapon_heavypistol', 'weapon_vintagepistol', 'weapon_revolver', 'weapon_microsmg', 'weapon_smg', 'weapon_assaultsmg', 'weapon_combatpdw',
    'weapon_assaultrifle', 'weapon_carbinerifle', 'weapon_advancedrifle', 'weapon_specialcarbine', 'weapon_bullpuprifle', 'weapon_compactrifle', 'weapon_mg',
    'weapon_combatmg', 'weapon_pumpshotgun', 'weapon_sawnoffshotgun', 'weapon_assaultshotgun', 'weapon_bullpupshotgun', 'weapon_heavyshotgun',
    'weapon_sniperrifle', 'weapon_heavysniper', 'weapon_marksmanrifle', 'weapon_grenade', 'weapon_molotov', 'weapon_stickybomb', 'weapon_rpg',
    'weapon_stungun', 'weapon_flaregun', 'weapon_fireextinguisher', 'weapon_petrolcan', 'weapon_run_over_by_car', 'weapon_rammed_by_car',
}) do weaponNames[joaat(n)] = n:gsub('^weapon_', ''):gsub('_', ' ') end

local function weaponLabel(hash)
    return weaponNames[hash] or 'weapon'
end

local function add(kind, other, weapon)
    if C.settings.clientEvents == false then return end
    local ped = PlayerPedId()
    local c = GetEntityCoords(ped)
    local list = Rec.events
    list[#list + 1] = { at = GetGameTimer(), k = kind, o = other, w = weapon or '', x = c.x, y = c.y, z = c.z }
    if #list > 150 then table.remove(list, 1) end
end

-- the list the server gets with a report (times are "seconds ago")
function Rec.collect()
    local now = GetGameTimer()
    local span = (C.settings.recSeconds or 60) * 1000
    local out = {}
    for _, e in ipairs(Rec.events) do
        local ago = now - e.at
        if ago <= span then out[#out + 1] = { k = e.k, t = ago / 1000.0, o = e.o, w = e.w, x = e.x, y = e.y, z = e.z } end
    end
    return out
end

local function serverIdOfPed(ped)
    if ped and ped ~= 0 and IsEntityAPed(ped) and IsPedAPlayer(ped) then
        local idx = NetworkGetPlayerIndexFromPed(ped)
        if idx and idx ~= -1 then return GetPlayerServerId(idx) end
    end
    return nil
end

-- damage between players
AddEventHandler('gameEventTriggered', function(name, args)
    if name ~= 'CEventNetworkEntityDamage' or not C.ready then return end
    local victim, attacker = args[1], args[2]
    local me = PlayerPedId()
    if victim == me then
        C.lastHurt = GetGameTimer()
        if C.settings.recDamage == false then return end
        local from = attacker
        if attacker and attacker ~= 0 and IsEntityAVehicle(attacker) then from = GetPedInVehicleSeat(attacker, -1) end
        local sid = serverIdOfPed(from)
        add('hurt', sid, from and from ~= 0 and IsEntityAPed(from) and weaponLabel(GetSelectedPedWeapon(from)) or (IsEntityAVehicle(attacker) and 'vehicle' or ''))
    elseif attacker == me and C.settings.recDamage ~= false then
        local sid = serverIdOfPed(victim)
        if sid then add('hit', sid, weaponLabel(GetSelectedPedWeapon(me))) end
    end
end)

-- shots, deaths and vehicles are polled a few times a second
CreateThread(function()
    while not C.ready do Wait(500) end
    local lastShot, wasDead, lastVeh = 0, false, 0
    while true do
        Wait(120)
        local ped = PlayerPedId()
        if C.settings.recShots ~= false and IsPedShooting(ped) and GetGameTimer() - lastShot > 350 then
            lastShot = GetGameTimer()
            add('shot', nil, weaponLabel(GetSelectedPedWeapon(ped)))
        end
        if C.settings.recVehicle ~= false then
            local veh = GetVehiclePedIsIn(ped, false)
            if veh ~= lastVeh then
                if veh ~= 0 then add('veh', nil, GetLabelText(GetDisplayNameFromVehicleModel(GetEntityModel(veh))):sub(1, 22)) else add('veh', nil, 'on foot') end
                lastVeh = veh
            end
        end
        local dead = IsEntityDead(ped)
        if dead and not wasDead then
            wasDead = true
            local src = GetPedSourceOfDeath(ped)
            if src and src ~= 0 and IsEntityAVehicle(src) then src = GetPedInVehicleSeat(src, -1) end
            local killer = serverIdOfPed(src)
            local w = weaponLabel(GetPedCauseOfDeath(ped))
            local c = GetEntityCoords(ped)
            add('dead', killer, w)
            TriggerServerEvent('bb:died', killer, w, c.x, c.y, c.z)
            -- ask who it was (after the server has heard about the death)
            CreateThread(function()
                Wait(1500)
                local r = C.req('form')
                if r.ok and r.payload and r.payload.killer then C.offerKiller(r.payload.killer) end
            end)
        elseif not dead and wasDead then
            wasDead = false
        end
    end
end)
