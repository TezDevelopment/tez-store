-- Staff tools on the client: teleports with a way back, spectate, live tracking blips and name tags

local returnPos
local spectating

local function fade(fn)
    DoScreenFadeOut(200)
    Wait(250)
    fn()
    Wait(250)
    DoScreenFadeIn(250)
end

local function saveReturn()
    if returnPos then return end
    local ped = PlayerPedId()
    local c = GetEntityCoords(ped)
    returnPos = { x = c.x, y = c.y, z = c.z, h = GetEntityHeading(ped) }
end

local function groundAt(x, y, z)
    for h = z + 30.0, z - 30.0, -5.0 do
        local ok, gz = GetGroundZFor_3dCoord(x, y, h, false)
        if ok then return gz end
    end
    return nil
end

local function teleport(x, y, z)
    local ped = PlayerPedId()
    local ent = ped
    local veh = GetVehiclePedIsIn(ped, false)
    if veh ~= 0 and GetPedInVehicleSeat(veh, -1) == ped then ent = veh end
    fade(function()
        RequestCollisionAtCoord(x, y, z)
        SetEntityCoords(ent, x + 0.0, y + 0.0, z + 0.5, false, false, false, false)
        local t = GetGameTimer() + 1500
        while not HasCollisionLoadedAroundEntity(ent) and GetGameTimer() < t do Wait(50) end
        local gz = groundAt(x, y, z)
        if gz and math.abs(gz - z) < 20.0 then SetEntityCoords(ent, x + 0.0, y + 0.0, gz + 0.3, false, false, false, false) end
    end)
end

local function stopSpectate()
    if not spectating then return end
    spectating = nil
    NetworkSetInSpectatorMode(false, PlayerPedId())
    SetEntityVisible(PlayerPedId(), true, false)
    FreezeEntityPosition(PlayerPedId(), false)
end

RegisterNetEvent('bb:saveReturn', saveReturn)

RegisterNetEvent('bb:staffTeleport', function(d)
    saveReturn()
    teleport(d.x, d.y, d.z)
end)

RegisterNetEvent('bb:bringed', function(d)
    saveReturn()
    teleport(d.x, d.y, d.z)
    C.toast(L('note.brought', d.by or ''), 'info')
end)

RegisterNetEvent('bb:staffReturn', function()
    stopSpectate()
    if returnPos then
        local r = returnPos
        returnPos = nil
        teleport(r.x, r.y, r.z)
        SetEntityHeading(PlayerPedId(), r.h or 0.0)
        C.toast(L('note.returned'), 'info')
    end
end)

RegisterNetEvent('bb:spectate', function(d)
    saveReturn()
    stopSpectate()
    local ped = PlayerPedId()
    fade(function()
        SetEntityCoords(ped, d.x + 0.0, d.y + 0.0, d.z + 12.0, false, false, false, false)
        FreezeEntityPosition(ped, true)
        SetEntityVisible(ped, false, false)
    end)
    local pl = GetPlayerFromServerId(d.target)
    local t = GetGameTimer() + 5000
    while (pl == -1 or not DoesEntityExist(GetPlayerPed(pl))) and GetGameTimer() < t do Wait(100) pl = GetPlayerFromServerId(d.target) end
    if pl == -1 then
        FreezeEntityPosition(ped, false)
        SetEntityVisible(ped, true, false)
        return C.toast(L('err.nostream'), 'error')
    end
    spectating = { name = d.name }
    NetworkSetInSpectatorMode(true, GetPlayerPed(pl))
    CreateThread(function()
        while spectating do
            Wait(0)
            BeginTextCommandDisplayHelp('STRING')
            AddTextComponentSubstringPlayerName(L('note.spectating', spectating.name or ''))
            EndTextCommandDisplayHelp(0, false, false, -1)
            if IsControlJustPressed(0, 177) or IsControlJustPressed(0, 194) then
                TriggerEvent('bb:staffReturn')
            end
        end
    end)
end)

-- ---------------------------------------------------------------- tracking

local track = nil
local blips = {}

local function dropBlips()
    for k, b in pairs(blips) do if DoesBlipExist(b) then RemoveBlip(b) end blips[k] = nil end
end

local function setBlip(key, p, colour, sprite)
    if not p then
        if blips[key] and DoesBlipExist(blips[key]) then RemoveBlip(blips[key]) end
        blips[key] = nil
        return
    end
    local b = blips[key]
    if not b or not DoesBlipExist(b) then
        b = AddBlipForCoord(p.x, p.y, p.z)
        SetBlipSprite(b, sprite or 1)
        SetBlipColour(b, colour)
        SetBlipScale(b, 0.95)
        SetBlipAsShortRange(b, false)
        ShowHeadingIndicatorOnBlip(b, false)
        BeginTextCommandSetBlipName('STRING')
        AddTextComponentSubstringPlayerName(p.name or '')
        EndTextCommandSetBlipName(b)
        blips[key] = b
    else
        SetBlipCoords(b, p.x, p.y, p.z)
    end
end

RegisterNetEvent('bb:track', function(d)
    track = d
    if not d then dropBlips() return end
    setBlip('a', d.a, 3, 1)
    setBlip('b', d.b, 1, 1)
end)

local function tag(p, label, r, g, b)
    if not p then return end
    local me = GetEntityCoords(PlayerPedId())
    if #(vector3(p.x, p.y, p.z) - me) > 150.0 then return end
    local on, sx, sy = World3dToScreen2d(p.x, p.y, p.z + 1.25)
    if not on then return end
    SetTextScale(0.34, 0.34)
    SetTextFont(4)
    SetTextProportional(true)
    SetTextColour(r, g, b, 235)
    SetTextOutline()
    SetTextCentre(true)
    BeginTextCommandDisplayText('STRING')
    AddTextComponentSubstringPlayerName(label)
    EndTextCommandDisplayText(sx, sy)
end

CreateThread(function()
    while true do
        if track and C.settings.toolTrack then
            Wait(0)
            tag(track.a, ('%s #%d  reporter (case %d)'):format(track.a and track.a.name or '', track.a and track.a.id or 0, track.case), 80, 170, 255)
            tag(track.b, ('%s #%d  accused (case %d)'):format(track.b and track.b.name or '', track.b and track.b.id or 0, track.case), 255, 90, 90)
        else
            Wait(500)
        end
    end
end)

AddEventHandler('onResourceStop', function(name)
    if name ~= GetCurrentResourceName() then return end
    dropBlips()
end)
