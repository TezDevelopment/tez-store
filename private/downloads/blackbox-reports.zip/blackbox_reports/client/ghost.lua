-- The in-world ghost replay.
-- Staff watch a scene replayed in the real game: see-through players and cars move along the recorded paths while a free camera
-- (or a follow camera) lets them look from any angle. Nothing is networked: every ghost exists only on the staff member's screen.
--
-- Keys: SPACE play/pause | LEFT/RIGHT step (hold to scrub) | UP/DOWN speed | 1 follow accused | 2 follow reporter | 3 free camera
--       4 top view | F jump to the impact | R restart | BACKSPACE leave
--       Free camera: mouse look, W A S D move, E up, Q down, SHIFT fast. Follow camera: mouse orbit, mouse wheel zoom.

local S -- the running session

local ROLE = {
    reporter = { 80, 170, 255 }, victim = { 80, 170, 255 }, accused = { 255, 90, 90 }, killer = { 255, 90, 90 }, nearby = { 190, 190, 190 },
}
local SPEEDS = { 0.1, 0.25, 0.5, 1.0, 2.0 }

local FALLBACK_PED_M = joaat('mp_m_freemode_01')
local FALLBACK_PED_F = joaat('mp_f_freemode_01')
local FALLBACK_VEH = joaat('sultan')

local function clamp(v, a, b) return v < a and a or (v > b and b or v) end

local function loadModel(hash, fallback)
    if not hash or hash == 0 or not IsModelInCdimage(hash) or not IsModelValid(hash) then hash = fallback end
    RequestModel(hash)
    local t = GetGameTimer() + 4000
    while not HasModelLoaded(hash) and GetGameTimer() < t do Wait(0) end
    if not HasModelLoaded(hash) then return nil end
    return hash
end

local function loadDict(d)
    if HasAnimDictLoaded(d) then return true end
    RequestAnimDict(d)
    local t = GetGameTimer() + 1500
    while not HasAnimDictLoaded(d) and GetGameTimer() < t do Wait(0) end
    return HasAnimDictLoaded(d)
end

local function lerpAngle(a, b, k)
    local d = ((b - a + 540.0) % 360.0) - 180.0
    return a + d * k
end

-- index of the frame at or before t, starting the search from the last known index
local function seekIdx(f, t, i)
    i = clamp(i or 1, 1, #f)
    while i > 1 and f[i][1] > t do i = i - 1 end
    while i < #f and f[i + 1][1] <= t do i = i + 1 end
    return i
end

-- ---------------------------------------------------------------- drawing

local function text(x, y, s, scale, r, g, b, a, centre, font)
    SetTextFont(font or 4)
    SetTextScale(scale, scale)
    SetTextColour(r or 255, g or 255, b or 255, a or 235)
    SetTextOutline()
    SetTextCentre(centre ~= false)
    BeginTextCommandDisplayText('STRING')
    AddTextComponentSubstringPlayerName(s)
    EndTextCommandDisplayText(x, y)
end

local function text3d(x, y, z, s, scale, r, g, b)
    local on, sx, sy = World3dToScreen2d(x, y, z)
    if on then text(sx, sy, s, scale, r, g, b, 240, true) end
end

local function fmt(t)
    local a = math.abs(t)
    return ('%s%d:%04.1f'):format(t < 0 and '-' or '+', math.floor(a / 60), a % 60)
end

-- ---------------------------------------------------------------- ghosts

local function styleGhost(ent)
    SetEntityAlpha(ent, 150, false)
    SetEntityCollision(ent, false, false)
    FreezeEntityPosition(ent, true)
    SetEntityInvincible(ent, true)
    SetEntityAsMissionEntity(ent, true, true)
end

local function makePed(A, x, y, z)
    local hash = loadModel(A.pm, A.female and FALLBACK_PED_F or FALLBACK_PED_M)
    if not hash then return nil end
    local ped = CreatePed(4, hash, x, y, z, 0.0, false, false)
    if not ped or ped == 0 then return nil end
    styleGhost(ped)
    SetBlockingOfNonTemporaryEvents(ped, true)
    SetPedCanRagdoll(ped, false)
    SetEntityVisible(ped, true, false)
    return ped
end

local function makeVeh(A, model, x, y, z)
    local hash = loadModel(model, FALLBACK_VEH)
    if not hash then return nil end
    local veh = CreateVehicle(hash, x, y, z, 0.0, false, false)
    if not veh or veh == 0 then return nil end
    styleGhost(veh)
    SetVehicleDoorsLocked(veh, 2)
    SetVehicleEngineOn(veh, false, true, true)
    SetVehicleUndriveable(veh, true)
    return veh
end

local function dropEntity(e)
    if e and DoesEntityExist(e) then
        SetEntityAsMissionEntity(e, true, true)
        DeleteEntity(e)
    end
end

local function setAnim(A, name)
    if A.anim == name or not A.ped then return end
    A.anim = name
    if name == 'idle' then
        ClearPedTasksImmediately(A.ped)
    elseif name == 'dead' then
        if loadDict('dead') then TaskPlayAnim(A.ped, 'dead', 'dead_a', 8.0, 8.0, -1, 1, 0.0, false, false, false) end
    else
        local dict = A.female and 'move_f@generic' or 'move_m@generic'
        if loadDict(dict) then TaskPlayAnim(A.ped, dict, name, 8.0, 8.0, -1, 1, 0.0, false, false, false) end
    end
end

-- where an actor is at time t (nil when it is not in the scene yet or any more)
local function sample(A, t)
    local f = A.f
    if t < f[1][1] - 0.4 or t > f[#f][1] + 1.5 then return nil end
    local i = seekIdx(f, t, A.i)
    A.i = i
    local a, b = f[i], f[i + 1]
    if not b or t <= a[1] or (b[1] - a[1]) > 3.0 or a[6] ~= b[6] then return a end
    local dx, dy = b[2] - a[2], b[3] - a[3]
    if dx * dx + dy * dy > 1600.0 then return a end
    local k = (t - a[1]) / (b[1] - a[1])
    return {
        t, a[2] + dx * k, a[3] + dy * k, a[4] + (b[4] - a[4]) * k, lerpAngle(a[5], b[5], k), a[6],
        a[7] + (b[7] - a[7]) * k, a[8] + (b[8] - a[8]) * k, a[9] + (b[9] - a[9]) * k, a[10],
    }
end

local function hideActor(A)
    if A.ped and DoesEntityExist(A.ped) then SetEntityVisible(A.ped, false, false) end
    if A.veh and DoesEntityExist(A.veh) then SetEntityVisible(A.veh, A.vehParked == true and A.t >= (A.vehFirst or 1e9), false) end
end

local function updateActor(A, t)
    A.t = t
    local s = sample(A, t)
    if not s then
        hideActor(A)
        A.pos = nil
        return
    end
    local x, y, z, h, vm, pitch, roll, sp, dead = s[2], s[3], s[4], s[5], s[6], s[7], s[8], s[9], s[10]
    A.pos = vector3(x, y, z)
    A.heading = h
    if vm ~= 0 then
        if A.veh and A.vm ~= vm then dropEntity(A.veh) A.veh = nil end
        if not A.veh or not DoesEntityExist(A.veh) then
            A.veh = makeVeh(A, vm, x, y, z)
            A.vm = vm
        end
        if A.veh then
            SetEntityVisible(A.veh, true, false)
            SetEntityCoordsNoOffset(A.veh, x, y, z, false, false, false)
            SetEntityRotation(A.veh, pitch, roll, h, 2, true)
            A.vehParked = true
        end
        if not A.ped or not DoesEntityExist(A.ped) then A.ped = makePed(A, x, y, z) A.inVeh = false end
        if A.ped and A.veh then
            if not A.inVeh then
                ClearPedTasksImmediately(A.ped)
                SetPedIntoVehicle(A.ped, A.veh, -1)
                A.inVeh, A.anim = true, nil
            end
            SetEntityVisible(A.ped, true, false)
        end
    else
        -- on foot (a car they left stays parked where they left it)
        if A.veh and DoesEntityExist(A.veh) then SetEntityVisible(A.veh, A.vehParked == true and t >= (A.vehFirst or 1e9), false) end
        if not A.ped or not DoesEntityExist(A.ped) then A.ped = makePed(A, x, y, z) A.inVeh = false A.anim = nil end
        if A.ped then
            if A.inVeh then
                ClearPedTasksImmediately(A.ped)
                A.inVeh, A.anim = false, nil
            end
            SetEntityVisible(A.ped, true, false)
            SetEntityCoordsNoOffset(A.ped, x, y, z, false, false, false)
            SetEntityHeading(A.ped, h + 0.0)
            if dead == 1 then setAnim(A, 'dead')
            elseif sp < 0.6 then setAnim(A, 'idle')
            elseif sp < 3.2 then setAnim(A, 'walk')
            else setAnim(A, 'run') end
        end
    end
end

-- ---------------------------------------------------------------- camera

local function camForward(yaw, pitch)
    local cp = math.cos(math.rad(pitch))
    return vector3(-math.sin(math.rad(yaw)) * cp, math.cos(math.rad(yaw)) * cp, math.sin(math.rad(pitch)))
end

local function actorByRole(want)
    for _, A in ipairs(S.actors) do
        if A.role == want and A.pos then return A end
    end
    for _, A in ipairs(S.actors) do if A.pos then return A end end
    return nil
end

local function setMode(mode)
    S.mode = mode
    if mode == 'follow_accused' then S.follow = 'accused' elseif mode == 'follow_reporter' then S.follow = 'reporter' end
end

local function updateCamera(dt)
    local lookX = GetDisabledControlNormal(0, 1)
    local lookY = GetDisabledControlNormal(0, 2)
    S.yaw = S.yaw - lookX * 5.0
    S.pitch = clamp(S.pitch - lookY * 5.0, -85.0, 85.0)
    local mode = S.mode
    if mode == 'free' then
        local fast = IsDisabledControlPressed(0, 21) and 4.0 or 1.0
        local sp = 9.0 * fast * dt
        local fw = camForward(S.yaw, S.pitch)
        local rt = vector3(math.cos(math.rad(S.yaw)), math.sin(math.rad(S.yaw)), 0.0)
        local dx, dy, dz = 0.0, 0.0, 0.0
        if IsDisabledControlPressed(0, 32) then dx, dy, dz = dx + fw.x * sp, dy + fw.y * sp, dz + fw.z * sp end
        if IsDisabledControlPressed(0, 33) then dx, dy, dz = dx - fw.x * sp, dy - fw.y * sp, dz - fw.z * sp end
        if IsDisabledControlPressed(0, 35) then dx, dy = dx + rt.x * sp, dy + rt.y * sp end
        if IsDisabledControlPressed(0, 34) then dx, dy = dx - rt.x * sp, dy - rt.y * sp end
        if IsDisabledControlPressed(0, 38) then dz = dz + sp end
        if IsDisabledControlPressed(0, 44) then dz = dz - sp end
        S.cx, S.cy, S.cz = S.cx + dx, S.cy + dy, S.cz + dz
        SetCamCoord(S.cam, S.cx, S.cy, S.cz)
        SetCamRot(S.cam, S.pitch, 0.0, S.yaw, 2)
    elseif mode == 'top' then
        local A = actorByRole('accused')
        local B = actorByRole('reporter')
        local px, py = S.cx, S.cy
        if A and B then px, py = (A.pos.x + B.pos.x) / 2, (A.pos.y + B.pos.y) / 2 elseif A then px, py = A.pos.x, A.pos.y end
        S.cx, S.cy = S.cx + (px - S.cx) * clamp(dt * 4.0, 0.0, 1.0), S.cy + (py - S.cy) * clamp(dt * 4.0, 0.0, 1.0)
        if IsDisabledControlPressed(0, 32) or IsDisabledControlJustPressed(0, 241) then S.topH = clamp(S.topH - 60.0 * dt, 20.0, 220.0) end
        if IsDisabledControlPressed(0, 33) or IsDisabledControlJustPressed(0, 242) then S.topH = clamp(S.topH + 60.0 * dt, 20.0, 220.0) end
        local base = (A and A.pos.z or S.cz)
        S.cz = base + S.topH
        SetCamCoord(S.cam, S.cx, S.cy, S.cz)
        SetCamRot(S.cam, -89.0, 0.0, 0.0, 2)
    else
        local A = actorByRole(S.follow)
        if A then
            if IsDisabledControlJustPressed(0, 241) then S.dist = clamp(S.dist - 1.5, 3.0, 60.0) end
            if IsDisabledControlJustPressed(0, 242) then S.dist = clamp(S.dist + 1.5, 3.0, 60.0) end
            local d = camForward(S.yaw, S.pitch)
            local tx, ty, tz = A.pos.x, A.pos.y, A.pos.z + 0.6
            S.cx, S.cy, S.cz = tx - d.x * S.dist, ty - d.y * S.dist, tz - d.z * S.dist
            SetCamCoord(S.cam, S.cx, S.cy, S.cz)
            SetCamRot(S.cam, S.pitch, 0.0, S.yaw, 2)
        end
    end
end

-- ---------------------------------------------------------------- overlay

local function drawOverlay()
    -- who is who
    local y = 0.05
    text(0.02, y - 0.012, ('Case #%d  |  in-game replay'):format(S.case), 0.42, 255, 255, 255, 240, false)
    y = y + 0.032
    for _, A in ipairs(S.actors) do
        local c = ROLE[A.role] or ROLE.nearby
        DrawRect(0.0135, y + 0.011, 0.008, 0.016, c[1], c[2], c[3], 220)
        text(0.024, y, ('%s  (%s)'):format(A.name, A.role), 0.32, c[1], c[2], c[3], 240, false)
        y = y + 0.026
    end

    -- name tags and rings
    for _, A in ipairs(S.actors) do
        if A.pos then
            local c = ROLE[A.role] or ROLE.nearby
            DrawMarker(25, A.pos.x, A.pos.y, A.pos.z - 0.92, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.1, 1.1, 0.4, c[1], c[2], c[3], 150, false, false, 2, false, nil, nil, false)
            text3d(A.pos.x, A.pos.y, A.pos.z + 1.25, A.name, 0.34, c[1], c[2], c[3])
        end
    end

    -- impact markers
    for _, m in ipairs(S.g.marks or {}) do
        local dtm = S.t - m.t
        if dtm > -0.3 and dtm < 2.5 then
            local label = m.k == 'dead' and 'DEATH' or (m.k == 'shot' and 'SHOT' or 'HIT')
            local w = tostring(m.w or ''):lower()
            if w:find('run over') or w:find('rammed') or w == 'vehicle' then label = label .. ' (VEHICLE)' elseif w ~= '' then label = label .. ' (' .. w .. ')' end
            DrawMarker(28, m.x, m.y, m.z, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.4, 1.4, 1.4, 255, 70, 50, math.floor(clamp(150 - dtm * 40.0, 30, 150)), false, false, 2, false, nil, nil, false)
            text3d(m.x, m.y, m.z + 1.7, label, 0.5, 255, 120, 90)
        end
    end

    -- bar
    local x0, x1, by = 0.18, 0.82, 0.935
    local span = (S.t1 - S.t0)
    DrawRect(0.5, by, x1 - x0, 0.012, 20, 20, 24, 200)
    local p = clamp((S.t - S.t0) / span, 0.0, 1.0)
    DrawRect(x0 + (x1 - x0) * p / 2, by, (x1 - x0) * p, 0.012, 80, 150, 255, 235)
    for _, m in ipairs(S.g.marks or {}) do
        if m.t >= S.t0 and m.t <= S.t1 then
            local mx = x0 + (x1 - x0) * (m.t - S.t0) / span
            local col = m.k == 'dead' and { 255, 70, 60 } or (m.k == 'shot' and { 250, 204, 21 } or { 251, 146, 60 })
            DrawRect(mx, by, 0.0025, 0.026, col[1], col[2], col[3], 240)
        end
    end
    DrawRect(x0 + (x1 - x0) * p, by, 0.003, 0.03, 255, 255, 255, 255)
    text(0.5, by - 0.045, ('%s   %s   %.2gx   %s'):format(fmt(S.t), S.playing and 'PLAYING' or 'PAUSED', S.speed, S.mode == 'free' and 'FREE CAMERA' or (S.mode == 'top' and 'TOP VIEW' or ('FOLLOW ' .. S.follow:upper()))), 0.38, 255, 255, 255, 245)
    text(0.5, by + 0.02, 'SPACE play  |  < > scrub  |  UP/DOWN speed  |  1 accused  2 reporter  3 free  4 top  |  F impact  R restart  |  BACKSPACE leave', 0.28, 200, 205, 220, 220)
end

-- ---------------------------------------------------------------- session

local function stopSession()
    if not S then return end
    local s = S
    S = nil
    if s.cam then
        RenderScriptCams(false, false, 0, true, true)
        DestroyCam(s.cam, false)
    end
    ClearFocus()
    for _, A in ipairs(s.actors) do
        dropEntity(A.ped)
        dropEntity(A.veh)
    end
    local me = PlayerPedId()
    SetEntityInvincible(me, s.wasInvincible == true)
    SetEntityVisible(me, true, false)
    FreezeEntityPosition(me, false)
    local mv = GetVehiclePedIsIn(me, false)
    if mv ~= 0 then FreezeEntityPosition(mv, false) end
    DisplayRadar(true)
end

local function startSession(d)
    if S then stopSession() end
    local g = d and d.g
    if type(g) ~= 'table' or type(g.actors) ~= 'table' or #g.actors == 0 then return C.toast(L('err.noghost'), 'error') end
    C.closeWindow()

    local actors = {}
    local t0, t1 = 0.0, 0.0
    for _, a in ipairs(g.actors) do
        local f = a.f
        if type(f) == 'table' and #f >= 2 then
            local A = { pub = a.pub, name = tostring(a.name or '?'), role = a.role or 'nearby', pm = a.pm, f = f, i = 1 }
            A.female = a.pm == FALLBACK_PED_F
            for _, fr in ipairs(f) do
                if fr[6] ~= 0 then A.vehFirst = fr[1] break end
            end
            if f[1][1] < t0 then t0 = f[1][1] end
            if f[#f][1] > t1 then t1 = f[#f][1] end
            actors[#actors + 1] = A
        end
    end
    if #actors == 0 then return C.toast(L('err.noghost'), 'error') end

    local me = PlayerPedId()
    S = {
        case = d.case, g = g, actors = actors, t0 = t0, t1 = math.max(t1, 0.0), t = t0, playing = false, speed = 1.0, speedI = 4,
        mode = 'follow_accused', follow = 'accused', yaw = 0.0, pitch = -14.0, dist = 9.0, topH = 70.0, wasInvincible = GetPlayerInvincible(PlayerId()),
    }

    -- start a few seconds before the impact (or at the beginning when there is none)
    local start = t0
    if g.focus then start = clamp(g.focus - 10.0, t0, S.t1) end
    S.t = start
    S.focusT = g.focus

    -- the staff member's own ped stays where it is, still and out of sight; only the camera travels
    SetEntityInvincible(me, true)
    SetEntityVisible(me, false, false)
    FreezeEntityPosition(me, true)
    local mv = GetVehiclePedIsIn(me, false)
    if mv ~= 0 then FreezeEntityPosition(mv, true) end
    DisplayRadar(false)

    -- first position of the camera
    local first = actors[1]
    local fr = first.f[seekIdx(first.f, S.t, 1)]
    S.cx, S.cy, S.cz = fr[2], fr[3], fr[4] + 6.0
    S.yaw = fr[5] + 0.0
    S.cam = CreateCam('DEFAULT_SCRIPTED_CAMERA', true)
    SetCamCoord(S.cam, S.cx, S.cy, S.cz)
    SetCamRot(S.cam, S.pitch, 0.0, S.yaw, 2)
    SetCamActive(S.cam, true)
    SetFocusPosAndVel(S.cx, S.cy, S.cz, 0.0, 0.0, 0.0)
    RenderScriptCams(true, true, 700, true, true)

    -- let the map around the scene load before anything moves
    local wait = GetGameTimer() + 2500
    while GetGameTimer() < wait and S do
        Wait(0)
        DisableAllControlActions(0)
        text(0.5, 0.48, 'Loading the scene...', 0.6, 255, 255, 255, 240)
    end
    if not S then return end
    S.playing = true
    S.last = GetGameTimer()

    local focusTick = 0
    while S do
        Wait(0)
        local now = GetGameTimer()
        local dt = math.min((now - S.last) / 1000.0, 0.1)
        S.last = now
        DisableAllControlActions(0)
        HideHudAndRadarThisFrame()

        -- keys
        if IsDisabledControlJustPressed(0, 22) then S.playing = not S.playing end
        if IsDisabledControlPressed(0, 175) then S.t = clamp(S.t + 6.0 * dt, S.t0, S.t1) elseif IsDisabledControlPressed(0, 174) then S.t = clamp(S.t - 6.0 * dt, S.t0, S.t1) end
        if IsDisabledControlJustPressed(0, 172) then S.speedI = clamp(S.speedI + 1, 1, #SPEEDS) S.speed = SPEEDS[S.speedI] end
        if IsDisabledControlJustPressed(0, 173) then S.speedI = clamp(S.speedI - 1, 1, #SPEEDS) S.speed = SPEEDS[S.speedI] end
        if IsDisabledControlJustPressed(0, 157) then setMode('follow_accused') end
        if IsDisabledControlJustPressed(0, 158) then setMode('follow_reporter') end
        if IsDisabledControlJustPressed(0, 160) then setMode('free') end
        if IsDisabledControlJustPressed(0, 164) then setMode('top') end
        if IsDisabledControlJustPressed(0, 23) then if S.focusT then S.t = clamp(S.focusT - 3.0, S.t0, S.t1) S.playing = true end end -- F
        if IsDisabledControlJustPressed(0, 45) then S.t = S.t0 S.playing = true end
        if IsDisabledControlJustPressed(0, 177) or IsDisabledControlJustPressed(0, 194) then break end

        if S.playing then
            S.t = S.t + dt * S.speed
            if S.t >= S.t1 then S.t = S.t1 S.playing = false end
        end

        for _, A in ipairs(S.actors) do updateActor(A, S.t) end
        updateCamera(dt)
        focusTick = focusTick + 1
        if focusTick % 8 == 0 then SetFocusPosAndVel(S.cx, S.cy, S.cz, 0.0, 0.0, 0.0) end
        drawOverlay()
    end
    stopSession()
end

RegisterNetEvent('bb:ghost', function(d)
    C.toast(L('note.ghoststart', d and d.case or 0), 'info')
    CreateThread(function() startSession(d) end)
end)

AddEventHandler('onResourceStop', function(name)
    if name ~= GetCurrentResourceName() then return end
    stopSession()
end)
