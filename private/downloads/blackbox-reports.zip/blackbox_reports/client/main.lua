-- Client core: requests to the server, the NUI bridge, commands, key presses, prompts and instant fixes

C = {
    ready = false,
    settings = {},
    me = nil,
    open = false,
    prompt = nil,          -- { kind, ... } the small "press Y" card on screen
    lastHurt = -100000,    -- game time when the player last took damage
}

-- ------------------------------------------------------------------ requests

local pending, nextRid = {}, 0

function C.req(action, data)
    nextRid = nextRid + 1
    local rid = nextRid
    local p = promise.new()
    pending[rid] = p
    TriggerServerEvent('bb:req', rid, action, data or {})
    SetTimeout(10000, function()
        if pending[rid] then
            pending[rid] = nil
            p:resolve({ ok = false, payload = L('err.noanswer') })
        end
    end)
    return Citizen.Await(p)
end

RegisterNetEvent('bb:res', function(rid, ok, payload)
    local p = pending[rid]
    if p then
        pending[rid] = nil
        p:resolve({ ok = ok, payload = payload })
    end
end)

-- -------------------------------------------------------------------- NUI

function C.nui(a, data)
    data = data or {}
    data.a = a
    SendNUIMessage(data)
end

function C.toast(message, kind) C.nui('toast', { message = message, kind = kind or 'info' }) end
RegisterNetEvent('bb:toast', function(message, kind) C.toast(message, kind) end)

function C.focus(on)
    SetNuiFocus(on, on)
    SetNuiFocusKeepInput(false)
end

function C.streetName()
    local c = GetEntityCoords(PlayerPedId())
    local s = GetStreetNameAtCoord(c.x, c.y, c.z)
    local street = GetStreetNameFromHashKey(s)
    local zone = GetLabelText(GetNameOfZone(c.x, c.y, c.z))
    if zone == 'NULL' then zone = '' end
    if street == '' then return zone end
    return zone ~= '' and (street .. ', ' .. zone) or street
end

-- ---------------------------------------------------------------- window

function C.openWindow(page, extra)
    if not C.ready then return end
    if C.open then
        C.nui('page', { page = page, extra = extra })
        return
    end
    C.open = true
    C.focus(true)
    C.nui('open', { page = page, extra = extra, me = C.me, settings = C.settings })
end

function C.closeWindow()
    if not C.open then return end
    C.open = false
    C.focus(false)
    C.nui('close', {})
end

RegisterNUICallback('close', function(_, cb) C.closeWindow() cb({}) end)

RegisterNUICallback('req', function(d, cb)
    if type(d) ~= 'table' or type(d.action) ~= 'string' then return cb({ ok = false, payload = 'Bad request' }) end
    local data = d.data or {}
    if d.action == 'fix' then data.hurt = (GetGameTimer() - C.lastHurt) / 1000 end
    if d.action == 'file' then
        data.street = C.streetName()
        data.events = Rec and Rec.collect() or {}
    end
    cb(C.req(d.action, data))
end)

-- the witness form sends its answer straight to the server
RegisterNUICallback('witness', function(d, cb)
    cb({})
    if type(d) ~= 'table' then return end
    TriggerServerEvent('bb:witness', tonumber(d.case), d.said == true, tostring(d.text or ''))
    C.closeWindow()
end)

RegisterNUICallback('promptDone', function(_, cb) C.prompt = nil cb({}) end)

-- ---------------------------------------------------------------- events

RegisterNetEvent('bb:init', function(payload)
    C.settings, C.me = payload.settings, payload.me
    C.ready = true
    C.registerCommands()
    C.nui('init', payload)
end)

RegisterNetEvent('bb:settings', function(settings)
    C.settings = settings
    C.registerCommands()
    C.nui('settings', { settings = settings })
end)

RegisterNetEvent('bb:duty', function(on)
    if C.me then C.me.duty = on end
    C.nui('duty', { on = on })
end)

RegisterNetEvent('bb:notice', function(n)
    C.nui('notice', { n = n })
    PlaySoundFrontend(-1, 'Text_Arrive_Tone', 'Phone_SoundSet_Default', true)
end)
RegisterNetEvent('bb:mineEvent', function(d) C.nui('mineEvent', d) end)
RegisterNetEvent('bb:deskEvent', function(d) C.nui('deskEvent', d) end)
RegisterNetEvent('bb:chat', function(m) C.nui('chat', { m = m }) end)
RegisterNetEvent('bb:adminSaved', function(d) C.nui('adminSaved', d) end)

RegisterNetEvent('bb:alert', function(case, escalated)
    C.nui('alert', { case = case, escalated = escalated == true })
    if C.settings.alertSound then PlaySoundFrontend(-1, escalated and 'Beep_Red' or 'Menu_Accept', escalated and 'DLC_HEIST_HACKING_SNAKE_SOUNDS' or 'Phone_SoundSet_Default', true) end
end)

RegisterNetEvent('bb:warned', function(d)
    C.nui('warned', d)
    PlaySoundFrontend(-1, 'Beep_Red', 'DLC_HEIST_HACKING_SNAKE_SOUNDS', true)
end)

-- ---------------------------------------------------------------- prompts

-- A small card with a key hint. Y answers it.
local function showPrompt(p, secs)
    p.exp = GetGameTimer() + secs * 1000
    C.prompt = p
    C.nui('prompt', { p = p, secs = secs })
end

RegisterNetEvent('bb:witnessAsk', function(d)
    showPrompt({ kind = 'witness', case = d.case, label = d.label, chars = d.chars, reward = d.reward, accused = d.accused }, d.secs)
end)

RegisterNetEvent('bb:rate', function(d)
    if C.settings.ratings == false then return end
    showPrompt({ kind = 'rate', case = d.case }, 40)
end)

function C.offerKiller(killer)
    if not C.settings.killerPrompt then return end
    showPrompt({ kind = 'death', pub = killer.pub, name = killer.name, weapon = killer.weapon }, C.settings.killerPromptSecs or 25)
end

local function answerPrompt()
    local p = C.prompt
    if not p or p.exp < GetGameTimer() then C.prompt = nil return end
    C.prompt = nil
    C.nui('promptClear', {})
    if p.kind == 'witness' then
        C.open = true
        C.focus(true)
        C.nui('open', { page = 'witness', extra = p, me = C.me, settings = C.settings })
    elseif p.kind == 'rate' then
        C.openWindow('mine', { rate = p.case })
    elseif p.kind == 'death' then
        C.openWindow('report', { prefill = { target = p.pub, targetName = p.name, category = 'rdm', weapon = p.weapon } })
    end
end

RegisterCommand('bb_yes', answerPrompt, false)
RegisterKeyMapping('bb_yes', 'Blackbox: answer the on-screen prompt', 'keyboard', Config.Keys.yes or 'Y')

CreateThread(function()
    while true do
        Wait(500)
        if C.prompt and C.prompt.exp < GetGameTimer() then
            if C.prompt.kind == 'witness' then TriggerServerEvent('bb:witness', C.prompt.case, false, '') end
            C.prompt = nil
            C.nui('promptClear', {})
        end
    end
end)

-- ------------------------------------------------------------------ commands

local registered = {}
local function registerOnce(name, fn)
    if not name or name == '' or registered[name] then return end
    registered[name] = true
    RegisterCommand(name, fn, false)
end

function C.registerCommands()
    registerOnce(C.settings.reportCommand, function() C.openWindow('report') end)
    registerOnce(C.settings.deskCommand, function()
        if C.me and C.me.isStaff then C.openWindow('desk') else C.toast(L('err.noperm'), 'error') end
    end)
    registerOnce(C.settings.dutyCommand, function()
        if not (C.me and C.me.isStaff) then return C.toast(L('err.noperm'), 'error') end
        C.req('duty', { on = not C.me.duty })
    end)
end

RegisterCommand(Config.AdminCommand, function()
    if not C.ready then return end
    if not C.me.isAdmin then return C.toast(L('err.noperm'), 'error') end
    C.openWindow('admin')
end, false)

-- key bindings players can change in their FiveM settings
RegisterCommand('bb_report', function() if C.ready then C.openWindow('report') end end, false)
RegisterKeyMapping('bb_report', 'Blackbox: open the report window', 'keyboard', Config.Keys.report or '')
RegisterCommand('bb_desk', function() if C.ready and C.me.isStaff then C.openWindow('desk') end end, false)
RegisterKeyMapping('bb_desk', 'Blackbox: open the staff desk', 'keyboard', Config.Keys.desk or '')

-- hold the panic key: files an urgent report without any typing
local holding, heldAt = false, 0
RegisterCommand('+bb_panic', function()
    if not C.ready or not C.settings.panicEnabled or C.open then return end
    holding, heldAt = true, GetGameTimer()
    C.nui('panic', { on = true, ms = C.settings.panicHoldMs })
    CreateThread(function()
        local ms = C.settings.panicHoldMs or 1500
        while holding and GetGameTimer() - heldAt < ms do Wait(50) end
        if holding then
            holding = false
            C.nui('panic', { on = false })
            local r = C.req('file', { panic = true, text = '', street = C.streetName(), events = Rec and Rec.collect() or {} })
            if r.ok then C.toast(L('note.panicsent'), 'success') else C.toast(tostring(r.payload), 'error') end
        end
    end)
end, false)
RegisterCommand('-bb_panic', function()
    if holding then holding = false C.nui('panic', { on = false }) end
end, false)
RegisterKeyMapping('+bb_panic', 'Blackbox: hold to send an urgent report', 'keyboard', Config.Keys.panic or '')

-- ------------------------------------------------------------ instant fixes

local function groundAt(x, y, z)
    for h = z + 50.0, z - 50.0, -10.0 do
        local ok, gz = GetGroundZFor_3dCoord(x, y, h, false)
        if ok then return gz end
    end
    return nil
end

local function unstuck()
    local ped = PlayerPedId()
    local c = GetEntityCoords(ped)
    local ent = ped
    local veh = GetVehiclePedIsIn(ped, false)
    if veh ~= 0 and GetPedInVehicleSeat(veh, -1) == ped then ent = veh end
    local found, pos = GetClosestVehicleNodeWithHeading(c.x, c.y, c.z, 1, 3.0, 0)
    DoScreenFadeOut(250)
    Wait(300)
    if found and pos then
        SetEntityCoords(ent, pos.x, pos.y, pos.z + 0.5, false, false, false, false)
    else
        local gz = groundAt(c.x, c.y, c.z)
        SetEntityCoords(ent, c.x, c.y, (gz or c.z) + 1.0, false, false, false, false)
    end
    Wait(300)
    DoScreenFadeIn(300)
end

RegisterNetEvent('bb:doFix', function(kind)
    local ped = PlayerPedId()
    local veh = GetVehiclePedIsIn(ped, false)
    if kind == 'unstuck' then
        unstuck()
    elseif kind == 'fixveh' then
        if veh == 0 then return C.toast(L('err.needveh'), 'error') end
        SetVehicleFixed(veh) SetVehicleDeformationFixed(veh) SetVehicleEngineHealth(veh, 1000.0) SetVehicleUndriveable(veh, false)
    elseif kind == 'clean' then
        if veh == 0 then return C.toast(L('err.needveh'), 'error') end
        SetVehicleDirtLevel(veh, 0.0)
    end
    C.toast(L('note.fixed'), 'success')
end)

-- ------------------------------------------------------------------ start

CreateThread(function()
    Bridge.waitLoaded()
    Wait(1500)
    TriggerServerEvent('bb:ready')
end)

AddEventHandler('onResourceStop', function(name)
    if name ~= GetCurrentResourceName() then return end
    SetNuiFocus(false, false)
    NetworkSetInSpectatorMode(false, PlayerPedId())
end)
