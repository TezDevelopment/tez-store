Config = {}

-- Almost everything is changed IN GAME with /bbadmin (saved in the database).
-- This file only holds what has to be known before the database loads.

Config.Locale = 'en'          -- file in /locales
Config.Debug  = false
Config.AdminCommand = 'bbadmin'

-- Default keys (players can rebind them in the FiveM key settings). Leave '' for "not bound".
Config.Keys = {
    report = '',              -- open the report window
    desk   = '',              -- staff desk
    panic  = '',              -- hold to file an urgent report
    yes    = 'Y',             -- answers the on-screen prompts (witness, killer, rating)
}

-- Account names used by your framework (the resource fills these in automatically)
Config.Accounts = { bank = 'bank', cash = 'money' }

-- Optional: URL of a text file that contains only the newest version number (e.g. 1.0.1)
Config.VersionUrl = ''
