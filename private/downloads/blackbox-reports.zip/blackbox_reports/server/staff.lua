-- Everything staff use: duty, the desk lists and case files, live tracking, teleport and spectate tools, player files, statistics and insights

local flag = BB.flag

-- ------------------------------------------------------------------ duty

function BB.setDuty(src, on)
    if not BB.players[src] then return end
    BB.duty[src] = on and true or nil
    BB.notify(src, on and L('note.dutyon') or L('note.dutyoff'), on and 'success' or 'info')
    TriggerClientEvent('bb:duty', src, on and true or false)
end

function BB.dutyList()
    local out = {}
    for s in pairs(BB.duty) do
        local p = BB.players[s]
        if p then out[#out + 1] = { pub = p.pub, name = p.name } end
    end
    table.sort(out, function(a, b) return a.name:lower() < b.name:lower() end)
    return out
end

-- ---------------------------------------------------------------- tracking

BB.tracks = {}   -- staff src -> { case, reporter, target }

function BB.startTracking(src, row)
    if not BB.get('toolTrack') then return end
    BB.tracks[src] = { case = row.id, reporter = row.reporter, target = row.target, rname = row.reporter_name, tname = row.target_name }
end

function BB.stopTracking(src)
    if BB.tracks[src] then
        BB.tracks[src] = nil
        TriggerClientEvent('bb:track', src, nil)
    end
end

function BB.stopTrackingFor(caseId)
    for s, t in pairs(BB.tracks) do
        if t.case == caseId then BB.tracks[s] = nil TriggerClientEvent('bb:track', s, nil) end
    end
end

function BB.trackTick()
    for s, t in pairs(BB.tracks) do
        if not BB.players[s] then
            BB.tracks[s] = nil
        else
            local function one(id, name)
                local ps = id ~= '' and BB.bySrc[id]
                if not ps then return nil end
                local c = BB.coords(ps)
                if not c then return nil end
                return { name = name, x = c.x, y = c.y, z = c.z, id = ps }
            end
            TriggerClientEvent('bb:track', s, { case = t.case, a = one(t.reporter, t.rname), b = one(t.target, t.tname) })
        end
    end
end

-- ------------------------------------------------------------------ queue

local function hiddenCategories(src)
    if BB.isAdmin(src, true) then return {} end
    local out = {}
    for _, c in ipairs(BB.get('categories') or {}) do if c.adminOnly then out[#out + 1] = c.id end end
    return out
end

local SUM = [[id, status, category, title, priority, prio_json, escalated, panic, reporter, reporter_name, anon, target, target_name, source, merged, statement_req,
    created, claimed_by, claimed_name, claimed_at, claim_secs, last_activity, closed_at, closed_name, verdict, rating, street]]

local function inList(list)
    local q = {}
    for i = 1, #list do q[i] = '?' end
    return table.concat(q, ',')
end

-- d = { tab = 'queue'|'mine'|'active'|'closed'|'all', q = text, category = id, band = 1-4, page }
function BB.deskList(src, d)
    local p = BB.players[src]
    if not p or not BB.isStaff(src, true) then return nil, L('err.noperm') end
    local hidden = hiddenCategories(src)
    local where, args = {}, {}
    local tab = d.tab or 'queue'
    if tab == 'queue' then where[#where + 1] = "status = 'open'"
    elseif tab == 'mine' then where[#where + 1] = "status IN ('claimed','waiting') AND claimed_by = ?" args[#args + 1] = p.id
    elseif tab == 'active' then where[#where + 1] = "status IN ('claimed','waiting')"
    elseif tab == 'closed' then where[#where + 1] = "status IN ('resolved','dismissed')"
    end
    if #hidden > 0 then where[#where + 1] = 'category NOT IN (' .. inList(hidden) .. ')' for _, h in ipairs(hidden) do args[#args + 1] = h end end
    if BB.get('seeOwnCases') then where[#where + 1] = 'reporter <> ? AND target <> ?' args[#args + 1] = p.id args[#args + 1] = p.id end
    if type(d.category) == 'string' and d.category ~= '' then where[#where + 1] = 'category = ?' args[#args + 1] = d.category end
    local q = BB.trim(tostring(d.q or '')):sub(1, 60)
    if q ~= '' then
        local n = tonumber(q:match('^#?(%d+)$'))
        if n then where[#where + 1] = 'id = ?' args[#args + 1] = n
        else
            local like = '%' .. q:gsub('[%%_]', ''):lower() .. '%'
            where[#where + 1] = '(LOWER(reporter_name) LIKE ? OR LOWER(target_name) LIKE ? OR LOWER(title) LIKE ?)'
            args[#args + 1] = like args[#args + 1] = like args[#args + 1] = like
        end
    end
    local order = (tab == 'closed' or tab == 'all') and 'id DESC' or 'priority DESC, id ASC'
    local page = math.max(1, math.floor(tonumber(d.page) or 1))
    local per = 40
    local sql = 'SELECT ' .. SUM .. ' FROM bb_cases' .. (#where > 0 and (' WHERE ' .. table.concat(where, ' AND ')) or '') .. ' ORDER BY ' .. order .. ' LIMIT ' .. per .. ' OFFSET ' .. ((page - 1) * per)
    local rows = MySQL.query.await(sql, args) or {}
    local list = {}
    for _, r in ipairs(rows) do
        local sum = BB.summary(r)
        sum.why = BB.jdec(r.prio_json, {})
        if not d.band or tonumber(d.band) == sum.band then list[#list + 1] = sum end
    end
    -- counts for the tab badges
    local hid = #hidden > 0 and (' AND category NOT IN (' .. inList(hidden) .. ')') or ''
    local function count(cond, extra)
        local a = {}
        for _, e in ipairs(extra or {}) do a[#a + 1] = e end
        for _, h in ipairs(hidden) do a[#a + 1] = h end
        return MySQL.scalar.await('SELECT COUNT(*) FROM bb_cases WHERE ' .. cond .. hid, a) or 0
    end
    local counts = {
        queue = count("status = 'open'"),
        mine = count("status IN ('claimed','waiting') AND claimed_by = ?", { p.id }),
        active = count("status IN ('claimed','waiting')"),
    }
    local eta, duty = BB.eta(counts.queue)
    return list, { counts = counts, duty = duty, eta = eta, page = page, per = per, onDuty = BB.duty[src] == true }
end

-- --------------------------------------------------------------- case file

local function profileOf(id, name)
    if not id or id == '' then return nil end
    local r = BB.rowOf(id)
    if not r then return { name = name } end
    local risk = BB.risk(id)
    local strikes = MySQL.query.await('SELECT case_id, label, points, note, staff, created FROM bb_strikes WHERE identifier = ? ORDER BY id DESC LIMIT 8', { id }) or {}
    local cases = MySQL.query.await("SELECT id, category, status, verdict, created FROM bb_cases WHERE target = ? ORDER BY id DESC LIMIT 6", { id }) or {}
    local against = MySQL.scalar.await('SELECT COUNT(*) FROM bb_cases WHERE target = ?', { id }) or 0
    local src = BB.bySrc[id]
    return {
        pub = r.pub, name = r.name ~= '' and r.name or name, online = src and true or false, id = src, trust = r.trust, filed = r.filed, valid = r.valid, falsed = r.falsed,
        risk = risk, step = BB.ladderStep(risk), watch = flag(r.watch), watchNote = r.watch_note, strikes = strikes, cases = cases, against = against,
        blocked = r.repban_until > BB.now() and r.repban_until or nil,
    }
end

function BB.caseDetail(src, caseId)
    local p = BB.players[src]
    local row = BB.getCase(caseId, true)
    if not p or not row then return nil, L('err.gone') end
    local ok, err = BB.canHandle(src, row)
    if not ok then return nil, err end
    local out = BB.summary(row)
    out.body = row.body
    out.answers = BB.jdec(row.answers, {})
    out.links = BB.jdec(row.links, {})
    out.why = BB.jdec(row.prio_json, {})
    out.panic = flag(row.panic)
    out.x, out.y, out.z = row.x, row.y, row.z
    out.verdictNote = row.verdict_note
    out.ratingNote = row.rating_note
    out.claimedAt = row.claimed_at
    out.claimSecs = row.claim_secs
    out.resolveSecs = row.resolve_secs
    out.closedName = row.closed_name
    out.mine = row.claimed_by == p.id
    out.reporterProfile = row.source == 'player' and profileOf(row.reporter, row.reporter_name) or nil
    out.targetProfile = profileOf(row.target, row.target_name)
    out.reporterSrc = row.reporter ~= '' and BB.bySrc[row.reporter] or nil
    out.targetSrc = row.target ~= '' and BB.bySrc[row.target] or nil
    out.others = {}
    for _, r in ipairs(MySQL.query.await('SELECT name, anon, body, trust, created FROM bb_reporters WHERE case_id = ? ORDER BY id', { row.id }) or {}) do
        out.others[#out.others + 1] = { name = r.name, anon = flag(r.anon), body = r.body, trust = r.trust, at = r.created }
    end
    local msgs = { reporter = {}, accused = {}, staff = {} }
    for _, m in ipairs(MySQL.query.await('SELECT channel, role, sender_name, text, created FROM bb_msgs WHERE case_id = ? ORDER BY id LIMIT 300', { row.id }) or {}) do
        if msgs[m.channel] then table.insert(msgs[m.channel], { role = m.role, name = m.role == 'staff' and m.sender_name or m.sender_name, text = m.text, at = m.created }) end
    end
    out.msgs = msgs
    out.events = {}
    for _, e in ipairs(MySQL.query.await('SELECT kind, text, actor, created FROM bb_events WHERE case_id = ? ORDER BY id LIMIT 200', { row.id }) or {}) do
        out.events[#out.events + 1] = { kind = e.kind, text = e.text, actor = e.actor, at = e.created }
    end
    out.witnesses = BB.witnesses(row.id)
    out.evidence = BB.jdec(row.evidence, nil)
    -- the ghost frames are big and only the game client needs them: the panel just learns that they exist
    if out.evidence and out.evidence.takes then
        for _, tk in ipairs(out.evidence.takes) do
            if tk.ghost then tk.hasGhost = true tk.ghost = nil end
        end
    end
    out.ladder = out.targetProfile and out.targetProfile.step or nil
    out.canAct = row.claimed_by == '' or row.claimed_by == p.id or BB.isAdmin(src, true)
    out.isAdmin = BB.isAdmin(src, true)
    return out
end

-- ------------------------------------------------------------------- tools

local function saveReturn(src) TriggerClientEvent('bb:saveReturn', src) end

local function logStaff(src, text)
    if BB.get('logStaff') then BB.log('staff', text, src) end
end

-- the in-world replay: the frames go straight to the staff member's game
function BB.ghostPlay(src, caseId, take)
    if not BB.get('ghostEnabled') then return false, L('err.disabled') end
    local row = BB.getCase(caseId, true)
    local p = BB.players[src]
    if not p or not row then return false, L('err.gone') end
    local ok, err = BB.canHandle(src, row)
    if not ok then return false, err end
    local ev = BB.jdec(row.evidence, nil)
    local tk = ev and ev.takes and ev.takes[math.floor(tonumber(take) or 0) + 1]
    if not tk or not tk.ghost then return false, L('err.noghost') end
    TriggerClientEvent('bb:ghost', src, { case = row.id, g = tk.ghost })
    logStaff(src, ('%s watched the in-game replay of case #%d'):format(p.name, row.id))
    BB.audit(row.id, 'tool', ('%s watched the in-game replay'):format(p.name), p.name)
    return true
end

-- who = 'scene' | 'reporter' | 'accused'
function BB.toolGoto(src, caseId, who)
    if not BB.get('toolGoto') then return false, L('err.disabled') end
    local row = BB.getCase(caseId)
    local p = BB.players[src]
    if not p or not row then return false, L('err.gone') end
    local ok, err = BB.canHandle(src, row)
    if not ok then return false, err end
    local x, y, z
    if who == 'scene' then x, y, z = row.x, row.y, row.z
    else
        local id = who == 'reporter' and row.reporter or row.target
        local ts = id ~= '' and BB.bySrc[id]
        local c = ts and BB.coords(ts)
        if not c then return false, L('err.offline') end
        x, y, z = c.x, c.y, c.z
    end
    if x == 0 and y == 0 then return false, L('err.nopos') end
    TriggerClientEvent('bb:staffTeleport', src, { x = x, y = y, z = z })
    logStaff(src, ('%s went to the %s of case #%d'):format(p.name, who, row.id))
    BB.audit(row.id, 'tool', ('%s went to the %s'):format(p.name, who), p.name)
    return true
end

function BB.toolBring(src, caseId, who)
    if not BB.get('toolBring') then return false, L('err.disabled') end
    local row = BB.getCase(caseId)
    local p = BB.players[src]
    if not p or not row then return false, L('err.gone') end
    local ok, err = BB.canHandle(src, row)
    if not ok then return false, err end
    local id = who == 'reporter' and row.reporter or row.target
    local ts = id ~= '' and BB.bySrc[id]
    local c = BB.coords(src)
    if not ts or not c then return false, L('err.offline') end
    TriggerClientEvent('bb:bringed', ts, { x = c.x, y = c.y, z = c.z, by = L('word.staff') })
    logStaff(src, ('%s brought %s (case #%d)'):format(p.name, BB.players[ts].name, row.id))
    BB.audit(row.id, 'tool', ('%s brought %s'):format(p.name, who == 'reporter' and 'the reporter' or 'the accused'), p.name)
    return true
end

function BB.toolSendBack(src, caseId, who)
    local row = BB.getCase(caseId)
    if not row then return false, L('err.gone') end
    local ok, err = BB.canHandle(src, row)
    if not ok then return false, err end
    local id = who == 'reporter' and row.reporter or row.target
    local ts = id ~= '' and BB.bySrc[id]
    if not ts then return false, L('err.offline') end
    TriggerClientEvent('bb:staffReturn', ts)
    return true
end

function BB.toolSpectate(src, caseId, who)
    if not BB.get('toolSpectate') then return false, L('err.disabled') end
    local row = BB.getCase(caseId)
    local p = BB.players[src]
    if not p or not row then return false, L('err.gone') end
    local ok, err = BB.canHandle(src, row)
    if not ok then return false, err end
    local id = who == 'reporter' and row.reporter or row.target
    local ts = id ~= '' and BB.bySrc[id]
    local c = ts and BB.coords(ts)
    if not ts or not c then return false, L('err.offline') end
    TriggerClientEvent('bb:spectate', src, { target = ts, x = c.x, y = c.y, z = c.z, name = BB.players[ts].name })
    logStaff(src, ('%s spectated %s (case #%d)'):format(p.name, BB.players[ts].name, row.id))
    BB.audit(row.id, 'tool', ('%s spectated %s'):format(p.name, who == 'reporter' and 'the reporter' or 'the accused'), p.name)
    return true
end

-- ------------------------------------------------------------ player files

function BB.playerFile(src, pub)
    local id = BB.fromPub(pub)
    if not id then return nil, L('err.notarget') end
    local pr = profileOf(id, '')
    if not pr then return nil, L('err.notarget') end
    pr.openAgainst = MySQL.scalar.await("SELECT COUNT(*) FROM bb_cases WHERE target = ? AND status IN ('open','claimed','waiting')", { id }) or 0
    return pr
end

function BB.staffPlayers(src, q)
    q = BB.trim(tostring(q or '')):lower()
    local out = {}
    for s, o in pairs(BB.players) do
        if q == '' or tostring(s) == q or o.name:lower():find(q, 1, true) then
            local r = BB.pd[o.id]
            out[#out + 1] = { pub = o.pub, name = o.name, id = s, trust = r and r.trust or 50, risk = BB.risk(o.id), watch = r and flag(r.watch) or false, staff = BB.isStaff(s, true) }
        end
    end
    table.sort(out, function(a, b) return a.name:lower() < b.name:lower() end)
    while #out > 60 do table.remove(out) end
    return out
end

-- admin: manual strike and trust change
function BB.manualStrike(src, pub, points, note)
    if not BB.isAdmin(src, true) then return false, L('err.noperm') end
    local id = BB.fromPub(pub)
    local row = id and BB.rowOf(id)
    if not row then return false, L('err.notarget') end
    points = math.floor(tonumber(points) or 0)
    if points < 1 or points > 500 then return false, L('err.badvalue') end
    MySQL.insert.await('INSERT INTO bb_strikes (identifier, name, case_id, verdict, label, points, note, staff, created) VALUES (?,?,?,?,?,?,?,?,?)',
        { id, row.name, 0, 'manual', 'Manual strike', points, BB.trim(tostring(note or '')):sub(1, 300), BB.players[src].name, BB.now() })
    BB.forgetRisk(id)
    BB.log('staff', ('%s gave %s a manual strike (%d points)'):format(BB.players[src].name, row.name, points), src)
    return true
end

function BB.clearStrikes(src, pub)
    if not BB.isAdmin(src, true) then return false, L('err.noperm') end
    local id = BB.fromPub(pub)
    local row = id and BB.rowOf(id)
    if not row then return false, L('err.notarget') end
    MySQL.update('DELETE FROM bb_strikes WHERE identifier = ?', { id })
    BB.forgetRisk(id)
    BB.log('staff', ('%s cleared the strikes of %s'):format(BB.players[src].name, row.name), src)
    return true
end

function BB.setTrust(src, pub, value)
    if not BB.isAdmin(src, true) then return false, L('err.noperm') end
    local id = BB.fromPub(pub)
    local row = id and BB.rowOf(id)
    if not row then return false, L('err.notarget') end
    value = math.floor(tonumber(value) or -1)
    if value < 0 or value > 100 then return false, L('err.badvalue') end
    row.trust = value
    row.repban_until = 0
    if BB.pd[id] then BB.pd[id].trust, BB.pd[id].repban_until = value, 0 end
    BB.saveRow(row)
    BB.log('staff', ('%s set the trust of %s to %d'):format(BB.players[src].name, row.name, value), src)
    return true
end

-- ------------------------------------------------------------- statistics

local periodSecs = { day = 86400, week = 7 * 86400, month = 30 * 86400, all = 3650 * 86400 }

function BB.staffStats(period)
    local since = BB.now() - (periodSecs[period] or periodSecs.week)
    local rows = MySQL.query.await([[SELECT closed_by AS id, MAX(closed_name) AS name, COUNT(*) AS n, AVG(NULLIF(claim_secs, 0)) AS claim, AVG(resolve_secs) AS resolve,
        AVG(NULLIF(rating, 0)) AS rating, SUM(rating > 0) AS rated FROM bb_cases WHERE closed_at > ? AND closed_by <> '' AND closed_by <> 'system' GROUP BY closed_by ORDER BY n DESC LIMIT 20]], { since }) or {}
    local out = {}
    for _, r in ipairs(rows) do
        out[#out + 1] = { name = r.name, n = r.n, claim = math.floor(tonumber(r.claim) or 0), resolve = math.floor(tonumber(r.resolve) or 0),
            rating = r.rating and math.floor(tonumber(r.rating) * 10 + 0.5) / 10 or nil, rated = tonumber(r.rated) or 0 }
    end
    return out
end

-- charts for the Insights page
function BB.insight(days)
    days = BB.clamp(math.floor(tonumber(days) or 14), 1, 90)
    local since = BB.now() - days * 86400
    local out = { days = days }
    out.total = MySQL.scalar.await('SELECT COUNT(*) FROM bb_cases WHERE created > ?', { since }) or 0
    out.closed = MySQL.scalar.await('SELECT COUNT(*) FROM bb_cases WHERE closed_at > ?', { since }) or 0
    out.avgClaim = math.floor(tonumber(MySQL.scalar.await('SELECT AVG(NULLIF(claim_secs, 0)) FROM bb_cases WHERE created > ?', { since })) or 0)
    out.avgResolve = math.floor(tonumber(MySQL.scalar.await('SELECT AVG(NULLIF(resolve_secs, 0)) FROM bb_cases WHERE closed_at > ?', { since })) or 0)
    local rt = MySQL.scalar.await('SELECT AVG(NULLIF(rating, 0)) FROM bb_cases WHERE closed_at > ?', { since })
    out.avgRating = rt and math.floor(tonumber(rt) * 10 + 0.5) / 10 or nil
    out.escalated = MySQL.scalar.await('SELECT COUNT(*) FROM bb_cases WHERE created > ? AND escalated = 1', { since }) or 0

    out.perDay = {}
    for _, r in ipairs(MySQL.query.await("SELECT DATE(FROM_UNIXTIME(created)) AS d, COUNT(*) AS n FROM bb_cases WHERE created > ? GROUP BY d ORDER BY d", { since }) or {}) do
        out.perDay[#out.perDay + 1] = { d = tostring(r.d):sub(1, 10), n = r.n }
    end
    out.byCategory = {}
    for _, r in ipairs(MySQL.query.await('SELECT category, COUNT(*) AS n FROM bb_cases WHERE created > ? GROUP BY category ORDER BY n DESC', { since }) or {}) do
        local c = BB.catById(r.category)
        out.byCategory[#out.byCategory + 1] = { id = r.category, label = c and c.label or r.category, color = c and c.color or '#94a3b8', n = r.n }
    end
    out.byVerdict = {}
    for _, r in ipairs(MySQL.query.await("SELECT verdict, COUNT(*) AS n FROM bb_cases WHERE closed_at > ? AND verdict <> '' GROUP BY verdict ORDER BY n DESC", { since }) or {}) do
        local v = BB.verdictById(r.verdict)
        out.byVerdict[#out.byVerdict + 1] = { id = r.verdict, label = v and v.label or r.verdict, color = v and v.color or '#94a3b8', n = r.n }
    end
    -- when does trouble start, and how fast do we answer
    out.hours = {}
    for h = 0, 23 do out.hours[h + 1] = { h = h, n = 0, claim = 0 } end
    for _, r in ipairs(MySQL.query.await('SELECT HOUR(FROM_UNIXTIME(created)) AS h, COUNT(*) AS n, AVG(NULLIF(claim_secs, 0)) AS c FROM bb_cases WHERE created > ? GROUP BY h', { since }) or {}) do
        local slot = out.hours[(tonumber(r.h) or 0) + 1]
        if slot then slot.n = r.n slot.claim = math.floor(tonumber(r.c) or 0) end
    end
    out.heat = {}
    for _, r in ipairs(MySQL.query.await('SELECT x, y FROM bb_cases WHERE created > ? AND (x <> 0 OR y <> 0) ORDER BY id DESC LIMIT 1200', { since }) or {}) do
        out.heat[#out.heat + 1] = { math.floor(r.x), math.floor(r.y) }
    end
    out.repeaters = {}
    for _, r in ipairs(MySQL.query.await("SELECT target, MAX(target_name) AS name, COUNT(*) AS n FROM bb_cases WHERE created > ? AND target <> '' GROUP BY target HAVING n > 1 ORDER BY n DESC LIMIT 6", { since }) or {}) do
        out.repeaters[#out.repeaters + 1] = { name = r.name, n = r.n, pub = BB.pubOf(r.target), risk = BB.risk(r.target) }
    end
    out.staff = BB.staffStats(days <= 1 and 'day' or days <= 7 and 'week' or days <= 30 and 'month' or 'all')
    return out
end

-- --------------------------------------------------------------- daily digest

function BB.sendDigest()
    local since = BB.now() - 86400
    local opened = MySQL.scalar.await('SELECT COUNT(*) FROM bb_cases WHERE created > ?', { since }) or 0
    local closed = MySQL.scalar.await('SELECT COUNT(*) FROM bb_cases WHERE closed_at > ?', { since }) or 0
    local open = MySQL.scalar.await("SELECT COUNT(*) FROM bb_cases WHERE status IN ('open','claimed','waiting')") or 0
    local avg = math.floor(tonumber(MySQL.scalar.await('SELECT AVG(NULLIF(claim_secs, 0)) FROM bb_cases WHERE created > ?', { since })) or 0)
    local top = MySQL.single.await('SELECT category, COUNT(*) AS n FROM bb_cases WHERE created > ? GROUP BY category ORDER BY n DESC LIMIT 1', { since })
    local cat = top and BB.catById(top.category)
    BB.embed('Daily report summary', ('Last 24 hours on %s'):format(BB.get('brand')), 16744960, {
        { name = 'Opened', value = tostring(opened), inline = true }, { name = 'Closed', value = tostring(closed), inline = true }, { name = 'Still open', value = tostring(open), inline = true },
        { name = 'Average pick-up', value = avg > 0 and (math.floor(avg / 60) .. ' min') or '-', inline = true },
        { name = 'Most common', value = cat and cat.label or '-', inline = true },
    }, nil)
end
