-- Loading, validating and saving the settings edited in /bbadmin

function BB.loadSettings()
    BB.S = Schema.defaults()
    BB.secrets = {}
    local row = MySQL.single.await('SELECT v FROM bb_settings WHERE k = ?', { 'config' })
    local saved = row and BB.jdec(row.v, {}) or {}
    for k, v in pairs(saved) do
        local f = Schema.byKey[k]
        if f then
            local ok, clean = Schema.validate(f, v)
            if ok then
                if f.secret then BB.secrets[k] = clean else BB.S[k] = clean end
            end
        end
    end
    local last = MySQL.single.await('SELECT v FROM bb_settings WHERE k = ?', { 'last' })
    BB.last = last and BB.jdec(last.v, {}) or {}
end

function BB.persistSettings()
    local blob = {}
    for _, f in ipairs(Schema.fields) do
        if f.secret then blob[f.k] = BB.secrets[f.k] or '' else blob[f.k] = BB.S[f.k] end
    end
    MySQL.query('REPLACE INTO bb_settings (k, v) VALUES (?, ?)', { 'config', BB.jenc(blob) })
    MySQL.query('REPLACE INTO bb_settings (k, v) VALUES (?, ?)', { 'last', BB.jenc(BB.last) })
end

-- Everything that is safe to show every player (secrets and staff-only things are never included)
local publicKeys = {
    'brand', 'themeColor', 'defaultMode', 'reportCommand', 'deskCommand', 'dutyCommand', 'currency', 'enabled', 'minChars', 'maxChars',
    'allowAnonymous', 'allowLinks', 'maxLinks', 'killerPrompt', 'killerPromptSecs', 'nearbyRadius', 'panicEnabled', 'panicHoldMs', 'ratings',
    'witnessSecs', 'witnessChars', 'fixesOn', 'fixes', 'mapImage', 'mapMinX', 'mapMaxX', 'mapMinY', 'mapMaxY', 'macros', 'toolGoto',
    'toolBring', 'toolSpectate', 'toolTrack', 'accusedStatements', 'recSeconds', 'recInterval', 'autoCategory', 'slaWarnMins', 'alertSound',
    'clientEvents', 'ghostEnabled', 'recShots', 'recDamage', 'recVehicle', 'recEnabled',
}
function BB.publicSettings()
    local out = {}
    for _, k in ipairs(publicKeys) do out[k] = BB.S[k] end
    -- categories without the keywords (those stay on the server) and without admin-only ones for normal players
    local cats = {}
    for _, c in ipairs(BB.S.categories or {}) do
        cats[#cats + 1] = { id = c.id, label = c.label, color = c.color, needsTarget = c.needsTarget, adminOnly = c.adminOnly, enabled = c.enabled,
            questions = c.questions, fix = c.fix, witness = c.witness, evidence = c.evidence }
    end
    out.categories = cats
    local vs = {}
    for _, v in ipairs(BB.S.verdicts or {}) do
        vs[#vs + 1] = { id = v.id, label = v.label, color = v.color, action = v.action, points = v.points, reporter = v.reporter, noteRequired = v.noteRequired, duration = v.duration }
    end
    out.verdicts = vs
    return out
end

local function summary(f, v)
    if f.secret then return v and '(changed)' or '' end
    local s = json.encode(v)
    if #s > 600 then s = s:sub(1, 600) .. '...' end
    return s
end

-- rules that involve more than one setting or one list
local function crossCheck()
    local S = BB.S
    local seen = {}
    for _, c in ipairs(S.categories) do
        if c.id == '' or c.id:find('[^%w_%-]') then return false, L('err.rule.catid', c.id) end
        if seen[c.id] then return false, L('err.rule.dupcat', c.id) end
        seen[c.id] = true
        if #c.questions > 4 then return false, L('err.rule.questions', c.label) end
    end
    if #S.categories < 1 then return false, L('err.rule.nocats') end
    if not seen[S.panicCategory] then return false, L('err.rule.panic', S.panicCategory) end
    seen = {}
    for _, v in ipairs(S.verdicts) do
        if v.id == '' or v.id:find('[^%w_%-]') then return false, L('err.rule.verdictid', v.id) end
        if seen[v.id] then return false, L('err.rule.dupverdict', v.id) end
        seen[v.id] = true
    end
    if #S.verdicts < 1 then return false, L('err.rule.noverdicts') end
    if not seen[S.autoCloseVerdict] and S.autoCloseHours > 0 then return false, L('err.rule.autoclose', S.autoCloseVerdict) end
    if not (S.p1 > S.p2 and S.p2 > S.p3) then return false, L('err.rule.bands') end
    if S.trustBan >= S.trustLow then return false, L('err.rule.trust') end
    seen = {}
    for _, f in ipairs(S.fixes) do
        if f.id == '' or f.id:find('[^%w_%-]') or seen[f.id] then return false, L('err.rule.fixid', f.id) end
        seen[f.id] = true
    end
    local last = -1
    for _, r in ipairs(S.ladder) do
        if r.risk <= last then return false, L('err.rule.ladder') end
        last = r.risk
    end
    return true
end

-- values = { key = value }, clear = { 'secretKey', ... }
-- Returns ok, errorText, listOfChangedKeys, diffs
function BB.saveSettings(src, values, clear)
    if type(values) ~= 'table' then return false, L('err.badvalue') end

    local backupS, backupSecrets, backupLast = {}, {}, {}
    for k, v in pairs(BB.S) do backupS[k] = v end
    for k, v in pairs(BB.secrets) do backupSecrets[k] = v end
    for k, v in pairs(BB.last) do backupLast[k] = v end

    local changed, diffs = {}, {}
    local function revert() BB.S, BB.secrets, BB.last = backupS, backupSecrets, backupLast end

    local who = (src and BB.players[src] and BB.players[src].name) or 'console'
    local now = BB.now()

    for k, v in pairs(values) do
        local f = Schema.byKey[k]
        if not f then revert() return false, L('err.unknownsetting', tostring(k)) end
        if f.secret then
            if type(v) == 'string' and v ~= '' then
                local ok, clean = Schema.validate(f, v)
                if not ok then revert() return false, L('err.badsetting', f.l) end
                BB.secrets[k] = clean
                changed[#changed + 1] = k
                diffs[#diffs + 1] = { k = k, old = '(secret)', new = '(changed)' }
                BB.last[k] = { by = who, at = now }
            end
        else
            local ok, clean = Schema.validate(f, v)
            if not ok then revert() return false, L('err.badsetting', f.l) end
            if json.encode(clean) ~= json.encode(BB.S[k]) then
                diffs[#diffs + 1] = { k = k, old = summary(f, BB.S[k]), new = summary(f, clean) }
                changed[#changed + 1] = k
                BB.last[k] = { by = who, at = now }
            end
            BB.S[k] = clean
        end
    end

    if type(clear) == 'table' then
        for _, k in ipairs(clear) do
            local f = Schema.byKey[k]
            if f and f.secret and (BB.secrets[k] or '') ~= '' then
                BB.secrets[k] = ''
                changed[#changed + 1] = k
                diffs[#diffs + 1] = { k = k, old = '(secret)', new = '(removed)' }
                BB.last[k] = { by = who, at = now }
            end
        end
    end

    local ok, err = crossCheck()
    if not ok then revert() return false, err end

    -- the admin may not lock themselves out
    if src and src > 0 and not BB.isAdmin(src, true) then
        revert()
        return false, L('err.lockout')
    end

    for _, d in ipairs(diffs) do
        MySQL.insert('INSERT INTO bb_history (k, old_v, new_v, admin, created) VALUES (?,?,?,?,?)', { d.k, d.old, d.new, who, now })
    end
    BB.persistSettings()
    BB.afterSettings(changed)
    return true, nil, changed, diffs
end

-- things that have to follow a settings change right away
function BB.afterSettings(changed)
    for _, p in pairs(BB.players) do
        local src = BB.bySrc[p.id]
        if src then TriggerClientEvent('bb:settings', src, BB.publicSettingsFor(src)) end
    end
end

-- Players may file under every category, but cases in an "only admins" category are only shown to admins.
function BB.publicSettingsFor(src)
    return BB.publicSettings()
end

function BB.history(key, limit)
    if key and key ~= '' then
        return MySQL.query.await('SELECT k, old_v, new_v, admin, created FROM bb_history WHERE k = ? ORDER BY id DESC LIMIT ?', { key, limit or 30 }) or {}
    end
    return MySQL.query.await('SELECT k, old_v, new_v, admin, created FROM bb_history ORDER BY id DESC LIMIT ?', { limit or 60 }) or {}
end
