-- Cases: filing, merging, claiming, messages, witnesses, verdicts, ratings and everything that happens on a timer

local COLS = [[id, status, category, title, body, answers, links, priority, prio_json, escalated, panic, reporter, reporter_name, anon, target, target_name, source,
    merged, statement_req, created, claimed_by, claimed_name, claimed_at, claim_secs, last_activity, closed_at, closed_by, closed_name, resolve_secs, verdict,
    verdict_note, rating, rating_note, x, y, z, street]]

local function flag(v) return v == 1 or v == true end
BB.flag = flag

local function open(row) return row.status == 'open' or row.status == 'claimed' or row.status == 'waiting' end
BB.isOpen = open

function BB.getCase(id, withEvidence)
    id = math.floor(tonumber(id) or 0)
    if id <= 0 then return nil end
    local cols = withEvidence and (COLS .. ', evidence') or COLS
    return MySQL.single.await('SELECT ' .. cols .. ' FROM bb_cases WHERE id = ?', { id })
end

function BB.audit(caseId, kind, text, actor)
    MySQL.insert('INSERT INTO bb_events (case_id, kind, text, actor, created) VALUES (?,?,?,?,?)',
        { caseId, kind, tostring(text):sub(1, 300), actor or '', BB.now() })
end

local function touch(id) MySQL.update('UPDATE bb_cases SET last_activity = ? WHERE id = ?', { BB.now(), id }) end

-- Tell a player (by identifier) something about a case. Offline players see it the next time they join.
function BB.push(identifier, caseId, text)
    if not identifier or identifier == '' then return end
    local src = BB.bySrc[identifier]
    if src then
        TriggerClientEvent('bb:notice', src, { case = caseId, text = text })
    else
        MySQL.insert('INSERT INTO bb_notifs (identifier, case_id, text, created) VALUES (?,?,?,?)', { identifier, caseId, text:sub(1, 300), BB.now() })
    end
end

function BB.deliverPending(src)
    local p = BB.players[src]
    if not p then return end
    local rows = MySQL.query.await('SELECT id, case_id, text, created FROM bb_notifs WHERE identifier = ? ORDER BY id LIMIT 20', { p.id }) or {}
    if #rows == 0 then return end
    MySQL.update('DELETE FROM bb_notifs WHERE identifier = ?', { p.id })
    for _, r in ipairs(rows) do TriggerClientEvent('bb:notice', src, { case = r.case_id, text = r.text }) end
end

-- ---------------------------------------------------------------- who sees what

local function isStaffSrc(src) return BB.isStaff(src, true) end

-- may this staff member work on this case?
function BB.canHandle(src, row)
    if not BB.isStaff(src, true) then return false, L('err.noperm') end
    local cat = BB.catById(row.category)
    if cat and cat.adminOnly and not BB.isAdmin(src, true) then return false, L('err.adminonly') end
    if BB.get('seeOwnCases') then
        local me = BB.idOf(src)
        if me and (row.reporter == me or row.target == me) then return false, L('err.owncase') end
    end
    return true
end

-- -------------------------------------------------------------------- summaries

local function parts(row) return BB.jdec(row.prio_json, {}) end

function BB.summary(row)
    local now = BB.now()
    return {
        id = row.id, status = row.status, category = row.category, title = row.title, priority = row.priority, band = BB.bandOf(row.priority),
        escalated = flag(row.escalated), panic = flag(row.panic), reporter = row.reporter_name, anon = flag(row.anon), target = row.target_name,
        source = row.source, merged = row.merged, created = row.created, claimed = row.claimed_name, claimedBy = row.claimed_by ~= '' and BB.pubOf(row.claimed_by) or nil,
        street = row.street, statement = flag(row.statement_req), verdict = row.verdict, closedAt = row.closed_at, last = row.last_activity, age = now - row.created,
        rating = row.rating,
    }
end

-- what a reporter or the accused is allowed to see
local function stageOf(row)
    if row.status == 'open' then return 1 end
    if row.status == 'claimed' then return 2 end
    if row.status == 'waiting' then return 2 end
    return 3
end

local function waitingCount()
    return MySQL.scalar.await("SELECT COUNT(*) FROM bb_cases WHERE status = 'open'") or 0
end

local function queuePos(row)
    return (MySQL.scalar.await("SELECT COUNT(*) FROM bb_cases WHERE status = 'open' AND (priority > ? OR (priority = ? AND id < ?))", { row.priority, row.priority, row.id }) or 0) + 1
end

local function playerCase(row, identifier)
    local cat = BB.catById(row.category)
    local v = row.verdict ~= '' and BB.verdictById(row.verdict) or nil
    local out = {
        id = row.id, status = row.status, stage = stageOf(row), category = row.category, label = cat and cat.label or row.category, color = cat and cat.color or '#94a3b8',
        title = row.title, created = row.created, closedAt = row.closed_at, body = row.body, target = (row.reporter == identifier) and row.target_name or nil,
        panic = flag(row.panic), rating = row.rating, canRate = BB.get('ratings') and not open(row) and row.rating == 0 and row.source == 'player',
        outcome = v and { label = v.label, color = v.color, message = v.message } or nil, merged = row.merged,
    }
    if open(row) then
        out.waitingOnYou = row.status == 'waiting'
        if row.status == 'open' then
            out.pos = queuePos(row)
            out.eta = select(1, BB.eta(waitingCount()))
        end
    end
    return out
end

-- cases of one player: the ones they filed (or were added to), plus the ones where staff asked for their side
function BB.myCases(src)
    local p = BB.players[src]
    if not p then return { mine = {}, about = {} } end
    local hours = BB.get('closedVisibleHours') * 3600
    local now = BB.now()
    local rows = MySQL.query.await('SELECT ' .. COLS .. [[ FROM bb_cases WHERE (reporter = ? OR id IN (SELECT case_id FROM bb_reporters WHERE identifier = ?))
        AND source = 'player' AND (status IN ('open','claimed','waiting') OR closed_at > ?) ORDER BY id DESC LIMIT 30]], { p.id, p.id, now - hours }) or {}
    local mine = {}
    for _, r in ipairs(rows) do mine[#mine + 1] = playerCase(r, p.id) end
    local about = {}
    if BB.get('accusedStatements') then
        for _, r in ipairs(MySQL.query.await('SELECT id, category, created FROM bb_cases WHERE target = ? AND statement_req = 1 AND status IN (\'open\',\'claimed\',\'waiting\') ORDER BY id DESC LIMIT 10', { p.id }) or {}) do
            local cat = BB.catById(r.category)
            about[#about + 1] = { id = r.id, label = cat and cat.label or r.category, created = r.created }
        end
    end
    local eta = BB.eta(waitingCount())
    return { mine = mine, about = about, duty = BB.dutyCount(), eta = eta }
end

-- one thread the player may read
function BB.thread(src, caseId, channel)
    local p = BB.players[src]
    local row = BB.getCase(caseId)
    if not p or not row then return nil end
    if channel == 'reporter' then
        if row.reporter ~= p.id then return nil end
    elseif channel == 'accused' then
        if row.target ~= p.id or not flag(row.statement_req) then return nil end
    else
        return nil
    end
    local msgs = MySQL.query.await('SELECT role, sender_name, text, created FROM bb_msgs WHERE case_id = ? AND channel = ? ORDER BY id LIMIT 100', { row.id, channel }) or {}
    local out = {}
    for _, m in ipairs(msgs) do out[#out + 1] = { role = m.role, name = m.role == 'staff' and L('word.staff') or m.sender_name, text = m.text, at = m.created } end
    local case = playerCase(row, p.id)
    if channel == 'accused' then case.target = nil case.body = nil end
    return { case = case, msgs = out, open = open(row), channel = channel }
end

-- ---------------------------------------------------------------- form helpers

function BB.formInfo(src)
    local p = BB.players[src]
    if not p then return nil end
    local me = BB.coords(src)
    local near = {}
    if me then
        for s, o in pairs(BB.players) do
            if s ~= src then
                local c = BB.coords(s)
                if c then
                    local d = #(c - me)
                    if d <= BB.get('nearbyRadius') then near[#near + 1] = { pub = o.pub, name = o.name, id = s, dist = math.floor(d) } end
                end
            end
        end
    end
    table.sort(near, function(a, b) return a.dist < b.dist end)
    while #near > 12 do table.remove(near) end
    local killer = Rec.lastKillerOf(p.pub, BB.get('killerPromptSecs') + 60)
    return {
        nearby = near, left = Rec.leftList(), duty = BB.dutyCount(), eta = BB.eta(waitingCount()),
        killer = killer and killer.killer and { pub = killer.killer, name = killer.kname, weapon = killer.w, ago = BB.now() - killer.t } or nil,
        open = MySQL.scalar.await("SELECT COUNT(*) FROM bb_cases WHERE reporter = ? AND status IN ('open','claimed','waiting')", { p.id }) or 0,
        trust = BB.pd[p.id] and BB.pd[p.id].trust or 50,
    }
end

function BB.playerSearch(src, q)
    q = BB.trim(q):lower()
    if #q < 1 then return {} end
    local out = {}
    for s, o in pairs(BB.players) do
        if s ~= src and (tostring(s) == q or o.name:lower():find(q, 1, true)) then out[#out + 1] = { pub = o.pub, name = o.name, id = s } end
    end
    table.sort(out, function(a, b) return a.name:lower() < b.name:lower() end)
    while #out > 10 do table.remove(out) end
    return out
end

-- ----------------------------------------------------------------- scoring

-- recompute the priority of one case from everything we know
function BB.rescore(row, evidenceCombat)
    if not open(row) then return row.priority end
    local reporterRow = row.source == 'player' and BB.rowOf(row.reporter) or nil
    local targetRow = row.target ~= '' and BB.rowOf(row.target) or nil
    local cat = BB.catById(row.category)
    BB.combat = BB.combat or {}
    if evidenceCombat ~= nil then BB.combat[row.id] = evidenceCombat end
    local combat = BB.combat[row.id]
    if combat == nil then
        local ev = MySQL.scalar.await('SELECT evidence FROM bb_cases WHERE id = ?', { row.id })
        local e = BB.jdec(ev, nil)
        combat = false
        for _, t in ipairs(e and e.takes or {}) do if t.combat then combat = true end end
        BB.combat[row.id] = combat
    end
    local score, why = BB.priority(row, {
        trust = reporterRow and reporterRow.trust or 70, merged = row.merged, risk = row.target ~= '' and BB.risk(row.target) or 0,
        watch = targetRow and flag(targetRow.watch), combat = combat, keyword = cat and BB.keywordHits(cat, row.body) > 0,
        escalated = flag(row.escalated), age = BB.now() - row.created,
    })
    score = math.floor(score + 0.5)
    if score ~= row.priority then
        MySQL.update('UPDATE bb_cases SET priority = ?, prio_json = ? WHERE id = ?', { score, BB.jenc(why), row.id })
        row.priority = score
    else
        MySQL.update('UPDATE bb_cases SET prio_json = ? WHERE id = ?', { BB.jenc(why), row.id })
    end
    row.prio_json = BB.jenc(why)
    return score
end

-- -------------------------------------------------------------- desk pushes

function BB.pushDesk(row, what)
    local sum = BB.summary(row)
    for s in pairs(BB.desk) do
        if BB.players[s] then
            local ok = BB.canHandle(s, row)
            if ok or BB.isAdmin(s, true) then TriggerClientEvent('bb:deskEvent', s, { what = what, case = sum }) end
        end
    end
end

local function pushMine(row, what)
    for _, id in ipairs({ row.reporter, row.target }) do
        local s = id ~= '' and BB.bySrc[id] or nil
        if s then TriggerClientEvent('bb:mineEvent', s, { what = what, id = row.id }) end
    end
end

-- ------------------------------------------------------------------ filing

local lastCat = {}   -- identifier -> category -> time
local lastFiled = {} -- identifier -> time

local function pickTarget(src, d)
    -- returns targetSrc, targetPub, targetRowId, targetName, err
    if type(d.target) ~= 'string' or d.target == '' then return nil end
    local id = BB.fromPub(d.target)
    if not id then return nil, nil, nil, nil, L('err.notarget') end
    if id == BB.idOf(src) then return nil, nil, nil, nil, L('err.self') end
    local tsrc = BB.bySrc[id]
    if tsrc and BB.players[tsrc] then return tsrc, d.target, id, BB.players[tsrc].name end
    local g = Rec.gone[d.target]
    if g then return nil, d.target, id, g.name end
    local row = BB.rowOf(id)
    if row then return nil, d.target, id, row.name end
    return nil, nil, nil, nil, L('err.notarget')
end

local function cleanLinks(list)
    local out = {}
    if type(list) ~= 'table' or not BB.get('allowLinks') then return out end
    for _, u in ipairs(list) do
        if #out >= BB.get('maxLinks') then break end
        local ok, url = BB.validLink(u)
        if ok then out[#out + 1] = url end
    end
    return out
end

local function cleanAnswers(cat, list)
    local out = {}
    if type(list) ~= 'table' then return out end
    for i, q in ipairs(cat.questions or {}) do
        if i > 4 then break end
        local a = list[i]
        if type(a) == 'string' then
            local ok, t = BB.filter(a)
            t = ok and t:sub(1, 200) or ''
            if t ~= '' then out[#out + 1] = { q = q, a = t } end
        end
    end
    return out
end

local function sceneCenter(src, tsrc, tpub)
    local c = src and BB.coords(src)
    if not c and tsrc then c = BB.coords(tsrc) end
    if not c and tpub and Rec.gone[tpub] then local g = Rec.gone[tpub] c = vector3(g.x, g.y, g.z) end
    return c
end

-- the reporter's client sent events; they are only trusted as hints
local function embedTake(ev, by)
    ev.by = by
    return ev
end

local function webhookNew(row, ev)
    if not BB.get('logNew') then return end
    local cat = BB.catById(row.category)
    local fields = {
        { name = 'Category', value = cat and cat.label or row.category, inline = true },
        { name = 'Priority', value = ('P%d (%d)'):format(BB.bandOf(row.priority), row.priority), inline = true },
        { name = 'Reporter', value = row.anon == 1 and (row.reporter_name .. ' (hidden from accused)') or row.reporter_name, inline = true },
    }
    if row.target_name ~= '' then fields[#fields + 1] = { name = 'Accused', value = row.target_name, inline = true } end
    if row.street ~= '' then fields[#fields + 1] = { name = 'Where', value = row.street, inline = true } end
    if ev and ev.count then fields[#fields + 1] = { name = 'Recorder', value = ('%d players, %ds'):format(ev.count, ev.span or 0), inline = true } end
    BB.embed(('Report #%d%s'):format(row.id, flag(row.panic) and ' (URGENT)' or ''), (row.body or ''):sub(1, 900), cat and tonumber(cat.color:sub(2), 16) or 16744960, fields)
end

local function askWitnesses(row, centre, exclude)
    local cat = BB.catById(row.category)
    if not BB.get('witnessOn') or not cat or not cat.witness or not centre then return end
    BB.asked = BB.asked or {}
    local now = BB.now()
    local ask = {}
    for s in pairs(BB.players) do
        if not exclude[s] then
            local c = BB.coords(s)
            if c then
                local d = #(c - centre)
                if d <= BB.get('witnessRadius') then ask[#ask + 1] = { s = s, d = d } end
            end
        end
    end
    table.sort(ask, function(a, b) return a.d < b.d end)
    BB.asked[row.id] = BB.asked[row.id] or {}
    for i, a in ipairs(ask) do
        if i > BB.get('witnessMaxAsk') then break end
        BB.asked[row.id][a.s] = { exp = now + BB.get('witnessSecs') + 5, role = 'witness' }
        TriggerClientEvent('bb:witnessAsk', a.s, { case = row.id, label = cat.label, secs = BB.get('witnessSecs'), chars = BB.get('witnessChars'), reward = BB.get('witnessReward') })
    end
end

-- d = { category, text, target (pub), answers = {}, links = {}, anon, panic, street, events = {} }
function BB.fileReport(src, d)
    local p = BB.players[src]
    if not p then return false, L('err.notloaded') end
    if not BB.get('enabled') then return false, L('err.closed') end
    if Hooks.canReport and Hooks.canReport(src) == false then return false, L('err.cannotnow') end
    local row = BB.pd[p.id]
    if not row then return false, L('err.notloaded') end
    BB.trustRecover(row)

    local blocked, until_ = BB.reportBlocked(row)
    if blocked then return false, L('err.repban', math.ceil((until_ - BB.now()) / 60)) end

    local isPanic = d.panic == true and BB.get('panicEnabled')
    local catId = isPanic and BB.get('panicCategory') or tostring(d.category or '')
    local cat = BB.catById(catId)
    if not cat or not cat.enabled then return false, L('err.nocat') end

    local now = BB.now()
    local mult = row.trust < BB.get('trustLow') and 3 or 1
    local cd = BB.get('globalCooldown') * mult
    if lastFiled[p.id] and now - lastFiled[p.id] < cd and not isPanic then return false, L('err.cooldown', cd - (now - lastFiled[p.id])) end
    lastCat[p.id] = lastCat[p.id] or {}
    local ccd = cat.cooldown * mult
    if lastCat[p.id][cat.id] and now - lastCat[p.id][cat.id] < ccd then return false, L('err.cooldown', ccd - (now - lastCat[p.id][cat.id])) end

    local openN = MySQL.scalar.await("SELECT COUNT(*) FROM bb_cases WHERE reporter = ? AND status IN ('open','claimed','waiting') AND source = 'player'", { p.id }) or 0
    if openN >= BB.get('maxOpen') then return false, L('err.toomany', BB.get('maxOpen')) end

    local text = BB.trim(tostring(d.text or ''))
    if isPanic and #text < BB.get('minChars') then text = text ~= '' and text or L('word.panictext') end
    if #text < BB.get('minChars') then return false, L('err.short', BB.get('minChars')) end
    if #text > BB.get('maxChars') then text = text:sub(1, BB.get('maxChars')) end
    local ok, clean = BB.filter(text)
    if not ok then return false, L('err.blocked') end
    text = clean

    if isPanic and (type(d.target) ~= 'string' or d.target == '') then
        local k = Rec.lastKillerOf(p.pub, 90)
        if k and k.killer and BB.fromPub(k.killer) then d.target = k.killer end
    end
    local tsrc, tpub, tid, tname, terr = pickTarget(src, d)
    if terr then return false, terr end
    if cat.needsTarget and not tid and not isPanic then return false, L('err.needtarget') end

    -- the very same text twice in a row is almost always a double click
    if row.last_text == text and now - (row.last_report or 0) < 120 then return false, L('err.duplicate') end
    row.last_text = text

    local answers = cleanAnswers(cat, d.answers)
    local links = cleanLinks(d.links)
    local anon = d.anon == true and BB.get('allowAnonymous') and 1 or 0
    local street = BB.trim(tostring(d.street or '')):sub(1, 100)
    local centre = sceneCenter(src, tsrc, tpub)
    local title = text:gsub('%s+', ' '):sub(1, 90)

    -- merge into an open case about the same player
    local window = BB.get('pileWindow') * 60
    if tid and window > 0 then
        local sql = [[SELECT ]] .. COLS .. [[ FROM bb_cases WHERE target = ? AND status IN ('open','claimed','waiting') AND created > ? AND reporter <> ? ]]
        local args = { tid, now - window, p.id }
        if BB.get('pileSameCategory') then sql = sql .. 'AND category = ? ' args[#args + 1] = cat.id end
        sql = sql .. 'ORDER BY id DESC LIMIT 1'
        local base = MySQL.single.await(sql, args)
        local already = base and MySQL.scalar.await('SELECT COUNT(*) FROM bb_reporters WHERE case_id = ? AND identifier = ?', { base.id, p.id }) or 0
        if base and already == 0 then
            MySQL.insert.await('INSERT INTO bb_reporters (case_id, identifier, name, anon, body, trust, created) VALUES (?,?,?,?,?,?,?)',
                { base.id, p.id, p.name, anon, text, row.trust, now })
            base.merged = base.merged + 1
            MySQL.update('UPDATE bb_cases SET merged = ?, last_activity = ? WHERE id = ?', { base.merged, now, base.id })
            if isPanic then
                MySQL.update('UPDATE bb_cases SET panic = 1 WHERE id = ?', { base.id })
                base.panic = 1
            end
            -- the second angle goes next to the first one in the replay
            if cat.evidence and BB.get('recEnabled') then
                local ev = Rec.snapshot({ reporter = src, target = tsrc, targetPub = tpub, events = d.events, center = centre })
                local old = BB.jdec(MySQL.scalar.await('SELECT evidence FROM bb_cases WHERE id = ?', { base.id }), { takes = {} })
                old.takes = old.takes or {}
                if #old.takes < 3 then
                    if ev.combat then BB.combat = BB.combat or {} BB.combat[base.id] = true end
                    old.takes[#old.takes + 1] = embedTake(ev, p.name)
                    MySQL.update('UPDATE bb_cases SET evidence = ? WHERE id = ?', { BB.jenc(old), base.id })
                end
            end
            BB.audit(base.id, 'merge', ('%s also reported this player (%d reporters)'):format(p.name, base.merged + 1), p.name)
            BB.rescore(base)
            lastFiled[p.id], lastCat[p.id][cat.id] = now, now
            row.filed, row.last_report = row.filed + 1, now
            BB.saveRow(row)
            BB.pushDesk(base, 'update')
            pushMine(base, 'update')
            if flag(base.escalated) == false and BB.bandOf(base.priority) <= 1 then BB.alertStaff(base) end
            return true, { id = base.id, merged = true, eta = select(1, BB.eta(waitingCount())) }
        end
    end

    -- a new case
    local ev
    if cat.evidence and BB.get('recEnabled') then
        ev = Rec.snapshot({ reporter = src, target = tsrc, targetPub = tpub, events = d.events, center = centre })
        embedTake(ev, p.name)
    end
    local evBlob = ev and BB.jenc({ takes = { ev } }) or ''
    local x, y, z = 0, 0, 0
    if centre then x, y, z = centre.x, centre.y, centre.z end

    local row2 = {
        status = 'open', category = cat.id, title = title, body = text, panic = isPanic and 1 or 0, reporter = p.id, reporter_name = p.name, anon = anon,
        target = tid or '', target_name = tname or '', source = 'player', merged = 0, created = now, escalated = 0, priority = 0,
    }
    local score, why = BB.priority(row2, {
        trust = row.trust, merged = 0, risk = tid and BB.risk(tid) or 0, watch = tid and (BB.rowOf(tid) and flag(BB.rowOf(tid).watch)),
        combat = ev and ev.combat or false, keyword = BB.keywordHits(cat, text) > 0, age = 0,
    })
    score = math.floor(score + 0.5)
    local id = MySQL.insert.await([[INSERT INTO bb_cases (status, category, title, body, answers, links, priority, prio_json, panic, reporter, reporter_name, anon, target, target_name,
        source, created, last_activity, x, y, z, street, evidence) VALUES ('open',?,?,?,?,?,?,?,?,?,?,?,?,?,'player',?,?,?,?,?,?,?)]],
        { cat.id, title, text, BB.jenc(answers), BB.jenc(links), score, BB.jenc(why), row2.panic, p.id, p.name, anon, tid or '', tname or '', now, now, x, y, z, street, evBlob })
    row2.id, row2.priority, row2.prio_json, row2.last_activity, row2.street = id, score, BB.jenc(why), now, street
    BB.combat = BB.combat or {}
    BB.combat[id] = ev and ev.combat or false

    lastFiled[p.id], lastCat[p.id][cat.id] = now, now
    row.filed, row.last_report = row.filed + 1, now
    BB.saveRow(row)

    BB.audit(id, 'filed', ('Filed by %s%s'):format(p.name, isPanic and ' (urgent button)' or ''), p.name)
    if ev and ev.left then BB.audit(id, 'flag', ('Accused left the server %ds before the report'):format(ev.left.ago), 'recorder') end
    if tid then
        local tr = BB.rowOf(tid)
        if tr and flag(tr.watch) then BB.audit(id, 'flag', 'The accused is on the watchlist', 'system') end
        if BB.get('accusedNotify') and tsrc then BB.notify(tsrc, L('note.reportedyou'), 'warn') end
    end

    local exclude = { [src] = true }
    if tsrc then exclude[tsrc] = true end
    askWitnesses(row2, centre, exclude)
    if BB.get('witnessIncludeReported') and tsrc then
        BB.asked = BB.asked or {}
        BB.asked[id] = BB.asked[id] or {}
        BB.asked[id][tsrc] = { exp = now + BB.get('witnessSecs') + 5, role = 'accused' }
        TriggerClientEvent('bb:witnessAsk', tsrc, { case = id, label = cat.label, secs = BB.get('witnessSecs'), chars = BB.get('witnessChars'), accused = true })
    end

    BB.alertStaff(row2)
    BB.pushDesk(row2, 'new')
    webhookNew(row2, ev)
    if Hooks.onReport then pcall(Hooks.onReport, row2) end
    local eta = select(1, BB.eta(waitingCount()))
    return true, { id = id, eta = eta, pos = queuePos(row2), duty = BB.dutyCount() }
end

-- Other scripts (anti-cheat, admin tools) can file a report. exports.blackbox_reports:AutoReport(targetSrc, 'cheating', 'Reason', { key = 'value' })
function BB.autoReport(targetSrc, categoryId, reason, meta)
    if not BB.get('autoReports') then return false end
    local t = BB.players[tonumber(targetSrc)]
    if not t then return false end
    local cat = BB.catById(categoryId) or BB.catById(BB.get('panicCategory'))
    if not cat then return false end
    local now = BB.now()
    local text = BB.trim(tostring(reason or 'Automatic report')):sub(1, 400)
    -- one open automatic report per player and category
    local dupe = MySQL.scalar.await("SELECT COUNT(*) FROM bb_cases WHERE source = 'system' AND target = ? AND category = ? AND status IN ('open','claimed','waiting')", { t.id, cat.id }) or 0
    if dupe > 0 then
        MySQL.update("UPDATE bb_cases SET merged = merged + 1, last_activity = ? WHERE source = 'system' AND target = ? AND category = ? AND status IN ('open','claimed','waiting')", { now, t.id, cat.id })
        return true
    end
    local ev
    if BB.get('recEnabled') then ev = Rec.snapshot({ target = targetSrc, center = BB.coords(targetSrc) }) embedTake(ev, 'System') end
    local c = BB.coords(targetSrc)
    local row2 = { status = 'open', category = cat.id, body = text, panic = 0, reporter = '', reporter_name = 'System', anon = 0, target = t.id, target_name = t.name, source = 'system', merged = 0, created = now }
    local tr = BB.rowOf(t.id)
    local score, why = BB.priority(row2, { trust = 75, risk = BB.risk(t.id), watch = tr and flag(tr.watch), combat = false, keyword = true, age = 0 })
    score = math.floor(score + 0.5)
    local meta2 = type(meta) == 'table' and meta or {}
    local metaText = {}
    for k, v in pairs(meta2) do metaText[#metaText + 1] = { q = tostring(k):sub(1, 40), a = tostring(v):sub(1, 120) } end
    table.sort(metaText, function(a, b) return a.q < b.q end)
    local id = MySQL.insert.await([[INSERT INTO bb_cases (status, category, title, body, answers, links, priority, prio_json, panic, reporter, reporter_name, anon, target, target_name,
        source, created, last_activity, x, y, z, evidence) VALUES ('open',?,?,?,?,'[]',?,?,0,'','System',0,?,?,'system',?,?,?,?,?,?)]],
        { cat.id, text:sub(1, 90), text, BB.jenc(metaText), score, BB.jenc(why), t.id, t.name, now, now, c and c.x or 0, c and c.y or 0, c and c.z or 0, ev and BB.jenc({ takes = { ev } }) or '' })
    row2.id, row2.priority, row2.prio_json, row2.last_activity, row2.street = id, score, BB.jenc(why), now, ''
    BB.audit(id, 'filed', 'Filed automatically by another script', 'system')
    BB.alertStaff(row2)
    BB.pushDesk(row2, 'new')
    webhookNew(row2, ev)
    return true, id
end

function BB.alertStaff(row)
    local mode = BB.get('alertBand')
    if mode == 'none' then return end
    local band = BB.bandOf(row.priority)
    if mode == 'p1' and band > 1 then return end
    if mode == 'p1p2' and band > 2 then return end
    local sum = BB.summary(row)
    for s in pairs(BB.duty) do
        if BB.players[s] and BB.canHandle(s, row) then TriggerClientEvent('bb:alert', s, sum) end
    end
end

-- ------------------------------------------------------------------ witnesses

function BB.witnessAnswer(src, caseId, said, text)
    local p = BB.players[src]
    local a = BB.asked and BB.asked[caseId] and BB.asked[caseId][src]
    if not p or not a then return false, L('err.nowitness') end
    BB.asked[caseId][src] = nil
    if a.exp < BB.now() then return false, L('err.toolate') end
    if not said then return true end
    text = BB.trim(tostring(text or ''))
    if #text < 5 then return false, L('err.short', 5) end
    local ok, clean = BB.filter(text:sub(1, BB.get('witnessChars')))
    if not ok then return false, L('err.blocked') end
    local row = BB.getCase(caseId)
    if not row then return false, L('err.gone') end
    MySQL.insert.await('INSERT INTO bb_witness (case_id, identifier, name, role, text, created) VALUES (?,?,?,?,?,?)', { caseId, p.id, p.name, a.role, clean, BB.now() })
    BB.audit(caseId, 'witness', ('%s gave a %s statement'):format(p.name, a.role == 'accused' and 'accused' or 'witness'), p.name)
    touch(caseId)
    if a.role == 'witness' then
        local reward = BB.get('witnessReward')
        if reward > 0 and Bridge.hasMoney() then Bridge.addMoney(src, BB.get('payAccount'), reward) end
        local r = BB.pd[p.id]
        if r and BB.get('witnessTrust') > 0 then BB.addTrust(r, BB.get('witnessTrust')) end
        BB.notify(src, L('note.witnessthanks', reward > 0 and (BB.get('currency') .. reward) or ''), 'success')
    end
    pushMine(row, 'update')
    BB.pushDesk(row, 'update')
    return true
end

function BB.witnesses(caseId)
    local out = {}
    for _, w in ipairs(MySQL.query.await('SELECT name, role, text, created FROM bb_witness WHERE case_id = ? ORDER BY id', { caseId }) or {}) do
        out[#out + 1] = { name = w.name, role = w.role, text = w.text, at = w.created }
    end
    return out
end

-- ------------------------------------------------------------------ messages

-- channel: 'reporter' (staff <-> reporter), 'accused' (staff <-> accused), 'staff' (internal notes)
function BB.sendMessage(src, caseId, channel, text)
    local p = BB.players[src]
    local row = BB.getCase(caseId)
    if not p or not row then return false, L('err.gone') end
    text = BB.trim(tostring(text or ''))
    if #text < 1 then return false, L('err.short', 1) end
    if not BB.rate(src, 'msg', 700) then return false, L('err.slowdown') end
    local ok, clean = BB.filter(text:sub(1, 500))
    if not ok then return false, L('err.blocked') end
    text = clean

    local staff = BB.isStaff(src, true) and BB.canHandle(src, row)
    local role
    if channel == 'staff' then
        if not staff then return false, L('err.noperm') end
        role = 'staff'
    elseif channel == 'reporter' then
        if staff then role = 'staff'
        elseif row.reporter == p.id and open(row) then role = 'player'
        else return false, L('err.noperm') end
    elseif channel == 'accused' then
        if staff then
            if not BB.get('accusedStatements') then return false, L('err.disabled') end
            role = 'staff'
        elseif row.target == p.id and flag(row.statement_req) and open(row) then role = 'player'
        else return false, L('err.noperm') end
    else
        return false, L('err.badvalue')
    end
    if role == 'staff' and open(row) and row.claimed_by ~= '' and row.claimed_by ~= p.id and not BB.isAdmin(src, true) then return false, L('err.notyours') end

    MySQL.insert.await('INSERT INTO bb_msgs (case_id, channel, role, sender, sender_name, text, created) VALUES (?,?,?,?,?,?,?)',
        { row.id, channel, role, p.id, p.name, text, BB.now() })
    touch(row.id)
    local msg = { case = row.id, channel = channel, role = role, name = role == 'staff' and L('word.staff') or p.name, text = text, at = BB.now() }

    if channel == 'reporter' then
        if role == 'player' then
            if row.status == 'waiting' then MySQL.update("UPDATE bb_cases SET status = 'claimed' WHERE id = ?", { row.id }) row.status = 'claimed' end
            if row.claimed_by ~= '' and BB.bySrc[row.claimed_by] then TriggerClientEvent('bb:chat', BB.bySrc[row.claimed_by], { case = row.id, channel = channel, role = 'player', name = p.name, text = text, at = msg.at }) end
        else
            BB.push(row.reporter, row.id, L('note.staffreplied', row.id))
            local rs = BB.bySrc[row.reporter]
            if rs then TriggerClientEvent('bb:chat', rs, msg) end
        end
    elseif channel == 'accused' then
        if role == 'player' then
            if row.claimed_by ~= '' and BB.bySrc[row.claimed_by] then TriggerClientEvent('bb:chat', BB.bySrc[row.claimed_by], { case = row.id, channel = channel, role = 'player', name = p.name, text = text, at = msg.at }) end
        else
            BB.push(row.target, row.id, L('note.staffreplied', row.id))
            local ts = BB.bySrc[row.target]
            if ts then TriggerClientEvent('bb:chat', ts, msg) end
        end
    else
        for s in pairs(BB.desk) do
            if s ~= src and BB.players[s] and BB.canHandle(s, row) then TriggerClientEvent('bb:chat', s, { case = row.id, channel = 'staff', role = 'staff', name = p.name, text = text, at = msg.at }) end
        end
    end
    return true, msg
end

-- ------------------------------------------------------------------ handling

function BB.claim(src, caseId)
    local p = BB.players[src]
    local row = BB.getCase(caseId)
    if not p or not row then return false, L('err.gone') end
    local ok, err = BB.canHandle(src, row)
    if not ok then return false, err end
    if not open(row) then return false, L('err.closedcase') end
    if row.claimed_by ~= '' and row.claimed_by ~= p.id then return false, L('err.claimed', row.claimed_name) end
    local now = BB.now()
    local first = row.claimed_at == 0
    MySQL.update("UPDATE bb_cases SET status = 'claimed', claimed_by = ?, claimed_name = ?, claimed_at = ?, claim_secs = IF(claim_secs = 0, ?, claim_secs), last_activity = ? WHERE id = ?",
        { p.id, p.name, now, now - row.created, now, row.id })
    if first then BB.recordClaimTime(now - row.created) end
    row.status, row.claimed_by, row.claimed_name, row.claimed_at, row.last_activity = 'claimed', p.id, p.name, now, now
    BB.audit(row.id, 'claim', ('%s took the case'):format(p.name), p.name)
    BB.log('claim', ('%s claimed case #%d'):format(p.name, row.id), src)
    if row.source == 'player' then BB.push(row.reporter, row.id, L('note.claimed', row.id)) end
    BB.startTracking(src, row)
    BB.pushDesk(row, 'update')
    pushMine(row, 'update')
    if Hooks.onClaim then pcall(Hooks.onClaim, row, src) end
    return true
end

function BB.release(src, caseId, reason)
    local p = BB.players[src]
    local row = BB.getCase(caseId)
    if not p or not row then return false, L('err.gone') end
    if not open(row) then return false, L('err.closedcase') end
    if row.claimed_by ~= p.id and not BB.isAdmin(src, true) then return false, L('err.notyours') end
    MySQL.update("UPDATE bb_cases SET status = 'open', claimed_by = '', claimed_name = '', last_activity = ? WHERE id = ?", { BB.now(), row.id })
    row.status, row.claimed_by, row.claimed_name = 'open', '', ''
    BB.audit(row.id, 'release', ('%s gave the case back%s'):format(p.name, reason and (' (' .. reason .. ')') or ''), p.name)
    BB.stopTracking(src)
    BB.rescore(row)
    BB.pushDesk(row, 'update')
    pushMine(row, 'update')
    return true
end

function BB.handoff(src, caseId, toPub)
    local p = BB.players[src]
    local row = BB.getCase(caseId)
    if not p or not row or not open(row) then return false, L('err.gone') end
    if row.claimed_by ~= p.id and not BB.isAdmin(src, true) then return false, L('err.notyours') end
    local tid = BB.fromPub(toPub)
    local tsrc = tid and BB.bySrc[tid]
    if not tsrc or not BB.isStaff(tsrc, true) then return false, L('err.nostaff') end
    local ok, err = BB.canHandle(tsrc, row)
    if not ok then return false, err end
    local to = BB.players[tsrc]
    MySQL.update("UPDATE bb_cases SET claimed_by = ?, claimed_name = ?, claimed_at = ?, last_activity = ? WHERE id = ?", { to.id, to.name, BB.now(), BB.now(), row.id })
    row.claimed_by, row.claimed_name = to.id, to.name
    BB.audit(row.id, 'handoff', ('%s handed the case to %s'):format(p.name, to.name), p.name)
    BB.stopTracking(src)
    BB.startTracking(tsrc, row)
    BB.notify(tsrc, L('note.handoff', row.id, p.name), 'info')
    BB.pushDesk(row, 'update')
    return true
end

function BB.setWaiting(src, caseId, on)
    local p = BB.players[src]
    local row = BB.getCase(caseId)
    if not p or not row or not open(row) then return false, L('err.gone') end
    if row.claimed_by ~= p.id and not BB.isAdmin(src, true) then return false, L('err.notyours') end
    local status = on and 'waiting' or 'claimed'
    MySQL.update('UPDATE bb_cases SET status = ?, last_activity = ? WHERE id = ?', { status, BB.now(), row.id })
    row.status = status
    BB.audit(row.id, 'status', on and 'Waiting on the reporter' or 'Back to work', p.name)
    if on and row.source == 'player' then BB.push(row.reporter, row.id, L('note.waiting', row.id)) end
    BB.pushDesk(row, 'update')
    pushMine(row, 'update')
    return true
end

function BB.requestStatement(src, caseId)
    local p = BB.players[src]
    local row = BB.getCase(caseId)
    if not p or not row or not open(row) then return false, L('err.gone') end
    if not BB.get('accusedStatements') then return false, L('err.disabled') end
    if row.target == '' then return false, L('err.notarget') end
    MySQL.update('UPDATE bb_cases SET statement_req = 1, last_activity = ? WHERE id = ?', { BB.now(), row.id })
    row.statement_req = 1
    BB.audit(row.id, 'statement', ('%s asked the accused for their side'):format(p.name), p.name)
    BB.push(row.target, row.id, L('note.statementreq'))
    BB.pushDesk(row, 'update')
    pushMine(row, 'update')
    return true
end

function BB.setWatch(src, pub, on, note)
    local id = BB.fromPub(pub)
    local row = id and BB.rowOf(id)
    if not row then return false, L('err.notarget') end
    row.watch = on and 1 or 0
    row.watch_note = BB.trim(tostring(note or '')):sub(1, 200)
    if BB.pd[id] then BB.pd[id].watch, BB.pd[id].watch_note = row.watch, row.watch_note end
    MySQL.update('UPDATE bb_players SET watch = ?, watch_note = ? WHERE identifier = ?', { row.watch, row.watch_note, id })
    BB.log('staff', ('%s %s %s on the watchlist'):format(BB.players[src] and BB.players[src].name or 'console', on and 'put' or 'removed', row.name), src)
    return true
end

-- --------------------------------------------------------------------- verdict

local function punish(v, row, targetSrc, reason)
    local minutes = v.duration
    local vars = { id = targetSrc or '', minutes = minutes, hours = math.ceil(minutes / 60), days = math.ceil(minutes / 1440), reason = reason }
    if Hooks.onPunish and Hooks.onPunish(v.action, targetSrc, row.target, minutes, reason, row) then return nil end
    local note
    if v.action == 'warn' then
        if targetSrc then TriggerClientEvent('bb:warned', targetSrc, { reason = reason, from = L('word.staff') }) end
        if not Bridge.runTemplate(BB.get('warnCommand'), vars) then return nil end
    elseif v.action == 'kick' then
        if not Bridge.runTemplate(BB.get('kickCommand'), vars) and targetSrc then DropPlayer(targetSrc, L('note.kicked', reason)) end
    elseif v.action == 'jail' then
        if not Bridge.runTemplate(BB.get('jailCommand'), vars) then note = L('warn.nojail') end
    elseif v.action == 'ban' then
        if not Bridge.runTemplate(BB.get('banCommand'), vars) then
            note = L('warn.noban')
            if targetSrc then DropPlayer(targetSrc, L('note.kicked', reason)) end
        end
    end
    return note
end

function BB.close(src, caseId, verdictId, note)
    local p = BB.players[src]
    local row = BB.getCase(caseId)
    if not p or not row then return false, L('err.gone') end
    local ok, err = BB.canHandle(src, row)
    if not ok then return false, err end
    if not open(row) then return false, L('err.closedcase') end
    if row.claimed_by ~= '' and row.claimed_by ~= p.id and not BB.isAdmin(src, true) then return false, L('err.notyours') end
    local v = BB.verdictById(tostring(verdictId))
    if not v then return false, L('err.badvalue') end
    note = BB.trim(tostring(note or '')):sub(1, 500)
    if v.noteRequired and #note < 5 then return false, L('err.noterequired') end
    return BB.finish(row, v, note, p, src)
end

-- the shared end of a case (staff verdict or automatic close)
function BB.finish(row, v, note, actor, actorSrc)
    local now = BB.now()
    local actorName = actor and actor.name or 'System'
    local actorId = actor and actor.id or 'system'
    local status = (v.reporter == 'false' or (v.action == 'none' and v.points == 0 and v.reporter == 'neutral')) and 'dismissed' or 'resolved'
    MySQL.update('UPDATE bb_cases SET status = ?, verdict = ?, verdict_note = ?, closed_at = ?, closed_by = ?, closed_name = ?, resolve_secs = ?, last_activity = ? WHERE id = ?',
        { status, v.id, note, now, actorId, actorName, now - row.created, now, row.id })
    row.status, row.verdict, row.verdict_note, row.closed_at = status, v.id, note, now

    local result = {}
    local targetSrc = row.target ~= '' and BB.bySrc[row.target] or nil
    local reason = note ~= '' and note or v.label
    if row.target ~= '' then
        if v.points > 0 then
            MySQL.insert.await('INSERT INTO bb_strikes (identifier, name, case_id, verdict, label, points, note, staff, created) VALUES (?,?,?,?,?,?,?,?,?)',
                { row.target, row.target_name, row.id, v.id, v.label, v.points, note:sub(1, 300), actorName, now })
            BB.forgetRisk(row.target)
        end
        if v.action ~= 'none' then result.warn = punish(v, row, targetSrc, reason) end
    end

    -- reporters: trust follows the verdict
    local reporters = {}
    if row.source == 'player' then reporters[#reporters + 1] = row.reporter end
    for _, r in ipairs(MySQL.query.await('SELECT identifier FROM bb_reporters WHERE case_id = ?', { row.id }) or {}) do reporters[#reporters + 1] = r.identifier end
    for _, id in ipairs(reporters) do
        local rr = BB.rowOf(id)
        if rr then
            if v.reporter == 'valid' then
                rr.valid = rr.valid + 1
                BB.addTrust(rr, BB.get('trustValid'))
            elseif v.reporter == 'false' then
                rr.falsed = rr.falsed + 1
                BB.addTrust(rr, -BB.get('trustFalse'))
            else
                MySQL.update('UPDATE bb_players SET valid = ?, falsed = ? WHERE identifier = ?', { rr.valid, rr.falsed, id })
            end
            if not BB.pd[id] then BB.saveRow(rr) end
        end
        BB.push(id, row.id, L('note.closed', row.id, v.message ~= '' and v.message or v.label))
        local s = BB.bySrc[id]
        if s and BB.get('ratings') and id == row.reporter then TriggerClientEvent('bb:rate', s, { case = row.id }) end
    end

    BB.audit(row.id, 'verdict', ('%s: %s%s'):format(actorName, v.label, note ~= '' and (' - ' .. note) or ''), actorName)
    BB.log('verdict', ('Case #%d closed by %s: %s'):format(row.id, actorName, v.label), actorSrc)
    BB.embed(('Case #%d closed'):format(row.id), (note ~= '' and note or v.label):sub(1, 900), tonumber(v.color:sub(2), 16) or 9807270, {
        { name = 'Verdict', value = v.label, inline = true }, { name = 'By', value = actorName, inline = true },
        { name = 'Accused', value = row.target_name ~= '' and row.target_name or '-', inline = true },
    }, 'logVerdict')
    BB.stopTrackingFor(row.id)
    if actorSrc and BB.get('returnOnClose') then TriggerClientEvent('bb:staffReturn', actorSrc) end
    BB.pushDesk(row, 'update')
    pushMine(row, 'update')
    if Hooks.onClose then pcall(Hooks.onClose, row, v, actorSrc) end
    result.status = status
    return true, result
end

function BB.reopen(src, caseId)
    local p = BB.players[src]
    local row = BB.getCase(caseId)
    if not p or not row then return false, L('err.gone') end
    if not BB.isAdmin(src, true) then return false, L('err.noperm') end
    if open(row) then return false, L('err.notclosed') end
    MySQL.update("UPDATE bb_cases SET status = 'claimed', claimed_by = ?, claimed_name = ?, verdict = '', verdict_note = '', closed_at = 0, closed_by = '', closed_name = '', resolve_secs = 0, last_activity = ? WHERE id = ?",
        { p.id, p.name, BB.now(), row.id })
    MySQL.update('DELETE FROM bb_strikes WHERE case_id = ?', { row.id })
    if row.target ~= '' then BB.forgetRisk(row.target) end
    row.status, row.verdict = 'claimed', ''
    BB.audit(row.id, 'reopen', ('%s reopened the case (strikes from it were removed)'):format(p.name), p.name)
    BB.pushDesk(row, 'update')
    pushMine(row, 'update')
    return true
end

function BB.rateCase(src, caseId, stars, note)
    local p = BB.players[src]
    local row = BB.getCase(caseId)
    if not p or not row or not BB.get('ratings') then return false, L('err.gone') end
    if row.reporter ~= p.id then return false, L('err.noperm') end
    if open(row) or row.rating ~= 0 then return false, L('err.notrate') end
    stars = math.floor(tonumber(stars) or 0)
    if stars < 1 or stars > 5 then return false, L('err.badvalue') end
    local ok, clean = BB.filter(BB.trim(tostring(note or '')):sub(1, 300))
    if not ok then clean = '' end
    MySQL.update('UPDATE bb_cases SET rating = ?, rating_note = ? WHERE id = ?', { stars, clean, row.id })
    BB.audit(row.id, 'rating', ('Rated %d/5%s'):format(stars, clean ~= '' and (': ' .. clean) or ''), p.name)
    if BB.get('logRatings') then BB.log('rating', ('Case #%d rated %d/5 (%s)'):format(row.id, stars, row.claimed_name), src) end
    return true
end

-- --------------------------------------------------------------------- timers

-- once a second is plenty: everything below only looks at cases that are still open
function BB.caseTick(n)
    local now = BB.now()
    if n % 15 == 0 then
        for _, row in ipairs(MySQL.query.await('SELECT ' .. COLS .. " FROM bb_cases WHERE status IN ('open','claimed','waiting') LIMIT 300") or {}) do
            local before = row.priority
            -- escalate cases nobody picked up
            if row.status == 'open' and not flag(row.escalated) and now - row.created >= BB.get('slaClaimMins') * 60 then
                MySQL.update('UPDATE bb_cases SET escalated = 1 WHERE id = ?', { row.id })
                row.escalated = 1
                BB.audit(row.id, 'escalate', ('Nobody took this case for %d minutes'):format(BB.get('slaClaimMins')), 'system')
                BB.log('escalate', ('Case #%d has waited %d minutes'):format(row.id, BB.get('slaClaimMins')))
                local cat = BB.catById(row.category)
                if BB.get('logEscalate') then
                    local role = BB.get('pingRole')
                    BB.embed(('Case #%d needs attention'):format(row.id), ('Nobody has picked this up for %d minutes.'):format(BB.get('slaClaimMins')), 15158332, {
                        { name = 'Category', value = cat and cat.label or row.category, inline = true }, { name = 'Priority', value = 'P' .. BB.bandOf(row.priority), inline = true },
                    }, 'logEscalate', role ~= '' and ('<@&' .. role .. '>') or nil)
                end
                for s in pairs(BB.duty) do if BB.players[s] and BB.canHandle(s, row) then TriggerClientEvent('bb:alert', s, BB.summary(row), true) end end
            end
            -- a claim nobody works on goes back to the queue
            local stale = BB.get('slaStaleMins')
            if stale > 0 and row.status == 'claimed' and now - row.last_activity >= stale * 60 then
                local holder = row.claimed_by ~= '' and BB.bySrc[row.claimed_by]
                local active = holder and BB.desk[holder]
                if not active then
                    MySQL.update("UPDATE bb_cases SET status = 'open', claimed_by = '', claimed_name = '', last_activity = ? WHERE id = ?", { now, row.id })
                    BB.audit(row.id, 'release', ('%s did not work on the case for %d minutes, it went back to the queue'):format(row.claimed_name, stale), 'system')
                    if holder then BB.stopTracking(holder) end
                    row.status, row.claimed_by, row.claimed_name = 'open', '', ''
                    BB.pushDesk(row, 'update')
                end
            end
            -- waiting on a reporter who never answered
            local ach = BB.get('autoCloseHours')
            if ach > 0 and row.status == 'waiting' and now - row.last_activity >= ach * 3600 then
                local v = BB.verdictById(BB.get('autoCloseVerdict'))
                if v then BB.finish(row, v, L('note.autoclosed', ach), nil, nil) end
            end
            if open(row) then
                BB.rescore(row)
                if row.priority ~= before or flag(row.escalated) then BB.pushDesk(row, 'update') end
            end
        end
    end
    if n % 3600 == 0 then
        local cut = now - BB.get('keepEvidenceDays') * 86400
        MySQL.update("UPDATE bb_cases SET evidence = NULL WHERE evidence IS NOT NULL AND closed_at > 0 AND closed_at < ?", { cut })
        MySQL.update('DELETE FROM bb_notifs WHERE created < ?', { now - 14 * 86400 })
        MySQL.update('DELETE FROM bb_msgs WHERE created < ? AND case_id IN (SELECT id FROM bb_cases WHERE closed_at > 0)', { now - 365 * 86400 })
    end
    -- witness windows
    if n % 10 == 0 and BB.asked then
        for cid, list in pairs(BB.asked) do
            local any = false
            for s, a in pairs(list) do if a.exp < now then list[s] = nil else any = true end end
            if not any then BB.asked[cid] = nil end
        end
    end
end
