-- Smart triage: priority scores that explain themselves, reporter trust, repeat offender risk and the punishment ladder

BB.pd = {}          -- identifier -> row of bb_players (online players)

function BB.rowOf(identifier)
    if not identifier or identifier == '' then return nil end
    local r = BB.pd[identifier]
    if r then return r end
    return MySQL.single.await('SELECT * FROM bb_players WHERE identifier = ?', { identifier })
end

function BB.saveRow(r)
    MySQL.update('UPDATE bb_players SET trust = ?, repban_until = ?, watch = ?, watch_note = ?, filed = ?, valid = ?, falsed = ?, last_report = ?, trust_day = ? WHERE identifier = ?',
        { r.trust, r.repban_until, r.watch, r.watch_note, r.filed, r.valid, r.falsed, r.last_report, r.trust_day, r.identifier })
end

function BB.catById(id)
    for _, c in ipairs(BB.get('categories') or {}) do if c.id == id then return c end end
end
function BB.verdictById(id)
    for _, v in ipairs(BB.get('verdicts') or {}) do if v.id == id then return v end end
end
function BB.fixById(id)
    for _, f in ipairs(BB.get('fixes') or {}) do if f.id == id then return f end end
end

-- ------------------------------------------------------------------ categories

local function words(text)
    return ' ' .. tostring(text or ''):lower():gsub('[^%w%s]', ' ') .. ' '
end

local function hits(cat, text)
    local w = words(text)
    local n = 0
    for _, k in ipairs(cat.keywords or {}) do
        local kk = k:lower():gsub('[^%w%s]', ' ')
        if kk ~= '' and w:find(' ' .. kk .. ' ', 1, true) then n = n + 1 end
    end
    return n
end
BB.keywordHits = hits

-- the category whose keywords match the text best (or nil)
function BB.suggestCategory(text)
    local best, bestN
    for _, c in ipairs(BB.get('categories') or {}) do
        if c.enabled then
            local n = hits(c, text)
            if n > 0 and (not bestN or n > bestN) then best, bestN = c.id, n end
        end
    end
    return best
end

-- ------------------------------------------------------------------ trust

-- trust slowly returns to the starting value, one step per day
function BB.trustRecover(row)
    local today = BB.dayKey()
    if row.trust_day == today then return end
    local y, m, d = (row.trust_day or ''):match('(%d+)-(%d+)-(%d+)')
    local days = 1
    if y then
        local then_ = os.time({ year = y, month = m, day = d, hour = 12 })
        days = math.max(1, math.floor((os.time() - then_) / 86400))
    end
    local start = BB.get('trustStart')
    if row.trust < start then row.trust = math.min(start, row.trust + days * BB.get('trustRecover')) end
    row.trust_day = today
    BB.saveRow(row)
end

function BB.addTrust(row, delta)
    row.trust = BB.clamp(math.floor(row.trust + delta + 0.5), 0, 100)
    local cut, hours = BB.get('trustBan'), BB.get('trustBanHours')
    if hours > 0 and row.trust <= cut and row.repban_until < BB.now() then row.repban_until = BB.now() + hours * 3600 end
    BB.saveRow(row)
end

-- returns true if this player may not file right now, and until when
function BB.reportBlocked(row)
    if row.repban_until and row.repban_until > BB.now() then return true, row.repban_until end
    return false
end

-- ------------------------------------------------------------------ risk

local riskCache = {}

-- points of every strike, each one halving every halfLife days
function BB.risk(identifier)
    local c = riskCache[identifier]
    if c and c.exp > BB.now() then return c.v end
    local half = BB.get('halfLife') * 86400
    local total, now = 0, BB.now()
    for _, s in ipairs(MySQL.query.await('SELECT points, created FROM bb_strikes WHERE identifier = ?', { identifier }) or {}) do
        total = total + s.points * (0.5 ^ ((now - s.created) / half))
    end
    total = math.floor(total * 10 + 0.5) / 10
    riskCache[identifier] = { v = total, exp = now + 20 }
    return total
end
function BB.forgetRisk(identifier) riskCache[identifier] = nil end

function BB.ladderStep(risk)
    local step
    for _, r in ipairs(BB.get('ladder') or {}) do
        if risk >= r.risk then step = r.step end
    end
    return step or ''
end

-- ---------------------------------------------------------------- priority

-- case: the case row; ctx = { trust, risk, watch, combat, keyword, merged, escalated, age }
-- returns score, parts (a list of { k, l, p }) that the desk shows as chips
function BB.priority(case, ctx)
    local cat = BB.catById(case.category) or { weight = 8, label = case.category }
    local parts = {}
    local total = 0
    local function add(k, label, pts)
        pts = math.floor(pts + 0.5)
        if pts ~= 0 then parts[#parts + 1] = { k = k, l = label, p = pts } total = total + pts end
    end
    add('cat', cat.label, cat.weight)
    if not BB.get('triageOn') then
        return total, parts, 4
    end
    local t = (ctx.trust or 50)
    add('trust', t >= 50 and 'Trusted reporter' or 'Low trust reporter', (t - 50) / 50 * BB.get('wTrust'))
    if (ctx.merged or 0) > 0 then add('pile', (ctx.merged + 1) .. ' people reported this player', math.min(ctx.merged, 3) * BB.get('wPile')) end
    if (ctx.risk or 0) > 0 then add('risk', 'Repeat offender', math.min(ctx.risk / 100, 1) * BB.get('wRisk')) end
    if case.panic == 1 or case.panic == true then add('panic', 'Urgent button', BB.get('wPanic')) end
    if ctx.combat then add('evidence', 'Recorder shows combat', BB.get('wEvidence')) end
    if ctx.watch then add('watch', 'On the watchlist', BB.get('wWatch')) end
    if ctx.keyword then add('keyword', 'Matches category keywords', BB.get('wKeyword')) end
    local mins = (ctx.age or 0) / 60
    add('age', 'Waiting', math.min(mins * BB.get('wAge'), BB.get('wAgeCap')))
    if ctx.escalated then add('sla', 'Escalated', BB.get('slaEscalatePoints')) end
    total = BB.clamp(total, 0, 200)
    local band = 4
    if total >= BB.get('p1') then band = 1 elseif total >= BB.get('p2') then band = 2 elseif total >= BB.get('p3') then band = 3 end
    return total, parts, band
end

function BB.bandOf(score)
    if score >= BB.get('p1') then return 1 end
    if score >= BB.get('p2') then return 2 end
    if score >= BB.get('p3') then return 3 end
    return 4
end

-- ---------------------------------------------------------------- wait time

-- Estimated minutes until a new case is picked up: recent average claim time, scaled by how many cases wait per staff member on duty
local recentClaims = {}
function BB.recordClaimTime(secs)
    recentClaims[#recentClaims + 1] = secs
    while #recentClaims > BB.get('etaSamples') do table.remove(recentClaims, 1) end
end

function BB.dutyCount()
    local n = 0
    for src in pairs(BB.duty) do if BB.players[src] then n = n + 1 end end
    return n
end

function BB.eta(waitingCount)
    local avg = BB.get('etaDefault') * 60
    if #recentClaims >= 3 then
        local sum = 0
        for _, s in ipairs(recentClaims) do sum = sum + s end
        avg = sum / #recentClaims
    end
    local duty = BB.dutyCount()
    if duty == 0 then return nil, 0 end
    local per = math.max(1, math.ceil((waitingCount + 1) / duty))
    return math.max(60, math.floor(avg * (0.6 + 0.4 * per))), duty
end
