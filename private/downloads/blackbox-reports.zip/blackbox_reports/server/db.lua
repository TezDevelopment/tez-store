-- Tables are created automatically every time the resource starts.

DB = {}

local create = {
    [[CREATE TABLE IF NOT EXISTS bb_meta (k VARCHAR(60) NOT NULL PRIMARY KEY, v VARCHAR(255) NOT NULL)]],
    [[CREATE TABLE IF NOT EXISTS bb_settings (k VARCHAR(40) NOT NULL PRIMARY KEY, v LONGTEXT NOT NULL)]],
    [[CREATE TABLE IF NOT EXISTS bb_history (
        id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
        k VARCHAR(40) NOT NULL, old_v TEXT NULL, new_v TEXT NULL,
        admin VARCHAR(80) NOT NULL DEFAULT '', created INT NOT NULL, INDEX (k)
    )]],
    [[CREATE TABLE IF NOT EXISTS bb_logs (
        id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
        category VARCHAR(20) NOT NULL, message VARCHAR(500) NOT NULL, actor VARCHAR(80) NOT NULL DEFAULT '', created INT NOT NULL
    )]],
    [[CREATE TABLE IF NOT EXISTS bb_players (
        identifier VARCHAR(80) NOT NULL PRIMARY KEY,
        pub VARCHAR(12) NOT NULL DEFAULT '', name VARCHAR(80) NOT NULL DEFAULT '', license VARCHAR(80) NOT NULL DEFAULT '',
        trust INT NOT NULL DEFAULT 50, repban_until INT NOT NULL DEFAULT 0,
        watch TINYINT(1) NOT NULL DEFAULT 0, watch_note VARCHAR(200) NOT NULL DEFAULT '',
        filed INT NOT NULL DEFAULT 0, valid INT NOT NULL DEFAULT 0, falsed INT NOT NULL DEFAULT 0,
        last_report INT NOT NULL DEFAULT 0, trust_day VARCHAR(10) NOT NULL DEFAULT '',
        created INT NOT NULL DEFAULT 0, INDEX (pub), INDEX (name)
    )]],
    [[CREATE TABLE IF NOT EXISTS bb_cases (
        id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
        status VARCHAR(12) NOT NULL DEFAULT 'open', category VARCHAR(30) NOT NULL DEFAULT 'other',
        title VARCHAR(120) NOT NULL DEFAULT '', body TEXT NULL, answers TEXT NULL, links TEXT NULL,
        priority INT NOT NULL DEFAULT 0, prio_json TEXT NULL, escalated TINYINT(1) NOT NULL DEFAULT 0, panic TINYINT(1) NOT NULL DEFAULT 0,
        reporter VARCHAR(80) NOT NULL DEFAULT '', reporter_name VARCHAR(80) NOT NULL DEFAULT '', anon TINYINT(1) NOT NULL DEFAULT 0,
        target VARCHAR(80) NOT NULL DEFAULT '', target_name VARCHAR(80) NOT NULL DEFAULT '',
        source VARCHAR(10) NOT NULL DEFAULT 'player', merged INT NOT NULL DEFAULT 0, statement_req TINYINT(1) NOT NULL DEFAULT 0,
        created INT NOT NULL DEFAULT 0, claimed_by VARCHAR(80) NOT NULL DEFAULT '', claimed_name VARCHAR(80) NOT NULL DEFAULT '',
        claimed_at INT NOT NULL DEFAULT 0, claim_secs INT NOT NULL DEFAULT 0, last_activity INT NOT NULL DEFAULT 0,
        closed_at INT NOT NULL DEFAULT 0, closed_by VARCHAR(80) NOT NULL DEFAULT '', closed_name VARCHAR(80) NOT NULL DEFAULT '', resolve_secs INT NOT NULL DEFAULT 0,
        verdict VARCHAR(30) NOT NULL DEFAULT '', verdict_note TEXT NULL, rating TINYINT NOT NULL DEFAULT 0, rating_note VARCHAR(300) NOT NULL DEFAULT '',
        x DOUBLE NOT NULL DEFAULT 0, y DOUBLE NOT NULL DEFAULT 0, z DOUBLE NOT NULL DEFAULT 0, street VARCHAR(100) NOT NULL DEFAULT '',
        evidence LONGTEXT NULL,
        INDEX (status), INDEX (target), INDEX (reporter), INDEX (created), INDEX (claimed_by)
    )]],
    [[CREATE TABLE IF NOT EXISTS bb_reporters (
        id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, case_id INT NOT NULL, identifier VARCHAR(80) NOT NULL,
        name VARCHAR(80) NOT NULL DEFAULT '', anon TINYINT(1) NOT NULL DEFAULT 0, body TEXT NULL, trust INT NOT NULL DEFAULT 50, created INT NOT NULL DEFAULT 0,
        INDEX (case_id)
    )]],
    [[CREATE TABLE IF NOT EXISTS bb_msgs (
        id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, case_id INT NOT NULL, channel VARCHAR(10) NOT NULL,
        role VARCHAR(8) NOT NULL, sender VARCHAR(80) NOT NULL DEFAULT '', sender_name VARCHAR(80) NOT NULL DEFAULT '',
        text VARCHAR(700) NOT NULL DEFAULT '', created INT NOT NULL, INDEX (case_id)
    )]],
    [[CREATE TABLE IF NOT EXISTS bb_events (
        id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, case_id INT NOT NULL, kind VARCHAR(16) NOT NULL,
        text VARCHAR(300) NOT NULL DEFAULT '', actor VARCHAR(80) NOT NULL DEFAULT '', created INT NOT NULL, INDEX (case_id)
    )]],
    [[CREATE TABLE IF NOT EXISTS bb_witness (
        id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, case_id INT NOT NULL, identifier VARCHAR(80) NOT NULL,
        name VARCHAR(80) NOT NULL DEFAULT '', role VARCHAR(10) NOT NULL DEFAULT 'witness', text VARCHAR(1000) NOT NULL DEFAULT '', created INT NOT NULL, INDEX (case_id)
    )]],
    [[CREATE TABLE IF NOT EXISTS bb_strikes (
        id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, identifier VARCHAR(80) NOT NULL, name VARCHAR(80) NOT NULL DEFAULT '',
        case_id INT NOT NULL DEFAULT 0, verdict VARCHAR(30) NOT NULL DEFAULT '', label VARCHAR(60) NOT NULL DEFAULT '',
        points INT NOT NULL DEFAULT 0, note VARCHAR(300) NOT NULL DEFAULT '', staff VARCHAR(80) NOT NULL DEFAULT '', created INT NOT NULL, INDEX (identifier)
    )]],
    [[CREATE TABLE IF NOT EXISTS bb_notifs (
        id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, identifier VARCHAR(80) NOT NULL, case_id INT NOT NULL DEFAULT 0,
        text VARCHAR(300) NOT NULL, created INT NOT NULL, INDEX (identifier)
    )]],
}

function DB.migrate()
    for _, q in ipairs(create) do MySQL.query.await(q) end
    MySQL.query.await("REPLACE INTO bb_meta (k, v) VALUES ('schema', '1')")
end

-- Loads (or creates) the row for a player and returns it
function DB.loadPlayer(identifier, name, license)
    local row = MySQL.single.await('SELECT * FROM bb_players WHERE identifier = ?', { identifier })
    if row then
        if name and name ~= row.name or (license and license ~= row.license) then
            MySQL.update('UPDATE bb_players SET name = ?, license = ? WHERE identifier = ?', { name or row.name, license or row.license, identifier })
            row.name, row.license = name or row.name, license or row.license
        end
        if row.pub == '' then
            row.pub = BB.newPub()
            MySQL.update('UPDATE bb_players SET pub = ? WHERE identifier = ?', { row.pub, identifier })
        end
        BB.setPub(identifier, row.pub)
        return row
    end
    local pub = BB.newPub()
    row = {
        identifier = identifier, pub = pub, name = name or '', license = license or '', trust = BB.get('trustStart'), repban_until = 0,
        watch = 0, watch_note = '', filed = 0, valid = 0, falsed = 0, last_report = 0, trust_day = BB.dayKey(), created = BB.now(),
    }
    MySQL.insert.await('INSERT INTO bb_players (identifier, pub, name, license, trust, trust_day, created) VALUES (?,?,?,?,?,?,?)',
        { identifier, pub, row.name, row.license, row.trust, row.trust_day, row.created })
    BB.setPub(identifier, pub)
    return row
end

function BB.dayKey(t) return os.date('%Y-%m-%d', t or os.time()) end

function DB.loadPubs()
    for _, r in ipairs(MySQL.query.await("SELECT identifier, pub FROM bb_players WHERE pub <> ''") or {}) do BB.setPub(r.identifier, r.pub) end
end
