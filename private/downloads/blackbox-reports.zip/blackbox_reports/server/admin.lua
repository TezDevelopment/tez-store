-- Admin access, logging, Discord and everything behind /bbadmin

BB.roleCache = {}

local function httpRequest(url, method, body, headers)
    local p = promise.new()
    PerformHttpRequest(url, function(status, text) p:resolve({ status = status, body = text }) end, method, body or '', headers or {})
    return Citizen.Await(p)
end
BB.httpRequest = httpRequest

-- ---------------------------------------------------------------- access

local function discordRoles(src, allowFetch)
    local token, guild = BB.secrets.discordToken, BB.get('discordGuild')
    if not token or token == '' or not guild or guild == '' then return nil end
    local c = BB.roleCache[src]
    local now = BB.now()
    if c and c.exp > now then return c.roles end
    if not allowFetch then return c and c.roles or nil end
    local did = GetPlayerIdentifierByType(src, 'discord')
    if not did then return nil end
    did = did:gsub('discord:', '')
    local res = httpRequest(('https://discord.com/api/v10/guilds/%s/members/%s'):format(guild, did), 'GET', '', { Authorization = 'Bot ' .. token })
    local data = res.status == 200 and BB.jdec(res.body, nil) or nil
    local roles = data and data.roles or {}
    BB.roleCache[src] = { roles = roles, exp = now + 60 }
    return roles
end

function BB.hasDiscordRole(src, wanted, cachedOnly)
    if not wanted or #wanted == 0 then return false end
    local roles = discordRoles(src, not cachedOnly)
    if not roles then return false end
    for _, w in ipairs(wanted) do
        for _, r in ipairs(roles) do if tostring(r) == tostring(w) then return true end end
    end
    return false
end

local function permission(src, ace, groupKey, roleKey, cachedOnly)
    if src == 0 then return true end
    if IsPlayerAceAllowed(src, ace) then return true end
    if Bridge.inGroup(src, BB.get(groupKey)) then return true end
    local roles = BB.get(roleKey)
    if roles and #roles > 0 and BB.hasDiscordRole(src, roles, cachedOnly) then return true end
    return false
end

function BB.isAdmin(src, cachedOnly) return permission(src, 'blackbox.admin', 'adminGroups', 'adminRoles', cachedOnly) end
function BB.isStaff(src, cachedOnly) return BB.isAdmin(src, cachedOnly) or permission(src, 'blackbox.staff', 'staffGroups', 'staffRoles', cachedOnly) end

-- ------------------------------------------------------------------ logging

local logCount = 0
local categoryFlag = {
    claim = 'logClaim', verdict = 'logVerdict', escalate = 'logEscalate', rating = 'logRatings', staff = 'logStaff', settings = 'logAdminChanges', new = 'logNew',
}
local ownEmbed = { new = true, verdict = true, escalate = true }

function BB.embed(title, desc, color, fields, flagKey, content)
    local hook = BB.secrets.logWebhook
    if not BB.get('logToWebhook') or not hook or hook == '' then return end
    if flagKey and not BB.get(flagKey) then return end
    PerformHttpRequest(hook, function() end, 'POST', json.encode({
        username = BB.get('brand'), content = content,
        embeds = { { title = tostring(title):sub(1, 250), description = tostring(desc or ''):sub(1, 1900), color = color or 16744960, fields = fields, timestamp = os.date('!%Y-%m-%dT%H:%M:%SZ') } },
    }), { ['Content-Type'] = 'application/json' })
end

function BB.log(category, message, actorSrc)
    local flag = categoryFlag[category]
    if flag and not BB.get(flag) then return end
    local actor = ''
    if actorSrc and BB.players[actorSrc] then actor = BB.players[actorSrc].name end
    MySQL.insert('INSERT INTO bb_logs (category, message, actor, created) VALUES (?,?,?,?)', { category, tostring(message):sub(1, 500), actor, BB.now() })
    logCount = logCount + 1
    if logCount % 200 == 0 then
        MySQL.update('DELETE FROM bb_logs WHERE id < (SELECT m FROM (SELECT MAX(id) - 3000 AS m FROM bb_logs) t)')
    end
    if not ownEmbed[category] then
        BB.embed(category, actor ~= '' and (actor .. ': ' .. message) or message, nil, nil, flag)
    end
end

-- ------------------------------------------------------------------- status

function BB.status()
    local w = {}
    if not Bridge.hasMoney() then w[#w + 1] = L('warn.nomoney') end
    if BB.get('logToWebhook') and (BB.secrets.logWebhook or '') == '' then w[#w + 1] = L('warn.nowebhook') end
    local usesRoles = #(BB.get('adminRoles') or {}) > 0 or #(BB.get('staffRoles') or {}) > 0
    if usesRoles and ((BB.secrets.discordToken or '') == '' or BB.get('discordGuild') == '') then w[#w + 1] = L('warn.nodiscord') end
    local uses = {}
    for _, v in ipairs(BB.get('verdicts')) do uses[v.action] = true end
    if uses.ban and BB.get('banCommand') == '' then w[#w + 1] = L('warn.noban') end
    if uses.jail and BB.get('jailCommand') == '' then w[#w + 1] = L('warn.nojail') end
    for _, c in ipairs(BB.get('categories')) do
        if c.fix ~= '' and not BB.fixById(c.fix) then w[#w + 1] = L('warn.fix', c.label, c.fix) end
    end
    if #(BB.get('blockedWords') or {}) == 0 then w[#w + 1] = L('warn.noblocked') end
    if not BB.get('recEnabled') then w[#w + 1] = L('warn.norec') end
    if BB.dutyCount() == 0 then w[#w + 1] = L('warn.noduty') end
    if BB.latestVersion and BB.latestVersion ~= BB.version then w[#w + 1] = L('warn.update', BB.latestVersion) end
    return { framework = Bridge.framework, version = BB.version, warnings = w, online = BB.count(BB.players), duty = BB.dutyCount() }
end

function BB.checkVersion()
    BB.version = GetResourceMetadata(GetCurrentResourceName(), 'version', 0) or '1.0.0'
    if not Config.VersionUrl or Config.VersionUrl == '' then return end
    PerformHttpRequest(Config.VersionUrl, function(status, body)
        if status == 200 and body then
            local v = body:match('[%d%.]+')
            if v then BB.latestVersion = v end
        end
    end, 'GET')
end

-- ------------------------------------------------------------------ the panel

function BB.adminPayload()
    local values, secretSet, fields = {}, {}, {}
    for _, f in ipairs(Schema.fields) do
        if f.secret then secretSet[f.k] = (BB.secrets[f.k] or '') ~= '' values[f.k] = '' else values[f.k] = BB.S[f.k] end
        fields[#fields + 1] = { k = f.k, p = f.p, t = f.t, d = f.d, l = f.l, h = f.h, min = f.min, max = f.max, opts = f.opts, secret = f.secret, sub = f.sub, restart = f.restart }
    end
    return { pages = Schema.pages, fields = fields, values = values, secretSet = secretSet, status = BB.status(), last = BB.last }
end

local function others(src, event, payload)
    for s in pairs(BB.panel) do
        if s ~= src and BB.players[s] then TriggerClientEvent(event, s, payload) end
    end
end

BB.AdminActions = {
    open = function(src) BB.panel[src] = true return true, BB.adminPayload() end,
    close = function(src) BB.panel[src] = nil return true end,

    save = function(src, d)
        local ok, err, changed, diffs = BB.saveSettings(src, d.values, d.clear)
        if not ok then return false, err end
        if #changed > 0 then
            local who = BB.players[src] and BB.players[src].name or 'console'
            for _, x in ipairs(diffs) do BB.log('settings', ('%s changed %s: %s -> %s'):format(who, x.k, x.old, x.new), src) end
            others(src, 'bb:adminSaved', { by = who, keys = changed, payload = BB.adminPayload() })
        end
        return true, BB.adminPayload()
    end,

    history = function(src, d) return true, BB.history(type(d.key) == 'string' and d.key or nil, 40) end,

    logs = function(src, d)
        local page = math.max(1, math.floor(tonumber(d.page) or 1))
        local per = 20
        local rows = MySQL.query.await('SELECT category, message, actor, created FROM bb_logs ORDER BY id DESC LIMIT ? OFFSET ?', { per, (page - 1) * per }) or {}
        local total = MySQL.scalar.await('SELECT COUNT(*) FROM bb_logs') or 0
        return true, { rows = rows, page = page, per = per, total = total }
    end,

    players = function(src) return true, BB.staffPlayers(src, '') end,

    test = function(src, d)
        if d.kind == 'webhook' then
            local hook = BB.secrets.logWebhook
            if not hook or hook == '' then return false, L('err.nowebhook') end
            local res = httpRequest(hook, 'POST', json.encode({ username = BB.get('brand'), content = L('admin.testmessage') }), { ['Content-Type'] = 'application/json' })
            if res.status and res.status >= 200 and res.status < 300 then return true, { text = L('admin.testok') } end
            return false, L('admin.testfail', tostring(res.status))
        elseif d.kind == 'digest' then
            BB.sendDigest()
            return true, { text = L('admin.testok') }
        end
        return false, L('err.badvalue')
    end,
}
