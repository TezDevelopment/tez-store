-- Shared state and helpers for the server side

BB = {
    players = {},         -- src -> { id = identifier, license, name, pub }
    bySrc = {},           -- identifier -> src
    duty = {},            -- src -> true while on duty
    panel = {},           -- src -> true while the admin panel is open
    desk = {},            -- src -> true while the staff desk is open
    S = {},               -- current settings
    secrets = {},
    last = {},            -- setting key -> { by, at }
    version = '1.0.0',
    ready = false,
}

function BB.now() return os.time() end

function BB.clamp(v, a, b)
    if v < a then return a end
    if v > b then return b end
    return v
end

function BB.trim(s)
    if type(s) ~= 'string' then return '' end
    return (s:gsub('^%s+', ''):gsub('%s+$', ''):gsub('%c', ' '))
end

function BB.get(key)
    local v = BB.S[key]
    if v == nil and Schema.byKey[key] then return Schema.byKey[key].d end
    return v
end

function BB.count(t) local n = 0 for _ in pairs(t) do n = n + 1 end return n end

function BB.jenc(v) return json.encode(v) end
function BB.jdec(s, fallback)
    if type(s) ~= 'string' or s == '' then return fallback end
    local ok, r = pcall(json.decode, s)
    if ok and r ~= nil then return r end
    return fallback
end

function BB.debug(...) if Config.Debug then print('[blackbox_reports]', ...) end end

-- ------------------------------------------------------------- blocked words

local leet = { ['0'] = 'o', ['1'] = 'i', ['3'] = 'e', ['4'] = 'a', ['5'] = 's', ['7'] = 't', ['@'] = 'a', ['$'] = 's', ['!'] = 'i' }

function BB.normalize(s)
    s = tostring(s or ''):lower()
    s = s:gsub('[013457@%$!]', function(c) return leet[c] or c end)
    s = s:gsub('[^%a]', '')
    s = s:gsub('(%a)%1+', '%1')
    return s
end

function BB.hasBlocked(text)
    local words = BB.get('blockedWords')
    if not words or #words == 0 then return false end
    local n = BB.normalize(text)
    for _, w in ipairs(words) do
        local nw = BB.normalize(w)
        if #nw >= 2 and n:find(nw, 1, true) then return true end
    end
    return false
end

-- returns ok, text
function BB.filter(text)
    text = BB.trim(text)
    if not BB.hasBlocked(text) then return true, text end
    if BB.get('blockMode') == 'stop' then return false end
    for _, w in ipairs(BB.get('blockedWords') or {}) do
        local esc = w:gsub('%p', '%%%0')
        text = text:gsub('%f[%w]' .. esc:lower() .. '%f[%W]', function(m) return ('*'):rep(#m) end)
        text = text:gsub('%f[%w]' .. esc:upper() .. '%f[%W]', function(m) return ('*'):rep(#m) end)
    end
    if BB.hasBlocked(text) then text = ('*'):rep(math.min(#text, 12)) end
    return true, text
end

-- Only https links from approved hosts
function BB.validLink(url)
    if type(url) ~= 'string' or url == '' or #url > 400 then return false end
    if url:find('[%s"\'<>]') then return false end
    local host = url:match('^https://([^/%?#:]+)')
    if not host then return false end
    host = host:lower()
    for _, h in ipairs(BB.get('imageSites') or {}) do
        if host == h:lower() then return true, url end
    end
    return false
end

-- ------------------------------------------------------------------ rate limits

local buckets, flood = {}, {}

function BB.rate(src, key, ms)
    local t = GetGameTimer()
    buckets[src] = buckets[src] or {}
    local last = buckets[src][key] or -100000
    if t - last < ms then return false end
    buckets[src][key] = t
    return true
end

function BB.floodOk(src)
    local t = GetGameTimer()
    local f = flood[src]
    if not f or t - f.start > 5000 then flood[src] = { start = t, n = 1 } return true end
    f.n = f.n + 1
    return f.n <= 40
end

function BB.clearLimits(src) buckets[src] = nil flood[src] = nil end

-- --------------------------------------------------------------------- positions

function BB.coords(src)
    local ped = GetPlayerPed(src)
    if not ped or ped == 0 then return nil end
    return GetEntityCoords(ped)
end

function BB.distance(a, b)
    local ca, cb = BB.coords(a), BB.coords(b)
    if not ca or not cb then return 99999.0 end
    return #(ca - cb)
end

-- ------------------------------------------------------------------- messaging

function BB.notify(src, msg, kind)
    if not src then return end
    if Hooks and Hooks.notify and Hooks.notify(src, msg, kind) then return end
    TriggerClientEvent('bb:toast', src, msg, kind or 'info')
end

-- ------------------------------------------------------------------- players

-- Public ids: players only ever see these, never the real identifier
BB.pubToId, BB.idToPub = {}, {}
function BB.setPub(identifier, pub) BB.pubToId[pub] = identifier BB.idToPub[identifier] = pub end
function BB.pubOf(identifier) return BB.idToPub[identifier] end
function BB.fromPub(pub) return type(pub) == 'string' and BB.pubToId[pub] or nil end
function BB.newPub()
    local chars = 'abcdefghjkmnpqrstuvwxyz23456789'
    for _ = 1, 20 do
        local t = {}
        for i = 1, 8 do local r = math.random(1, #chars) t[i] = chars:sub(r, r) end
        local pub = table.concat(t)
        if not BB.pubToId[pub] then return pub end
    end
    return tostring(os.time() % 100000000)
end

function BB.idOf(src) local p = BB.players[src] return p and p.id or nil end

-- Find a loaded player (source) by identifier
function BB.srcOf(identifier) return BB.bySrc[identifier] end
