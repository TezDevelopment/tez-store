-- Start up, player join and leave, the request router, timers and exports

BB.ready = false

CreateThread(function()
    while GetResourceState('oxmysql') ~= 'started' do Wait(200) end
    DB.migrate()
    BB.loadSettings()
    BB.checkVersion()
    Bridge.init()
    DB.loadPubs()
    BB.ready = true
    print(('[blackbox_reports] ready. Framework: %s'):format(Bridge.framework))
    for _, id in ipairs(GetPlayers()) do BB.onJoin(tonumber(id)) end
end)

-- ================================================================== players

function BB.initPayload(src)
    local p = BB.players[src]
    local row = BB.pd[p.id]
    return {
        settings = BB.publicSettingsFor(src),
        me = {
            pub = p.pub, name = p.name, src = src, trust = row and row.trust or 50,
            isStaff = BB.isStaff(src), isAdmin = BB.isAdmin(src), duty = BB.duty[src] == true,
        },
        now = BB.now(),
    }
end

function BB.onJoin(src)
    src = tonumber(src)
    if not BB.ready or not src or not GetPlayerName(src) then return end
    if BB.players[src] then return end
    local license = Bridge.license(src)
    if not license then return end
    local name = Bridge.name(src)
    local row = DB.loadPlayer(license, name, license)
    row.name = name
    BB.trustRecover(row)
    BB.pd[license] = row
    BB.players[src] = { id = license, name = name, pub = row.pub }
    BB.bySrc[license] = src
    if BB.isStaff(src) and BB.get('autoDuty') then BB.duty[src] = true end
    TriggerClientEvent('bb:init', src, BB.initPayload(src))
    BB.deliverPending(src)
    if row.watch == 1 or row.watch == true then
        for s in pairs(BB.duty) do
            if s ~= src and BB.players[s] then BB.notify(s, L('note.watchjoin', name, src, row.watch_note), 'warn') end
        end
    end
end

AddEventHandler('bb:internalLoaded', function(src) SetTimeout(2000, function() BB.onJoin(src) end) end)
RegisterNetEvent('bb:ready', function() BB.onJoin(source) end)

AddEventHandler('playerDropped', function(reason)
    local src = source
    local p = BB.players[src]
    if p then
        Rec.onDrop(src, reason)
        local row = BB.pd[p.id]
        if row then BB.saveRow(row) end
        if row and (row.watch == 1 or row.watch == true) then
            for s in pairs(BB.duty) do if BB.players[s] then BB.notify(s, L('note.watchleft', p.name), 'warn') end end
        end
        BB.pd[p.id] = nil
        BB.bySrc[p.id] = nil
    end
    BB.stopTracking(src)
    BB.players[src], BB.duty[src], BB.panel[src], BB.desk[src], BB.roleCache[src] = nil, nil, nil, nil, nil
    BB.clearLimits(src)
end)

-- ============================================================ request router

local A = {}
local fixUsed = {}

-- players
A.form = function(src) return true, BB.formInfo(src) end
A.search = function(src, d) return true, BB.playerSearch(src, d.q) end
A.suggest = function(src, d)
    if not BB.get('autoCategory') then return true, nil end
    return true, BB.suggestCategory(tostring(d.text or ''):sub(1, 800))
end
A.file = function(src, d) return BB.fileReport(src, d) end
A.mine = function(src) return true, BB.myCases(src) end
A.thread = function(src, d)
    local t = BB.thread(src, d.id, tostring(d.channel))
    if not t then return false, L('err.gone') end
    return true, t
end
A.send = function(src, d) return BB.sendMessage(src, d.id, tostring(d.channel), d.text) end
A.rate = function(src, d) return BB.rateCase(src, d.id, d.stars, d.note) end
A.fix = function(src, d)
    if not BB.get('fixesOn') then return false, L('err.disabled') end
    local f = BB.fixById(tostring(d.id))
    local p = BB.players[src]
    if not f or not f.enabled or not p then return false, L('err.badvalue') end
    local hurt = tonumber(d.hurt)
    if f.combatLock > 0 and hurt and hurt < f.combatLock then return false, L('err.combat', math.ceil(f.combatLock - hurt)) end
    fixUsed[p.id] = fixUsed[p.id] or {}
    local last = fixUsed[p.id][f.id]
    if last and BB.now() - last < f.cooldown then return false, L('err.cooldown', f.cooldown - (BB.now() - last)) end
    fixUsed[p.id][f.id] = BB.now()
    TriggerClientEvent('bb:doFix', src, f.kind)
    return true
end

-- staff
A.duty = function(src, d)
    if not BB.isStaff(src) then return false, L('err.noperm') end
    BB.setDuty(src, d.on == true)
    return true
end
A.deskState = function(src, d)
    if not BB.isStaff(src) then return false, L('err.noperm') end
    BB.desk[src] = d.open == true or nil
    return true
end
A.deskList = function(src, d)
    if not BB.isStaff(src) then return false, L('err.noperm') end
    local list, meta = BB.deskList(src, d)
    if not list then return false, meta end
    return true, { list = list, meta = meta }
end
A.deskCase = function(src, d)
    local c, err = BB.caseDetail(src, d.id)
    if not c then return false, err end
    return true, c
end
A.claim = function(src, d) return BB.claim(src, d.id) end
A.release = function(src, d) return BB.release(src, d.id) end
A.handoff = function(src, d) return BB.handoff(src, d.id, d.pub) end
A.waiting = function(src, d) return BB.setWaiting(src, d.id, d.on == true) end
A.statement = function(src, d) return BB.requestStatement(src, d.id) end
A.close = function(src, d) return BB.close(src, d.id, d.verdict, d.note) end
A.reopen = function(src, d) return BB.reopen(src, d.id) end
A.jump = function(src, d) return BB.toolGoto(src, d.id, tostring(d.who)) end
A.bring = function(src, d) return BB.toolBring(src, d.id, tostring(d.who)) end
A.sendBack = function(src, d) return BB.toolSendBack(src, d.id, tostring(d.who)) end
A.spectate = function(src, d) return BB.toolSpectate(src, d.id, tostring(d.who)) end
A.ghost = function(src, d) return BB.ghostPlay(src, d.id, d.take) end
A.dutyList = function(src) return true, BB.dutyList() end
A.playerFile = function(src, d)
    local f, err = BB.playerFile(src, d.pub)
    if not f then return false, err end
    return true, f
end
A.staffPlayers = function(src, d) return true, BB.staffPlayers(src, d.q) end
A.watch = function(src, d) return BB.setWatch(src, d.pub, d.on == true, d.note) end
A.strike = function(src, d) return BB.manualStrike(src, d.pub, d.points, d.note) end
A.clearStrikes = function(src, d) return BB.clearStrikes(src, d.pub) end
A.trust = function(src, d) return BB.setTrust(src, d.pub, d.value) end
A.stats = function(src, d) return true, BB.staffStats(tostring(d.period)) end
A.insight = function(src, d) return true, BB.insight(d.days) end

local playerActions = { form = true, search = true, suggest = true, file = true, mine = true, thread = true, send = true, rate = true, fix = true }

local function reply(src, rid, good, payload) TriggerClientEvent('bb:res', src, rid, good == true, payload) end

RegisterNetEvent('bb:req', function(rid, action, data)
    local src = source
    if type(rid) ~= 'number' or type(action) ~= 'string' then return end
    if not BB.ready then return reply(src, rid, false, L('err.starting')) end
    if not BB.floodOk(src) then return reply(src, rid, false, L('err.slowdown')) end
    if type(data) ~= 'table' then data = {} end

    local handler
    if action:sub(1, 6) == 'admin.' then
        if not BB.isAdmin(src) then
            BB.log('staff', ('Blocked admin request "%s" from %s'):format(action, GetPlayerName(src) or src), src)
            return reply(src, rid, false, L('err.noperm'))
        end
        handler = BB.AdminActions[action:sub(7)]
    else
        if not BB.players[src] then
            BB.onJoin(src)
            if not BB.players[src] then return reply(src, rid, false, L('err.notloaded')) end
        end
        handler = A[action]
        if handler and not playerActions[action] and not BB.isStaff(src) then
            return reply(src, rid, false, L('err.noperm'))
        end
    end
    if not handler then return reply(src, rid, false, L('err.badvalue')) end

    local good, a, b = pcall(handler, src, data)
    if not good then
        print(('[blackbox_reports] error in "%s": %s'):format(action, tostring(a)))
        return reply(src, rid, false, L('err.internal'))
    end
    reply(src, rid, a, b)
end)

-- the reporter's own game: deaths feed the recorder and the post-death prompt
RegisterNetEvent('bb:died', function(killer, weapon, x, y, z)
    local src = source
    if not BB.players[src] or not BB.rate(src, 'died', 4000) then return end
    killer = tonumber(killer)
    if killer == src then killer = nil end
    Rec.addDeath(src, killer, weapon, x, y, z)
end)

RegisterNetEvent('bb:witness', function(caseId, said, text)
    local src = source
    if not BB.players[src] or not BB.rate(src, 'witness', 1500) then return end
    local ok, err = BB.witnessAnswer(src, math.floor(tonumber(caseId) or 0), said == true, text)
    if not ok and err then BB.notify(src, err, 'error') end
end)

-- ================================================================ timers

CreateThread(function()
    while not BB.ready do Wait(500) end
    local n, digestDay = 0, nil
    while true do
        Wait(1000)
        n = n + 1
        local ok, err = pcall(function()
            BB.caseTick(n)
            BB.trackTick()
            local hour = BB.get('digestHour')
            if hour >= 0 and n % 60 == 0 then
                local d = os.date('*t')
                if d.hour == hour and digestDay ~= BB.dayKey() then digestDay = BB.dayKey() BB.sendDigest() end
            end
        end)
        if not ok then print('[blackbox_reports] timer error: ' .. tostring(err)) end
    end
end)

AddEventHandler('onResourceStop', function(name)
    if name ~= GetCurrentResourceName() then return end
    for _, row in pairs(BB.pd) do BB.saveRow(row) end
end)

-- ================================================================ exports

exports('AutoReport', function(targetSrc, category, reason, meta) return BB.autoReport(targetSrc, category, reason, meta) end)
exports('GetTrust', function(src) local p = BB.players[tonumber(src)] local r = p and BB.pd[p.id] return r and r.trust or nil end)
exports('GetRisk', function(src) local p = BB.players[tonumber(src)] return p and BB.risk(p.id) or nil end)
exports('IsOnDuty', function(src) return BB.duty[tonumber(src)] == true end)
