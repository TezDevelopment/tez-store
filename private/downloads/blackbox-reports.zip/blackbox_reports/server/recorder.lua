-- The flight recorder.
-- The SERVER samples every player every few seconds and keeps the last minute. A report copies the part
-- that matters (the reporter, the accused and everyone nearby), so the trail can not be edited by the reporter.
-- The reporter's own game adds shots, hits and deaths on top of that.

Rec = { trails = {}, gone = {}, deaths = {}, dense = {}, pm = {}, clips = {} }

local function round1(n) return math.floor((tonumber(n) or 0) * 10 + 0.5) / 10 end

local function ringSize()
    return math.ceil(BB.get('recSeconds') / math.max(1, BB.get('recInterval'))) + 2
end

function Rec.sample()
    if not BB.get('recEnabled') then return end
    local now = BB.now()
    local size = ringSize()
    for src in pairs(BB.players) do
        local ped = GetPlayerPed(src)
        if ped and ped ~= 0 then
            local c = GetEntityCoords(ped)
            local tr = Rec.trails[src]
            if not tr then tr = {} Rec.trails[src] = tr end
            tr[#tr + 1] = {
                t = now, x = c.x, y = c.y, z = c.z, h = GetEntityHeading(ped), hp = GetEntityHealth(ped),
                ar = GetPedArmour(ped), v = GetVehiclePedIsIn(ped, false) ~= 0, s = GetEntitySpeed(ped),
            }
            while #tr > size do table.remove(tr, 1) end
        end
    end
    for pub, g in pairs(Rec.gone) do
        if now - g.at > 900 then Rec.gone[pub] = nil end
    end
    while #Rec.deaths > 0 and now - Rec.deaths[1].t > 900 do table.remove(Rec.deaths, 1) end
end

-- the player left: keep the trail for a while (this catches players who leave in the middle of a scene)
function Rec.onDrop(src, reason)
    local p = BB.players[src]
    local tr = Rec.trails[src]
    Rec.trails[src] = nil
    if not p or not tr or #tr == 0 then Rec.dense[src], Rec.pm[src] = nil, nil return end
    local last = tr[#tr]
    Rec.gone[p.pub] = { id = p.id, name = p.name, at = BB.now(), reason = tostring(reason or ''):sub(1, 80), trail = tr, x = last.x, y = last.y, z = last.z, dense = Rec.dense[src], pm = Rec.pm[src] }
    Rec.dense[src], Rec.pm[src] = nil, nil
end

-- players who left in the last minutes (for the "who did you mean" list)
function Rec.leftList()
    local out, now = {}, BB.now()
    for pub, g in pairs(Rec.gone) do
        out[#out + 1] = { pub = pub, name = g.name, ago = now - g.at, reason = g.reason }
    end
    table.sort(out, function(a, b) return a.ago < b.ago end)
    while #out > 10 do table.remove(out) end
    return out
end

-- a player died (reported by their own game)
function Rec.addDeath(victimSrc, killerSrc, weapon, x, y, z)
    local v = BB.players[victimSrc]
    if not v then return end
    local k = killerSrc and BB.players[killerSrc] or nil
    Rec.deaths[#Rec.deaths + 1] = {
        t = BB.now(), victim = v.pub, vname = v.name, killer = k and k.pub or nil, kname = k and k.name or nil,
        w = tostring(weapon or ''):sub(1, 24), x = tonumber(x) or 0, y = tonumber(y) or 0, z = tonumber(z) or 0,
    }
    if #Rec.deaths > 200 then table.remove(Rec.deaths, 1) end
    Rec.captureClip(victimSrc, killerSrc)
end

-- who killed this player most recently (used to prefill the report)
function Rec.lastKillerOf(pub, withinSecs)
    local now = BB.now()
    for i = #Rec.deaths, 1, -1 do
        local d = Rec.deaths[i]
        if d.victim == pub and now - d.t <= (withinSecs or 120) then return d end
    end
    return nil
end


-- ------------------------------------------------------------------ ghost replay
-- A second, denser recorder just for the in-world replay. Every few hundred milliseconds it keeps where each player is, which way they
-- face, the vehicle model they are in and its tilt. When someone dies a clip is saved on the spot (plus a few seconds after), so a report
-- filed minutes later still shows the hit. A frame is { t, x, y, z, heading, vehicleModel, pitch, roll, speed, dead }.

local function ghostRingSize()
    return math.ceil(BB.get('ghostSeconds') / (math.max(250, BB.get('ghostInterval')) / 1000)) + 6
end

function Rec.sampleDense()
    if not BB.get('recEnabled') or not BB.get('ghostEnabled') then
        if next(Rec.dense) then Rec.dense = {} end
        return
    end
    local now = GetGameTimer()
    local size = ghostRingSize()
    for src in pairs(BB.players) do
        local ped = GetPlayerPed(src)
        if ped and ped ~= 0 then
            local ring = Rec.dense[src]
            if not ring then ring = {} Rec.dense[src] = ring end
            local veh = GetVehiclePedIsIn(ped, false)
            local f
            if veh and veh ~= 0 then
                local c, rot = GetEntityCoords(veh), GetEntityRotation(veh)
                f = { t = now, x = c.x, y = c.y, z = c.z, h = GetEntityHeading(veh), vm = GetEntityModel(veh), p = rot.x, r = rot.y, sp = GetEntitySpeed(veh), d = 0 }
            else
                local c = GetEntityCoords(ped)
                f = { t = now, x = c.x, y = c.y, z = c.z, h = GetEntityHeading(ped), vm = 0, p = 0, r = 0, sp = GetEntitySpeed(ped), d = GetEntityHealth(ped) <= 105 and 1 or 0 }
            end
            ring[#ring + 1] = f
            while #ring > size do table.remove(ring, 1) end
            if not Rec.pm[src] then Rec.pm[src] = GetEntityModel(ped) end
        end
    end
    local t = BB.now()
    local maxAge = BB.get('ghostClipAge')
    for pub, c in pairs(Rec.clips) do if t - c.at > maxAge then Rec.clips[pub] = nil end end
end

-- entries = { { pub, name, role, ring, pm } ... } already in priority order; endMs = server time of the last frame
local function buildGhost(entries, endMs, span, endAt)
    local g = { v = 1, at = endAt, span = span, actors = {}, marks = {} }
    local lo = 0
    for _, e in ipairs(entries) do
        if #g.actors >= BB.get('ghostMaxActors') then break end
        local f = {}
        for _, s in ipairs(e.ring or {}) do
            local ago = (endMs - s.t) / 1000
            if ago <= span and ago >= -0.5 then
                f[#f + 1] = { -round1(math.max(ago, 0)), round1(s.x), round1(s.y), round1(s.z), math.floor(s.h + 0.5), s.vm, round1(s.p), round1(s.r), round1(s.sp), s.d }
            end
        end
        if #f >= 2 then
            if f[1][1] < lo then lo = f[1][1] end
            g.actors[#g.actors + 1] = { pub = e.pub, name = e.name, role = e.role, pm = e.pm or 0, f = f }
        end
    end
    if #g.actors == 0 then return nil end
    g.lo = lo
    return g
end

local function entryFor(src, role)
    local p = BB.players[src]
    if not p then return nil end
    return { pub = p.pub, name = p.name, role = role, ring = Rec.dense[src], pm = Rec.pm[src] }
end

local function hasPub(g, pub)
    for _, a in ipairs(g.actors) do if a.pub == pub then return true end end
    return false
end

-- deaths (and the reporter's own hits) that fall inside the clip, with times relative to its end
local function addMarks(g, extra)
    local actors = {}
    for _, a in ipairs(g.actors) do actors[a.pub] = true end
    for _, d in ipairs(Rec.deaths) do
        local t = d.t - g.at
        if t >= g.lo - 1 and t <= 12 and (actors[d.victim] or (d.killer and actors[d.killer])) then
            g.marks[#g.marks + 1] = { t = t, k = 'dead', x = round1(d.x), y = round1(d.y), z = round1(d.z), w = d.w, who = d.victim, other = d.killer }
        end
    end
    for _, e in ipairs(extra or {}) do
        if (e.k == 'hurt' or e.k == 'hit' or e.k == 'shot') and #g.marks < 60 and e.t >= g.lo then
            g.marks[#g.marks + 1] = { t = e.t, k = e.k, x = e.x, y = e.y, z = e.z, w = e.w, who = e.who, other = e.other }
        end
    end
    table.sort(g.marks, function(a, b) return a.t < b.t end)
    for _, m in ipairs(g.marks) do
        if m.k == 'dead' then g.focus = m.t break end
    end
    if not g.focus then
        for _, m in ipairs(g.marks) do if m.k == 'hurt' or m.k == 'hit' then g.focus = m.t break end end
    end
end

-- saved when somebody dies: the victim, the killer and whoever was close
function Rec.captureClip(victimSrc, killerSrc)
    if not BB.get('recEnabled') or not BB.get('ghostEnabled') then return end
    local v = BB.players[victimSrc]
    if not v then return end
    local vpub = v.pub
    SetTimeout(math.max(0, BB.get('ghostTail')) * 1000, function()
        local list = {}
        local entry = entryFor(victimSrc, 'victim')
        if not entry then return end
        list[#list + 1] = entry
        local seen = { [victimSrc] = true }
        if killerSrc and BB.players[killerSrc] then
            list[#list + 1] = entryFor(killerSrc, 'killer')
            seen[killerSrc] = true
        end
        local centre = BB.coords(victimSrc)
        if centre then
            local near = {}
            for s in pairs(BB.players) do
                if not seen[s] then
                    local c = BB.coords(s)
                    if c and #(c - centre) <= BB.get('recRadius') then near[#near + 1] = { s = s, d = #(c - centre) } end
                end
            end
            table.sort(near, function(a, b) return a.d < b.d end)
            for _, n in ipairs(near) do list[#list + 1] = entryFor(n.s, 'nearby') end
        end
        local g = buildGhost(list, GetGameTimer(), BB.get('ghostSeconds'), BB.now())
        if not g then return end
        addMarks(g)
        g.clip = true
        Rec.clips[vpub] = { at = BB.now(), ghost = g }
    end)
end

-- the ghost that goes with a report. A death clip of the reporter is used when it covers the accused; otherwise it is built from now.
-- list = actors of the snapshot, srcOf = pub -> server id, ev = the snapshot
function Rec.ghostForReport(opts, ev, list, srcOf)
    if not BB.get('ghostEnabled') then return nil end
    local roleOf = {}
    for _, a in ipairs(list) do roleOf[a.pub] = a.role end
    local accusedPub
    for _, a in ipairs(list) do if a.role == 'accused' then accusedPub = a.pub end end
    local reporterPub = opts.reporter and BB.players[opts.reporter] and BB.players[opts.reporter].pub or nil
    local clip = reporterPub and Rec.clips[reporterPub]
    if clip and BB.now() - clip.at <= BB.get('ghostClipAge') and (not accusedPub or hasPub(clip.ghost, accusedPub)) then
        local g = BB.jdec(BB.jenc(clip.ghost), nil)
        if g then
            for _, a in ipairs(g.actors) do a.role = roleOf[a.pub] or 'nearby' end
            return g
        end
    end
    local entries = {}
    for _, a in ipairs(list) do
        local src = srcOf[a.pub]
        if src then
            local e = entryFor(src, a.role)
            if e then entries[#entries + 1] = e end
        elseif opts.targetPub == a.pub and Rec.gone[a.pub] then
            local gone = Rec.gone[a.pub]
            entries[#entries + 1] = { pub = a.pub, name = gone.name, role = a.role, ring = gone.dense, pm = gone.pm }
        end
    end
    local g = buildGhost(entries, GetGameTimer(), BB.get('ghostSeconds'), BB.now())
    if g then addMarks(g, ev.events) end
    return g
end

-- ------------------------------------------------------------------ the snapshot

local function liveCoords(src)
    local tr = Rec.trails[src]
    local c = BB.coords(src)
    if c then return c end
    if tr and #tr > 0 then local l = tr[#tr] return vector3(l.x, l.y, l.z) end
    return nil
end

local function packTrail(samples, now, span)
    local out = {}
    for _, s in ipairs(samples) do
        local ago = now - s.t
        if ago <= span then
            out[#out + 1] = { -ago, round1(s.x), round1(s.y), round1(s.z), math.floor((s.h or 0) + 0.5), s.hp or 0, math.floor((s.s or 0) * 3.6 + 0.5), s.v and 1 or 0, s.ar or 0 }
        end
    end
    return out
end

-- flags that may mean cheating or a combat log. They are hints, not proof (doors, respawns and ambulances look like jumps).
local function analyse(actors, now)
    local flags = {}
    for pub, a in pairs(actors) do
        local tr = a.trail
        for i = 2, #tr do
            local p, q = tr[i - 1], tr[i]
            local dt = q[1] - p[1]
            if dt > 0 and p[6] > 105 and q[6] > 0 then
                local dx, dy = q[2] - p[2], q[3] - p[3]
                local d = math.sqrt(dx * dx + dy * dy)
                local sp = d / dt
                if p[8] == 0 and q[8] == 0 then
                    if d > 120 and sp > 60 then
                        flags[#flags + 1] = { k = 'jump', who = pub, t = q[1], v = math.floor(d) }
                    elseif sp > 14 and d > 20 then
                        flags[#flags + 1] = { k = 'fastfoot', who = pub, t = q[1], v = math.floor(sp * 3.6) }
                    end
                end
            end
        end
    end
    return flags
end

-- closest the reporter and the accused came to each other, and when
local function closest(a, b)
    if not a or not b then return nil end
    local best
    for _, p in ipairs(a.trail) do
        local q
        for _, c in ipairs(b.trail) do if not q or math.abs(c[1] - p[1]) < math.abs(q[1] - p[1]) then q = c end end
        if q and math.abs(q[1] - p[1]) <= (BB.get('recInterval') + 1) then
            local d = math.sqrt((p[2] - q[2]) ^ 2 + (p[3] - q[3]) ^ 2 + (p[4] - q[4]) ^ 2)
            if not best or d < best.d then best = { d = math.floor(d * 10 + 0.5) / 10, t = p[1] } end
        end
    end
    return best
end

local kinds = { shot = true, hit = true, hurt = true, veh = true, dead = true, kill = true }

local function cleanEvents(list, reporterPub, span)
    local out = {}
    if type(list) ~= 'table' then return out end
    for _, e in ipairs(list) do
        if #out >= 120 then break end
        if type(e) == 'table' and kinds[e.k] then
            local t = tonumber(e.t)
            if t and t >= 0 and t <= span then
                local other
                local o = tonumber(e.o)
                if o and BB.players[o] then other = BB.players[o].pub end
                out[#out + 1] = {
                    t = -math.floor(t * 10 + 0.5) / 10, k = e.k, who = reporterPub, other = other,
                    x = round1(e.x), y = round1(e.y), z = round1(e.z), w = tostring(e.w or ''):gsub('[%c<>"]', ''):sub(1, 24),
                }
            end
        end
    end
    return out
end

-- opts = { reporter = src|nil, target = src|nil, targetPub = pub|nil (player who left), events = list|nil, center = vector3|nil }
function Rec.snapshot(opts)
    local now = BB.now()
    local span = BB.get('recSeconds')
    local radius = BB.get('recRadius')
    local maxActors = BB.get('recMaxActors')
    local ev = { v = 1, at = now, span = span, actors = {}, events = {}, flags = {} }

    local list = {}
    local seen = {}
    local srcOf = {}
    local function addActor(src, role)
        if not src or seen[src] or not BB.players[src] then return end
        seen[src] = true
        srcOf[BB.players[src].pub] = src
        local p = BB.players[src]
        local tr = Rec.trails[src] or {}
        local live = BB.coords(src)
        local samples = {}
        for _, s in ipairs(tr) do samples[#samples + 1] = s end
        if live then
            local ped = GetPlayerPed(src)
            samples[#samples + 1] = { t = now, x = live.x, y = live.y, z = live.z, h = GetEntityHeading(ped), hp = GetEntityHealth(ped), ar = GetPedArmour(ped),
                v = GetVehiclePedIsIn(ped, false) ~= 0, s = GetEntitySpeed(ped) }
        end
        list[#list + 1] = { pub = p.pub, name = p.name, role = role, trail = packTrail(samples, now, span) }
    end

    addActor(opts.reporter, 'reporter')
    if opts.target then
        addActor(opts.target, 'accused')
    elseif opts.targetPub and Rec.gone[opts.targetPub] then
        local g = Rec.gone[opts.targetPub]
        local samples = {}
        for _, s in ipairs(g.trail) do samples[#samples + 1] = s end
        list[#list + 1] = { pub = opts.targetPub, name = g.name, role = 'accused', left = true, trail = packTrail(samples, now, span) }
        ev.left = { pub = opts.targetPub, name = g.name, ago = now - g.at, reason = g.reason }
    end

    -- everyone else in the scene, closest first
    local centers = {}
    if opts.reporter then local c = liveCoords(opts.reporter) if c then centers[#centers + 1] = c end end
    if opts.target then local c = liveCoords(opts.target) if c then centers[#centers + 1] = c end end
    if opts.targetPub and Rec.gone[opts.targetPub] then local g = Rec.gone[opts.targetPub] centers[#centers + 1] = vector3(g.x, g.y, g.z) end
    if opts.center then centers[#centers + 1] = opts.center end
    local near = {}
    for src in pairs(BB.players) do
        if not seen[src] then
            local c = liveCoords(src)
            if c then
                local best = 1e9
                for _, k in ipairs(centers) do local d = #(c - k) if d < best then best = d end end
                if best <= radius then near[#near + 1] = { src = src, d = best } end
            end
        end
    end
    table.sort(near, function(a, b) return a.d < b.d end)
    for _, n in ipairs(near) do
        if #list >= maxActors then break end
        addActor(n.src, 'nearby')
    end

    for _, a in ipairs(list) do ev.actors[a.pub] = { name = a.name, role = a.role, left = a.left, trail = a.trail } end

    -- events: the reporter's own game plus recorded deaths that involve anyone in the scene
    local reporterPub = opts.reporter and BB.players[opts.reporter] and BB.players[opts.reporter].pub or nil
    if reporterPub and BB.get('clientEvents') then
        for _, e in ipairs(cleanEvents(opts.events, reporterPub, span)) do ev.events[#ev.events + 1] = e end
    end
    for _, d in ipairs(Rec.deaths) do
        local ago = now - d.t
        if ago <= span and (ev.actors[d.victim] or (d.killer and ev.actors[d.killer])) then
            ev.events[#ev.events + 1] = { t = -ago, k = 'dead', who = d.victim, other = d.killer, x = round1(d.x), y = round1(d.y), z = round1(d.z), w = d.w }
        end
    end
    table.sort(ev.events, function(a, b) return a.t < b.t end)

    -- analysis
    local accusedPub
    for pub, a in pairs(ev.actors) do if a.role == 'accused' then accusedPub = pub end end
    ev.flags = analyse(ev.actors, now)
    if reporterPub and accusedPub then
        ev.closest = closest(ev.actors[reporterPub], ev.actors[accusedPub])
        for _, e in ipairs(ev.events) do
            if (e.k == 'hit' or e.k == 'hurt' or e.k == 'dead') and e.other and ((e.who == reporterPub and e.other == accusedPub) or (e.who == accusedPub and e.other == reporterPub)) then
                ev.combat = true
            end
        end
    end
    ev.count = #list
    -- the in-world replay
    local okg, g = pcall(Rec.ghostForReport, opts, ev, list, srcOf)
    if okg and g then ev.ghost = g elseif not okg then print('[blackbox_reports] ghost error: ' .. tostring(g)) end
    return ev
end

CreateThread(function()
    while not BB.ready do Wait(500) end
    while true do
        Wait(math.max(1, BB.get('recInterval')) * 1000)
        local ok, err = pcall(Rec.sample)
        if not ok then print('[blackbox_reports] recorder error: ' .. tostring(err)) end
    end
end)

CreateThread(function()
    while not BB.ready do Wait(500) end
    while true do
        Wait(math.max(250, BB.get('ghostInterval')))
        local ok, err = pcall(Rec.sampleDense)
        if not ok then print('[blackbox_reports] ghost recorder error: ' .. tostring(err)) end
    end
end)
