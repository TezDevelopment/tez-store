Locales = Locales or {}

function L(key, ...)
    local pack = Locales[Config.Locale] or Locales.en or {}
    local s = pack[key] or (Locales.en and Locales.en[key]) or key
    if select('#', ...) > 0 then
        local ok, r = pcall(string.format, s, ...)
        if ok then return r end
    end
    return s
end

-- The 11 permissions a rank can have
SquadPerms = {
    'invite', 'kick', 'wars', 'bounties', 'deposit', 'withdraw',
    'edit_name', 'edit_photo', 'edit_banner', 'edit_color', 'edit_settings',
}

OWNER_LEVEL = 100

PingTypes = {
    { id = 'go',      label = 'Go Here',        color = { 59, 130, 246 } },
    { id = 'enemy',   label = 'Enemy Spotted',  color = { 239, 68, 68 } },
    { id = 'danger',  label = 'Danger',         color = { 249, 115, 22 } },
    { id = 'loot',    label = 'Loot Here',      color = { 234, 179, 8 } },
    { id = 'defend',  label = 'Defend',         color = { 34, 197, 94 } },
    { id = 'vehicle', label = 'Vehicle Spotted',color = { 168, 85, 247 } },
    { id = 'enemyveh',label = 'Enemy Vehicle',  color = { 236, 72, 153 } },
}

DailyTasks = {
    { id = 'kills',    label = 'Get kills' },
    { id = 'time',     label = 'Minutes in a squad' },
    { id = 'messages', label = 'Send squad messages' },
    { id = 'pings',    label = 'Ping your squad' },
    { id = 'bounties', label = 'Complete bounties' },
    { id = 'wars',     label = 'Win KOS wars' },
}

function hexToRgb(hex)
    if type(hex) ~= 'string' then return 59, 130, 246 end
    local r, g, b = hex:match('^#(%x%x)(%x%x)(%x%x)$')
    if not r then return 59, 130, 246 end
    return tonumber(r, 16), tonumber(g, 16), tonumber(b, 16)
end
