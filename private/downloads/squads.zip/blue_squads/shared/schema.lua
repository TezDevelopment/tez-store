-- Every setting the admin panel can change.
-- t = type: bool, int, float, string, secret, color, select, list
-- Values are validated on the server with Schema.validate before they are saved.

Schema = { pages = {}, fields = {}, byKey = {} }

local function page(id, label) Schema.pages[#Schema.pages + 1] = { id = id, label = label } end

local function add(p, k, t, d, label, o)
    o = o or {}
    local f = { k = k, p = p, t = t, d = d, l = label, h = o.help, min = o.min, max = o.max, opts = o.opts, secret = (t == 'secret') }
    Schema.fields[#Schema.fields + 1] = f
    Schema.byKey[k] = f
end

page('general', 'General')
page('squads', 'Squads')
page('recruitment', 'Recruitment')
page('chat', 'Chat')
page('teamwork', 'Teamwork & radio')
page('abilities', 'Abilities')
page('wars', 'KOS wars')
page('bounties', 'Bounties')
page('bank', 'Squad bank')
page('tasks', 'Daily tasks')
page('xp', 'XP & levels')
page('world', 'World')
page('defaults', 'Player defaults')
page('moderation', 'Moderation')
page('logs', 'Logs')
page('permissions', 'Permissions')

-- General
add('general', 'themeColor', 'color', '#3b82f6', 'Theme colour', { help = 'Main colour of the menu for everyone (players can pick their own).' })
add('general', 'defaultMode', 'select', 'dark', 'Default mode', { opts = { 'dark', 'light' } })
add('general', 'menuKey', 'string', 'F9', 'Menu key', { max = 20, help = 'Default key. Applies after a player reconnects; players can still rebind it.' })

-- Squads
add('squads', 'squadMode', 'select', 'choice', 'Squad type', { opts = { 'choice', 'temporary', 'permanent' }, help = 'choice = the player picks when creating a squad.' })
add('squads', 'maxMembers', 'int', 40, 'Max members per squad', { min = 2, max = 128, help = 'Owners can pick any size up to this.' })
add('squads', 'nameMin', 'int', 3, 'Shortest squad name', { min = 1, max = 30 })
add('squads', 'nameMax', 'int', 20, 'Longest squad name', { min = 3, max = 40 })
add('squads', 'tagMax', 'int', 4, 'Longest tag', { min = 1, max = 8 })
add('squads', 'tagRequired', 'bool', false, 'Require a tag')
add('squads', 'createFee', 'int', 0, 'Cost to create a squad', { min = 0, max = 10000000 })
add('squads', 'friendlyFire', 'bool', false, 'Friendly fire on by default')
add('squads', 'maxRanks', 'int', 8, 'Max ranks per squad', { min = 1, max = 8 })
add('squads', 'graceMinutes', 'int', 10, 'Disconnect grace (minutes)', { min = 0, max = 120, help = 'A member who disconnects keeps their spot this long in a temporary squad.' })
add('squads', 'inactiveDays', 'int', 30, 'Remove unused permanent squads after (days)', { min = 0, max = 3650, help = '0 = never.' })

-- Recruitment
add('recruitment', 'inviteDistance', 'float', 25.0, 'Invite list distance (m)', { min = 3, max = 200 })
add('recruitment', 'inviteTimeout', 'int', 30, 'Invite lasts (seconds)', { min = 5, max = 300 })
add('recruitment', 'allowPassword', 'bool', true, 'Allow password squads')
add('recruitment', 'allowApply', 'bool', true, 'Allow apply-to-join squads')
add('recruitment', 'maxApplications', 'int', 50, 'Max waiting applications', { min = 1, max = 500 })
add('recruitment', 'targetInvite', 'bool', true, 'Invite by aiming (J)')
add('recruitment', 'useTargetResource', 'bool', true, 'Use ox_target / qb-target if installed')

-- Chat
add('chat', 'chatEnabled', 'bool', true, 'Squad chat enabled')
add('chat', 'quickChatEnabled', 'bool', true, 'Quick chat (Y) enabled')
add('chat', 'chatMaxLength', 'int', 160, 'Max message length', { min = 20, max = 400 })
add('chat', 'chatCooldown', 'int', 600, 'Cooldown between messages (ms)', { min = 0, max = 10000 })
add('chat', 'chatFeedSeconds', 'int', 10, 'Seconds a message stays on screen', { min = 2, max = 60 })

-- Teamwork
add('teamwork', 'ordersEnabled', 'bool', true, 'Teamwork orders enabled')
add('teamwork', 'orderRadius', 'float', 15.0, 'Order area radius (m)', { min = 3, max = 100 })
add('teamwork', 'orderHold', 'int', 30, 'Seconds to hold the area', { min = 5, max = 600 })
add('teamwork', 'orderMinMembers', 'int', 2, 'Members needed in the area', { min = 1, max = 20 })
add('teamwork', 'orderCooldown', 'int', 300, 'Order cooldown (seconds)', { min = 0, max = 7200 })
add('teamwork', 'orderCash', 'int', 500, 'Cash reward per member', { min = 0, max = 1000000 })
add('teamwork', 'orderXp', 'int', 50, 'XP reward per member', { min = 0, max = 100000 })
add('teamwork', 'radioEnabled', 'bool', true, 'Squad radio (pma-voice)')
add('teamwork', 'radioBase', 'int', 5000, 'First squad radio channel', { min = 1, max = 60000 })
add('teamwork', 'leadersChannel', 'int', 4999, 'Leaders radio channel', { min = 1, max = 60000 })
add('teamwork', 'leaderVoice', 'bool', true, 'Leaders-only radio')

-- Abilities
add('abilities', 'uavEnabled', 'bool', true, 'UAV scan enabled')
add('abilities', 'uavCost', 'int', 5000, 'UAV cost (from squad bank)', { min = 0, max = 10000000 })
add('abilities', 'uavCooldown', 'int', 300, 'UAV cooldown (seconds)', { min = 0, max = 86400 })
add('abilities', 'uavDuration', 'int', 30, 'UAV lasts (seconds)', { min = 5, max = 600 })
add('abilities', 'armorEnabled', 'bool', true, 'Armor resupply enabled')
add('abilities', 'armorCost', 'int', 3000, 'Armor resupply cost', { min = 0, max = 10000000 })
add('abilities', 'armorCooldown', 'int', 180, 'Armor resupply cooldown (seconds)', { min = 0, max = 86400 })
add('abilities', 'armorRadius', 'float', 25.0, 'Armor resupply radius (m)', { min = 3, max = 200 })
add('abilities', 'armorAmount', 'int', 100, 'Armor given', { min = 1, max = 100 })
add('abilities', 'xpBoostEnabled', 'bool', true, 'Double XP enabled')
add('abilities', 'xpBoostCost', 'int', 4000, 'Double XP cost', { min = 0, max = 10000000 })
add('abilities', 'xpBoostCooldown', 'int', 600, 'Double XP cooldown (seconds)', { min = 0, max = 86400 })
add('abilities', 'xpBoostDuration', 'int', 300, 'Double XP lasts (seconds)', { min = 30, max = 7200 })

-- Wars
add('wars', 'warsEnabled', 'bool', true, 'KOS wars enabled')
add('wars', 'warMin', 'int', 5, 'Shortest war (minutes)', { min = 1, max = 60 })
add('wars', 'warMax', 'int', 30, 'Longest war (minutes)', { min = 1, max = 120 })
add('wars', 'warRequestExpire', 'int', 60, 'Request expires after (seconds)', { min = 10, max = 600 })
add('wars', 'warCooldown', 'int', 600, 'Cooldown for the same two squads (seconds)', { min = 0, max = 86400 })
add('wars', 'warSurrender', 'bool', true, 'Allow surrender')

-- Bounties
add('bounties', 'bountiesEnabled', 'bool', true, 'Bounties enabled')
add('bounties', 'bountyMin', 'int', 500, 'Smallest bounty', { min = 1, max = 10000000 })
add('bounties', 'bountyMax', 'int', 100000, 'Largest bounty', { min = 1, max = 10000000 })
add('bounties', 'bountyHours', 'int', 24, 'Bounty lasts (hours)', { min = 1, max = 720 })
add('bounties', 'bountyAccount', 'select', 'bank', 'Pay from / pay to', { opts = { 'bank', 'cash' } })

-- Bank
add('bank', 'bankEnabled', 'bool', true, 'Squad bank enabled')
add('bank', 'bankAccount', 'select', 'bank', 'Player account used', { opts = { 'bank', 'cash' } })
add('bank', 'bankMaxBalance', 'int', 5000000, 'Max balance', { min = 1000, max = 1000000000 })
add('bank', 'bankChartPoints', 'int', 30, 'Chart points', { min = 5, max = 100 })

-- Tasks
add('tasks', 'tasksEnabled', 'bool', true, 'Daily tasks enabled')
add('tasks', 'tasksAccount', 'select', 'bank', 'Reward account', { opts = { 'bank', 'cash' } })
add('tasks', 'task_kills_goal', 'int', 10, 'Kills: goal', { min = 1, max = 10000 })
add('tasks', 'task_kills_reward', 'int', 1000, 'Kills: reward', { min = 0, max = 1000000 })
add('tasks', 'task_time_goal', 'int', 30, 'Time in squad (minutes): goal', { min = 1, max = 1440 })
add('tasks', 'task_time_reward', 'int', 800, 'Time in squad: reward', { min = 0, max = 1000000 })
add('tasks', 'task_messages_goal', 'int', 20, 'Squad messages: goal', { min = 1, max = 1000 })
add('tasks', 'task_messages_reward', 'int', 400, 'Squad messages: reward', { min = 0, max = 1000000 })
add('tasks', 'task_pings_goal', 'int', 10, 'Pings: goal', { min = 1, max = 1000 })
add('tasks', 'task_pings_reward', 'int', 400, 'Pings: reward', { min = 0, max = 1000000 })
add('tasks', 'task_bounties_goal', 'int', 1, 'Bounties completed: goal', { min = 1, max = 100 })
add('tasks', 'task_bounties_reward', 'int', 1500, 'Bounties completed: reward', { min = 0, max = 1000000 })
add('tasks', 'task_wars_goal', 'int', 1, 'KOS wars won: goal', { min = 1, max = 100 })
add('tasks', 'task_wars_reward', 'int', 2000, 'KOS wars won: reward', { min = 0, max = 1000000 })

-- XP
add('xp', 'xpEnabled', 'bool', true, 'XP & levels enabled')
add('xp', 'xpPerMinute', 'int', 5, 'XP per minute in a squad', { min = 0, max = 1000 })
add('xp', 'xpNearBonus', 'int', 3, 'Bonus XP per minute near squadmates', { min = 0, max = 1000, help = 'Permanent squads only.' })
add('xp', 'xpNearDistance', 'float', 40.0, 'Near distance (m)', { min = 5, max = 500 })
add('xp', 'xpPerKill', 'int', 10, 'XP per kill', { min = 0, max = 1000 })
add('xp', 'xpLevelBase', 'int', 100, 'XP scale per level', { min = 10, max = 100000, help = 'Level N needs about (N-1)^2 x this much XP.' })

-- World
add('world', 'tagDistance', 'float', 50.0, 'Nametag distance (m)', { min = 5, max = 300 })
add('world', 'tagFarMultiplier', 'float', 2.0, 'Nametag distance while holding side button', { min = 1, max = 5 })
add('world', 'blipsEnabled', 'bool', true, 'Teammate map blips')
add('world', 'radarEnabled', 'bool', true, 'Mini radar')
add('world', 'radarRange', 'float', 80.0, 'Mini radar range (m)', { min = 20, max = 500 })
add('world', 'rallyEnabled', 'bool', true, 'Rally points')
add('world', 'pingRange', 'float', 600.0, 'Ping range (m)', { min = 50, max = 3000 })
add('world', 'pingDuration', 'int', 10, 'Ping lasts (seconds)', { min = 2, max = 60 })
add('world', 'pingCooldown', 'int', 700, 'Ping cooldown (ms)', { min = 100, max = 10000 })
add('world', 'liveInterval', 'int', 700, 'Squad data update (ms)', { min = 300, max = 3000, help = 'Higher = less network use on big servers.' })
add('world', 'verifyDamage', 'bool', true, 'Check kills against real damage')

-- Player defaults (every player can change their own in Settings)
add('defaults', 'def_mode', 'select', 'dark', 'Menu mode', { opts = { 'dark', 'light' } })
add('defaults', 'def_menuColor', 'color', '#3b82f6', 'Menu colour')
add('defaults', 'def_hudShow', 'bool', true, 'Show squad HUD')
add('defaults', 'def_hudX', 'float', 1.0, 'HUD position left (%)', { min = 0, max = 95 })
add('defaults', 'def_hudY', 'float', 30.0, 'HUD position top (%)', { min = 0, max = 95 })
add('defaults', 'def_hudScale', 'float', 1.0, 'HUD size', { min = 0.5, max = 2 })
add('defaults', 'def_hudOpacity', 'float', 1.0, 'HUD opacity', { min = 0.2, max = 1 })
add('defaults', 'def_hudCompact', 'bool', false, 'Compact HUD cards')
add('defaults', 'def_hudHealth', 'color', '#22c55e', 'HUD health colour')
add('defaults', 'def_hudArmor', 'color', '#3b82f6', 'HUD armor colour')
add('defaults', 'def_hudPhotoSide', 'select', 'left', 'HUD picture side', { opts = { 'left', 'right' } })
add('defaults', 'def_hudMax', 'int', 8, 'HUD members shown', { min = 1, max = 40 })
add('defaults', 'def_tags', 'bool', true, 'Nametags')
add('defaults', 'def_tagIds', 'bool', true, 'Show IDs on nametags')
add('defaults', 'def_tagHealth', 'bool', true, 'Show health on nametags')
add('defaults', 'def_blips', 'bool', true, 'Teammate blips')
add('defaults', 'def_blipColor', 'color', '', 'Teammate blip colour (empty = squad colour)')
add('defaults', 'def_radar', 'bool', true, 'Mini radar')
add('defaults', 'def_warBar', 'bool', true, 'War bar')
add('defaults', 'def_chatAlerts', 'bool', true, 'Chat alerts')
add('defaults', 'def_pingAlerts', 'bool', true, 'Ping alerts and sounds')

-- Moderation
add('moderation', 'blockedWords', 'list', {}, 'Blocked words', { help = 'Blocked in squad names, tags, profiles and notes, even with spaces or symbols between letters.' })
add('moderation', 'imageSites', 'list', { 'cdn.discordapp.com', 'media.discordapp.net', 'i.imgur.com', 'r2.fivemanage.com', 'i.postimg.cc', 'avatars.steamstatic.com', 'avatars.akamai.steamstatic.com' }, 'Approved image sites', { help = 'Squad and profile pictures can only come from these hosts.' })

-- Logs
add('logs', 'logWebhook', 'secret', '', 'Discord webhook URL', { max = 300, help = 'Never leaves the server. Leave empty to keep the saved one.' })
add('logs', 'logToWebhook', 'bool', false, 'Log to Discord')
add('logs', 'fivemanageKey', 'secret', '', 'Fivemanage API key', { max = 200, help = 'Never leaves the server.' })
add('logs', 'logToFivemanage', 'bool', false, 'Log to Fivemanage')
add('logs', 'logSquadEvents', 'bool', true, 'Also log squad events (create, disband, war)')

-- Permissions
add('permissions', 'adminGroups', 'list', { 'admin', 'god', 'superadmin', 'owner' }, 'Admin groups', { help = 'Framework groups that can open /squadsadmin. The ace squads.admin always works.' })
add('permissions', 'adminRoles', 'list', {}, 'Admin Discord role IDs', { help = 'Needs the Discord bot token and server ID below.' })
add('permissions', 'useGroups', 'list', {}, 'Only these groups can use squads', { help = 'Empty = everyone.' })
add('permissions', 'useRoles', 'list', {}, 'Only these Discord roles can use squads', { help = 'Empty = everyone.' })
add('permissions', 'discordGuild', 'string', '', 'Discord server ID', { max = 40 })
add('permissions', 'discordToken', 'secret', '', 'Discord bot token', { max = 200, help = 'Used for role checks and Discord profile pictures. Never leaves the server.' })
add('permissions', 'steamKey', 'secret', '', 'Steam Web API key', { max = 100, help = 'Optional, for Steam profile pictures.' })

function Schema.defaults()
    local out = {}
    for _, f in ipairs(Schema.fields) do
        if type(f.d) == 'table' then
            local copy = {}
            for i, v in ipairs(f.d) do copy[i] = v end
            out[f.k] = copy
        else
            out[f.k] = f.d
        end
    end
    return out
end

-- returns ok, cleanedValue
function Schema.validate(f, v)
    local t = f.t
    if t == 'bool' then
        if type(v) ~= 'boolean' then return false end
        return true, v
    elseif t == 'int' or t == 'float' then
        v = tonumber(v)
        if not v or v ~= v or v == math.huge or v == -math.huge then return false end
        if t == 'int' then v = math.floor(v + 0.5) end
        if (f.min and v < f.min) or (f.max and v > f.max) then return false end
        return true, v
    elseif t == 'string' or t == 'secret' then
        if type(v) ~= 'string' then return false end
        v = v:gsub('[%c]', ''):sub(1, f.max or 200)
        return true, v
    elseif t == 'color' then
        if type(v) ~= 'string' then return false end
        if v == '' and f.d == '' then return true, '' end
        if not v:match('^#%x%x%x%x%x%x$') then return false end
        return true, v:lower()
    elseif t == 'select' then
        for _, o in ipairs(f.opts or {}) do if o == v then return true, v end end
        return false
    elseif t == 'list' then
        if type(v) ~= 'table' or #v > 200 then return false end
        local out = {}
        for _, s in ipairs(v) do
            if type(s) ~= 'string' then return false end
            s = s:gsub('[%c]', ''):sub(1, 80)
            if s ~= '' then out[#out + 1] = s end
        end
        return true, out
    end
    return false
end
