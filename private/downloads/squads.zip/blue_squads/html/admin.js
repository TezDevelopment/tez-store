'use strict';
// Admin panel (/squadsadmin): every server setting, squads, players and logs. Changes apply live.

const AD = { data: null, dirty: {}, clear: {}, tab: 'status', search: '' };
const SETTING_ALIAS = { status: 'Status' };

PAGES.admin = {
  title: 'Admin panel', sub: 'Changes apply instantly. No restart needed.',
  async render(el) {
    if (!AD.data) {
      const r = await req('admin.open');
      if (!r.ok) { el.innerHTML = empty('No access', typeof r.payload === 'string' ? r.payload : ''); return; }
      AD.data = r.payload;
    }
    const tabs = [{ id: 'status', label: 'Status' }].concat(AD.data.pages.map(p => ({ id: p.id, label: p.label })), [{ id: '_squads', label: 'Manage squads' }, { id: '_players', label: 'Players' }, { id: '_logs', label: 'Log history' }]);
    el.innerHTML = `<div class="admin-wrap"><div class="admin-side" style="position:sticky;top:0;align-self:flex-start;max-height:100%">${tabs.map(t => `<button class="tab ${AD.tab === t.id ? 'active' : ''}" data-act="adTab" data-arg="${t.id}">${esc(t.label)}</button>`).join('')}</div>
      <div class="admin-main"><div id="ad-body" class="admin-body"></div><div id="ad-bar"></div></div></div>`;
    await renderAdminBody(); renderBar();
  },
};
ACT.adTab = el => { AD.tab = el.dataset.arg; AD.search = ''; refreshPage(); };
const dirtyCount = () => Object.keys(AD.dirty).length + Object.keys(AD.clear).length;

async function renderAdminBody() {
  const box = $('#ad-body'); if (!box) return;
  const t = AD.tab;
  if (t === 'status') return adStatus(box);
  if (t === '_squads') return adSquads(box);
  if (t === '_players') return adPlayers(box);
  if (t === '_logs') return adLogs(box);
  adSettings(box, t);
}

// ---- status
function adStatus(box) {
  const s = AD.data.status;
  box.innerHTML = `<div class="status-grid">
    <div class="stat"><b>${esc(s.version)}</b><span>Version</span></div><div class="stat"><b>${s.online}</b><span>Players</span></div><div class="stat"><b>${s.squads}</b><span>Squads</span></div><div class="stat"><b>${esc(s.framework)}</b><span>Framework</span></div></div>
    <div class="card"><div class="row-flex wrap"><span class="muted">Death detection:</span> <b>${esc(s.death)}</b> <span class="muted" style="margin-left:14px">Radio:</span> <b>${esc(s.radio)}</b></div></div>
    <div class="section">Things to check</div>${s.warnings.length ? s.warnings.map(w => `<div class="warn-box">${esc(w)}</div>`).join('') : '<div class="card" style="color:#4ade80">Everything looks good.</div>'}`;
}

// ---- settings pages
function curVal(f) { return Object.prototype.hasOwnProperty.call(AD.dirty, f.k) ? AD.dirty[f.k] : AD.data.values[f.k]; }
function adControl(f) {
  const v = curVal(f), k = esc(f.k);
  if (f.t === 'bool') return toggle(!!v, 'adBool', f.k);
  if (f.t === 'select') return `<select data-change="adField" data-k="${k}">${f.opts.map(o => `<option value="${esc(o)}" ${o === v ? 'selected' : ''}>${esc(o)}</option>`).join('')}</select>`;
  if (f.t === 'color') return `<input type="color" value="${esc(v || '#3b82f6')}" data-change="adField" data-k="${k}">${f.d === '' ? `<button class="btn tiny" data-act="adColorClear" data-arg="${k}">Clear</button>` : ''}<span class="muted">${esc(v || 'not set')}</span>`;
  if (f.t === 'int' || f.t === 'float') return `<input type="number" step="${f.t === 'int' ? 1 : 'any'}" ${f.min != null ? `min="${f.min}"` : ''} ${f.max != null ? `max="${f.max}"` : ''} value="${esc(v)}" data-input="adField" data-k="${k}">`;
  if (f.t === 'secret') {
    const set = AD.data.secretSet[f.k] && !AD.clear[f.k];
    return `<input type="password" autocomplete="off" placeholder="${set ? 'Saved (type to replace)' : 'Not set'}" value="${esc(AD.dirty[f.k] || '')}" data-input="adField" data-k="${k}">${AD.data.secretSet[f.k] ? `<button class="btn tiny danger" data-act="adSecretClear" data-arg="${k}">${AD.clear[f.k] ? 'Undo' : 'Remove'}</button>` : ''}`;
  }
  if (f.t === 'list') return `<textarea rows="3" placeholder="One per line" data-input="adField" data-k="${k}">${esc((v || []).join('\n'))}</textarea>`;
  return `<input type="text" value="${esc(v)}" ${f.max ? `maxlength="${f.max}"` : ''} data-input="adField" data-k="${k}">`;
}
function adSettings(box, page) {
  const q = AD.search.toLowerCase();
  const fields = AD.data.fields.filter(f => q ? (f.l + ' ' + (f.h || '') + ' ' + f.k).toLowerCase().includes(q) : f.p === page);
  const pg = AD.data.pages.find(p => p.id === page);
  box.innerHTML = `<div class="toolbar"><div class="search-box">${ico('search', 16)}<input id="ad-search" type="text" placeholder="Search every setting" value="${esc(AD.search)}" data-input="adSearch"></div>
    ${!q ? '<button class="btn small ghost" data-act="adDefaults">Reset page to defaults</button>' : ''}</div>
    <div class="card"><h3>${q ? 'Search results' : esc(pg ? pg.label : '')}</h3>${fields.length ? fields.map(f => `<div class="setting ${Object.prototype.hasOwnProperty.call(AD.dirty, f.k) || AD.clear[f.k] ? 'changed' : ''}" data-key="${esc(f.k)}"><div><div class="t">${esc(f.l)}</div>${f.h ? `<div class="d">${esc(f.h)}</div>` : ''}</div><div class="ctl">${adControl(f)}</div></div>`).join('') : '<p class="muted">No settings match.</p>'}
    ${page === 'logs' && !q ? `<div class="row-flex wrap" style="margin-top:14px"><button class="btn small" data-act="adTest" data-arg="webhook">Send Discord test</button><button class="btn small" data-act="adTest" data-arg="fivemanage">Send Fivemanage test</button><span class="muted" style="font-size:12px">Save first, the test uses the saved key.</span></div>` : ''}</div>`;
}
INPUT.adSearch = el => {
  AD.search = el.value;
  adSettings($('#ad-body'), AD.tab);
  const i = $('#ad-search'); i.focus(); i.setSelectionRange(i.value.length, i.value.length);
};
const adField = k => AD.data.fields.find(f => f.k === k);
function adSet(k, v) {
  const f = adField(k);
  const same = f.secret ? v === '' : JSON.stringify(v) === JSON.stringify(AD.data.values[k]);
  if (same) delete AD.dirty[k]; else AD.dirty[k] = v;
  if (f.secret && v !== '') delete AD.clear[k];
  markChanged(k); renderBar();
}
function markChanged(k) {
  const row = document.querySelector(`.setting[data-key="${k}"]`);
  if (row) row.classList.toggle('changed', Object.prototype.hasOwnProperty.call(AD.dirty, k) || !!AD.clear[k]);
}
function readField(el) {
  const f = adField(el.dataset.k);
  if (f.t === 'int') return el.value === '' ? NaN : Math.round(Number(el.value));
  if (f.t === 'float') return el.value === '' ? NaN : Number(el.value);
  if (f.t === 'list') return el.value.split('\n').map(s => s.trim()).filter(Boolean);
  return el.value;
}
INPUT.adField = el => { const v = readField(el); if (typeof v === 'number' && isNaN(v)) return; adSet(el.dataset.k, v); };
CHANGE.adField = el => { const v = readField(el); if (typeof v === 'number' && isNaN(v)) return; adSet(el.dataset.k, v); };
ACT.adBool = el => { const k = el.dataset.arg; adSet(k, !curVal(adField(k))); el.classList.toggle('on'); };
ACT.adColorClear = el => { adSet(el.dataset.arg, ''); adSettings($('#ad-body'), AD.tab); };
ACT.adSecretClear = el => { const k = el.dataset.arg; if (AD.clear[k]) delete AD.clear[k]; else { AD.clear[k] = true; delete AD.dirty[k]; } markChanged(k); adSettings($('#ad-body'), AD.tab); renderBar(); };
ACT.adDefaults = () => confirmBox('Reset this page?', 'Every setting on this page goes back to its default. Nothing is saved until you press Save.', 'Reset', () => {
  AD.data.fields.filter(f => f.p === AD.tab && !f.secret).forEach(f => adSet(f.k, f.d));
  adSettings($('#ad-body'), AD.tab);
});

function renderBar() {
  const bar = $('#ad-bar'); if (!bar) return;
  const n = dirtyCount();
  bar.innerHTML = n ? `<div class="admin-bar"><b>${n} unsaved change${n === 1 ? '' : 's'}</b><div class="grow"></div><button class="btn small ghost" data-act="adDiscard">Discard</button><button class="btn small primary" data-act="adSave">Save changes</button></div>` : '';
}
ACT.adDiscard = () => { AD.dirty = {}; AD.clear = {}; refreshPage(); };
ACT.adSave = async () => {
  const r = await run('admin.save', { values: AD.dirty, clear: Object.keys(AD.clear) }, 'Settings saved. They are live now.');
  if (!r.ok) return;
  AD.data = r.payload; AD.dirty = {}; AD.clear = {}; refreshPage();
};
ACT.adTest = async el => {
  if (dirtyCount()) return toast('Save your changes first.', 'error');
  const r = await run('admin.test', { kind: el.dataset.arg });
  if (r.ok) toast(r.payload && r.payload.text || 'Test sent.', 'success');
};

// ---- squads
async function adSquads(box) {
  const page = AD.sqPage || 1, q = AD.sqSearch || '';
  const r = await req('admin.squads', { search: q, page }); if (!r.ok) { box.innerHTML = empty('Could not load', r.payload); return; }
  const d = r.payload, pages = Math.max(1, Math.ceil(d.total / d.per));
  box.innerHTML = `<div class="toolbar"><div class="search-box">${ico('search', 16)}<input id="sq-search" type="text" placeholder="Search squads, tags or owners" value="${esc(q)}"></div><button class="btn small" id="sq-go">Search</button></div>` +
    (d.list.length ? d.list.map(s => `<div class="row click" data-act="adSquadOpen" data-arg="${s.id}">${avatar('', s.name, s.color)}<div class="grow"><div class="name">${s.tag ? '[' + esc(s.tag) + '] ' : ''}${esc(s.name)}</div><div class="meta">Owner ${esc(s.owner)} · ${s.count}/${s.max} members · ${s.online} online${s.permanent ? ' · ' + money(s.bank) : ''}</div></div>${pill(s.permanent ? 'Permanent' : 'Temporary')}</div>`).join('') : empty('No squads', ''))
    + (pages > 1 ? `<div class="row-flex" style="justify-content:center"><button class="btn small" data-act="adSqPage" data-arg="-1" ${page <= 1 ? 'disabled' : ''}>Previous</button><span class="muted">Page ${page} of ${pages}</span><button class="btn small" data-act="adSqPage" data-arg="1" ${page >= pages ? 'disabled' : ''}>Next</button></div>` : '');
  const go = () => { AD.sqSearch = val('sq-search'); AD.sqPage = 1; adSquads(box); };
  $('#sq-go').onclick = go; $('#sq-search').onkeydown = e => { if (e.key === 'Enter') go(); };
}
ACT.adSqPage = el => { AD.sqPage = Math.max(1, (AD.sqPage || 1) + parseInt(el.dataset.arg, 10)); renderAdminBody(); };
function adSquadModal(d) {
  modal(`<h3>${d.tag ? '[' + esc(d.tag) + '] ' : ''}${esc(d.name)}</h3><div class="row-flex wrap" style="margin-bottom:12px">${pill(d.permanent ? 'Permanent' : 'Temporary')}${pill(d.privacy)}${pill(d.members.length + ' / ' + d.max + ' members', 'accent')}${d.permanent ? pill(money(d.bank), 'gold') : ''}</div>
    ${d.members.map(m => `<div class="row"><div class="grow"><div class="name">${m.owner ? ico('crown', 14) + ' ' : ''}${esc(m.name)}</div><div class="meta">${m.online ? 'Online' : 'Offline'}</div></div>${!m.owner ? `<button class="btn tiny danger" data-act="adKick" data-id="${d.id}" data-arg="${esc(m.id)}">Remove</button>` : ''}</div>`).join('')}
    ${d.permanent ? `<div class="row-flex" style="margin-top:10px"><input id="ad-bank" type="number" placeholder="Add or remove money (use - to remove)" style="flex:1"><button class="btn small" data-act="adBank" data-arg="${d.id}">Apply</button></div>` : ''}
    <div class="modal-actions"><button class="btn danger" data-act="adDisband" data-arg="${d.id}">Disband</button><button class="btn" data-act="adJoin" data-arg="${d.id}">Join as staff</button><button class="btn" data-act="closeModal">Close</button></div>`, { wide: true, noFocus: true });
}
ACT.adSquadOpen = async el => { const r = await run('admin.squad', { id: parseInt(el.dataset.arg, 10) }); if (r.ok) adSquadModal(r.payload); };
ACT.adKick = async el => { const r = await run('admin.kick', { id: parseInt(el.dataset.id, 10), identifier: el.dataset.arg }, 'Removed.'); if (r.ok) { if (r.payload) adSquadModal(r.payload); else closeModal(); renderAdminBody(); } };
ACT.adBank = async el => { const r = await run('admin.bank', { id: parseInt(el.dataset.arg, 10), amount: parseInt(val('ad-bank'), 10) || 0 }, 'Bank changed.'); if (r.ok) adSquadModal(r.payload); };
ACT.adJoin = async el => { const r = await run('admin.join', { id: parseInt(el.dataset.arg, 10) }, 'You joined the squad.'); if (r.ok) closeModal(); };
ACT.adDisband = el => confirmBox('Disband this squad?', 'This removes it for good, including its bank.', 'Disband', async () => { const r = await run('admin.disband', { id: parseInt(el.dataset.arg, 10) }, 'Squad disbanded.'); if (r.ok) { closeModal(); renderAdminBody(); } }, true);

// ---- players (verified badge)
async function adPlayers(box) {
  const r = await req('admin.players'); if (!r.ok) { box.innerHTML = empty('Could not load', r.payload); return; }
  box.innerHTML = `<p class="muted">Give trusted players a verified badge. They must be online.</p>` + (r.payload.length ? r.payload.map(p => `<div class="row"><div class="grow"><div class="name">${esc(p.name)} <span class="muted">#${p.src}</span> ${p.verified ? `<span style="color:#7dd3fc">${ico('badge', 14)}</span>` : ''}</div></div><button class="btn small ${p.verified ? 'danger' : 'primary'}" data-act="adVerify" data-arg="${esc(p.id)}" data-on="${p.verified ? 0 : 1}">${p.verified ? 'Remove badge' : 'Verify'}</button></div>`).join('') : empty('Nobody online', ''));
}
ACT.adVerify = async el => { const r = await run('admin.verify', { identifier: el.dataset.arg, value: el.dataset.on === '1' }, 'Updated.'); if (r.ok) renderAdminBody(); };

// ---- logs
async function adLogs(box) {
  const page = AD.logPage || 1;
  const r = await req('admin.logs', { page }); if (!r.ok) { box.innerHTML = empty('Could not load', r.payload); return; }
  const d = r.payload, pages = Math.max(1, Math.ceil(d.total / d.per));
  box.innerHTML = (d.rows.length ? `<div class="card" style="padding:8px 14px">${d.rows.map(l => `<div class="log-row"><span class="muted">${ago(l.created)}</span><span>${pill(l.category)}</span><span style="user-select:text">${esc(l.message)}</span></div>`).join('')}</div>` : empty('No logs yet', ''))
    + `<div class="row-flex" style="justify-content:center"><button class="btn small" data-act="adLogPage" data-arg="-1" ${page <= 1 ? 'disabled' : ''}>Newer</button><span class="muted">Page ${page} of ${pages}</span><button class="btn small" data-act="adLogPage" data-arg="1" ${page >= pages ? 'disabled' : ''}>Older</button></div>`;
}
ACT.adLogPage = el => { AD.logPage = Math.max(1, (AD.logPage || 1) + parseInt(el.dataset.arg, 10)); renderAdminBody(); };

// forget cached admin data when the menu closes so the next open is fresh
const _origHide = HANDLERS.menu;
HANDLERS.menu = d => { if (!d.open) { AD.data = null; AD.dirty = {}; AD.clear = {}; } _origHide(d); };
