'use strict';
// Menu pages: browse, my squad (members, chat, recruit, bank, abilities, ranks, edit), wars, bounties

const CHANGE = {}, INPUT = {};
document.addEventListener('change', e => { const el = e.target.closest('[data-change]'); if (el && CHANGE[el.dataset.change]) CHANGE[el.dataset.change](el, e); });
document.addEventListener('input', e => { const el = e.target.closest('[data-input]'); if (el && INPUT[el.dataset.input]) INPUT[el.dataset.input](el, e); });

const PALETTE = ['#3b82f6', '#06b6d4', '#22c55e', '#eab308', '#f97316', '#ef4444', '#ec4899', '#a855f7', '#6366f1', '#94a3b8'];
const PERM_LABELS = {
  invite: 'Invite and accept', kick: 'Kick and ban', wars: 'Start and answer wars', bounties: 'Place bounties', deposit: 'Deposit to bank', withdraw: 'Withdraw and use abilities',
  edit_name: 'Edit name and tag', edit_photo: 'Edit picture', edit_banner: 'Edit banner', edit_color: 'Edit colour', edit_settings: 'Edit squad settings',
};
const PERM_KEYS = Object.keys(PERM_LABELS);
const can = p => !!(S.squad && S.squad.me && S.squad.me.perms && S.squad.me.perms[p]);
const isOwner = () => !!(S.squad && S.squad.me && S.squad.me.isOwner);
const val = id => { const e = document.getElementById(id); return e ? e.value : ''; };
const checked = id => { const e = document.getElementById(id); return !!(e && e.checked); };

function swatches(current, act) {
  return `<div class="swatches">${PALETTE.map(c => `<button class="swatch ${c === current ? 'active' : ''}" style="--c:${c}" data-act="${act}" data-arg="${c}" aria-label="${c}"></button>`).join('')}<input type="color" value="${esc(current)}" data-change="${act}Pick"></div>`;
}
function privacyPill(s) {
  if (s.privacy === 'password') return pill('Password', 'private');
  if (s.privacy === 'apply') return pill('Apply', 'gold');
  return pill('Open', 'open');
}

function squadCard(s, actions) {
  const c = rgbStr(s.color), cover = safeUrl(s.banner);
  return `<div class="squad" style="--c:${c}">
    <div class="cover" style="${cover ? `background-image:url('${esc(cover)}')` : ''}"></div>
    <div class="body"><div class="top">${avatar(s.photo, s.name, s.color, 'lg')}
      <div class="grow" style="padding-top:34px"><div class="nm">${s.tag ? `<span class="tag">[${esc(s.tag)}]</span> ` : ''}${esc(s.name)}</div><div class="muted" style="font-size:12px">Owner ${esc(s.ownerName)}</div></div></div>
      <div class="row-flex wrap">${privacyPill(s)}${pill(s.permanent ? 'Permanent' : 'Temporary')}${s.atWar ? pill('At war', 'war') : ''}${pill(s.online + ' online', 'accent')}</div>
      <div class="foot"><span class="count">${s.count} / ${s.max} members</span><div class="actions row-flex">${actions || ''}</div></div></div></div>`;
}

// ================================================================== BROWSE
PAGES.browse = {
  title: 'Browse squads',
  sub: () => S.squad ? 'You are already in a squad' : 'Find a squad to join or start your own',
  async render(el) {
    const r = await req('list');
    S.cache.list = r.ok ? r.payload : [];
    el.innerHTML = `<div class="toolbar"><div class="search-box">${ico('search', 16)}<input id="browse-q" type="text" placeholder="Search by name, tag or owner" data-input="browseQ" value="${esc(S.tab.browseQ || '')}"></div>
      ${!S.squad ? `<button class="btn primary" data-act="createOpen">${ico('plus', 16)} Create squad</button>` : ''}</div><div id="browse-list"></div>`;
    renderBrowseList();
  },
};
INPUT.browseQ = el => { S.tab.browseQ = el.value; renderBrowseList(); };
function renderBrowseList() {
  const box = $('#browse-list'); if (!box) return;
  const q = (S.tab.browseQ || '').toLowerCase();
  const list = (S.cache.list || []).filter(s => !q || s.name.toLowerCase().includes(q) || s.tag.toLowerCase().includes(q) || s.ownerName.toLowerCase().includes(q));
  if (!list.length) { box.innerHTML = empty('No squads found', S.squad ? '' : 'Be the first and create one.'); return; }
  box.innerHTML = `<div class="grid">${list.map(s => {
    let btn = '';
    if (!S.squad) {
      const full = s.count >= s.max;
      const label = s.privacy === 'apply' ? 'Apply' : s.privacy === 'password' ? 'Join with password' : 'Join';
      btn = `<button class="btn small primary" ${full ? 'disabled' : ''} data-act="joinSquad" data-arg="${s.id}" data-privacy="${s.privacy}">${full ? 'Full' : label}</button>`;
    }
    return squadCard(s, btn);
  }).join('')}</div>`;
}
ACT.joinSquad = async el => {
  const id = parseInt(el.dataset.arg, 10), privacy = el.dataset.privacy;
  if (privacy === 'password') {
    modal(`<h3>Enter the password</h3><div class="field"><input id="join-pw" type="password" maxlength="32" placeholder="Password"></div>
      <div class="modal-actions"><button class="btn" data-act="closeModal">Cancel</button><button class="btn primary" id="join-go">Join</button></div>`);
    const go = async () => { const r = await run('join', { id, password: val('join-pw') }, 'Joined the squad.'); if (r.ok) { closeModal(); S.page = 'squad'; } };
    $('#join-go').onclick = go; $('#join-pw').onkeydown = e => { if (e.key === 'Enter') go(); };
    return;
  }
  if (privacy === 'apply') { const r = await run('apply', { id }, 'Application sent.'); return; }
  const r = await run('join', { id }, 'Joined the squad.');
  if (r.ok) S.page = 'squad';
};

// ---- create squad
let draft = null;
ACT.createOpen = () => {
  const st = S.settings;
  draft = { color: st.themeColor || '#3b82f6', permanent: st.squadMode === 'permanent', privacy: 'open' };
  const typeField = st.squadMode === 'choice'
    ? `<div class="field"><label>Type</label><select id="cf-perm"><option value="0">Temporary (ends when everyone leaves)</option><option value="1">Permanent (saved, has bank and abilities)</option></select></div>` : '';
  modal(`<h3>Create a squad</h3>
    <div class="grid"><div class="field"><label>Name</label><input id="cf-name" type="text" maxlength="${st.nameMax || 20}"></div>
    <div class="field"><label>Tag${st.tagRequired ? ' (required)' : ''}</label><input id="cf-tag" type="text" maxlength="${st.tagMax || 4}" style="text-transform:uppercase"></div></div>
    ${typeField}
    <div class="grid"><div class="field"><label>Who can join</label><select id="cf-privacy"><option value="open">Open</option>${st.allowPassword !== false ? '<option value="password">Password</option>' : ''}${st.allowApply !== false ? '<option value="apply">Apply to join</option>' : ''}</select></div>
    <div class="field"><label>Max members (2 to ${st.maxMembers || 40})</label><input id="cf-max" type="number" min="2" max="${st.maxMembers || 40}" value="${Math.min(st.maxMembers || 40, 10)}"></div></div>
    <div class="field" id="cf-pwbox" style="display:none"><label>Password (4 to 32 characters)</label><input id="cf-pw" type="password" maxlength="32"></div>
    <div class="field"><label>Colour</label><div id="cf-colors">${swatches(draft.color, 'cfColor')}</div></div>
    <div class="grid"><div class="field"><label>Picture link (optional)</label><input id="cf-photo" type="url" placeholder="https://"></div>
    <div class="field"><label>Banner link (optional)</label><input id="cf-banner" type="url" placeholder="https://"></div></div>
    <div class="toggle-row"><div><div class="t">Friendly fire</div><div class="d">Squadmates can hurt each other.</div></div><label class="row-flex"><input id="cf-ff" type="checkbox" ${st.friendlyFire ? 'checked' : ''}></label></div>
    ${st.createFee > 0 ? `<p class="muted">Creating a squad costs ${money(st.createFee)}.</p>` : ''}
    <div class="modal-actions"><button class="btn" data-act="closeModal">Cancel</button><button class="btn primary" id="cf-go">Create squad</button></div>`, { wide: true });
  $('#cf-privacy').onchange = e => { $('#cf-pwbox').style.display = e.target.value === 'password' ? '' : 'none'; };
  $('#cf-go').onclick = async () => {
    const d = {
      name: val('cf-name'), tag: val('cf-tag'), privacy: val('cf-privacy'), password: val('cf-pw'), color: draft.color,
      maxMembers: parseInt(val('cf-max'), 10) || 10, photo: val('cf-photo'), banner: val('cf-banner'), friendlyFire: checked('cf-ff'),
      permanent: st.squadMode === 'choice' ? val('cf-perm') === '1' : st.squadMode === 'permanent',
    };
    const r = await run('create', d, 'Squad created.');
    if (r.ok) { closeModal(); S.page = 'squad'; }
  };
};
ACT.cfColor = el => { draft.color = el.dataset.arg; $('#cf-colors').innerHTML = swatches(draft.color, 'cfColor'); };
CHANGE.cfColorPick = el => { draft.color = el.value; $('#cf-colors').innerHTML = swatches(draft.color, 'cfColor'); };

// ================================================================== MY SQUAD
function squadTabs() {
  const st = S.settings, sq = S.squad, tabs = [{ id: 'members', label: 'Members' }];
  if (st.chatEnabled !== false) tabs.push({ id: 'chat', label: 'Chat' });
  if (can('invite') || can('kick')) tabs.push({ id: 'recruit', label: 'Recruitment' });
  if (sq.permanent && st.bankEnabled !== false && S.me.money) tabs.push({ id: 'bank', label: 'Bank' });
  if (sq.permanent || st.ordersEnabled !== false) tabs.push({ id: 'abilities', label: 'Abilities & orders' });
  if (isOwner()) tabs.push({ id: 'ranks', label: 'Ranks' });
  if (isOwner() || PERM_KEYS.some(p => p.startsWith('edit_') && can(p))) tabs.push({ id: 'edit', label: 'Edit squad' });
  return tabs;
}

PAGES.squad = {
  title: () => S.squad ? S.squad.name : 'My squad',
  sub: () => S.squad ? `${S.squad.members.filter(m => m.online).length} of ${S.squad.members.length} members online` : '',
  async render(el) {
    const sq = S.squad; if (!sq) return;
    const tabs = squadTabs();
    let tab = S.tab.squad; if (!tabs.find(x => x.id === tab)) tab = S.tab.squad = 'members';
    const c = rgbStr(sq.color), cover = safeUrl(sq.banner);
    const war = sq.war;
    el.innerHTML = `<div class="squad" style="--c:${c};margin-bottom:14px"><div class="cover" style="height:84px;${cover ? `background-image:url('${esc(cover)}')` : ''}"></div>
      <div class="body"><div class="top">${avatar(sq.photo, sq.name, sq.color, 'xl')}<div class="grow" style="padding-top:38px"><div class="nm" style="font-size:20px">${sq.tag ? `<span class="tag">[${esc(sq.tag)}]</span> ` : ''}${esc(sq.name)}</div>
        <div class="row-flex wrap" style="margin-top:4px">${privacyPill(sq)}${pill(sq.permanent ? 'Permanent' : 'Temporary')}${pill(sq.members.length + ' / ' + sq.maxMembers + ' members', 'accent')}${sq.friendlyFire ? pill('Friendly fire', 'war') : ''}${sq.permanent && S.me.money ? pill(money(sq.bank), 'gold') : ''}${sq.radioChannel ? pill('Radio ' + sq.radioChannel) : ''}</div></div>
        <div class="actions row-flex" style="padding-top:38px">${sq.rally ? `<button class="btn small" data-act="rallyGo">${ico('pin', 14)} Rally</button>` : ''}<button class="btn small danger" data-act="leaveSquad">${ico('logout', 14)} Leave</button></div></div></div></div>
      ${war && war.state === 'pending' && war.requester !== sq.id ? `<div class="warcard"><div><b>War request</b><div class="muted">${esc((war.requester === war.a.id ? war.a : war.b).name)} challenged you to a ${war.minutes} minute KOS war</div></div><button class="btn small" data-act="goto" data-arg="wars">View</button></div>` : ''}
      <div class="tabs">${tabs.map(x => `<button class="tab ${x.id === tab ? 'active' : ''}" data-act="squadTab" data-arg="${x.id}">${esc(x.label)}${x.id === 'recruit' && sq.applications && sq.applications.length ? ` (${sq.applications.length})` : ''}</button>`).join('')}</div>
      <div id="squad-tab"></div>`;
    await SQUAD_TABS[tab]($('#squad-tab'));
  },
};
ACT.squadTab = el => { S.tab.squad = el.dataset.arg; rankDraft = null; refreshPage(); };
ACT.leaveSquad = () => confirmBox('Leave the squad?', S.squad.members.length === 1 && !S.squad.permanent ? 'You are the last member, so the squad will end.' : 'You can join again later if the squad lets you.', 'Leave', async () => {
  const r = await run('leave', {}, 'You left the squad.'); if (r.ok) { S.page = 'browse'; }
}, true);
ACT.rallyGo = () => post('waypointRally', {});

const SQUAD_TABS = {};

// ---- members
SQUAD_TABS.members = el => {
  const sq = S.squad, myLevel = sq.me.level;
  let html = '';
  if (isOwner() && S.settings.rallyEnabled !== false) {
    html += `<div class="card"><h3>Rally point</h3><div class="row-flex wrap"><button class="btn small" data-act="rallyHere">Set here</button><button class="btn small" data-act="rallyWp">Set to my map waypoint</button>${sq.rally ? '<button class="btn small danger" data-act="rallyClear">Clear</button>' : ''}</div></div>`;
  }
  html += sq.members.map(m => {
    const me = m.id === sq.me.id;
    const manage = !me && !m.owner && can('kick') && m.level < myLevel;
    return `<div class="row click" data-act="profileOpen" data-arg="${esc(m.id)}">${avatar(m.picture, m.name, sq.color, '', m.status)}
      <div class="grow"><div class="name">${m.owner ? `<span class="crown">${ico('crown', 14)}</span> ` : ''}${esc(m.name)}${m.verified ? ` <span style="color:#7dd3fc">${ico('badge', 14)}</span>` : ''}${me ? ' <span class="muted">(you)</span>' : ''}</div>
      <div class="meta">${pill(m.rank, m.owner ? 'gold' : '')}${m.online ? '<span style="color:#4ade80">Online</span>' : '<span>Offline</span>'}${m.xpLevel ? `<span>Level ${m.xpLevel}</span>` : ''}</div></div>
      <div class="actions" onclick="event.stopPropagation()">
        ${isOwner() && !me && !m.owner ? `<select data-change="memberRank" data-id="${esc(m.id)}" style="width:auto">${sq.ranks.map(r => `<option value="${r.id}" ${r.id === m.rankId ? 'selected' : ''}>${esc(r.name)}</option>`).join('')}</select>` : ''}
        ${m.online && m.src != null && !me ? `<button class="btn tiny" data-act="memberWp" data-arg="${m.src}" title="Waypoint">${ico('pin', 12)}</button>` : ''}
        ${manage ? `<button class="btn tiny" data-act="memberKick" data-arg="${esc(m.id)}">Kick</button><button class="btn tiny danger" data-act="memberBan" data-arg="${esc(m.id)}">Ban</button>` : ''}
        ${isOwner() && !me && !m.owner ? `<button class="btn tiny" data-act="memberTransfer" data-arg="${esc(m.id)}">Make owner</button>` : ''}
      </div></div>`;
  }).join('');
  el.innerHTML = html;
};
ACT.rallyHere = async () => { await run('rally', {}, 'Rally point set.'); };
ACT.rallyWp = async () => { const r = await post('rallyWaypoint', {}); if (r && r.ok) toast('Rally point set.', 'success'); else if (r && r.payload) toast(r.payload, 'error'); };
ACT.rallyClear = async () => { await run('rally', { clear: true }, 'Rally point cleared.'); };
ACT.memberWp = el => post('waypoint', { src: parseInt(el.dataset.arg, 10) });
CHANGE.memberRank = async el => { await run('member', { op: 'rank', identifier: el.dataset.id, rankId: parseInt(el.value, 10) }, 'Rank changed.'); };
const memberName = id => (S.squad.members.find(m => m.id === id) || {}).name || 'this player';
ACT.memberKick = el => confirmBox('Kick ' + memberName(el.dataset.arg) + '?', 'They can join again unless the squad is closed.', 'Kick', () => run('member', { op: 'kick', identifier: el.dataset.arg }, 'Player removed.'), true);
ACT.memberBan = el => {
  const id = el.dataset.arg;
  modal(`<h3>Ban ${esc(memberName(id))}</h3><div class="field"><label>Reason (optional)</label><input id="ban-reason" type="text" maxlength="80"></div><div class="modal-actions"><button class="btn" data-act="closeModal">Cancel</button><button class="btn danger" id="ban-go">Ban</button></div>`);
  $('#ban-go').onclick = async () => { const r = await run('member', { op: 'ban', identifier: id, reason: val('ban-reason') }, 'Player banned.'); if (r.ok) closeModal(); };
};
ACT.memberTransfer = el => confirmBox('Make ' + memberName(el.dataset.arg) + ' the owner?', 'You will become a normal member with the lowest rank.', 'Transfer', () => run('member', { op: 'transfer', identifier: el.dataset.arg }, 'Ownership transferred.'), true);

// ---- chat
SQUAD_TABS.chat = async el => {
  const r = await req('chatHistory'); S.cache.chat = r.ok ? r.payload : [];
  el.innerHTML = `<div class="card"><div id="chat-list" class="chat-list"></div><div class="row-flex"><input id="chat-in" type="text" maxlength="${S.settings.chatMaxLength || 160}" placeholder="Message your squad" autocomplete="off"><button class="btn primary" data-act="chatSend">Send</button></div></div>`;
  const list = $('#chat-list');
  list.innerHTML = S.cache.chat.length ? '' : '<div class="empty">No messages yet.</div>';
  S.cache.chat.forEach(m => list.insertAdjacentHTML('beforeend', chatLine(m)));
  list.scrollTop = list.scrollHeight;
  $('#chat-in').onkeydown = e => { if (e.key === 'Enter') ACT.chatSend(); e.stopPropagation(); };
};
const chatLine = m => `<div class="msg"><b>${esc(m.name)}</b>${esc(m.msg)}<small>${ago(m.t)}</small></div>`;
function appendChat(entry) {
  const list = $('#chat-list'); if (!list) return;
  const e = list.querySelector('.empty'); if (e) e.remove();
  list.insertAdjacentHTML('beforeend', chatLine(entry)); list.scrollTop = list.scrollHeight;
}
ACT.chatSend = async () => { const i = $('#chat-in'); if (!i || !i.value.trim()) return; const msg = i.value; i.value = ''; await run('chat', { msg }); };

// ---- recruitment
SQUAD_TABS.recruit = async el => {
  const sq = S.squad; let html = '';
  if (can('invite')) {
    if (sq.applications && sq.applications.length) {
      html += `<div class="section">Applications</div>` + sq.applications.map(a => `<div class="row">${avatar('', a.name, sq.color)}<div class="grow"><div class="name">${esc(a.name)}</div><div class="meta">Applied ${ago(a.at)}</div></div>
        <div class="actions"><button class="btn small primary" data-act="appYes" data-arg="${esc(a.id)}">Accept</button><button class="btn small" data-act="appNo" data-arg="${esc(a.id)}">Decline</button></div></div>`).join('');
    }
    const mode = S.tab.invMode || 'nearby';
    const r = await req(mode === 'nearby' ? 'nearby' : 'players'); const list = r.ok ? r.payload : [];
    html += `<div class="section">Invite players</div><div class="tabs"><button class="tab ${mode === 'nearby' ? 'active' : ''}" data-act="invMode" data-arg="nearby">Nearby</button><button class="tab ${mode === 'all' ? 'active' : ''}" data-act="invMode" data-arg="all">Everyone online</button></div>`;
    html += list.length ? list.map(p => `<div class="row">${avatar('', p.name, sq.color)}<div class="grow"><div class="name">${esc(p.name)} <span class="muted">#${p.src}</span></div><div class="meta">${p.distance != null ? p.distance + ' m away' : (p.squad ? 'In squad ' + esc(p.squad) : 'No squad')}</div></div>
      <div class="actions"><button class="btn small primary" data-act="invitePlayer" data-arg="${p.src}">Invite</button></div></div>`).join('') : empty(mode === 'nearby' ? 'Nobody nearby' : 'Nobody to invite', mode === 'nearby' ? 'Stand next to players you want to invite, or aim at them and press J.' : '');
  }
  if (can('kick')) {
    const bans = sq.bans || [], per = 8, page = Math.min(S.tab.banPage || 0, Math.max(0, Math.ceil(bans.length / per) - 1));
    html += `<div class="section">Banned players (${bans.length})</div>`;
    html += bans.length ? bans.slice(page * per, page * per + per).map(b => `<div class="row"><div class="grow"><div class="name">${esc(b.name)}</div><div class="meta">${b.reason ? esc(b.reason) + ' · ' : ''}by ${esc(b.by)} · ${ago(b.at)}</div></div><div class="actions"><button class="btn small" data-act="unban" data-arg="${esc(b.id)}">Unban</button></div></div>`).join('') : '<p class="muted">Nobody is banned.</p>';
    if (bans.length > per) html += `<div class="row-flex" style="justify-content:center"><button class="btn small" data-act="banPage" data-arg="-1">Previous</button><span class="muted">Page ${page + 1} of ${Math.ceil(bans.length / per)}</span><button class="btn small" data-act="banPage" data-arg="1">Next</button></div>`;
  }
  el.innerHTML = html;
};
ACT.appYes = el => run('app', { identifier: el.dataset.arg, accept: true }, 'Player accepted.');
ACT.appNo = el => run('app', { identifier: el.dataset.arg, accept: false });
ACT.invMode = el => { S.tab.invMode = el.dataset.arg; refreshPage(); };
ACT.invitePlayer = async el => { await run('invite', { target: parseInt(el.dataset.arg, 10) }); };
ACT.unban = el => run('member', { op: 'unban', identifier: el.dataset.arg }, 'Player unbanned.');
ACT.banPage = el => { S.tab.banPage = Math.max(0, (S.tab.banPage || 0) + parseInt(el.dataset.arg, 10)); refreshPage(); };

// ---- bank
function chartSvg(points) {
  if (!points.length) return '<p class="muted">No bank activity yet.</p>';
  const w = 600, h = 130, pad = 8, max = Math.max(...points.map(p => p.balance), 1), min = Math.min(...points.map(p => p.balance), 0);
  const x = i => points.length === 1 ? w / 2 : pad + i * (w - pad * 2) / (points.length - 1), y = v => h - pad - (v - min) / Math.max(max - min, 1) * (h - pad * 2);
  const path = points.map((p, i) => (i ? 'L' : 'M') + x(i).toFixed(1) + ' ' + y(p.balance).toFixed(1)).join(' ');
  return `<svg class="chart" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none"><defs><linearGradient id="cg" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="var(--accent)" stop-opacity=".4"/><stop offset="1" stop-color="var(--accent)" stop-opacity="0"/></linearGradient></defs>
    <path d="${path} L${x(points.length - 1).toFixed(1)} ${h} L${x(0).toFixed(1)} ${h} Z" fill="url(#cg)"/><path d="${path}" fill="none" stroke="var(--accent)" stroke-width="2.5" vector-effect="non-scaling-stroke"/></svg>`;
}
SQUAD_TABS.bank = async el => {
  const r = await req('bankHistory'); const d = r.ok ? r.payload : { history: [], chart: [], balance: S.squad.bank };
  el.innerHTML = `<div class="card"><div class="row-flex" style="justify-content:space-between"><div><div class="muted">Squad bank</div><div style="font-size:32px;font-weight:800">${money(d.balance)}</div></div>
    <div class="row-flex"><input id="bank-amt" type="number" min="1" placeholder="Amount" style="width:140px"><button class="btn primary" data-act="bankDo" data-arg="deposit" ${can('deposit') ? '' : 'disabled'}>Deposit</button><button class="btn" data-act="bankDo" data-arg="withdraw" ${can('withdraw') ? '' : 'disabled'}>Withdraw</button></div></div>${chartSvg(d.chart || [])}</div>
    <div class="section">History</div>${(d.history || []).length ? `<table class="table"><tr><th>Who</th><th>Action</th><th>Amount</th><th>Balance</th><th>When</th></tr>${d.history.map(h => `<tr><td>${esc(h.name)}</td><td>${esc(h.kind)}</td><td style="color:${h.amount < 0 ? '#fca5a5' : '#4ade80'}">${h.amount < 0 ? '-' : '+'}${money(Math.abs(h.amount))}</td><td>${money(h.balance)}</td><td class="muted">${ago(h.created)}</td></tr>`).join('')}</table>` : '<p class="muted">Nothing yet.</p>'}`;
};
ACT.bankDo = async el => {
  const amount = parseInt(val('bank-amt'), 10); if (!amount) return toast('Enter an amount.', 'error');
  await run('bank', { op: el.dataset.arg, amount }, el.dataset.arg === 'deposit' ? 'Deposited.' : 'Withdrawn.');
};

// ---- abilities and orders
const remaining = name => Math.max(0, ((S.squad.cooldowns || {})[name] || 0) - (nowSec() - (S.squad.now || nowSec())));
SQUAD_TABS.abilities = el => {
  const st = S.settings, sq = S.squad;
  const abilities = [
    { id: 'uav', icon: 'radar', name: 'UAV scan', on: st.uavEnabled, cost: st.uavCost, text: `Shows enemy players on the map for ${st.uavDuration} seconds.`, active: (sq.boost.uavUntil || 0) > nowSec() },
    { id: 'armor', icon: 'shield', name: 'Armor resupply', on: st.armorEnabled, cost: st.armorCost, text: `Gives full armor to squadmates within ${st.armorRadius} m.` },
    { id: 'xp', icon: 'bolt', name: 'Double XP', on: st.xpBoostEnabled, cost: st.xpBoostCost, text: `Double XP for the whole squad for ${Math.round(st.xpBoostDuration / 60)} minutes.`, active: (sq.boost.xpUntil || 0) > nowSec() },
  ];
  let html = '';
  if (sq.permanent) {
    html += `<div class="grid three">${abilities.filter(a => a.on).map(a => {
      const cd = remaining(a.id);
      return `<div class="card"><div style="color:var(--accent)">${ico(a.icon, 28)}</div><h3 style="margin-top:8px">${a.name}</h3><p class="muted" style="margin:0 0 10px;font-size:12.5px">${esc(a.text)}</p>
        <div class="row-flex" style="justify-content:space-between"><b>${S.me.money ? money(a.cost) : 'Free'}</b>${a.active ? pill('Active', 'open') : ''}</div>
        <button class="btn primary" style="width:100%;margin-top:10px" ${cd > 0 || !can('withdraw') ? 'disabled' : ''} data-act="useAbility" data-arg="${a.id}">${cd > 0 ? 'Ready in ' + fmtLong(cd) : 'Use'}</button></div>`;
    }).join('')}</div>`;
    if (!can('withdraw')) html += '<p class="muted">Your rank cannot use abilities.</p>';
  }
  if (st.ordersEnabled !== false) {
    const cd = remaining('order');
    html += `<div class="card"><h3>${ico('flag', 16)} Teamwork order</h3><p class="muted">Set a rally point, then start an order. If ${st.orderMinMembers} or more squadmates hold the area for ${st.orderHold} seconds, everyone in it earns ${S.me.money ? money(st.orderCash) + ' and ' : ''}${st.orderXp} XP.</p>
      ${sq.order ? `<p>${pill('Order active', 'open')} Gather at the marked area.</p>` : ''}
      <button class="btn primary" data-act="startOrder" ${!sq.rally || cd > 0 || sq.order ? 'disabled' : ''}>${!sq.rally ? 'Set a rally point first' : cd > 0 ? 'Ready in ' + fmtLong(cd) : 'Start order'}</button></div>`;
  }
  el.innerHTML = html || empty('Nothing here', 'Abilities need a permanent squad.');
};
ACT.useAbility = el => run('ability', { id: el.dataset.arg });
ACT.startOrder = () => run('order', {}, 'Order started.');

// ---- ranks
let rankDraft = null;
SQUAD_TABS.ranks = el => {
  if (!rankDraft) rankDraft = S.squad.ranks.map(r => ({ id: r.id, name: r.name, level: r.level, perms: Object.assign({}, r.perms) }));
  const max = S.settings.maxRanks || 8;
  el.innerHTML = `<p class="muted">Higher level ranks can manage lower ones. The owner always has every permission. Up to ${max} ranks.</p>` +
    rankDraft.map((r, i) => `<div class="card"><div class="row-flex"><input type="text" value="${esc(r.name)}" maxlength="20" data-input="rankName" data-i="${i}" style="max-width:220px"><span class="muted">Level</span><input type="number" min="1" max="99" value="${r.level}" data-input="rankLevel" data-i="${i}" style="width:80px"><div class="grow"></div>
      <button class="btn small danger" data-act="rankDel" data-arg="${i}" ${rankDraft.length <= 1 ? 'disabled' : ''}>${ico('trash', 14)}</button></div>
      <div class="perm-grid">${PERM_KEYS.map(p => `<div class="perm ${r.perms[p] ? 'on' : ''}" data-act="rankPerm" data-i="${i}" data-arg="${p}"><i></i>${esc(PERM_LABELS[p])}</div>`).join('')}</div></div>`).join('') +
    `<div class="row-flex"><button class="btn" data-act="rankAdd" ${rankDraft.length >= max ? 'disabled' : ''}>${ico('plus', 14)} Add rank</button><button class="btn ghost" data-act="rankReset">Reset</button><div class="grow"></div><button class="btn primary" data-act="rankSave">Save ranks</button></div>`;
};
INPUT.rankName = el => { rankDraft[+el.dataset.i].name = el.value; };
INPUT.rankLevel = el => { rankDraft[+el.dataset.i].level = parseInt(el.value, 10) || 1; };
ACT.rankPerm = el => { const r = rankDraft[+el.dataset.i]; r.perms[el.dataset.arg] = !r.perms[el.dataset.arg]; el.classList.toggle('on'); };
ACT.rankDel = el => { rankDraft.splice(+el.dataset.arg, 1); SQUAD_TABS.ranks($('#squad-tab')); };
ACT.rankAdd = () => { rankDraft.push({ name: 'New rank', level: 1, perms: {} }); SQUAD_TABS.ranks($('#squad-tab')); };
ACT.rankReset = () => { rankDraft = null; refreshPage(); };
ACT.rankSave = async () => { const r = await run('ranks', { list: rankDraft }, 'Ranks saved.'); if (r.ok) rankDraft = null; };

// ---- edit squad
SQUAD_TABS.edit = el => {
  const sq = S.squad, st = S.settings; editDraft = { color: sq.color };
  const f = (perm, html) => can(perm) ? html : '';
  el.innerHTML = `<div class="card">
    ${f('edit_name', `<div class="grid"><div class="field"><label>Name</label><input id="ef-name" type="text" value="${esc(sq.name)}" maxlength="${st.nameMax || 20}"></div><div class="field"><label>Tag</label><input id="ef-tag" type="text" value="${esc(sq.tag)}" maxlength="${st.tagMax || 4}"></div></div>`)}
    ${f('edit_photo', `<div class="field"><label>Picture link</label><input id="ef-photo" type="url" value="${esc(sq.photo)}" placeholder="https://"></div>`)}
    ${f('edit_banner', `<div class="field"><label>Banner link</label><input id="ef-banner" type="url" value="${esc(sq.banner)}" placeholder="https://"></div>`)}
    ${f('edit_color', `<div class="field"><label>Colour</label><div id="ef-colors">${swatches(sq.color, 'efColor')}</div></div>`)}
    ${f('edit_settings', `<div class="grid"><div class="field"><label>Who can join</label><select id="ef-privacy"><option value="open" ${sq.privacy === 'open' ? 'selected' : ''}>Open</option><option value="password" ${sq.privacy === 'password' ? 'selected' : ''}>Password</option><option value="apply" ${sq.privacy === 'apply' ? 'selected' : ''}>Apply to join</option></select></div>
      <div class="field"><label>Password ${sq.privacy === 'password' ? '(leave empty to keep)' : ''}</label><input id="ef-pw" type="password" maxlength="32"></div></div>
      <div class="grid"><div class="field"><label>Radio channel (0 = automatic)</label><input id="ef-radio" type="number" min="0" value="${sq.radio || 0}"><div class="help">Custom channels must be between ${st.radioBase} and ${st.radioBase + 9999}.</div></div>
      <div class="toggle-row" style="border:0"><div><div class="t">Friendly fire</div></div><input id="ef-ff" type="checkbox" ${sq.friendlyFire ? 'checked' : ''}></div></div>`)}
    ${isOwner() ? `<div class="field"><label>Max members (2 to ${st.maxMembers})</label><input id="ef-max" type="number" min="2" max="${st.maxMembers}" value="${sq.maxMembers}" style="max-width:160px"></div>` : ''}
    <div class="modal-actions"><button class="btn primary" data-act="editSave">Save changes</button></div></div>`;
};
let editDraft = {};
ACT.efColor = el => { editDraft.color = el.dataset.arg; $('#ef-colors').innerHTML = swatches(editDraft.color, 'efColor'); };
CHANGE.efColorPick = el => { editDraft.color = el.value; $('#ef-colors').innerHTML = swatches(editDraft.color, 'efColor'); };
ACT.editSave = async () => {
  const sq = S.squad, d = {}, has = id => !!document.getElementById(id);
  if (has('ef-name')) { d.name = val('ef-name'); d.tag = val('ef-tag'); }
  if (has('ef-photo')) d.photo = val('ef-photo');
  if (has('ef-banner')) d.banner = val('ef-banner');
  if (has('ef-colors')) d.color = editDraft.color;
  if (has('ef-privacy')) { d.privacy = val('ef-privacy'); d.password = val('ef-pw'); d.radio = parseInt(val('ef-radio'), 10) || 0; d.friendlyFire = checked('ef-ff'); }
  if (has('ef-max') && parseInt(val('ef-max'), 10) !== sq.maxMembers) d.maxMembers = parseInt(val('ef-max'), 10);
  await run('edit', d, 'Squad updated.');
};

// ================================================================== PROFILE CARD (shared)
function profileCard(p) {
  const c = rgbStr(p.squad ? p.squad.color : (S.settings.themeColor || '#3b82f6')), banner = safeUrl(p.banner);
  const st = { online: 'online', idle: 'idle', dnd: 'dnd' }[p.status] || '';
  return `<div class="squad" style="--c:${c}"><div class="cover" style="height:96px;${banner ? `background-image:url('${esc(banner)}')` : ''}"></div>
    <div class="body"><div class="top">${avatar(p.picture, p.name, p.squad ? p.squad.color : S.settings.themeColor, 'xl', st)}<div class="grow" style="padding-top:40px"><div class="nm" style="font-size:20px">${esc(p.name)}${p.verified ? ` <span style="color:#7dd3fc" title="Verified">${ico('badge', 18)}</span>` : ''}</div>
      <div class="row-flex wrap" style="margin-top:4px">${p.squad ? pill((p.squad.tag ? '[' + p.squad.tag + '] ' : '') + p.squad.name, 'accent') : pill('No squad')}${pill('Level ' + p.level)}${pill(p.status === 'dnd' ? 'Do not disturb' : p.status[0].toUpperCase() + p.status.slice(1))}</div></div></div>
      ${p.bio ? `<p style="margin:12px 0;user-select:text">${esc(p.bio)}</p>` : ''}
      <div class="stats" style="margin-top:12px"><div class="stat"><b>${num(p.kills)}</b><span>Kills</span></div><div class="stat"><b>${num(p.deaths)}</b><span>Deaths</span></div><div class="stat"><b>${(+p.kd || 0).toFixed(2)}</b><span>K/D</span></div><div class="stat"><b>${num(p.warsWon)}</b><span>Wars won</span></div></div>
      ${(p.gallery || []).length ? `<div class="gallery">${p.gallery.map(u => `<div style="background-image:url('${esc(safeUrl(u))}')" data-act="zoom" data-arg="${esc(safeUrl(u))}"></div>`).join('')}</div>` : ''}</div></div>`;
}
ACT.profileOpen = async el => {
  const r = await run('profile', { identifier: el.dataset.arg });
  if (!r.ok) return;
  modal(profileCard(r.payload) + `<div class="modal-actions"><button class="btn" data-act="closeModal">Close</button></div>`, { wide: true, noFocus: true });
};

// ================================================================== WARS
PAGES.wars = {
  title: 'KOS wars', sub: 'Challenge another squad. Kills inside the war count for score.',
  async render(el) {
    const sq = S.squad, war = sq && sq.war; let html = '';
    if (war && war.state === 'pending') {
      const mine = war.requester === sq.id, other = war.a.id === sq.id ? war.b : war.a, left = Math.max(0, war.expiresAt - nowSec());
      html += `<div class="warcard"><div><b>${mine ? 'Waiting for ' + esc(other.name) : esc(other.name) + ' challenged your squad'}</b><div class="muted">${war.minutes} minute war · expires in ${fmtTime(left)}</div></div>
        ${!mine && can('wars') ? '<div class="row-flex"><button class="btn small primary" data-act="warYes">Accept</button><button class="btn small" data-act="warNo">Decline</button></div>' : ''}</div>`;
    } else if (war && war.state === 'active') {
      html += `<div class="warcard"><div><b>${esc(war.a.name)} vs ${esc(war.b.name)}</b><div class="muted">Ends in ${fmtTime(Math.max(0, war.endsAt - nowSec()))}</div></div><div class="score">${war.ka} - ${war.kb}</div>
        ${S.settings.warSurrender !== false && can('wars') ? '<button class="btn small danger" data-act="warSurrender">Surrender</button>' : ''}</div>`;
    }
    const [lr, wr] = await Promise.all([req('list'), req('wars')]);
    const list = (lr.ok ? lr.payload : []).filter(s => !sq || s.id !== sq.id), wars = wr.ok ? wr.payload : [];
    html += `<div class="section">Wars in progress</div>` + (wars.length ? wars.map(w => `<div class="row"><div class="grow"><div class="name">${esc(w.a.name)} <span class="muted">vs</span> ${esc(w.b.name)}</div><div class="meta">Ends in ${fmtTime(Math.max(0, w.endsAt - nowSec()))}</div></div><b style="font-size:18px">${w.ka} - ${w.kb}</b></div>`).join('') : '<p class="muted">No wars right now.</p>');
    if (sq && can('wars') && !war) {
      html += `<div class="section">Challenge a squad</div>` + (list.length ? `<div class="grid">${list.map(s => squadCard(s, s.atWar ? pill('At war', 'war') : `<button class="btn small primary" data-act="warChallenge" data-arg="${s.id}" data-name="${esc(s.name)}">Challenge</button>`)).join('')}</div>` : '<p class="muted">There are no other squads.</p>');
    } else if (sq && !can('wars')) html += '<p class="muted">Your rank cannot start wars.</p>';
    else if (!sq) html += '<p class="muted">Join a squad to take part in wars.</p>';
    el.innerHTML = html;
  },
};
ACT.warChallenge = el => {
  const st = S.settings, id = parseInt(el.dataset.arg, 10);
  modal(`<h3>Challenge ${esc(el.dataset.name)}</h3><div class="field"><label>Length in minutes (${st.warMin} to ${st.warMax})</label><input id="war-min" type="number" min="${st.warMin}" max="${st.warMax}" value="${Math.min(st.warMax, Math.max(st.warMin, 10))}"></div>
    <div class="modal-actions"><button class="btn" data-act="closeModal">Cancel</button><button class="btn primary" id="war-go">Send challenge</button></div>`);
  $('#war-go').onclick = async () => { const r = await run('warChallenge', { id, minutes: parseInt(val('war-min'), 10) }); if (r.ok) closeModal(); };
};
ACT.warYes = () => run('warAnswer', { accept: true });
ACT.warNo = () => run('warAnswer', { accept: false });
ACT.warSurrender = () => confirmBox('Surrender?', 'The other squad wins the war.', 'Surrender', () => run('warSurrender', {}), true);

// ================================================================== BOUNTIES
PAGES.bounties = {
  title: 'Bounties', sub: 'Put money on a player. Whoever takes them out collects it.',
  async render(el) {
    const r = await req('bounties'), list = r.ok ? r.payload : [], sq = S.squad;
    const canPlace = sq && can('bounties') && S.me.money;
    el.innerHTML = `<div class="toolbar"><div class="grow muted">${list.length} active bount${list.length === 1 ? 'y' : 'ies'}</div>${canPlace ? `<button class="btn primary" data-act="bountyOpen">${ico('plus', 16)} Place bounty</button>` : ''}</div>` +
      (list.length ? list.map(b => `<div class="row"><div class="avatar" style="border-color:rgba(239,68,68,.6);color:#fca5a5;background:rgba(239,68,68,.12)">${ico('target', 18)}</div><div class="grow"><div class="name">${esc(b.target)}</div><div class="meta">Placed by ${esc(b.squad)}${b.note ? ' · ' + esc(b.note) : ''} · expires in ${fmtLong(b.expires - nowSec())}</div></div>
        <b style="font-size:18px;color:#4ade80">${money(b.amount)}</b>${sq && b.squadId === sq.id && can('bounties') ? `<button class="btn small danger" data-act="bountyCancel" data-arg="${b.id}">Cancel</button>` : ''}</div>`).join('') : empty('No bounties', 'Be the first to place one.'));
  },
};
ACT.bountyOpen = async () => {
  const r = await req('players'), list = r.ok ? r.payload : [], st = S.settings;
  modal(`<h3>Place a bounty</h3><div class="field"><label>Player</label><select id="bt-target">${list.length ? list.filter(p => !p.hidden).map(p => `<option value="${p.src}">${esc(p.name)} (#${p.src})${p.squad ? ' [' + esc(p.squad) + ']' : ''}</option>`).join('') : '<option value="">No players online</option>'}</select></div>
    <div class="field"><label>Amount (${money(st.bountyMin)} to ${money(st.bountyMax)})</label><input id="bt-amt" type="number" min="${st.bountyMin}" max="${st.bountyMax}" value="${st.bountyMin}"></div>
    <div class="field"><label>Note (optional)</label><input id="bt-note" type="text" maxlength="${st.bountyNoteMax || 80}"></div>
    ${S.squad.permanent && st.bankEnabled !== false && can('withdraw') ? '<div class="toggle-row"><div><div class="t">Pay from the squad bank</div></div><input id="bt-bank" type="checkbox"></div>' : ''}
    <p class="muted">The money is taken when you place it. If it expires or you cancel it you are refunded.</p>
    <div class="modal-actions"><button class="btn" data-act="closeModal">Cancel</button><button class="btn primary" id="bt-go">Place bounty</button></div>`);
  $('#bt-go').onclick = async () => {
    const res = await run('bountyPlace', { target: parseInt(val('bt-target'), 10), amount: parseInt(val('bt-amt'), 10), note: val('bt-note'), fromBank: checked('bt-bank') }, 'Bounty placed.');
    if (res.ok) { closeModal(); refreshPage(); }
  };
};
ACT.bountyCancel = async el => { const r = await run('bountyCancel', { id: parseInt(el.dataset.arg, 10) }, 'Bounty cancelled.'); if (r.ok) refreshPage(); };
