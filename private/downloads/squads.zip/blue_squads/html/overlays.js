'use strict';
// Always-on pieces: HUD, mini radar, war bar, chat feed, quick chat, invite popup, ping wheel, toasts

let hudMode = null;          // null | 'edit' | 'click'
let radarData = { on: false, dots: [] };

// ---------------------------------------------------------------- game messages
HANDLERS.init = d => {
  S.settings = d.settings || {}; S.me = d.me; S.squad = d.squad; S.ui = d.ui || {}; S.pingTypes = d.pingTypes || [];
  if (S.squad) S.nowOffset = (S.squad.now || nowSec()) - Math.floor(Date.now() / 1000);
  applyTheme(); renderHud(); renderWarBar();
};
HANDLERS.settings = d => { S.settings = d.settings || {}; applyTheme(); renderHud(); renderWarBar(); if (S.menuOpen) refreshPage(); };
HANDLERS.squad = d => {
  S.squad = d.squad;
  if (S.squad && S.squad.now) S.nowOffset = S.squad.now - Math.floor(Date.now() / 1000);
  if (!S.squad) { S.live = []; closeInvite(); }
  renderHud(); renderWarBar(); renderRadar();
  if (S.menuOpen) onSquadChanged();
};
HANDLERS.live = d => { S.live = d.list || []; renderHud(); };
HANDLERS.toast = d => toast(d.message, d.kind);
HANDLERS.prefs = d => { if (S.me) S.me.prefs = d.prefs; applyTheme(); renderHud(); renderRadar(); };
HANDLERS.radar = d => { radarData = d; renderRadar(); };

// ---------------------------------------------------------------- HUD
function liveOf(src) { return S.live.find(l => l.s === src); }

function renderHud() {
  const el = $('#hud');
  const sq = S.squad;
  const show = sq && myPref('hudShow', true) !== false;
  if (!show) { el.classList.add('hidden'); return; }
  el.classList.remove('hidden');
  el.style.setProperty('--hx', myPref('hudX', 1)); el.style.setProperty('--hy', myPref('hudY', 30));
  el.style.setProperty('--hs', myPref('hudScale', 1)); el.style.setProperty('--ho', myPref('hudOpacity', 1));
  el.style.setProperty('--sq', sq.color); el.style.setProperty('--sq-rgb', rgbStr(sq.color));
  el.classList.toggle('edit', hudMode === 'edit');
  el.classList.toggle('click', hudMode === 'click');

  const compact = myPref('hudCompact', false) === true;
  const right = myPref('hudPhotoSide', 'left') === 'right';
  const hp = myPref('hudHealth', '#22c55e'), ar = myPref('hudArmor', '#3b82f6');
  const max = clamp(parseInt(myPref('hudMax', 8), 10) || 8, 1, 40);

  const rows = sq.members.filter(m => m.online && m.src != null).map(m => ({ m, l: liveOf(m.src) }));
  rows.sort((a, b) => (b.m.src === S.me.src) - (a.m.src === S.me.src));
  if (hudMode === 'edit' && rows.length < 3) {   // sample cards so the player can see what they are placing
    const samples = [['Alex', 100, 60], ['Sam', 72, 0], ['Riley', 35, 100]];
    samples.forEach((s, i) => rows.push({ m: { src: -1 - i, name: s[0], picture: '', owner: false }, l: { h: s[1], a: s[2], d: false, t: i === 1 } }));
  }
  const shown = rows.slice(0, max);
  el.innerHTML = shown.map(({ m, l }) => {
    const h = l ? l.h : 0, a = l ? l.a : 0, down = l && l.d, talk = l && l.t;
    const img = safeUrl(m.picture);
    return `<div class="hm ${right ? 'right' : ''} ${compact ? 'compact' : ''} ${down ? 'down' : ''} ${talk ? 'talk' : ''}" data-src="${m.src}">
      <div class="hav" style="${img ? `background-image:url('${esc(img)}');color:transparent` : ''}">${img ? '' : esc(initials(m.name))}</div>
      <div class="hi"><div class="hn">${m.owner ? `<span class="crown">${ico('crown', 12)}</span>` : ''}<span>${esc(m.name)}</span>${talk ? `<span class="mic">${ico('mic', 12)}</span>` : ''}${down ? '<span style="color:#fca5a5">DOWN</span>' : ''}</div>
      <div class="hbars"><div class="hb"><i style="width:${h}%;background:${esc(hp)}"></i></div><div class="hb"><i style="width:${a}%;background:${esc(ar)}"></i></div></div></div></div>`;
  }).join('') + (rows.length > shown.length ? `<div class="more">+${rows.length - shown.length} more</div>` : '');
}

// click a teammate to set a waypoint on them
$('#hud').addEventListener('click', e => {
  if (hudMode !== 'click') return;
  const row = e.target.closest('.hm'); if (!row) return;
  post('waypoint', { src: parseInt(row.dataset.src, 10) });
});

// drag to move, wheel to resize (edit mode)
(function () {
  const el = $('#hud'); let drag = null;
  el.addEventListener('mousedown', e => {
    if (hudMode !== 'edit') return;
    const r = el.getBoundingClientRect();
    drag = { dx: e.clientX - r.left, dy: e.clientY - r.top };
    e.preventDefault();
  });
  window.addEventListener('mousemove', e => {
    if (!drag) return;
    const x = clamp((e.clientX - drag.dx) / innerWidth * 100, 0, 95), y = clamp((e.clientY - drag.dy) / innerHeight * 100, 0, 95);
    S.me.prefs.hudX = +x.toFixed(1); S.me.prefs.hudY = +y.toFixed(1);
    el.style.setProperty('--hx', S.me.prefs.hudX); el.style.setProperty('--hy', S.me.prefs.hudY);
  });
  window.addEventListener('mouseup', () => {
    if (!drag) return; drag = null;
    savePref('hudX', S.me.prefs.hudX); savePref('hudY', S.me.prefs.hudY);
  });
  el.addEventListener('wheel', e => {
    if (hudMode !== 'edit') return;
    const s = clamp(+(myPref('hudScale', 1) - Math.sign(e.deltaY) * 0.05).toFixed(2), 0.5, 2);
    savePref('hudScale', s); syncHudTools();
  });
})();

function startHudEdit() {
  hudMode = 'edit';
  post('hudMode', { on: true });
  hideMenuSilently();
  renderHud(); showHudTools();
}
function showHudTools() {
  let tools = $('#hud-tools');
  if (!tools) { tools = document.createElement('div'); tools.id = 'hud-tools'; tools.className = 'hud-tools'; document.body.appendChild(tools); }
  tools.classList.remove('hidden');
  tools.innerHTML = `<b>Edit squad HUD</b><p>Drag the cards to move them. Scroll over them to resize.</p>
    <label>Size <input id="ht-scale" type="range" min="0.5" max="2" step="0.05"></label>
    <label>Opacity <input id="ht-op" type="range" min="0.2" max="1" step="0.05"></label>
    <div class="row-flex"><button class="btn small" data-act="hudReset">Reset</button><button class="btn small primary" data-act="hudDone">Done</button></div>`;
  syncHudTools();
  $('#ht-scale').oninput = e => { savePref('hudScale', +e.target.value); };
  $('#ht-op').oninput = e => { savePref('hudOpacity', +e.target.value); };
}
function syncHudTools() { const a = $('#ht-scale'), b = $('#ht-op'); if (a) a.value = myPref('hudScale', 1); if (b) b.value = myPref('hudOpacity', 1); }
function endHudMode() {
  hudMode = null; const t = $('#hud-tools'); if (t) t.classList.add('hidden');
  post('hudMode', { on: false }); renderHud();
}
ACT.hudDone = () => { endHudMode(); };
ACT.hudReset = () => {
  const s = S.settings;
  savePref('hudX', s.def_hudX); savePref('hudY', s.def_hudY); savePref('hudScale', s.def_hudScale); savePref('hudOpacity', s.def_hudOpacity);
  syncHudTools();
};
HANDLERS.hudMode = d => { if (d.click) { hudMode = 'click'; renderHud(); } else { hudMode = null; const t = $('#hud-tools'); if (t) t.classList.add('hidden'); renderHud(); } };

// ---------------------------------------------------------------- mini radar
function renderRadar() {
  const box = $('#radar');
  const on = radarData.on && S.squad && myPref('radar', true) !== false;
  box.classList.toggle('hidden', !on);
  if (!on) return;
  const c = $('#radar-canvas'), g = c.getContext('2d'), w = c.width, hgt = c.height, cx = w / 2, cy = hgt / 2, r = w / 2 - 4;
  g.clearRect(0, 0, w, hgt);
  const acc = getComputedStyle(document.documentElement).getPropertyValue('--accent').trim() || '#3b82f6';
  g.fillStyle = 'rgba(8,10,16,.72)'; g.beginPath(); g.arc(cx, cy, r, 0, 7); g.fill();
  g.strokeStyle = 'rgba(255,255,255,.18)'; g.lineWidth = 1.5; g.stroke();
  g.strokeStyle = 'rgba(255,255,255,.1)';
  g.beginPath(); g.arc(cx, cy, r / 2, 0, 7); g.moveTo(cx - r, cy); g.lineTo(cx + r, cy); g.moveTo(cx, cy - r); g.lineTo(cx, cy + r); g.stroke();
  (radarData.dots || []).forEach(p => {
    const x = cx + p.x * r, y = cy + p.y * r;
    g.fillStyle = p.d ? '#ef4444' : (S.squad.color || acc);
    g.beginPath(); g.arc(x, y, 5, 0, 7); g.fill();
    g.strokeStyle = 'rgba(255,255,255,.8)'; g.lineWidth = 1.5; g.stroke();
  });
  g.fillStyle = '#fff'; g.beginPath(); g.moveTo(cx, cy - 7); g.lineTo(cx + 5, cy + 5); g.lineTo(cx - 5, cy + 5); g.closePath(); g.fill();
}

// ---------------------------------------------------------------- war bar and result
function renderWarBar() {
  const box = $('#warbar'), war = S.squad && S.squad.war;
  if (!war || war.state !== 'active' || myPref('warBar', true) === false || S.settings.warsEnabled === false) { box.classList.add('hidden'); return; }
  box.classList.remove('hidden');
  const left = Math.max(0, war.endsAt - nowSec());
  const side = (s, k, cls) => {
    const img = safeUrl(s.photo);
    return `<div class="side ${cls}" style="--c:${rgbStr(s.color)};${safeUrl(s.banner) ? `background-image:url('${esc(safeUrl(s.banner))}')` : ''}">${avatar(img, s.name, s.color, '')}<div class="grow"><div class="sn">${esc(s.name)}</div></div><div class="sk">${k}</div></div>`;
  };
  box.innerHTML = side(war.a, war.ka, 'a') + `<div class="mid"><small>KOS WAR</small><b>${fmtTime(left)}</b></div>` + side(war.b, war.kb, 'b');
}
setInterval(() => { if (S.squad && S.squad.war && S.squad.war.state === 'active') renderWarBar(); }, 1000);
HANDLERS.warScore = d => {
  const w = S.squad && S.squad.war;
  if (w && w.id === d.score.id) { w.ka = d.score.ka; w.kb = d.score.kb; renderWarBar(); }
};
HANDLERS.warEnd = d => {
  const r = d.result, box = $('#warend');
  box.innerHTML = `<h2>${r.draw ? 'War ended in a draw' : esc(r.winnerName) + ' won the war'}</h2><p>${esc(r.aName)} ${r.ka} - ${r.kb} ${esc(r.bName)}</p>`;
  box.classList.remove('hidden');
  setTimeout(() => box.classList.add('hidden'), 6500);
};

// ---------------------------------------------------------------- chat
function addFeed(entry) {
  if (myPref('chatAlerts', true) === false) return;
  const feed = $('#chatfeed'), el = document.createElement('div');
  el.className = 'cm'; el.innerHTML = `<b>${esc(entry.name)}</b>${esc(entry.msg)}`;
  feed.appendChild(el);
  while (feed.children.length > 6) feed.firstChild.remove();
  const life = (S.settings.chatFeedSeconds || 10) * 1000;
  setTimeout(() => el.classList.add('out'), life);
  setTimeout(() => el.remove(), life + 600);
}
HANDLERS.chat = d => {
  addFeed(d.entry);
  if (S.cache.chat) { S.cache.chat.push(d.entry); if (S.menuOpen && S.page === 'squad' && S.tab.squad === 'chat') appendChat(d.entry); }
};
HANDLERS.quickchat = () => {
  const q = $('#quick'), i = $('#quick-input');
  q.classList.remove('hidden'); i.value = ''; setTimeout(() => i.focus(), 30);
};
function closeQuick() { $('#quick').classList.add('hidden'); $('#quick-input').blur(); }
$('#quick-input').addEventListener('keydown', e => {
  if (e.key === 'Enter') { const msg = e.target.value.trim(); closeQuick(); post('chatSend', { msg }); }
  else if (e.key === 'Escape') { closeQuick(); post('chatClose', {}); }
  e.stopPropagation();
});

// ---------------------------------------------------------------- invite popup
let inviteTimer = null;
HANDLERS.invite = d => {
  const inv = d.invite, box = $('#invite');
  const end = Date.now() + inv.seconds * 1000;
  box.style.setProperty('--accent-rgb', rgbStr(inv.color));
  box.innerHTML = `<div class="t">Squad invite</div><div class="d"><b>${esc(inv.from)}</b> invited you to <b style="color:${esc(inv.color)}">${inv.tag ? '[' + esc(inv.tag) + '] ' : ''}${esc(inv.squad)}</b></div>
    <div class="keys"><span class="key">PgUp</span> accept <span class="key">PgDn</span> decline</div><div class="timer"><i id="invite-t" style="width:100%"></i></div>`;
  box.classList.remove('hidden');
  clearInterval(inviteTimer);
  inviteTimer = setInterval(() => {
    const p = (end - Date.now()) / (inv.seconds * 1000);
    const t = $('#invite-t'); if (t) t.style.width = clamp(p * 100, 0, 100) + '%';
    if (p <= 0) closeInvite();
  }, 100);
};
function closeInvite() { clearInterval(inviteTimer); $('#invite').classList.add('hidden'); }
HANDLERS.inviteDone = closeInvite;

// ---------------------------------------------------------------- ping wheel
let wheelHot = null;
HANDLERS.wheel = d => {
  const box = $('#wheel');
  if (d.open) {
    const ring = $('#wheel-ring'), types = d.types || S.pingTypes, n = types.length, R = 132;
    ring.innerHTML = types.map((tp, i) => {
      const ang = -Math.PI / 2 + i * 2 * Math.PI / n;
      return `<div class="wheel-item" data-id="${esc(tp.id)}" style="--c:${tp.color.join(',')};left:${170 + Math.cos(ang) * R}px;top:${170 + Math.sin(ang) * R}px">${esc(tp.label)}</div>`;
    }).join('');
    wheelHot = null; box.classList.remove('hidden');
    $('#wheel-hint').textContent = '';
  } else {
    box.classList.add('hidden');
    if (d.pick) post('pingChoose', { id: wheelHot }); else post('pingChoose', {});
    wheelHot = null;
  }
};
window.addEventListener('mousemove', e => {
  if ($('#wheel').classList.contains('hidden')) return;
  const ring = $('#wheel-ring').getBoundingClientRect();
  const dx = e.clientX - (ring.left + ring.width / 2), dy = e.clientY - (ring.top + ring.height / 2);
  const items = $$('.wheel-item');
  if (Math.hypot(dx, dy) < 50 || !items.length) { wheelHot = null; items.forEach(i => i.classList.remove('hot')); return; }
  let ang = Math.atan2(dy, dx) + Math.PI / 2; if (ang < 0) ang += Math.PI * 2;
  const idx = Math.round(ang / (Math.PI * 2 / items.length)) % items.length;
  items.forEach((it, i) => it.classList.toggle('hot', i === idx));
  wheelHot = items[idx].dataset.id;
});

// ---------------------------------------------------------------- Escape
window.addEventListener('keydown', e => {
  if (e.key !== 'Escape') return;
  if (!$('#lightbox').classList.contains('hidden')) { $('#lightbox').click(); return; }
  if (closeModal()) return;
  if (!$('#tour').classList.contains('hidden')) return;
  if (hudMode) { endHudMode(); return; }
  if (S.menuOpen) closeMenu();
});
