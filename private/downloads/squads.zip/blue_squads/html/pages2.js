'use strict';
// Menu pages: leaderboard, daily tasks, profile, player settings

// ================================================================== LEADERBOARD
const BOARD_SORTS = {
  kills: { label: 'Kills', fn: (a, b) => b.kills - a.kills },
  kd: { label: 'K/D', fn: (a, b) => b.kd - a.kd },
  bounties: { label: 'Bounties', fn: (a, b) => b.bounties - a.bounties },
  level: { label: 'Level', fn: (a, b) => b.level - a.level },
};
PAGES.board = {
  title: 'Leaderboard', sub: 'The top players on the server',
  async render(el) {
    const r = await req('leaderboard'); S.cache.board = r.ok ? r.payload : [];
    el.innerHTML = `<div class="tabs">${Object.entries(BOARD_SORTS).map(([k, v]) => `<button class="tab ${((S.tab.board || 'kills') === k) ? 'active' : ''}" data-act="boardSort" data-arg="${k}">${v.label}</button>`).join('')}</div><div id="board-body"></div>`;
    renderBoard();
  },
};
ACT.boardSort = el => { S.tab.board = el.dataset.arg; $$('.tabs .tab').forEach(t => t.classList.toggle('active', t.dataset.arg === S.tab.board)); renderBoard(); };
function renderBoard() {
  const box = $('#board-body'); if (!box) return;
  const list = (S.cache.board || []).slice().sort(BOARD_SORTS[S.tab.board || 'kills'].fn);
  if (!list.length) { box.innerHTML = empty('Nobody on the board yet', 'Get some kills.'); return; }
  box.innerHTML = `<table class="table"><tr><th></th><th>Player</th><th>Squad</th><th>Kills</th><th>Deaths</th><th>K/D</th><th>Bounties</th><th>Level</th></tr>${list.map((p, i) =>
    `<tr class="${S.me && p.id === S.me.id ? 'me' : ''}"><td><span class="rank-num r${i + 1}">${i + 1}</span></td><td><a data-act="profileOpen" data-arg="${esc(p.id)}" style="cursor:pointer;font-weight:700">${esc(p.name)}</a></td><td class="muted">${p.tag ? '[' + esc(p.tag) + '] ' : ''}${esc(p.squad)}</td><td>${num(p.kills)}</td><td>${num(p.deaths)}</td><td>${(+p.kd).toFixed(2)}</td><td>${num(p.bounties)}</td><td>${p.level}</td></tr>`).join('')}</table>`;
}

// ================================================================== DAILY TASKS
PAGES.tasks = {
  title: 'Daily tasks', sub: () => S.cache.tasks ? `Resets in ${fmtLong(S.cache.tasks.resetIn)}` : 'Finish tasks for rewards',
  async render(el) {
    const r = await req('tasks'); if (!r.ok) { el.innerHTML = empty('Not available', r.payload); return; }
    S.cache.tasks = r.payload; renderHeader();
    const tasks = r.payload.tasks;
    el.innerHTML = r.payload.enabled === false ? empty('Daily tasks are off', '') : `<div class="grid">${tasks.map(t => {
      const done = t.progress >= t.goal;
      return `<div class="card"><div class="row-flex" style="justify-content:space-between"><h3 style="margin:0">${esc(t.label)}</h3>${t.claimed ? pill('Claimed', 'open') : pill(money(t.reward), 'gold')}</div>
        <div class="row-flex" style="margin:12px 0 6px;justify-content:space-between"><span class="muted">${num(Math.min(t.progress, t.goal))} / ${num(t.goal)}</span>${done ? `<span style="color:#4ade80">${ico('check', 14)}</span>` : ''}</div>${bar(t.progress, t.goal, done ? 'done' : '')}
        <button class="btn ${done && !t.claimed ? 'primary' : ''}" style="width:100%;margin-top:12px" data-act="taskClaim" data-arg="${t.id}" ${!done || t.claimed ? 'disabled' : ''}>${t.claimed ? 'Claimed' : done ? 'Claim reward' : 'In progress'}</button></div>`;
    }).join('')}</div>`;
  },
};
ACT.taskClaim = async el => { const r = await run('claimTask', { id: el.dataset.arg }, 'Reward claimed.'); if (r.ok) refreshPage(); };

// ================================================================== PROFILE
let profDraft = null;
PAGES.profile = {
  title: 'My profile', sub: 'How other players see you',
  async render(el) {
    const r = await req('profile', { identifier: S.me.id }); if (!r.ok) { el.innerHTML = empty('Not available', r.payload); return; }
    const p = r.payload; S.cache.me = p;
    if (!profDraft) profDraft = { bio: p.bio, picture: p.picture, banner: p.banner, status: p.ownStatus || p.status, gallery: (p.gallery || []).slice() };
    const d = profDraft;
    el.innerHTML = `<div id="prof-preview" class="preview">${profileCard(Object.assign({}, p, { bio: d.bio, picture: d.picture, banner: d.banner, status: d.status === 'invisible' ? 'offline' : d.status, gallery: d.gallery }))}</div>
      <div class="card"><div class="grid"><div class="field"><label>Status</label><select id="pf-status" data-change="pfField" data-k="status">${['online', 'idle', 'dnd', 'invisible'].map(s => `<option value="${s}" ${d.status === s ? 'selected' : ''}>${{ online: 'Online', idle: 'Idle', dnd: 'Do not disturb', invisible: 'Invisible' }[s]}</option>`).join('')}</select></div>
        <div class="field"><label>Picture link</label><input type="url" value="${esc(d.picture)}" placeholder="https://" data-input="pfField" data-k="picture"></div></div>
        <div class="row-flex wrap" style="margin-bottom:12px"><button class="btn small" data-act="importAvatar" data-arg="discord">Use my Discord picture</button><button class="btn small" data-act="importAvatar" data-arg="steam">Use my Steam picture</button></div>
        <div class="field"><label>Banner link</label><input type="url" value="${esc(d.banner)}" placeholder="https://" data-input="pfField" data-k="banner"></div>
        <div class="field"><label>About you (200 characters)</label><textarea maxlength="200" data-input="pfField" data-k="bio">${esc(d.bio)}</textarea></div>
        <div class="field"><label>Gallery (up to 9 picture links, one per line)</label><textarea id="pf-gallery" data-input="pfGallery" placeholder="https://">${esc(d.gallery.join('\n'))}</textarea></div>
        <div class="modal-actions"><button class="btn ghost" data-act="profReset">Undo changes</button><button class="btn primary" data-act="profSave">Save profile</button></div></div>`;
  },
};
function previewProfile() {
  const box = $('#prof-preview'), p = S.cache.me, d = profDraft; if (!box || !p) return;
  box.innerHTML = profileCard(Object.assign({}, p, { bio: d.bio, picture: d.picture, banner: d.banner, status: d.status === 'invisible' ? 'offline' : d.status, gallery: d.gallery }));
}
INPUT.pfField = el => { profDraft[el.dataset.k] = el.value; previewProfile(); };
CHANGE.pfField = el => { profDraft[el.dataset.k] = el.value; previewProfile(); };
INPUT.pfGallery = el => { profDraft.gallery = el.value.split(/\s*\n\s*/).map(s => s.trim()).filter(Boolean).slice(0, 9); previewProfile(); };
ACT.profReset = () => { profDraft = null; refreshPage(); };
ACT.profSave = async () => {
  const d = profDraft; const r = await run('profileSave', { bio: d.bio, picture: d.picture, banner: d.banner, status: d.status, gallery: d.gallery }, 'Profile saved.');
  if (r.ok) { profDraft = null; refreshPage(); }
};
ACT.importAvatar = async el => {
  const r = await run('avatar', { kind: el.dataset.arg }, 'Picture imported.');
  if (r.ok) { profDraft = null; refreshPage(); }
};

// ================================================================== PLAYER SETTINGS
function prefToggle(key, label, desc) {
  return `<div class="toggle-row"><div><div class="t">${esc(label)}</div>${desc ? `<div class="d">${esc(desc)}</div>` : ''}</div>${toggle(!!(S.me.prefs[key]), 'pref', key)}</div>`;
}
PAGES.settings = {
  title: 'Settings', sub: 'Only you see these changes',
  render(el) {
    const p = S.me.prefs;
    el.innerHTML = `<div class="grid"><div>
      <div class="card"><h3>Appearance</h3>
        <div class="toggle-row"><div><div class="t">Light mode</div></div>${toggle(p.mode === 'light', 'prefMode')}</div>
        <div class="field" style="margin-top:10px"><label>Menu colour</label>${swatches(p.menuColor || S.settings.themeColor, 'prefColor')}</div></div>
      <div class="card"><h3>Squad HUD</h3>
        ${prefToggle('hudShow', 'Show the squad HUD')}${prefToggle('hudCompact', 'Compact cards')}
        <div class="toggle-row"><div><div class="t">Picture on the right</div></div>${toggle(p.hudPhotoSide === 'right', 'prefSide')}</div>
        <div class="field" style="margin-top:10px"><label>Members shown: <b>${p.hudMax}</b></label><input type="range" min="1" max="40" value="${p.hudMax}" data-input="prefRange" data-k="hudMax" data-int="1" style="accent-color:var(--accent)"></div>
        <div class="grid"><div class="field"><label>Health colour</label><input type="color" value="${esc(p.hudHealth)}" data-change="prefColorField" data-k="hudHealth"></div><div class="field"><label>Armor colour</label><input type="color" value="${esc(p.hudArmor)}" data-change="prefColorField" data-k="hudArmor"></div></div>
        <button class="btn" data-act="hudEdit">${ico('edit', 14)} Move and resize the HUD</button>
        <p class="muted" style="margin:10px 0 0;font-size:12px">Tip: type /squadhud in game to click a teammate and set a waypoint.</p></div>
    </div><div>
      <div class="card"><h3>In the world</h3>
        ${prefToggle('tags', 'Nametags above teammates')}${prefToggle('tagIds', 'Show IDs on nametags')}${prefToggle('tagHealth', 'Show health on nametags')}
        ${prefToggle('blips', 'Teammate blips on the map')}${prefToggle('radar', 'Mini radar')}
        <div class="field" style="margin-top:10px"><label>Blip colour (leave on squad colour for default)</label><div class="row-flex"><input type="color" value="${esc(p.blipColor || (S.squad ? S.squad.color : '#3b82f6'))}" data-change="prefColorField" data-k="blipColor"><button class="btn small" data-act="blipReset">Use squad colour</button></div></div></div>
      <div class="card"><h3>Alerts</h3>${prefToggle('warBar', 'War bar')}${prefToggle('chatAlerts', 'Squad chat on screen')}${prefToggle('pingAlerts', 'Ping alerts and sounds')}</div>
      <button class="btn" data-act="tourAgain">Show the welcome tour again</button>
    </div></div>`;
  },
};
ACT.pref = el => { const k = el.dataset.arg; savePref(k, !S.me.prefs[k]); refreshPage(); };
ACT.prefMode = () => { savePref('mode', S.me.prefs.mode === 'light' ? 'dark' : 'light'); refreshPage(); };
ACT.prefSide = () => { savePref('hudPhotoSide', S.me.prefs.hudPhotoSide === 'right' ? 'left' : 'right'); refreshPage(); };
ACT.prefColor = el => { savePref('menuColor', el.dataset.arg); refreshPage(); };
CHANGE.prefColorPick = el => { savePref('menuColor', el.value); refreshPage(); };
CHANGE.prefColorField = el => savePref(el.dataset.k, el.value);
INPUT.prefRange = el => { const v = el.dataset.int ? parseInt(el.value, 10) : parseFloat(el.value); savePref(el.dataset.k, v); const b = el.parentElement.querySelector('b'); if (b) b.textContent = v; };
ACT.blipReset = () => { savePref('blipColor', ''); refreshPage(); };
ACT.hudEdit = () => { if (!S.squad) return toast('Join a squad to place the HUD.', 'error'); startHudEdit(); };
ACT.tourAgain = () => startTour();
