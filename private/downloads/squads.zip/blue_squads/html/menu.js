'use strict';
// The menu window: rail, page router, header and the welcome tour

const RAIL = [
  { id: 'squad', icon: 'users', label: 'My squad', show: () => !!S.squad },
  { id: 'browse', icon: 'search', label: 'Browse squads', show: () => true },
  { id: 'wars', icon: 'swords', label: 'KOS wars', show: () => S.settings.warsEnabled !== false },
  { id: 'bounties', icon: 'target', label: 'Bounties', show: () => S.settings.bountiesEnabled !== false },
  { id: 'board', icon: 'trophy', label: 'Leaderboard', show: () => true },
  { id: 'tasks', icon: 'list', label: 'Daily tasks', show: () => S.settings.tasksEnabled !== false },
  { id: 'profile', icon: 'user', label: 'Profile', show: () => true },
  { id: 'settings', icon: 'gear', label: 'Settings', show: () => true },
  { id: 'admin', icon: 'wrench', label: 'Admin panel', show: () => !!(S.me && S.me.isAdmin) },
];

function defaultPage() { return S.squad ? 'squad' : 'browse'; }

HANDLERS.menu = d => {
  if (d.open) openMenu(d.page);
  else { S.menuOpen = false; setMenuClass(false); $('#app').classList.add('hidden'); closeModal(); }
};

function setMenuClass(v) { document.body.classList.toggle('menu-open', !!v); }
function openMenu(page) {
  S.menuOpen = true; setMenuClass(true);
  $('#app').classList.remove('hidden');
  S.page = page && pageAllowed(page) ? page : defaultPage();
  renderRail();
  refreshPage();
  if (S.me && !S.me.prefs.tourDone && !S.tourShown) { S.tourShown = true; startTour(); }
}
function hideMenuSilently() { S.menuOpen = false; setMenuClass(false); $('#app').classList.add('hidden'); closeModal(); }
function closeMenu() {
  if (typeof AD !== 'undefined') { AD.data = null; AD.dirty = {}; AD.clear = {}; }
  S.menuOpen = false; setMenuClass(false);
  $('#app').classList.add('hidden');
  closeModal();
  post('close', {});
}
ACT.closeMenu = closeMenu;
$('#btn-close').addEventListener('click', closeMenu);

function pageAllowed(id) { const r = RAIL.find(x => x.id === id); return !!(r && r.show() && PAGES[id]); }

function renderRail() {
  const rail = $('#rail');
  if (!pageAllowed(S.page)) S.page = defaultPage();
  rail.innerHTML = `<div class="logo">${ico('logo', 22)}</div>` + RAIL.filter(r => r.show()).map(r =>
    `<button class="nav ${S.page === r.id ? 'active' : ''}" data-act="goto" data-arg="${r.id}" title="${esc(r.label)}">${ico(r.icon, 20)}${r.id === 'squad' && S.squad && S.squad.war && S.squad.war.state === 'pending' && S.squad.war.requester !== S.squad.id ? '<i class="dot"></i>' : ''}${r.id === 'squad' && S.squad && S.squad.applications && S.squad.applications.length ? '<i class="dot"></i>' : ''}</button>`).join('');
}
ACT.goto = el => { S.page = el.dataset.arg; renderRail(); refreshPage(); };

function renderHeader() {
  const p = PAGES[S.page]; if (!p) return;
  $('#page-title').textContent = typeof p.title === 'function' ? p.title() : p.title;
  $('#page-sub').textContent = typeof p.sub === 'function' ? p.sub() : (p.sub || '');
  const chips = [];
  if (S.me && S.settings.xpEnabled !== false) chips.push(`<span class="chip accent">${ico('star', 14)} Level ${S.me.level}</span>`);
  if (S.squad && S.squad.war && S.squad.war.state === 'active') chips.push(`<span class="chip war">${ico('swords', 14)} At war</span>`);
  $('#head-chips').innerHTML = chips.join('');
}

let renderToken = 0;
async function refreshPage() {
  const page = PAGES[S.page]; if (!page) return;
  const token = ++renderToken;
  renderHeader();
  const el = $('#page');
  const keep = el.scrollTop;
  try { await page.render(el, token); } catch (e) { console.error('[squads] page', S.page, e); el.innerHTML = empty('Something went wrong', 'Close the menu and open it again.'); }
  if (token === renderToken) el.scrollTop = keep;
}
// a live update arrived: redraw unless the player is typing
function onSquadChanged() {
  if (!pageAllowed(S.page)) S.page = defaultPage();
  renderRail();
  const a = document.activeElement;
  if (a && /^(INPUT|TEXTAREA|SELECT)$/.test(a.tagName) && $('#page').contains(a)) { renderHeader(); return; }
  if (!$('#modal').classList.contains('hidden')) { renderHeader(); return; }
  refreshPage();
}

// ------------------------------------------------------------------ welcome tour
const TOUR = [
  { icon: 'users', title: 'Welcome to Squads', text: 'Team up with other players. Create your own squad or join one from the browse screen.' },
  { icon: 'pin', title: 'See your team', text: 'Teammates show on the map and above their heads, and the squad HUD shows health and armor. Click a card (with /squadhud) to set a waypoint.' },
  { icon: 'flag', title: 'Ping what you see', text: 'Tap the middle mouse button to ping, double tap for an enemy, hold for the ping wheel. Press Y to quick chat.' },
  { icon: 'swords', title: 'Wars, bounties and more', text: 'Challenge squads to KOS wars, place bounties, complete daily tasks and climb the leaderboard.' },
  { icon: 'gear', title: 'Make it yours', text: 'Open Settings to move and resize the HUD, change colours and turn things off. Press Esc any time to close the menu.' },
];
let tourStep = 0;
function startTour() { tourStep = 0; renderTour(); $('#tour').classList.remove('hidden'); }
function renderTour() {
  const s = TOUR[tourStep], last = tourStep === TOUR.length - 1;
  $('#tour').innerHTML = `<div class="tour-card"><div style="color:var(--accent)">${ico(s.icon, 44)}</div><h3>${esc(s.title)}</h3><p>${esc(s.text)}</p>
    <div class="dots">${TOUR.map((_, i) => `<i class="${i === tourStep ? 'on' : ''}"></i>`).join('')}</div>
    <div class="row-flex" style="justify-content:center"><button class="btn ghost" data-act="tourSkip">Skip</button><button class="btn primary" data-act="tourNext">${last ? 'Get started' : 'Next'}</button></div></div>`;
}
ACT.tourNext = () => { if (tourStep >= TOUR.length - 1) ACT.tourSkip(); else { tourStep++; renderTour(); } };
ACT.tourSkip = () => { $('#tour').classList.add('hidden'); savePref('tourDone', true); };
