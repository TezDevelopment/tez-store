-- Tables are created and updated automatically every time the resource starts.

DB = {}

local VERSION = 1

local create = {
    [[CREATE TABLE IF NOT EXISTS squad_meta (
        k VARCHAR(40) NOT NULL PRIMARY KEY,
        v VARCHAR(255) NOT NULL
    )]],
    [[CREATE TABLE IF NOT EXISTS squad_settings (
        k VARCHAR(40) NOT NULL PRIMARY KEY,
        v LONGTEXT NOT NULL
    )]],
    [[CREATE TABLE IF NOT EXISTS squads (
        id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(60) NOT NULL,
        tag VARCHAR(12) NOT NULL DEFAULT '',
        privacy VARCHAR(12) NOT NULL DEFAULT 'open',
        pwhash VARCHAR(100) NULL,
        pwsalt VARCHAR(40) NULL,
        color VARCHAR(9) NOT NULL DEFAULT '#3b82f6',
        photo VARCHAR(300) NOT NULL DEFAULT '',
        banner VARCHAR(300) NOT NULL DEFAULT '',
        owner VARCHAR(80) NOT NULL,
        owner_name VARCHAR(80) NOT NULL DEFAULT '',
        max_members INT NOT NULL DEFAULT 40,
        friendly_fire TINYINT(1) NOT NULL DEFAULT 0,
        bank BIGINT NOT NULL DEFAULT 0,
        radio INT NOT NULL DEFAULT 0,
        ranks LONGTEXT NULL,
        bans LONGTEXT NULL,
        rally VARCHAR(100) NULL,
        created INT NOT NULL DEFAULT 0,
        last_active INT NOT NULL DEFAULT 0
    )]],
    [[CREATE TABLE IF NOT EXISTS squad_members (
        identifier VARCHAR(80) NOT NULL PRIMARY KEY,
        squad_id INT NOT NULL,
        rank_id INT NOT NULL DEFAULT 0,
        joined INT NOT NULL DEFAULT 0,
        name VARCHAR(80) NOT NULL DEFAULT '',
        INDEX (squad_id)
    )]],
    [[CREATE TABLE IF NOT EXISTS squad_players (
        identifier VARCHAR(80) NOT NULL PRIMARY KEY,
        name VARCHAR(80) NOT NULL DEFAULT '',
        kills INT NOT NULL DEFAULT 0,
        deaths INT NOT NULL DEFAULT 0,
        teamkills INT NOT NULL DEFAULT 0,
        bounties INT NOT NULL DEFAULT 0,
        wars_won INT NOT NULL DEFAULT 0,
        xp BIGINT NOT NULL DEFAULT 0,
        profile LONGTEXT NULL,
        settings LONGTEXT NULL,
        daily LONGTEXT NULL,
        updated INT NOT NULL DEFAULT 0
    )]],
    [[CREATE TABLE IF NOT EXISTS squad_bounties (
        id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
        squad_id INT NOT NULL DEFAULT 0,
        squad_name VARCHAR(60) NOT NULL DEFAULT '',
        poster VARCHAR(80) NOT NULL,
        poster_name VARCHAR(80) NOT NULL DEFAULT '',
        target VARCHAR(80) NOT NULL,
        target_name VARCHAR(80) NOT NULL DEFAULT '',
        amount INT NOT NULL,
        note VARCHAR(120) NOT NULL DEFAULT '',
        from_bank TINYINT(1) NOT NULL DEFAULT 0,
        created INT NOT NULL,
        expires INT NOT NULL,
        INDEX (target)
    )]],
    [[CREATE TABLE IF NOT EXISTS squad_bank_log (
        id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
        squad_id INT NOT NULL,
        identifier VARCHAR(80) NOT NULL DEFAULT '',
        name VARCHAR(80) NOT NULL DEFAULT '',
        kind VARCHAR(20) NOT NULL,
        amount INT NOT NULL,
        balance BIGINT NOT NULL,
        created INT NOT NULL,
        INDEX (squad_id)
    )]],
    [[CREATE TABLE IF NOT EXISTS squad_pending (
        id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
        identifier VARCHAR(80) NOT NULL,
        account VARCHAR(10) NOT NULL DEFAULT 'bank',
        amount INT NOT NULL,
        reason VARCHAR(80) NOT NULL DEFAULT '',
        INDEX (identifier)
    )]],
    [[CREATE TABLE IF NOT EXISTS squad_logs (
        id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
        category VARCHAR(20) NOT NULL,
        message VARCHAR(500) NOT NULL,
        actor VARCHAR(80) NOT NULL DEFAULT '',
        created INT NOT NULL
    )]],
}

function DB.migrate()
    for _, q in ipairs(create) do MySQL.query.await(q) end
    local row = MySQL.single.await('SELECT v FROM squad_meta WHERE k = ?', { 'version' })
    local current = row and tonumber(row.v) or 0
    -- future updates go here, e.g. if current < 2 then ALTER TABLE ... end
    if current < VERSION then
        MySQL.query.await('REPLACE INTO squad_meta (k, v) VALUES (?, ?)', { 'version', tostring(VERSION) })
    end
end

-- ------------------------------------------------------------------ squads

function DB.saveSquad(s)
    if not s.permanent then return end
    local rally = s.rally and SQ.jenc(s.rally) or ''
    MySQL.update(
        [[UPDATE squads SET name=?, tag=?, privacy=?, pwhash=?, pwsalt=?, color=?, photo=?, banner=?, owner=?, owner_name=?,
          max_members=?, friendly_fire=?, bank=?, radio=?, ranks=?, bans=?, rally=?, last_active=? WHERE id=?]],
        { s.name, s.tag, s.privacy, s.pwhash or '', s.pwsalt or '', s.color, s.photo, s.banner, s.owner, s.ownerName or '',
          s.maxMembers, s.friendlyFire and 1 or 0, s.bank, s.radio or 0, SQ.jenc(s.ranks), SQ.jenc(s.bans or {}), rally,
          s.lastActive or SQ.now(), s.id })
end

function DB.insertSquad(s)
    return MySQL.insert.await(
        [[INSERT INTO squads (name, tag, privacy, pwhash, pwsalt, color, photo, banner, owner, owner_name, max_members,
          friendly_fire, bank, radio, ranks, bans, created, last_active) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)]],
        { s.name, s.tag, s.privacy, s.pwhash or '', s.pwsalt or '', s.color, s.photo, s.banner, s.owner, s.ownerName or '',
          s.maxMembers, s.friendlyFire and 1 or 0, s.bank, s.radio or 0, SQ.jenc(s.ranks), SQ.jenc(s.bans or {}),
          s.created, s.lastActive })
end

function DB.deleteSquad(id)
    MySQL.update('DELETE FROM squads WHERE id = ?', { id })
    MySQL.update('DELETE FROM squad_members WHERE squad_id = ?', { id })
    MySQL.update('DELETE FROM squad_bank_log WHERE squad_id = ?', { id })
end

function DB.saveMember(squadId, identifier, rankId, joined, name)
    MySQL.update('REPLACE INTO squad_members (identifier, squad_id, rank_id, joined, name) VALUES (?,?,?,?,?)',
        { identifier, squadId, rankId, joined, name or '' })
end

function DB.deleteMember(identifier)
    MySQL.update('DELETE FROM squad_members WHERE identifier = ?', { identifier })
end

function DB.bankLog(squadId, identifier, name, kind, amount, balance)
    MySQL.insert('INSERT INTO squad_bank_log (squad_id, identifier, name, kind, amount, balance, created) VALUES (?,?,?,?,?,?,?)',
        { squadId, identifier or '', name or '', kind, amount, balance, SQ.now() })
end

-- ------------------------------------------------------------------ players

function DB.loadPlayer(identifier, name)
    local row = MySQL.single.await('SELECT * FROM squad_players WHERE identifier = ?', { identifier })
    if not row then
        MySQL.insert.await('INSERT INTO squad_players (identifier, name, updated) VALUES (?,?,?)', { identifier, name or '', SQ.now() })
        row = { identifier = identifier, name = name, kills = 0, deaths = 0, teamkills = 0, bounties = 0, wars_won = 0, xp = 0 }
    end
    return {
        identifier = identifier,
        name = name or row.name,
        kills = row.kills or 0, deaths = row.deaths or 0, teamkills = row.teamkills or 0,
        bounties = row.bounties or 0, warsWon = row.wars_won or 0, xp = row.xp or 0,
        profile = SQ.jdec(row.profile, {}),
        settings = SQ.jdec(row.settings, {}),
        daily = SQ.jdec(row.daily, {}),
        dirty = false,
    }
end

function DB.savePlayer(p)
    if not p or not p.dirty then return end
    p.dirty = false
    MySQL.update(
        [[UPDATE squad_players SET name=?, kills=?, deaths=?, teamkills=?, bounties=?, wars_won=?, xp=?, profile=?, settings=?, daily=?, updated=?
          WHERE identifier=?]],
        { p.name or '', p.kills, p.deaths, p.teamkills, p.bounties, p.warsWon, math.floor(p.xp), SQ.jenc(p.profile),
          SQ.jenc(p.settings), SQ.jenc(p.daily), SQ.now(), p.identifier })
end
