-- Money, player data, daily tasks, XP, wars, bounties, bank, abilities, orders, kills, profiles

-- ===================================================================== money

function SQ.pay(identifier, acct, amount, reason)
    amount = math.floor(tonumber(amount) or 0)
    if amount <= 0 or not Bridge.hasMoney() then return end
    for src, p in pairs(SQ.players) do
        if p.id == identifier then
            if Bridge.addMoney(src, acct, amount, reason) then
                SQ.notify(src, L('note.paid', amount), 'success')
                return
            end
        end
    end
    MySQL.insert('INSERT INTO squad_pending (identifier, account, amount, reason) VALUES (?,?,?,?)',
        { identifier, acct, amount, reason or '' })
end

function SQ.payPending(src, identifier)
    if not Bridge.hasMoney() then return end
    local rows = MySQL.query.await('SELECT id, account, amount FROM squad_pending WHERE identifier = ?', { identifier })
    if not rows or #rows == 0 then return end
    local total = 0
    for _, r in ipairs(rows) do
        if Bridge.addMoney(src, r.account, r.amount, 'squads (owed)') then
            total = total + r.amount
            MySQL.update('DELETE FROM squad_pending WHERE id = ?', { r.id })
        end
    end
    if total > 0 then SQ.notify(src, L('note.owed', total), 'success') end
end

-- ================================================================ player data

function SQ.loadPlayer(src)
    local p = SQ.players[src]
    if not p then return nil end
    if SQ.pd[p.id] then return SQ.pd[p.id] end
    local pd = DB.loadPlayer(p.id, p.name)
    pd.name = p.name
    SQ.pd[p.id] = pd
    return pd
end

function SQ.pdOf(src)
    local p = SQ.players[src]
    return p and SQ.pd[p.id] or nil
end

function SQ.playerSettings(pd)
    local out = {}
    for _, f in ipairs(Schema.fields) do
        if f.k:sub(1, 4) == 'def_' then
            local key = f.k:sub(5)
            out[key] = SQ.S[f.k]
            if pd and pd.settings and pd.settings[key] ~= nil then out[key] = pd.settings[key] end
        end
    end
    out.tourDone = pd and pd.settings and pd.settings.tourDone == true or false
    return out
end

function SQ.saveAll()
    for _, pd in pairs(SQ.pd) do DB.savePlayer(pd) end
end

-- ================================================================ daily tasks

local function today() return os.date('%Y-%m-%d') end

local function dailyOf(pd)
    local d = pd.daily
    if type(d) ~= 'table' or d.date ~= today() then
        pd.daily = { date = today(), prog = {}, claimed = {} }
        pd.dirty = true
    end
    pd.daily.prog = pd.daily.prog or {}
    pd.daily.claimed = pd.daily.claimed or {}
    return pd.daily
end

function SQ.taskProgress(src, id, n)
    if not SQ.get('tasksEnabled') then return end
    local pd = SQ.pdOf(src)
    if not pd then return end
    local d = dailyOf(pd)
    local goal = SQ.get('task_' .. id .. '_goal')
    if not goal then return end
    d.prog[id] = math.min(goal, (d.prog[id] or 0) + (n or 1))
    pd.dirty = true
end

function SQ.tasksView(src)
    local pd = SQ.pdOf(src)
    if not pd then return nil end
    local d = dailyOf(pd)
    local list = {}
    for _, t in ipairs(DailyTasks) do
        list[#list + 1] = {
            id = t.id, label = t.label,
            goal = SQ.get('task_' .. t.id .. '_goal'), reward = SQ.get('task_' .. t.id .. '_reward'),
            progress = d.prog[t.id] or 0, claimed = d.claimed[t.id] == true,
        }
    end
    local t = os.date('*t')
    return { enabled = SQ.get('tasksEnabled'), tasks = list, resetIn = 86400 - (t.hour * 3600 + t.min * 60 + t.sec) }
end

function SQ.claimTask(src, id)
    if not SQ.get('tasksEnabled') then return false, L('err.disabled') end
    local pd = SQ.pdOf(src)
    if not pd then return false, L('err.notloaded') end
    local d = dailyOf(pd)
    local goal, reward = SQ.get('task_' .. tostring(id) .. '_goal'), SQ.get('task_' .. tostring(id) .. '_reward')
    if not goal then return false, L('err.badvalue') end
    if d.claimed[id] then return false, L('err.claimed') end
    if (d.prog[id] or 0) < goal then return false, L('err.notdone') end
    if reward > 0 and not Bridge.addMoney(src, SQ.get('tasksAccount'), reward, 'squad daily task') then return false, L('err.paymentfailed') end
    d.claimed[id] = true
    pd.dirty = true
    return true
end

-- ====================================================================== XP

function SQ.addXp(src, amount)
    if not SQ.get('xpEnabled') or amount <= 0 then return end
    local pd = SQ.pdOf(src)
    if not pd then return end
    local before = SQ.levelOfXp(pd.xp)
    pd.xp = pd.xp + amount
    pd.dirty = true
    local after = SQ.levelOfXp(pd.xp)
    if after > before then
        SQ.notify(src, L('note.levelup', after), 'success')
        local squad = SQ.squadOf(src)
        if squad then SQ.pushSquad(squad) end
    end
end

-- runs once a minute
function SQ.minuteTick()
    local now = SQ.now()
    for _, squad in pairs(SQ.squads) do
        local online = SQ.onlineMembers(squad)
        local mult = ((squad.xpUntil or 0) > now) and 2 or 1
        for _, m in ipairs(online) do
            SQ.taskProgress(m.src, 'time', 1)
            local gain = SQ.get('xpPerMinute')
            if squad.permanent and #online > 1 then
                for _, o in ipairs(online) do
                    if o.src ~= m.src and SQ.distance(m.src, o.src) <= SQ.get('xpNearDistance') then
                        gain = gain + SQ.get('xpNearBonus')
                        break
                    end
                end
            end
            SQ.addXp(m.src, gain * mult)
        end
    end
    SQ.saveAll()
end

-- ===================================================================== wars

local warCooldown = {}
local function pairKey(a, b) return math.min(a, b) .. '-' .. math.max(a, b) end

local function warOfSquad(id, states)
    for _, w in pairs(SQ.wars) do
        if (w.a == id or w.b == id) and (not states or states[w.state]) then return w end
    end
end

function SQ.warChallenge(src, targetId, minutes)
    if not SQ.get('warsEnabled') then return false, L('err.disabled') end
    local squad, p = SQ.squadOf(src)
    if not squad then return false, L('err.nosquad') end
    if not SQ.hasPerm(squad, p.id, 'wars') then return false, L('err.noperm') end
    local target = SQ.squads[tonumber(targetId)]
    if not target or target.id == squad.id then return false, L('err.gone') end
    minutes = math.floor(tonumber(minutes) or 0)
    if minutes < SQ.get('warMin') or minutes > SQ.get('warMax') then return false, L('err.warminutes', SQ.get('warMin'), SQ.get('warMax')) end
    if warOfSquad(squad.id) then return false, L('err.alreadywar') end
    if warOfSquad(target.id) then return false, L('err.targetwar') end
    local cd = warCooldown[pairKey(squad.id, target.id)]
    if cd and cd > SQ.now() then return false, L('err.warcooldown', cd - SQ.now()) end

    local id = SQ.nextWarId
    SQ.nextWarId = id + 1
    SQ.wars[id] = {
        id = id, a = squad.id, b = target.id, state = 'pending', requester = squad.id, minutes = minutes,
        expiresAt = SQ.now() + SQ.get('warRequestExpire'), ka = 0, kb = 0,
    }
    SQ.pushSquad(squad)
    SQ.pushSquad(target)
    for _, m in ipairs(SQ.onlineMembers(target)) do
        if SQ.hasPerm(target, m.id, 'wars') then SQ.notify(m.src, L('note.warrequest', squad.name, minutes), 'warn') end
    end
    SQ.notify(src, L('note.warsent', target.name), 'success')
    return true
end

function SQ.warAnswer(src, accept)
    local squad, p = SQ.squadOf(src)
    if not squad then return false, L('err.nosquad') end
    if not SQ.hasPerm(squad, p.id, 'wars') then return false, L('err.noperm') end
    local war = warOfSquad(squad.id, { pending = true })
    if not war or war.requester == squad.id then return false, L('err.nowar') end
    local other = SQ.squads[war.requester]
    if not accept then
        SQ.wars[war.id] = nil
        SQ.pushSquad(squad)
        if other then
            SQ.pushSquad(other)
            SQ.squadNotify(other, L('note.wardeclined', squad.name), 'warn')
        end
        return true
    end
    war.state = 'active'
    war.startedAt = SQ.now()
    war.endsAt = SQ.now() + war.minutes * 60
    SQ.pushSquad(squad)
    if other then SQ.pushSquad(other) end
    SQ.squadNotify(squad, L('note.warstart', war.minutes), 'warn')
    if other then SQ.squadNotify(other, L('note.warstart', war.minutes), 'warn') end
    SQ.log('war', ('War started: %s vs %s (%d min)'):format(squad.name, other and other.name or '?', war.minutes))
    SQ.hook('onWarStart', war, squad, other)
    return true
end

function SQ.warSurrender(src)
    if not SQ.get('warSurrender') then return false, L('err.disabled') end
    local squad, p = SQ.squadOf(src)
    if not squad then return false, L('err.nosquad') end
    if not SQ.hasPerm(squad, p.id, 'wars') then return false, L('err.noperm') end
    local war = warOfSquad(squad.id, { active = true })
    if not war then return false, L('err.nowar') end
    local winner = (war.a == squad.id) and war.b or war.a
    SQ.endWar(war, 'surrender', winner)
    return true
end

local function creditWarWin(squad)
    for identifier, m in pairs(squad.members) do
        local pd = SQ.pd[identifier]
        if m.src and pd then
            pd.warsWon = pd.warsWon + 1
            pd.dirty = true
            SQ.taskProgress(m.src, 'wars', 1)
        else
            MySQL.update('UPDATE squad_players SET wars_won = wars_won + 1 WHERE identifier = ?', { identifier })
        end
    end
end

-- winnerId nil = decided by score (or a draw)
function SQ.endWar(war, why, winnerId)
    if not SQ.wars[war.id] then return end
    SQ.wars[war.id] = nil
    local a, b = SQ.squads[war.a], SQ.squads[war.b]
    if war.state ~= 'active' then
        if a then SQ.pushSquad(a) end
        if b then SQ.pushSquad(b) end
        return
    end
    if not winnerId and why == 'time' then
        if war.ka > war.kb then winnerId = war.a elseif war.kb > war.ka then winnerId = war.b end
    end
    warCooldown[pairKey(war.a, war.b)] = SQ.now() + SQ.get('warCooldown')

    local winner = winnerId and SQ.squads[winnerId]
    if winner then creditWarWin(winner) end

    local result = {
        draw = winnerId == nil, winnerName = winner and winner.name or nil, ka = war.ka, kb = war.kb,
        aName = a and a.name or '?', bName = b and b.name or '?', why = why,
    }
    for _, squad in ipairs({ a, b }) do
        if squad then
            for _, m in ipairs(SQ.onlineMembers(squad)) do
                TriggerClientEvent('squads:warEnd', m.src, result)
            end
        end
    end
    if a then SQ.pushSquad(a) end
    if b then SQ.pushSquad(b) end
    SQ.log('war', ('War ended: %s %d - %d %s (%s)'):format(result.aName, war.ka, war.kb, result.bName, winner and ('winner ' .. winner.name) or 'draw'))
    SQ.hook('onWarEnd', war, winner)
end

function SQ.endWarsFor(squadId, why)
    for _, w in pairs(SQ.wars) do
        if w.a == squadId or w.b == squadId then
            if w.state == 'active' then
                local other = (w.a == squadId) and w.b or w.a
                SQ.endWar(w, why, other)
            else
                SQ.wars[w.id] = nil
                local a, b = SQ.squads[w.a], SQ.squads[w.b]
                if a then SQ.pushSquad(a) end
                if b then SQ.pushSquad(b) end
            end
        end
    end
end

function SQ.warTick()
    local now = SQ.now()
    for _, w in pairs(SQ.wars) do
        if w.state == 'pending' and w.expiresAt <= now then
            SQ.wars[w.id] = nil
            local a, b = SQ.squads[w.a], SQ.squads[w.b]
            if a then SQ.pushSquad(a) SQ.squadNotify(a, L('note.warexpired'), 'warn') end
            if b then SQ.pushSquad(b) end
        elseif w.state == 'active' and w.endsAt <= now then
            SQ.endWar(w, 'time')
        end
    end
end

local function warKill(killerSquad, victimSquad)
    for _, w in pairs(SQ.wars) do
        if w.state == 'active' then
            local hit = false
            if w.a == killerSquad.id and w.b == victimSquad.id then w.ka = w.ka + 1 hit = true
            elseif w.b == killerSquad.id and w.a == victimSquad.id then w.kb = w.kb + 1 hit = true end
            if hit then
                for _, s in ipairs({ killerSquad, victimSquad }) do
                    for _, m in ipairs(SQ.onlineMembers(s)) do
                        TriggerClientEvent('squads:warScore', m.src, { id = w.id, ka = w.ka, kb = w.kb })
                    end
                end
                return
            end
        end
    end
end

-- ================================================================== bounties

function SQ.loadBounties()
    SQ.bounties = {}
    local rows = MySQL.query.await('SELECT * FROM squad_bounties') or {}
    for _, r in ipairs(rows) do
        SQ.bounties[r.id] = {
            id = r.id, squadId = r.squad_id, squadName = r.squad_name, poster = r.poster, posterName = r.poster_name,
            target = r.target, targetName = r.target_name, amount = r.amount, note = r.note,
            fromBank = r.from_bank == 1, created = r.created, expires = r.expires,
        }
    end
end

function SQ.bountyList()
    local list = {}
    for _, b in pairs(SQ.bounties) do
        list[#list + 1] = {
            id = b.id, squad = b.squadName, squadId = b.squadId, poster = b.posterName, target = b.targetName,
            amount = b.amount, note = b.note, expires = b.expires, fromBank = b.fromBank,
        }
    end
    table.sort(list, function(x, y) return x.amount > y.amount end)
    return list
end

function SQ.onlinePlayers(src)
    local list = {}
    local me = SQ.players[src]
    for s, p in pairs(SQ.players) do
        if s ~= src then
            local pd = SQ.pd[p.id]
            local status = pd and pd.profile.status or 'online'
            list[#list + 1] = { src = s, name = p.name, squad = SQ.memberSquad[p.id] and SQ.squads[SQ.memberSquad[p.id]] and SQ.squads[SQ.memberSquad[p.id]].tag or '', hidden = status == 'invisible' }
        end
    end
    table.sort(list, function(x, y) return x.name:lower() < y.name:lower() end)
    return list
end

function SQ.bountyPlace(src, d)
    if not SQ.get('bountiesEnabled') then return false, L('err.disabled') end
    if not Bridge.hasMoney() then return false, L('err.nomoneysystem') end
    local squad, p = SQ.squadOf(src)
    if not squad then return false, L('err.nosquad') end
    if not SQ.hasPerm(squad, p.id, 'bounties') then return false, L('err.noperm') end
    if type(d) ~= 'table' then return false, L('err.badvalue') end
    local targetSrc = tonumber(d.target)
    local t = targetSrc and SQ.players[targetSrc]
    if not t or targetSrc == src then return false, L('err.noplayer') end
    if squad.members[t.id] then return false, L('err.ownmember') end
    local amount = math.floor(tonumber(d.amount) or 0)
    if amount < SQ.get('bountyMin') or amount > SQ.get('bountyMax') then return false, L('err.bountyrange', SQ.get('bountyMin'), SQ.get('bountyMax')) end
    local note = SQ.trim(d.note or ''):sub(1, SQ.get('bountyNoteMax') or 80)
    if SQ.hasBlocked(note) then return false, L('err.blocked') end
    for _, b in pairs(SQ.bounties) do
        if b.squadId == squad.id and b.target == t.id then return false, L('err.bountyexists') end
    end

    local fromBank = squad.permanent and SQ.get('bankEnabled') and d.fromBank == true
    if fromBank then
        if not SQ.hasPerm(squad, p.id, 'withdraw') then return false, L('err.noperm') end
        if squad.bank < amount then return false, L('err.bankshort') end
        squad.bank = squad.bank - amount
        DB.bankLog(squad.id, p.id, p.name, 'bounty', -amount, squad.bank)
        SQ.save(squad)
    else
        if not Bridge.removeMoney(src, SQ.get('bountyAccount'), amount, 'squad bounty') then return false, L('err.nomoney') end
    end

    local now = SQ.now()
    local b = {
        squadId = squad.id, squadName = squad.name, poster = p.id, posterName = p.name, target = t.id, targetName = t.name,
        amount = amount, note = note, fromBank = fromBank, created = now, expires = now + SQ.get('bountyHours') * 3600,
    }
    b.id = MySQL.insert.await(
        [[INSERT INTO squad_bounties (squad_id, squad_name, poster, poster_name, target, target_name, amount, note, from_bank, created, expires)
          VALUES (?,?,?,?,?,?,?,?,?,?,?)]],
        { b.squadId, b.squadName, b.poster, b.posterName, b.target, b.targetName, b.amount, b.note, b.fromBank and 1 or 0, b.created, b.expires })
    SQ.bounties[b.id] = b
    SQ.pushSquad(squad)
    SQ.notify(targetSrc, L('note.bountyontarget', amount), 'warn')
    SQ.squadNotify(squad, L('note.bountyplaced', t.name, amount), 'info', src)
    SQ.log('bounty', ('%s (%s) placed $%d on %s'):format(p.name, squad.name, amount, t.name), src)
    return true
end

local function refundBounty(b)
    SQ.bounties[b.id] = nil
    MySQL.update('DELETE FROM squad_bounties WHERE id = ?', { b.id })
    local squad = SQ.squads[b.squadId]
    if b.fromBank and squad then
        squad.bank = squad.bank + b.amount
        DB.bankLog(squad.id, '', 'bounty refund', 'refund', b.amount, squad.bank)
        SQ.save(squad)
        SQ.pushSquad(squad)
    else
        SQ.pay(b.poster, SQ.get('bountyAccount'), b.amount, 'bounty refund')
    end
end

function SQ.bountyCancel(src, id)
    local squad, p = SQ.squadOf(src)
    if not squad then return false, L('err.nosquad') end
    local b = SQ.bounties[tonumber(id)]
    if not b or b.squadId ~= squad.id then return false, L('err.badvalue') end
    if b.poster ~= p.id and not SQ.hasPerm(squad, p.id, 'bounties') then return false, L('err.noperm') end
    refundBounty(b)
    return true
end

function SQ.refundSquadBounties(squad)
    for _, b in pairs(SQ.bounties) do
        if b.squadId == squad.id then refundBounty(b) end
    end
end

function SQ.bountiesOnLeave() end

function SQ.bountyTick()
    local now = SQ.now()
    for _, b in pairs(SQ.bounties) do
        if b.expires <= now then refundBounty(b) end
    end
end

local function bountyKill(killerSrc, killerSquad, victimId)
    for _, b in pairs(SQ.bounties) do
        if b.target == victimId and b.squadId == killerSquad.id then
            SQ.bounties[b.id] = nil
            MySQL.update('DELETE FROM squad_bounties WHERE id = ?', { b.id })
            if not Bridge.addMoney(killerSrc, SQ.get('bountyAccount'), b.amount, 'squad bounty') then
                SQ.pay(SQ.players[killerSrc].id, SQ.get('bountyAccount'), b.amount, 'squad bounty')
            end
            local pd = SQ.pdOf(killerSrc)
            if pd then pd.bounties = pd.bounties + 1 pd.dirty = true end
            SQ.taskProgress(killerSrc, 'bounties', 1)
            SQ.squadNotify(killerSquad, L('note.bountydone', SQ.players[killerSrc].name, b.targetName, b.amount), 'success')
            SQ.pushSquad(killerSquad)
            SQ.log('bounty', ('%s collected $%d on %s'):format(SQ.players[killerSrc].name, b.amount, b.targetName), killerSrc)
        end
    end
end

-- ===================================================================== bank

function SQ.bank(src, op, amount)
    if not SQ.get('bankEnabled') then return false, L('err.disabled') end
    if not Bridge.hasMoney() then return false, L('err.nomoneysystem') end
    local squad, p = SQ.squadOf(src)
    if not squad then return false, L('err.nosquad') end
    if not squad.permanent then return false, L('err.permonly') end
    amount = math.floor(tonumber(amount) or 0)
    if amount < 1 or amount > 1000000000 then return false, L('err.badvalue') end
    local acct = SQ.get('bankAccount')
    if op == 'deposit' then
        if not SQ.hasPerm(squad, p.id, 'deposit') then return false, L('err.noperm') end
        if squad.bank + amount > SQ.get('bankMaxBalance') then return false, L('err.bankfull') end
        if not Bridge.removeMoney(src, acct, amount, 'squad bank deposit') then return false, L('err.nomoney') end
        squad.bank = squad.bank + amount
        DB.bankLog(squad.id, p.id, p.name, 'deposit', amount, squad.bank)
    elseif op == 'withdraw' then
        if not SQ.hasPerm(squad, p.id, 'withdraw') then return false, L('err.noperm') end
        if squad.bank < amount then return false, L('err.bankshort') end
        squad.bank = squad.bank - amount
        if not Bridge.addMoney(src, acct, amount, 'squad bank withdrawal') then
            squad.bank = squad.bank + amount
            return false, L('err.paymentfailed')
        end
        DB.bankLog(squad.id, p.id, p.name, 'withdraw', -amount, squad.bank)
    else
        return false, L('err.badvalue')
    end
    SQ.save(squad)
    SQ.pushSquad(squad)
    SQ.log('bank', ('%s %s $%d (squad "%s")'):format(p.name, op, amount, squad.name), src)
    return true
end

function SQ.bankHistory(src)
    local squad = SQ.squadOf(src)
    if not squad then return nil end
    local rows = MySQL.query.await(
        'SELECT name, kind, amount, balance, created FROM squad_bank_log WHERE squad_id = ? ORDER BY id DESC LIMIT 100', { squad.id }) or {}
    local points = SQ.get('bankChartPoints')
    local chart = {}
    for i = math.min(#rows, points), 1, -1 do chart[#chart + 1] = { t = rows[i].created, balance = rows[i].balance } end
    return { history = rows, chart = chart, balance = squad.bank }
end

-- ================================================================= abilities

local abilityDef = {
    uav =   { enabled = 'uavEnabled', cost = 'uavCost', cd = 'uavCooldown' },
    armor = { enabled = 'armorEnabled', cost = 'armorCost', cd = 'armorCooldown' },
    xp =    { enabled = 'xpBoostEnabled', cost = 'xpBoostCost', cd = 'xpBoostCooldown' },
}

function SQ.useAbility(src, id)
    local def = abilityDef[id]
    if not def then return false, L('err.badvalue') end
    if not SQ.get(def.enabled) then return false, L('err.disabled') end
    local squad, p = SQ.squadOf(src)
    if not squad then return false, L('err.nosquad') end
    if not squad.permanent then return false, L('err.permonly') end
    if not SQ.hasPerm(squad, p.id, 'withdraw') then return false, L('err.noperm') end
    squad.cd = squad.cd or {}
    local now = SQ.now()
    if (squad.cd[id] or 0) > now then return false, L('err.cooldown', squad.cd[id] - now) end
    local cost = SQ.get(def.cost)
    if squad.bank < cost then return false, L('err.bankshort') end

    if id == 'uav' then
        local war = warOfSquad(squad.id, { active = true })
        if not war then return false, L('err.uavwar') end
        squad.uavUntil = now + SQ.get('uavDuration')
    elseif id == 'armor' then
        local c = SQ.coords(src)
        if not c then return false, L('err.badvalue') end
        for _, m in ipairs(SQ.onlineMembers(squad)) do
            if SQ.distance(src, m.src) <= SQ.get('armorRadius') then
                TriggerClientEvent('squads:armor', m.src, SQ.get('armorAmount'))
            end
        end
    elseif id == 'xp' then
        squad.xpUntil = now + SQ.get('xpBoostDuration')
    end

    squad.bank = squad.bank - cost
    squad.cd[id] = now + SQ.get(def.cd)
    DB.bankLog(squad.id, p.id, p.name, 'ability', -cost, squad.bank)
    SQ.save(squad)
    SQ.pushSquad(squad)
    SQ.squadNotify(squad, L('note.ability.' .. id, p.name), 'success')
    SQ.log('ability', ('%s used %s for "%s"'):format(p.name, id, squad.name), src)
    return true
end

-- the UAV shows the enemy squad's members on the map during a war
function SQ.uavTick()
    local now = SQ.now()
    for _, squad in pairs(SQ.squads) do
        if (squad.uavUntil or 0) > now then
            local war = warOfSquad(squad.id, { active = true })
            local points = {}
            if war then
                local enemy = SQ.squads[(war.a == squad.id) and war.b or war.a]
                if enemy then
                    for _, m in ipairs(SQ.onlineMembers(enemy)) do
                        local c = SQ.coords(m.src)
                        if c then points[#points + 1] = { x = c.x, y = c.y, z = c.z, name = enemy.members[m.id].name } end
                    end
                end
            end
            for _, m in ipairs(SQ.onlineMembers(squad)) do TriggerClientEvent('squads:uav', m.src, points) end
        elseif squad.uavUntil and squad.uavUntil > 0 then
            squad.uavUntil = 0
            for _, m in ipairs(SQ.onlineMembers(squad)) do TriggerClientEvent('squads:uav', m.src, {}) end
            SQ.pushSquad(squad)
        end
    end
end

-- ================================================================ teamwork orders

function SQ.orderStart(src)
    if not SQ.get('ordersEnabled') then return false, L('err.disabled') end
    local squad, p = SQ.squadOf(src)
    if not squad then return false, L('err.nosquad') end
    if squad.owner ~= p.id then return false, L('err.owneronly') end
    if not squad.rally then return false, L('err.norally') end
    squad.cd = squad.cd or {}
    local now = SQ.now()
    if (squad.cd.order or 0) > now then return false, L('err.cooldown', squad.cd.order - now) end
    squad.cd.order = now + SQ.get('orderCooldown')
    SQ.orders[squad.id] = {
        pos = vector3(squad.rally.x, squad.rally.y, squad.rally.z), started = now,
        expires = now + SQ.get('orderHold') * 6 + 120, held = {}, rewarded = {},
    }
    SQ.pushSquad(squad)
    SQ.squadNotify(squad, L('note.orderstart', p.name), 'warn')
    return true
end

function SQ.orderTick()
    local now = SQ.now()
    for squadId, o in pairs(SQ.orders) do
        local squad = SQ.squads[squadId]
        if not squad or o.expires <= now then
            SQ.orders[squadId] = nil
            if squad then SQ.pushSquad(squad) end
        else
            local inside = {}
            for _, m in ipairs(SQ.onlineMembers(squad)) do
                local c = SQ.coords(m.src)
                if c and #(c - o.pos) <= SQ.get('orderRadius') then inside[#inside + 1] = m end
            end
            if #inside >= SQ.get('orderMinMembers') then
                for _, m in ipairs(inside) do
                    o.held[m.id] = (o.held[m.id] or 0) + 1
                    if o.held[m.id] >= SQ.get('orderHold') and not o.rewarded[m.id] then
                        o.rewarded[m.id] = true
                        local cash = SQ.get('orderCash')
                        if cash > 0 then Bridge.addMoney(m.src, SQ.get('bankAccount'), cash, 'squad teamwork') end
                        SQ.addXp(m.src, SQ.get('orderXp'))
                        SQ.notify(m.src, L('note.orderdone', cash, SQ.get('orderXp')), 'success')
                    end
                end
            end
        end
    end
end

-- ===================================================================== kills

local lastDeath = {}

function SQ.handleDeath(victim, killer)
    local vp = SQ.players[victim]
    if not vp then return end
    local t = GetGameTimer()
    if lastDeath[victim] and t - lastDeath[victim] < 4000 then return end
    lastDeath[victim] = t

    local vpd = SQ.pd[vp.id]
    if vpd then vpd.deaths = vpd.deaths + 1 vpd.dirty = true end

    if not killer or killer == victim or not SQ.players[killer] then return end

    -- the kill has to match real damage the killer dealt
    if SQ.get('verifyDamage') and SQ.damageSeen then
        local hit = SQ.damage[victim] and SQ.damage[victim][killer]
        if not hit or SQ.now() - hit > 20 then return end
    end

    local kp = SQ.players[killer]
    local kpd = SQ.pd[kp.id]
    local ksquad = SQ.squadOf(killer)
    local vsquad = SQ.squadOf(victim)

    if ksquad and vsquad and ksquad.id == vsquad.id then
        if kpd then kpd.teamkills = kpd.teamkills + 1 kpd.dirty = true end
        SQ.notify(killer, L('note.teamkill'), 'warn')
        return
    end

    if kpd then kpd.kills = kpd.kills + 1 kpd.dirty = true end
    SQ.taskProgress(killer, 'kills', 1)
    SQ.addXp(killer, SQ.get('xpPerKill'))

    if ksquad then
        if vsquad then warKill(ksquad, vsquad) end
        bountyKill(killer, ksquad, vp.id)
    end
end

-- ================================================================ leaderboard

local boardCache = { at = 0, data = nil }

function SQ.leaderboard()
    local now = SQ.now()
    if boardCache.data and now - boardCache.at < 10 then return boardCache.data end
    SQ.saveAll()
    local rows = MySQL.query.await(
        [[SELECT p.identifier, p.name, p.kills, p.deaths, p.teamkills, p.bounties, p.xp, s.name AS squad, s.tag AS tag
          FROM squad_players p
          LEFT JOIN squad_members m ON m.identifier = p.identifier
          LEFT JOIN squads s ON s.id = m.squad_id
          ORDER BY p.kills DESC, p.deaths ASC LIMIT 50]]) or {}
    local list = {}
    for i, r in ipairs(rows) do
        local squadName, tag = r.squad, r.tag
        local sid = SQ.memberSquad[r.identifier]
        if sid and SQ.squads[sid] then squadName, tag = SQ.squads[sid].name, SQ.squads[sid].tag end
        list[i] = {
            id = r.identifier, name = r.name, kills = r.kills, deaths = r.deaths, teamkills = r.teamkills,
            bounties = r.bounties, level = SQ.levelOfXp(r.xp), squad = squadName or '', tag = tag or '',
            kd = r.deaths > 0 and (r.kills / r.deaths) or r.kills,
        }
    end
    boardCache = { at = now, data = list }
    return list
end

-- ================================================================== profiles

local statuses = { online = true, idle = true, dnd = true, invisible = true }

function SQ.profileGet(src, identifier)
    identifier = type(identifier) == 'string' and identifier or (SQ.players[src] and SQ.players[src].id)
    if not identifier then return nil end
    local pd = SQ.pd[identifier]
    local isMe = SQ.players[src] and SQ.players[src].id == identifier
    local row
    if not pd then
        row = MySQL.single.await('SELECT * FROM squad_players WHERE identifier = ?', { identifier })
        if not row then return nil end
        pd = { name = row.name, kills = row.kills, deaths = row.deaths, teamkills = row.teamkills, bounties = row.bounties,
               warsWon = row.wars_won, xp = row.xp, profile = SQ.jdec(row.profile, {}) }
    end
    local profile = pd.profile or {}
    local online = SQ.pd[identifier] ~= nil
    local status = online and (profile.status or 'online') or 'offline'
    if status == 'invisible' and not isMe then status = 'offline' end
    local sid = SQ.memberSquad[identifier]
    local squad = sid and SQ.squads[sid]
    return {
        id = identifier, name = pd.name, picture = profile.picture or '', banner = profile.banner or '', bio = profile.bio or '',
        gallery = profile.gallery or {}, status = status, ownStatus = isMe and (profile.status or 'online') or nil,
        verified = profile.verified == true, isMe = isMe,
        squad = squad and { name = squad.name, tag = squad.tag, color = squad.color } or nil,
        kills = pd.kills, deaths = pd.deaths, teamkills = pd.teamkills, bounties = pd.bounties, warsWon = pd.warsWon,
        level = SQ.levelOfXp(pd.xp), xp = math.floor(pd.xp),
        kd = pd.deaths > 0 and (pd.kills / pd.deaths) or pd.kills,
    }
end

function SQ.profileSave(src, d)
    local pd = SQ.pdOf(src)
    if not pd then return false, L('err.notloaded') end
    if type(d) ~= 'table' then return false, L('err.badvalue') end
    local profile = pd.profile
    if d.bio ~= nil then
        local bio = SQ.trim(tostring(d.bio)):sub(1, 200)
        if SQ.hasBlocked(bio) then return false, L('err.blocked') end
        profile.bio = bio
    end
    for _, key in ipairs({ 'picture', 'banner' }) do
        if d[key] ~= nil then
            local ok, url = SQ.validImage(d[key])
            if not ok then return false, L('err.badimage') end
            profile[key] = url
        end
    end
    if d.gallery ~= nil then
        if type(d.gallery) ~= 'table' or #d.gallery > 9 then return false, L('err.gallery') end
        local out = {}
        for _, url in ipairs(d.gallery) do
            local ok, clean = SQ.validImage(url)
            if not ok then return false, L('err.badimage') end
            if clean ~= '' then out[#out + 1] = clean end
        end
        profile.gallery = out
    end
    if d.status ~= nil then
        if not statuses[d.status] then return false, L('err.badvalue') end
        profile.status = d.status
    end
    pd.dirty = true
    local squad = SQ.squadOf(src)
    if squad then SQ.pushSquad(squad) end
    return true
end

local function httpGet(url, headers)
    local p = promise.new()
    PerformHttpRequest(url, function(status, body) p:resolve({ status = status, body = body }) end, 'GET', '', headers or {})
    return Citizen.Await(p)
end

function SQ.importAvatar(src, kind)
    local pd = SQ.pdOf(src)
    if not pd then return false, L('err.notloaded') end
    local url
    if kind == 'discord' then
        local token = SQ.secrets.discordToken
        local did = GetPlayerIdentifierByType(src, 'discord')
        if not token or token == '' or not did then return false, L('err.avatarnotavailable') end
        did = did:gsub('discord:', '')
        local res = httpGet('https://discord.com/api/v10/users/' .. did, { Authorization = 'Bot ' .. token })
        local data = res.status == 200 and SQ.jdec(res.body, nil) or nil
        if not data or not data.avatar then return false, L('err.avatarnotavailable') end
        url = ('https://cdn.discordapp.com/avatars/%s/%s.png?size=256'):format(did, data.avatar)
    elseif kind == 'steam' then
        local key = SQ.secrets.steamKey
        local hex = GetPlayerIdentifierByType(src, 'steam')
        if not key or key == '' or not hex then return false, L('err.avatarnotavailable') end
        local steamId = tostring(tonumber(hex:gsub('steam:', ''), 16))
        local res = httpGet(('https://api.steampowered.com/ISteamUser/GetPlayerSummaries/v2/?key=%s&steamids=%s'):format(key, steamId))
        local data = res.status == 200 and SQ.jdec(res.body, nil) or nil
        local player = data and data.response and data.response.players and data.response.players[1]
        if not player or not player.avatarfull then return false, L('err.avatarnotavailable') end
        url = player.avatarfull
    else
        return false, L('err.badvalue')
    end
    pd.profile.picture = url
    pd.dirty = true
    return true, url
end

function SQ.setVerified(identifier, value)
    local pd = SQ.pd[identifier]
    if pd then
        pd.profile.verified = value == true
        pd.dirty = true
        local sid = SQ.memberSquad[identifier]
        if sid and SQ.squads[sid] then SQ.pushSquad(SQ.squads[sid]) end
        return true
    end
    local row = MySQL.single.await('SELECT profile FROM squad_players WHERE identifier = ?', { identifier })
    if not row then return false end
    local profile = SQ.jdec(row.profile, {})
    profile.verified = value == true
    MySQL.update('UPDATE squad_players SET profile = ? WHERE identifier = ?', { SQ.jenc(profile), identifier })
    return true
end

-- ================================================================ settings (player)

function SQ.savePlayerSettings(src, d)
    local pd = SQ.pdOf(src)
    if not pd then return false, L('err.notloaded') end
    if type(d) ~= 'table' then return false, L('err.badvalue') end
    for key, value in pairs(d) do
        if key == 'tourDone' then
            pd.settings.tourDone = value == true
        else
            local f = Schema.byKey['def_' .. tostring(key)]
            if f then
                local ok, clean = Schema.validate(f, value)
                if ok then pd.settings[key] = clean end
            end
        end
    end
    pd.dirty = true
    return true
end
