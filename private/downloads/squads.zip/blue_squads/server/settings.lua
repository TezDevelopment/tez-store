-- Loading, validating and saving the settings edited in /squadsadmin

function SQ.loadSettings()
    SQ.S = Schema.defaults()
    SQ.secrets = {}
    local row = MySQL.single.await('SELECT v FROM squad_settings WHERE k = ?', { 'config' })
    local saved = row and SQ.jdec(row.v, {}) or {}
    for k, v in pairs(saved) do
        local f = Schema.byKey[k]
        if f then
            local ok, clean = Schema.validate(f, v)
            if ok then
                if f.secret then SQ.secrets[k] = clean else SQ.S[k] = clean end
            end
        end
    end
end

function SQ.persistSettings()
    local blob = {}
    for _, f in ipairs(Schema.fields) do
        if f.secret then blob[f.k] = SQ.secrets[f.k] or '' else blob[f.k] = SQ.S[f.k] end
    end
    MySQL.query('REPLACE INTO squad_settings (k, v) VALUES (?, ?)', { 'config', SQ.jenc(blob) })
end

-- Everything that is safe to show every player (secrets are never included)
function SQ.publicSettings()
    local out = {}
    for _, f in ipairs(Schema.fields) do
        if not f.secret then out[f.k] = SQ.S[f.k] end
    end
    return out
end

-- values = { key = value }, clear = { 'secretKey', ... }
-- Returns ok, errorText, listOfChangedKeys
function SQ.saveSettings(src, values, clear)
    if type(values) ~= 'table' then return false, L('err.badvalue') end

    local backupS, backupSecrets = {}, {}
    for k, v in pairs(SQ.S) do backupS[k] = v end
    for k, v in pairs(SQ.secrets) do backupSecrets[k] = v end

    local changed = {}
    local function revert()
        SQ.S, SQ.secrets = backupS, backupSecrets
    end

    for k, v in pairs(values) do
        local f = Schema.byKey[k]
        if not f then revert() return false, L('err.unknownsetting', tostring(k)) end
        if f.secret then
            if type(v) == 'string' and v ~= '' then
                local ok, clean = Schema.validate(f, v)
                if not ok then revert() return false, L('err.badsetting', f.l) end
                SQ.secrets[k] = clean
                changed[#changed + 1] = k
            end
        else
            local ok, clean = Schema.validate(f, v)
            if not ok then revert() return false, L('err.badsetting', f.l) end
            SQ.S[k] = clean
            changed[#changed + 1] = k
        end
    end

    if type(clear) == 'table' then
        for _, k in ipairs(clear) do
            local f = Schema.byKey[k]
            if f and f.secret then SQ.secrets[k] = '' changed[#changed + 1] = k end
        end
    end

    -- rules that involve more than one setting
    if SQ.S.nameMin > SQ.S.nameMax then revert() return false, L('err.rule.name') end
    if SQ.S.warMin > SQ.S.warMax then revert() return false, L('err.rule.war') end
    if SQ.S.bountyMin > SQ.S.bountyMax then revert() return false, L('err.rule.bounty') end

    -- the admin may not lock themselves out
    if src and src > 0 and not SQ.isAdmin(src, true) then
        revert()
        return false, L('err.lockout')
    end

    SQ.persistSettings()
    TriggerClientEvent('squads:settings', -1, SQ.publicSettings())
    return true, nil, changed
end
