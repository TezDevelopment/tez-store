SQ = {
    squads = {},          -- squadId -> squad
    memberSquad = {},     -- identifier -> squadId
    players = {},         -- src -> { id = identifier, name = name }
    pd = {},              -- identifier -> player data (stats, profile, settings, daily)
    live = {},            -- src -> last status sent by that player's client
    invites = {},         -- target src -> invite
    wars = {},            -- warId -> war
    bounties = {},        -- bountyId -> bounty
    chat = {},            -- squadId -> recent messages
    orders = {},          -- squadId -> teamwork order
    damage = {},          -- victim src -> { attacker src -> time }
    nextTempId = 1000000,
    nextWarId = 1,
    damageSeen = false,
    S = {},               -- current settings
    secrets = {},         -- secret values (never sent to clients)
}

function SQ.now() return os.time() end

function SQ.clamp(v, a, b)
    if v < a then return a end
    if v > b then return b end
    return v
end

function SQ.trim(s)
    if type(s) ~= 'string' then return '' end
    return (s:gsub('^%s+', ''):gsub('%s+$', ''):gsub('%c', ''))
end

function SQ.get(key)
    local v = SQ.S[key]
    if v == nil and Schema.byKey[key] then return Schema.byKey[key].d end
    return v
end

function SQ.account(kind)
    if kind == 'cash' then return 'cash' end
    return 'bank'
end

function SQ.count(t)
    local n = 0
    for _ in pairs(t) do n = n + 1 end
    return n
end

-- ---------------------------------------------------------------- blocked words

local leet = { ['0'] = 'o', ['1'] = 'i', ['3'] = 'e', ['4'] = 'a', ['5'] = 's', ['7'] = 't', ['@'] = 'a', ['$'] = 's', ['!'] = 'i' }

function SQ.normalize(s)
    s = tostring(s or ''):lower()
    s = s:gsub('[0134577@%$!]', function(c) return leet[c] or c end)
    s = s:gsub('[^%a]', '')
    -- collapse long runs of the same letter (shiiit -> shit)
    s = s:gsub('(%a)%1+', '%1')
    return s
end

function SQ.hasBlocked(text)
    local words = SQ.get('blockedWords')
    if not words or #words == 0 then return false end
    local n = SQ.normalize(text)
    for _, w in ipairs(words) do
        local nw = SQ.normalize(w)
        if #nw >= 2 and n:find(nw, 1, true) then return true end
    end
    return false
end

-- Only https links from approved hosts
function SQ.validImage(url)
    if url == nil or url == '' then return true, '' end
    if type(url) ~= 'string' or #url > 300 then return false end
    local host = url:match('^https://([^/%?#:]+)')
    if not host then return false end
    host = host:lower()
    for _, h in ipairs(SQ.get('imageSites') or {}) do
        if host == h:lower() then return true, url end
    end
    return false
end

-- ------------------------------------------------------------------ rate limits

local buckets, flood = {}, {}

function SQ.rate(src, key, ms)
    local t = GetGameTimer()
    buckets[src] = buckets[src] or {}
    local last = buckets[src][key] or -100000
    if t - last < ms then return false end
    buckets[src][key] = t
    return true
end

-- at most 40 requests per 5 seconds per player
function SQ.floodOk(src)
    local t = GetGameTimer()
    local f = flood[src]
    if not f or t - f.start > 5000 then flood[src] = { start = t, n = 1 } return true end
    f.n = f.n + 1
    return f.n <= 40
end

function SQ.clearLimits(src) buckets[src] = nil flood[src] = nil end

-- --------------------------------------------------------------------- distances

function SQ.coords(src)
    local ped = GetPlayerPed(src)
    if not ped or ped == 0 then return nil end
    return GetEntityCoords(ped)
end

function SQ.distance(a, b)
    local ca, cb = SQ.coords(a), SQ.coords(b)
    if not ca or not cb then return 99999.0 end
    return #(ca - cb)
end

-- --------------------------------------------------------------------- messaging

function SQ.notify(src, msg, kind)
    TriggerClientEvent('squads:toast', src, msg, kind or 'info')
end

function SQ.hash(password, salt)
    return MySQL.scalar.await('SELECT SHA2(?, 256)', { salt .. ':' .. password })
end

function SQ.randomSalt()
    local chars, out = 'abcdefghijklmnopqrstuvwxyz0123456789', {}
    for i = 1, 16 do
        local r = math.random(1, #chars)
        out[i] = chars:sub(r, r)
    end
    return table.concat(out)
end

function SQ.jenc(v) return json.encode(v) end
function SQ.jdec(s, fallback)
    if type(s) ~= 'string' or s == '' then return fallback end
    local ok, r = pcall(json.decode, s)
    if ok and r ~= nil then return r end
    return fallback
end

function SQ.debug(...)
    if Config.Debug then print('[blue_squads]', ...) end
end
