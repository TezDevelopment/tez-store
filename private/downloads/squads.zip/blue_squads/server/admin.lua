-- Admin access, logging and everything behind /squadsadmin

SQ.roleCache = {}

local function httpRequest(url, method, body, headers)
    local p = promise.new()
    PerformHttpRequest(url, function(status, text) p:resolve({ status = status, body = text }) end, method, body or '', headers or {})
    return Citizen.Await(p)
end

-- ---------------------------------------------------------------- access

local function discordRoles(src, allowFetch)
    local token, guild = SQ.secrets.discordToken, SQ.get('discordGuild')
    if not token or token == '' or not guild or guild == '' then return nil end
    local c = SQ.roleCache[src]
    local now = SQ.now()
    if c and c.exp > now then return c.roles end
    if not allowFetch then return c and c.roles or nil end
    local did = GetPlayerIdentifierByType(src, 'discord')
    if not did then return nil end
    did = did:gsub('discord:', '')
    local res = httpRequest(('https://discord.com/api/v10/guilds/%s/members/%s'):format(guild, did), 'GET', '',
        { Authorization = 'Bot ' .. token })
    local data = res.status == 200 and SQ.jdec(res.body, nil) or nil
    local roles = data and data.roles or {}
    SQ.roleCache[src] = { roles = roles, exp = now + 60 }
    return roles
end

function SQ.hasDiscordRole(src, wanted, cachedOnly)
    local roles = discordRoles(src, not cachedOnly)
    if not roles then return false end
    for _, w in ipairs(wanted) do
        for _, r in ipairs(roles) do if tostring(r) == tostring(w) then return true end end
    end
    return false
end

function SQ.isAdmin(src, cachedOnly)
    if src == 0 then return true end
    if IsPlayerAceAllowed(src, 'squads.admin') then return true end
    if Bridge.inGroup(src, SQ.get('adminGroups')) then return true end
    local roles = SQ.get('adminRoles')
    if roles and #roles > 0 and SQ.hasDiscordRole(src, roles, cachedOnly) then return true end
    return false
end

-- ------------------------------------------------------------------ logging

local logCount = 0

function SQ.log(category, message, actorSrc)
    local actor = ''
    if actorSrc and SQ.players[actorSrc] then actor = SQ.players[actorSrc].name end
    MySQL.insert('INSERT INTO squad_logs (category, message, actor, created) VALUES (?,?,?,?)',
        { category, tostring(message):sub(1, 500), actor, SQ.now() })
    logCount = logCount + 1
    if logCount % 200 == 0 then
        MySQL.update('DELETE FROM squad_logs WHERE id < (SELECT m FROM (SELECT MAX(id) - 2000 AS m FROM squad_logs) t)')
    end

    local always = category == 'settings' or category == 'admin'
    if not always and not SQ.get('logSquadEvents') then return end

    local text = actor ~= '' and (actor .. ': ' .. message) or message
    local hook, key = SQ.secrets.logWebhook, SQ.secrets.fivemanageKey
    if SQ.get('logToWebhook') and hook and hook ~= '' then
        PerformHttpRequest(hook, function() end, 'POST', json.encode({
            username = 'Squads',
            embeds = { { title = category, description = text, color = 3900150, timestamp = os.date('!%Y-%m-%dT%H:%M:%SZ') } },
        }), { ['Content-Type'] = 'application/json' })
    end
    if SQ.get('logToFivemanage') and key and key ~= '' then
        PerformHttpRequest('https://api.fivemanage.com/api/logs', function() end, 'POST', json.encode({
            level = 'info', message = text, metadata = { category = category, resource = GetCurrentResourceName() },
        }), { ['Content-Type'] = 'application/json', Authorization = key })
    end
end

-- ------------------------------------------------------------------- status

function SQ.status()
    local warnings = {}
    local radio = GetResourceState('pma-voice')
    if radio ~= 'started' and SQ.get('radioEnabled') then
        warnings[#warnings + 1] = L('warn.noradio')
    end
    if not Bridge.hasMoney() then warnings[#warnings + 1] = L('warn.nomoney') end
    if SQ.get('logToWebhook') and (SQ.secrets.logWebhook or '') == '' then warnings[#warnings + 1] = L('warn.nowebhook') end
    if SQ.get('logToFivemanage') and (SQ.secrets.fivemanageKey or '') == '' then warnings[#warnings + 1] = L('warn.nofivemanage') end
    if (#(SQ.get('adminRoles') or {}) > 0 or #(SQ.get('useRoles') or {}) > 0)
        and ((SQ.secrets.discordToken or '') == '' or SQ.get('discordGuild') == '') then
        warnings[#warnings + 1] = L('warn.nodiscord')
    end
    if #(SQ.get('blockedWords') or {}) == 0 then warnings[#warnings + 1] = L('warn.noblocked') end
    if SQ.get('verifyDamage') and not SQ.damageSeen then warnings[#warnings + 1] = L('warn.nodamage') end
    if SQ.latestVersion and SQ.latestVersion ~= SQ.version then warnings[#warnings + 1] = L('warn.update', SQ.latestVersion) end
    return {
        framework = Bridge.framework,
        death = Bridge.deathSource(),
        radio = radio == 'started' and 'pma-voice' or 'none',
        version = SQ.version,
        warnings = warnings,
        online = SQ.count(SQ.players),
        squads = SQ.count(SQ.squads),
    }
end

function SQ.checkVersion()
    SQ.version = GetResourceMetadata(GetCurrentResourceName(), 'version', 0) or '0'
    if not Config.VersionUrl or Config.VersionUrl == '' then return end
    PerformHttpRequest(Config.VersionUrl, function(status, body)
        if status == 200 and body then
            local v = body:match('[%d%.]+')
            if v then SQ.latestVersion = v end
        end
    end, 'GET')
end

-- ------------------------------------------------------------------ the panel

function SQ.adminPayload()
    local values, secretSet = {}, {}
    for _, f in ipairs(Schema.fields) do
        if f.secret then
            secretSet[f.k] = (SQ.secrets[f.k] or '') ~= ''
            values[f.k] = ''
        else
            values[f.k] = SQ.S[f.k]
        end
    end
    local fields = {}
    for _, f in ipairs(Schema.fields) do
        fields[#fields + 1] = { k = f.k, p = f.p, t = f.t, d = f.d, l = f.l, h = f.h, min = f.min, max = f.max, opts = f.opts, secret = f.secret }
    end
    return { pages = Schema.pages, fields = fields, values = values, secretSet = secretSet, status = SQ.status() }
end

function SQ.adminSquads(search, page)
    search = tostring(search or ''):lower()
    page = math.max(1, math.floor(tonumber(page) or 1))
    local all = {}
    for _, s in pairs(SQ.squads) do
        if search == '' or s.name:lower():find(search, 1, true) or s.tag:lower():find(search, 1, true) or s.ownerName:lower():find(search, 1, true) then
            all[#all + 1] = {
                id = s.id, name = s.name, tag = s.tag, color = s.color, permanent = s.permanent, owner = s.ownerName,
                count = SQ.memberCount(s), max = s.maxMembers, bank = s.bank, online = #SQ.onlineMembers(s),
            }
        end
    end
    table.sort(all, function(a, b) return a.name:lower() < b.name:lower() end)
    local per = 12
    local out = {}
    for i = (page - 1) * per + 1, math.min(#all, page * per) do out[#out + 1] = all[i] end
    return { list = out, total = #all, page = page, per = per }
end

local function squadDetail(squad)
    local members = {}
    for identifier, m in pairs(squad.members) do
        members[#members + 1] = { id = identifier, name = m.name, online = m.src ~= nil, owner = identifier == squad.owner, src = m.src }
    end
    table.sort(members, function(a, b) if a.owner ~= b.owner then return a.owner end return a.name:lower() < b.name:lower() end)
    return {
        id = squad.id, name = squad.name, tag = squad.tag, color = squad.color, permanent = squad.permanent, bank = squad.bank,
        owner = squad.ownerName, members = members, max = squad.maxMembers, privacy = squad.privacy,
    }
end

-- Every admin action goes through here so each one is checked and logged
SQ.AdminActions = {
    open = function(src) return true, SQ.adminPayload() end,

    save = function(src, d)
        local ok, err, changed = SQ.saveSettings(src, d.values, d.clear)
        if not ok then return false, err end
        if #changed > 0 then SQ.log('settings', ('Changed: %s'):format(table.concat(changed, ', ')), src) end
        return true, SQ.adminPayload()
    end,

    squads = function(src, d) return true, SQ.adminSquads(d.search, d.page) end,

    squad = function(src, d)
        local squad = SQ.squads[tonumber(d.id)]
        if not squad then return false, L('err.gone') end
        return true, squadDetail(squad)
    end,

    bank = function(src, d)
        local squad = SQ.squads[tonumber(d.id)]
        if not squad then return false, L('err.gone') end
        if not squad.permanent then return false, L('err.permonly') end
        local amount = math.floor(tonumber(d.amount) or 0)
        if amount == 0 or math.abs(amount) > 1000000000 then return false, L('err.badvalue') end
        if squad.bank + amount < 0 then return false, L('err.bankshort') end
        if squad.bank + amount > SQ.get('bankMaxBalance') then return false, L('err.bankfull') end
        squad.bank = squad.bank + amount
        DB.bankLog(squad.id, '', 'staff', 'staff', amount, squad.bank)
        SQ.save(squad)
        SQ.pushSquad(squad)
        SQ.log('admin', ('%s changed the bank of "%s" by %d'):format(SQ.players[src] and SQ.players[src].name or 'console', squad.name, amount), src)
        return true, squadDetail(squad)
    end,

    join = function(src, d)
        local squad = SQ.squads[tonumber(d.id)]
        local p = SQ.players[src]
        if not squad or not p then return false, L('err.gone') end
        if SQ.memberSquad[p.id] then return false, L('err.insquad') end
        local low
        for _, r in ipairs(squad.ranks) do if not low or r.level < low.level then low = r end end
        squad.members[p.id] = { rankId = low and low.id or 0, joined = SQ.now(), name = p.name, src = src }
        SQ.memberSquad[p.id] = squad.id
        if squad.permanent then DB.saveMember(squad.id, p.id, low and low.id or 0, SQ.now(), p.name) end
        SQ.pushSquad(squad)
        SQ.log('admin', ('%s joined "%s" as staff'):format(p.name, squad.name), src)
        return true
    end,

    kick = function(src, d)
        local squad = SQ.squads[tonumber(d.id)]
        if not squad or type(d.identifier) ~= 'string' or not squad.members[d.identifier] then return false, L('err.gone') end
        local name = squad.members[d.identifier].name
        local targetSrc = squad.members[d.identifier].src
        SQ.removeMember(squad, d.identifier, 'kicked')
        if targetSrc then SQ.notify(targetSrc, L('note.kicked', squad.name), 'warn') end
        SQ.log('admin', ('Staff removed %s from "%s"'):format(name, squad.name), src)
        return true, SQ.squads[squad.id] and squadDetail(squad) or nil
    end,

    disband = function(src, d)
        local squad = SQ.squads[tonumber(d.id)]
        if not squad then return false, L('err.gone') end
        local name = squad.name
        SQ.disband(squad, 'staff')
        SQ.log('admin', ('Staff disbanded "%s"'):format(name), src)
        return true
    end,

    logs = function(src, d)
        local page = math.max(1, math.floor(tonumber(d.page) or 1))
        local per = 20
        local rows = MySQL.query.await('SELECT category, message, actor, created FROM squad_logs ORDER BY id DESC LIMIT ? OFFSET ?',
            { per, (page - 1) * per }) or {}
        local total = MySQL.scalar.await('SELECT COUNT(*) FROM squad_logs') or 0
        return true, { rows = rows, page = page, per = per, total = total }
    end,

    players = function(src)
        local list = {}
        for s, p in pairs(SQ.players) do
            local pd = SQ.pd[p.id]
            list[#list + 1] = { src = s, id = p.id, name = p.name, verified = pd and pd.profile.verified == true or false }
        end
        table.sort(list, function(a, b) return a.name:lower() < b.name:lower() end)
        return true, list
    end,

    verify = function(src, d)
        if type(d.identifier) ~= 'string' then return false, L('err.badvalue') end
        if not SQ.setVerified(d.identifier, d.value == true) then return false, L('err.gone') end
        SQ.log('admin', ('Verified badge %s for %s'):format(d.value and 'given' or 'removed', d.identifier), src)
        return true
    end,

    test = function(src, d)
        local kind = d.kind
        local msg = L('admin.testmessage')
        if kind == 'webhook' then
            local hook = SQ.secrets.logWebhook
            if not hook or hook == '' then return false, L('err.nowebhook') end
            local res = httpRequest(hook, 'POST', json.encode({ username = 'Squads', content = msg }), { ['Content-Type'] = 'application/json' })
            if res.status and res.status >= 200 and res.status < 300 then return true, { text = L('admin.testok') } end
            return false, L('admin.testfail', tostring(res.status))
        elseif kind == 'fivemanage' then
            local key = SQ.secrets.fivemanageKey
            if not key or key == '' then return false, L('err.nofivemanage') end
            local res = httpRequest('https://api.fivemanage.com/api/logs', 'POST',
                json.encode({ level = 'info', message = msg, metadata = { category = 'test' } }),
                { ['Content-Type'] = 'application/json', Authorization = key })
            if res.status and res.status >= 200 and res.status < 300 then return true, { text = L('admin.testok') } end
            return false, L('admin.testfail', tostring(res.status))
        end
        return false, L('err.badvalue')
    end,
}
