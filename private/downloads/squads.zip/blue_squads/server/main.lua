-- Entry point: startup, loading, request routing, player events and timers

SQ.ready = false
SQ.pings = {}
local pingCounter = 0

-- ================================================================== loading

function SQ.loadSquads()
    local rows = MySQL.query.await('SELECT * FROM squads') or {}
    local members = MySQL.query.await('SELECT * FROM squad_members') or {}
    local now = SQ.now()
    local days = SQ.get('inactiveDays')

    for _, r in ipairs(rows) do
        local inactive = days > 0 and r.last_active > 0 and (now - r.last_active) > days * 86400
        if inactive then
            DB.deleteSquad(r.id)
        else
            local squad = {
                id = r.id, name = r.name, tag = r.tag, permanent = true, privacy = r.privacy, pwhash = r.pwhash or '', pwsalt = r.pwsalt or '',
                color = r.color, photo = r.photo or '', banner = r.banner or '', owner = r.owner, ownerName = r.owner_name,
                maxMembers = r.max_members, friendlyFire = r.friendly_fire == 1, bank = r.bank, radio = r.radio or 0,
                ranks = SQ.jdec(r.ranks, nil), bans = SQ.jdec(r.bans, {}), rally = SQ.jdec(r.rally, nil),
                created = r.created, lastActive = r.last_active, members = {}, applications = {}, cd = {},
            }
            if type(squad.ranks) ~= 'table' or #squad.ranks == 0 then
                squad.ranks = { { id = 1, name = 'Member', level = 1, perms = { deposit = true } } }
            end
            SQ.squads[squad.id] = squad
            SQ.nameIndex[squad.name:lower()] = squad.id
            if squad.tag ~= '' then SQ.tagIndex[squad.tag] = squad.id end
        end
    end

    for _, m in ipairs(members) do
        local squad = SQ.squads[m.squad_id]
        if squad then
            squad.members[m.identifier] = { rankId = m.rank_id, joined = m.joined, name = m.name }
            SQ.memberSquad[m.identifier] = squad.id
        else
            DB.deleteMember(m.identifier)
        end
    end

    -- a squad whose owner row is missing passes to someone, or ends
    for _, squad in pairs(SQ.squads) do
        if not squad.members[squad.owner] then
            local best
            for identifier, m in pairs(squad.members) do
                if not best or m.joined < squad.members[best].joined then best = identifier end
            end
            if best then
                squad.owner = best
                squad.ownerName = squad.members[best].name
                squad.members[best].rankId = 0
                DB.saveSquad(squad)
            else
                SQ.disband(squad, 'empty')
            end
        end
        if SQ.squads[squad.id] then SQ.registerRadio(squad) end
    end
end

-- ================================================================== players

function SQ.initPayload(src)
    local p = SQ.players[src]
    local pd = SQ.pd[p.id]
    local squad = SQ.memberSquad[p.id] and SQ.squads[SQ.memberSquad[p.id]]
    return {
        settings = SQ.publicSettings(),
        me = {
            id = p.id, name = p.name, src = src,
            xp = math.floor(pd.xp), level = SQ.levelOfXp(pd.xp),
            prefs = SQ.playerSettings(pd),
            isAdmin = SQ.isAdmin(src),
            canUse = SQ.canUse(src),
            money = Bridge.hasMoney(),
        },
        squad = squad and SQ.view(squad, p.id) or nil,
        ui = Locales[Config.Locale] and Locales[Config.Locale].ui or {},
        pingTypes = PingTypes,
    }
end

function SQ.onJoin(src)
    src = tonumber(src)
    if not src or not GetPlayerName(src) then return end
    local id = Bridge.identifier(src)
    if not id then return end
    local name = Bridge.name(src)

    if SQ.players[src] and SQ.players[src].id == id then
        TriggerClientEvent('squads:init', src, SQ.initPayload(src))
        return
    end

    SQ.players[src] = { id = id, name = name }
    local pd = SQ.loadPlayer(src)
    pd.name = name
    pd.dirty = true
    SQ.payPending(src, id)

    local sid = SQ.memberSquad[id]
    local squad = sid and SQ.squads[sid]
    if squad and squad.members[id] then
        squad.members[id].src = src
        squad.members[id].name = name
        squad.members[id].graceUntil = nil
        if squad.owner == id then squad.ownerName = name end
    elseif sid then
        SQ.memberSquad[id] = nil
    end

    TriggerClientEvent('squads:init', src, SQ.initPayload(src))
    if squad then SQ.pushSquad(squad) end
end

RegisterNetEvent('squads:ready', function()
    local src = source
    if not SQ.ready then return end
    SQ.onJoin(src)
end)

AddEventHandler('blue_squads:internalLoaded', function(src)
    if SQ.ready then
        Wait(1500)
        SQ.onJoin(src)
    end
end)

AddEventHandler('blue_squads:internalDeath', function(victim, killer)
    if SQ.ready then SQ.handleDeath(victim, killer) end
end)

AddEventHandler('playerDropped', function()
    local src = source
    local p = SQ.players[src]
    if p then
        local pd = SQ.pd[p.id]
        if pd then DB.savePlayer(pd) SQ.pd[p.id] = nil end
        local sid = SQ.memberSquad[p.id]
        local squad = sid and SQ.squads[sid]
        SQ.players[src] = nil
        if squad and squad.members[p.id] then
            squad.members[p.id].src = nil
            if not squad.permanent then
                local grace = SQ.get('graceMinutes')
                if grace <= 0 then
                    SQ.removeMember(squad, p.id, 'left')
                    squad = nil
                else
                    squad.members[p.id].graceUntil = SQ.now() + grace * 60
                end
            end
            if squad and SQ.squads[squad.id] then SQ.pushSquad(squad) end
        end
    end
    SQ.live[src] = nil
    SQ.invites[src] = nil
    SQ.damage[src] = nil
    SQ.roleCache[src] = nil
    SQ.clearLimits(src)
end)

-- ================================================================== damage

-- Tracks who really damaged whom (used to verify kills) and blocks friendly fire
AddEventHandler('weaponDamageEvent', function(sender, data)
    if not SQ.ready or type(data) ~= 'table' or not data.hitGlobalId then return end
    local ok, ent = pcall(NetworkGetEntityFromNetworkId, data.hitGlobalId)
    if not ok or not ent or ent == 0 or not DoesEntityExist(ent) or not IsPedAPlayer(ent) then return end
    local victim = NetworkGetEntityOwner(ent)
    if not victim or victim <= 0 then return end
    SQ.damageSeen = true
    SQ.damage[victim] = SQ.damage[victim] or {}
    SQ.damage[victim][sender] = SQ.now()

    local a, b = SQ.squadOf(sender), SQ.squadOf(victim)
    if a and b and a.id == b.id and not a.friendlyFire and sender ~= victim then
        CancelEvent()
    end
end)

-- ================================================================== requests

local A = {}

local function ok(...) return true, ... end

A.list = function(src) return true, SQ.listView() end

A.create = function(src, d)
    local good, res = SQ.createSquad(src, d)
    return good, res
end

A.join = function(src, d) return SQ.join(src, d.id, d.password) end
A.apply = function(src, d) return SQ.apply(src, d.id) end
A.leave = function(src) return SQ.leave(src) end
A.invite = function(src, d) return SQ.invite(src, d.target) end
A.inviteAnswer = function(src, d) return SQ.answerInvite(src, d.accept == true) end
A.app = function(src, d) return SQ.decideApplication(src, tostring(d.identifier), d.accept == true) end
A.member = function(src, d) return SQ.memberAction(src, d) end
A.ranks = function(src, d) return SQ.saveRanks(src, d.list) end
A.edit = function(src, d) return SQ.edit(src, d) end
A.rally = function(src, d)
    if d.x then return SQ.setRallyAt(src, d.x, d.y, d.z) end
    return SQ.setRally(src, d.clear == true)
end
A.chat = function(src, d) return SQ.sendChat(src, d.msg) end
A.chatHistory = function(src)
    local squad = SQ.squadOf(src)
    return true, squad and SQ.chat[squad.id] or {}
end

A.nearby = function(src)
    local list = {}
    local range = SQ.get('inviteDistance')
    for s, p in pairs(SQ.players) do
        if s ~= src and not SQ.memberSquad[p.id] then
            local dist = SQ.distance(src, s)
            if dist <= range then list[#list + 1] = { src = s, name = p.name, distance = math.floor(dist) } end
        end
    end
    table.sort(list, function(a, b) return a.distance < b.distance end)
    return true, list
end

A.players = function(src)
    local squad = SQ.squadOf(src)
    local list = {}
    for _, e in ipairs(SQ.onlinePlayers(src)) do
        local p = SQ.players[e.src]
        if not (squad and p and squad.members[p.id]) then list[#list + 1] = e end
    end
    return true, list
end

A.warChallenge = function(src, d) return SQ.warChallenge(src, d.id, d.minutes) end
A.warAnswer = function(src, d) return SQ.warAnswer(src, d.accept == true) end
A.warSurrender = function(src) return SQ.warSurrender(src) end
A.wars = function(src)
    local list = {}
    for _, w in pairs(SQ.wars) do
        if w.state == 'active' then
            local s = SQ.warSummary(w.a)
            if s then list[#list + 1] = s end
        end
    end
    return true, list
end

A.bounties = function(src) return true, SQ.bountyList() end
A.bountyPlace = function(src, d) return SQ.bountyPlace(src, d) end
A.bountyCancel = function(src, d) return SQ.bountyCancel(src, d.id) end

A.bank = function(src, d) return SQ.bank(src, d.op, d.amount) end
A.bankHistory = function(src)
    local h = SQ.bankHistory(src)
    if not h then return false, L('err.nosquad') end
    return true, h
end
A.ability = function(src, d) return SQ.useAbility(src, tostring(d.id)) end
A.order = function(src) return SQ.orderStart(src) end

A.tasks = function(src)
    local t = SQ.tasksView(src)
    if not t then return false, L('err.notloaded') end
    return true, t
end
A.claimTask = function(src, d)
    local good, err = SQ.claimTask(src, tostring(d.id))
    if not good then return false, err end
    return true, SQ.tasksView(src)
end

A.leaderboard = function(src) return true, SQ.leaderboard() end
A.profile = function(src, d)
    local prof = SQ.profileGet(src, d.identifier)
    if not prof then return false, L('err.gone') end
    return true, prof
end
A.profileSave = function(src, d)
    local good, err = SQ.profileSave(src, d)
    if not good then return false, err end
    return true, SQ.profileGet(src)
end
A.avatar = function(src, d)
    local good, res = SQ.importAvatar(src, tostring(d.kind))
    if not good then return false, res end
    return true, SQ.profileGet(src)
end
A.settingsSave = function(src, d) return SQ.savePlayerSettings(src, d) end

local function reply(src, rid, good, payload)
    TriggerClientEvent('squads:res', src, rid, good == true, payload)
end

RegisterNetEvent('squads:req', function(rid, action, data)
    local src = source
    if type(rid) ~= 'number' or type(action) ~= 'string' then return end
    if not SQ.ready then return reply(src, rid, false, L('err.starting')) end
    if not SQ.floodOk(src) then return reply(src, rid, false, L('err.slowdown')) end
    if type(data) ~= 'table' then data = {} end

    local admin = action:sub(1, 6) == 'admin.'
    local handler
    if admin then
        if not SQ.isAdmin(src) then
            SQ.log('admin', ('Blocked admin request "%s" from %s'):format(action, GetPlayerName(src) or src), src)
            return reply(src, rid, false, L('err.noperm'))
        end
        handler = SQ.AdminActions[action:sub(7)]
    else
        if not SQ.players[src] then
            SQ.onJoin(src)
            if not SQ.players[src] then return reply(src, rid, false, L('err.notloaded')) end
        end
        handler = A[action]
    end
    if not handler then return reply(src, rid, false, L('err.badvalue')) end

    local good, a, b = pcall(handler, src, data)
    if not good then
        print(('[blue_squads] error in "%s": %s'):format(action, tostring(a)))
        return reply(src, rid, false, L('err.internal'))
    end
    -- handlers return: ok, payloadOrError
    reply(src, rid, a, b)
end)

-- ================================================================== live data

RegisterNetEvent('squads:status', function(d)
    local src = source
    if type(d) ~= 'table' or not SQ.players[src] then return end
    if not SQ.rate(src, 'status', 250) then return end
    SQ.live[src] = { talk = d.talk == true, down = d.down == true }
end)

local function round1(v) return math.floor(v * 10 + 0.5) / 10 end

function SQ.liveTick()
    for _, squad in pairs(SQ.squads) do
        local online = SQ.onlineMembers(squad)
        if #online > 0 then
            local list = {}
            for _, m in ipairs(online) do
                local ped = GetPlayerPed(m.src)
                if ped and ped ~= 0 then
                    local c = GetEntityCoords(ped)
                    local maxHp = math.max(1, GetEntityMaxHealth(ped) - 100)
                    local hp = SQ.clamp(math.floor(((GetEntityHealth(ped) - 100) / maxHp) * 100), 0, 100)
                    local live = SQ.live[m.src] or {}
                    list[#list + 1] = {
                        s = m.src, h = hp, a = SQ.clamp(GetPedArmour(ped), 0, 100),
                        x = round1(c.x), y = round1(c.y), z = round1(c.z), r = math.floor(GetEntityHeading(ped)),
                        v = GetVehiclePedIsIn(ped, false) ~= 0, d = live.down == true, t = live.talk == true,
                    }
                end
            end
            for _, m in ipairs(online) do TriggerClientEvent('squads:live', m.src, list) end
        end
    end
end

-- ================================================================== pings

RegisterNetEvent('squads:ping', function(d)
    local src = source
    local squad, p = SQ.squadOf(src)
    if not squad or type(d) ~= 'table' then return end
    if not SQ.rate(src, 'ping', SQ.get('pingCooldown')) then return end
    local valid
    for _, t in ipairs(PingTypes) do if t.id == d.type then valid = true end end
    local x, y, z = tonumber(d.x), tonumber(d.y), tonumber(d.z)
    if not valid or not x or not y or not z then return end
    local c = SQ.coords(src)
    if not c or #(c - vector3(x, y, z)) > SQ.get('pingRange') + 25.0 then return end
    local net = math.floor(tonumber(d.net) or 0)

    pingCounter = pingCounter + 1
    local ping = { id = pingCounter, from = src, name = p.name, type = d.type, x = x, y = y, z = z, net = net, dur = SQ.get('pingDuration') }
    SQ.pings[squad.id] = SQ.pings[squad.id] or {}
    SQ.pings[squad.id][ping.id] = SQ.now() + ping.dur + 5
    for _, m in ipairs(SQ.onlineMembers(squad)) do TriggerClientEvent('squads:ping', m.src, ping) end
    SQ.taskProgress(src, 'pings', 1)
end)

RegisterNetEvent('squads:pingReact', function(d)
    local src = source
    local squad, p = SQ.squadOf(src)
    if not squad or type(d) ~= 'table' then return end
    if d.kind ~= 'ack' and d.kind ~= 'dibs' then return end
    local id = tonumber(d.id)
    local list = SQ.pings[squad.id]
    if not id or not list or not list[id] or list[id] < SQ.now() then return end
    if not SQ.rate(src, 'pingReact', 500) then return end
    for _, m in ipairs(SQ.onlineMembers(squad)) do
        TriggerClientEvent('squads:pingReact', m.src, { id = id, kind = d.kind, name = p.name })
    end
end)

-- ================================================================== timers

local function sweep()
    local now = SQ.now()
    for src, inv in pairs(SQ.invites) do
        if inv.expires < now then SQ.invites[src] = nil end
    end
    for _, squad in pairs(SQ.squads) do
        for identifier, m in pairs(squad.members) do
            if not m.src and m.graceUntil and m.graceUntil < now and SQ.squads[squad.id] then
                SQ.removeMember(squad, identifier, 'left')
            end
        end
    end
    for squadId, list in pairs(SQ.pings) do
        for id, exp in pairs(list) do if exp < now then list[id] = nil end end
        if next(list) == nil then SQ.pings[squadId] = nil end
    end
    for src, c in pairs(SQ.roleCache) do
        if c.exp < now - 300 then SQ.roleCache[src] = nil end
    end
end

CreateThread(function()
    Bridge.init()
    DB.migrate()
    SQ.loadSettings()
    SQ.loadSquads()
    SQ.loadBounties()
    SQ.checkVersion()
    SQ.ready = true
    print(('[blue_squads] ready (%s, %d squads loaded)'):format(Bridge.framework, SQ.count(SQ.squads)))

    for _, id in ipairs(GetPlayers()) do SQ.onJoin(tonumber(id)) end

    local last1s, lastLive, lastMinute, lastSweep = 0, 0, 0, 0
    while true do
        Wait(250)
        local now = GetGameTimer()
        if now - last1s >= 1000 then
            last1s = now
            pcall(SQ.warTick)
            pcall(SQ.orderTick)
            pcall(SQ.uavTick)
        end
        if now - lastLive >= SQ.get('liveInterval') then
            lastLive = now
            local good, err = pcall(SQ.liveTick)
            if not good then print('[blue_squads] live tick error: ' .. tostring(err)) end
        end
        if now - lastSweep >= 30000 then
            lastSweep = now
            pcall(sweep)
            pcall(SQ.bountyTick)
        end
        if now - lastMinute >= 60000 then
            lastMinute = now
            pcall(SQ.minuteTick)
        end
    end
end)

AddEventHandler('onResourceStop', function(name)
    if name ~= GetCurrentResourceName() then return end
    SQ.saveAll()
    for _, squad in pairs(SQ.squads) do DB.saveSquad(squad) end
end)

-- Console / ace helpers
exports('GetSquadOf', function(src)
    local squad = SQ.squadOf(src)
    if not squad then return nil end
    return { id = squad.id, name = squad.name, tag = squad.tag, color = squad.color, owner = squad.owner }
end)

exports('GetSquadRadioChannel', function(src)
    local squad = SQ.squadOf(src)
    return squad and SQ.radioChannel(squad) or nil
end)
