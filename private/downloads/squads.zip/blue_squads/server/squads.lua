-- Squads: creation, members, ranks, invites, applications, bans, chat

SQ.nameIndex = {}
SQ.tagIndex = {}

local function hook(name, ...)
    local fn = Hooks and Hooks[name]
    if fn then
        local ok, err = pcall(fn, ...)
        if not ok then print('[blue_squads] hook ' .. name .. ' error: ' .. tostring(err)) end
    end
end
SQ.hook = hook

-- ------------------------------------------------------------------- helpers

local function allPerms(value)
    local t = {}
    for _, p in ipairs(SquadPerms) do t[p] = value end
    return t
end

local function defaultRanks()
    local enforcer = allPerms(false)
    enforcer.invite, enforcer.kick, enforcer.wars, enforcer.bounties, enforcer.deposit = true, true, true, true, true
    local member = allPerms(false)
    member.deposit = true
    return {
        { id = 1, name = 'Enforcer', level = 2, perms = enforcer },
        { id = 2, name = 'Member', level = 1, perms = member },
    }
end

local function rankById(squad, id)
    for _, r in ipairs(squad.ranks) do if r.id == id then return r end end
end

local function lowestRank(squad)
    local low
    for _, r in ipairs(squad.ranks) do
        if not low or r.level < low.level then low = r end
    end
    return low
end

function SQ.squadOf(src)
    local p = SQ.players[src]
    if not p then return nil end
    local id = SQ.memberSquad[p.id]
    return id and SQ.squads[id] or nil, p
end

function SQ.levelOf(squad, identifier)
    if squad.owner == identifier then return OWNER_LEVEL end
    local m = squad.members[identifier]
    if not m then return 0 end
    local r = rankById(squad, m.rankId) or lowestRank(squad)
    return r and r.level or 1
end

function SQ.hasPerm(squad, identifier, perm)
    if squad.owner == identifier then return true end
    local m = squad.members[identifier]
    if not m then return false end
    local r = rankById(squad, m.rankId) or lowestRank(squad)
    return r and r.perms and r.perms[perm] == true or false
end

function SQ.memberCount(squad) return SQ.count(squad.members) end

function SQ.onlineMembers(squad)
    local out = {}
    for identifier, m in pairs(squad.members) do
        if m.src and SQ.players[m.src] then out[#out + 1] = { src = m.src, id = identifier } end
    end
    return out
end

function SQ.squadNotify(squad, msg, kind, except)
    for _, m in ipairs(SQ.onlineMembers(squad)) do
        if m.src ~= except then SQ.notify(m.src, msg, kind) end
    end
end

function SQ.radioChannel(squad)
    if squad.radio and squad.radio > 0 then return squad.radio end
    return SQ.get('radioBase') + (squad.id % 4000)
end

function SQ.save(squad)
    squad.lastActive = SQ.now()
    DB.saveSquad(squad)
end

-- ------------------------------------------------------------------- views

function SQ.warSummary(squadId)
    for _, w in pairs(SQ.wars) do
        if w.a == squadId or w.b == squadId then
            local a, b = SQ.squads[w.a], SQ.squads[w.b]
            if a and b then
                return {
                    id = w.id, state = w.state, minutes = w.minutes, requester = w.requester,
                    endsAt = w.endsAt, expiresAt = w.expiresAt, ka = w.ka, kb = w.kb,
                    a = { id = a.id, name = a.name, tag = a.tag, color = a.color, photo = a.photo, banner = a.banner },
                    b = { id = b.id, name = b.name, tag = b.tag, color = b.color, photo = b.photo, banner = b.banner },
                }
            end
        end
    end
end

local function levelOfXp(xp)
    local base = SQ.get('xpLevelBase')
    return math.floor(math.sqrt((xp or 0) / base)) + 1
end
SQ.levelOfXp = levelOfXp

function SQ.view(squad, viewerId)
    local now = SQ.now()
    local members = {}
    for identifier, m in pairs(squad.members) do
        local pd = m.src and SQ.pd[identifier]
        local rank = identifier == squad.owner and { name = 'Owner', level = OWNER_LEVEL } or (rankById(squad, m.rankId) or lowestRank(squad))
        local status = 'offline'
        if m.src and SQ.players[m.src] then
            status = (pd and pd.profile.status) or 'online'
            if status == 'invisible' then status = 'offline' end
        end
        members[#members + 1] = {
            id = identifier, src = m.src, name = m.name, rankId = m.rankId, rank = rank and rank.name or 'Member',
            level = rank and rank.level or 1, online = m.src ~= nil and SQ.players[m.src] ~= nil, status = status,
            owner = identifier == squad.owner, joined = m.joined,
            picture = pd and pd.profile.picture or '', verified = pd and pd.profile.verified or false,
            xpLevel = pd and levelOfXp(pd.xp) or nil,
        }
    end
    table.sort(members, function(x, y)
        if x.level ~= y.level then return x.level > y.level end
        if x.online ~= y.online then return x.online end
        return x.name:lower() < y.name:lower()
    end)

    local perms = {}
    for _, p in ipairs(SquadPerms) do perms[p] = SQ.hasPerm(squad, viewerId, p) end

    local ranks = {}
    for _, r in ipairs(squad.ranks) do ranks[#ranks + 1] = { id = r.id, name = r.name, level = r.level, perms = r.perms } end

    local view = {
        id = squad.id, name = squad.name, tag = squad.tag, permanent = squad.permanent, privacy = squad.privacy,
        color = squad.color, photo = squad.photo, banner = squad.banner, owner = squad.owner, ownerName = squad.ownerName,
        maxMembers = squad.maxMembers, friendlyFire = squad.friendlyFire, bank = squad.bank, created = squad.created,
        radio = squad.radio or 0, radioChannel = SQ.radioChannel(squad),
        ranks = ranks, members = members,
        me = { id = viewerId, isOwner = squad.owner == viewerId, perms = perms, level = SQ.levelOf(squad, viewerId) },
        rally = squad.rally, war = SQ.warSummary(squad.id),
        boost = { xpUntil = squad.xpUntil or 0, uavUntil = squad.uavUntil or 0 },
        cooldowns = {
            uav = math.max(0, (squad.cd and squad.cd.uav or 0) - now),
            armor = math.max(0, (squad.cd and squad.cd.armor or 0) - now),
            xp = math.max(0, (squad.cd and squad.cd.xp or 0) - now),
            order = math.max(0, (squad.cd and squad.cd.order or 0) - now),
        },
        order = SQ.orders[squad.id] and { x = SQ.orders[squad.id].pos.x, y = SQ.orders[squad.id].pos.y, z = SQ.orders[squad.id].pos.z, expires = SQ.orders[squad.id].expires } or nil,
        now = now,
    }

    if perms.invite then
        local apps = {}
        for identifier, a in pairs(squad.applications) do apps[#apps + 1] = { id = identifier, name = a.name, at = a.at } end
        table.sort(apps, function(x, y) return x.at < y.at end)
        view.applications = apps
    end
    if perms.kick then
        local bans = {}
        for identifier, b in pairs(squad.bans) do bans[#bans + 1] = { id = identifier, name = b.name, reason = b.reason, by = b.by, at = b.at } end
        table.sort(bans, function(x, y) return x.at > y.at end)
        view.bans = bans
    end
    return view
end

function SQ.pushSquad(squad)
    for _, m in ipairs(SQ.onlineMembers(squad)) do
        TriggerClientEvent('squads:squad', m.src, SQ.view(squad, m.id))
    end
end

function SQ.pushNone(src) TriggerClientEvent('squads:squad', src, nil) end

function SQ.listView()
    local war = {}
    for _, w in pairs(SQ.wars) do
        if w.state == 'active' then war[w.a] = true war[w.b] = true end
    end
    local list = {}
    for _, s in pairs(SQ.squads) do
        list[#list + 1] = {
            id = s.id, name = s.name, tag = s.tag, color = s.color, photo = s.photo, banner = s.banner,
            count = SQ.memberCount(s), max = s.maxMembers, privacy = s.privacy, permanent = s.permanent,
            atWar = war[s.id] or false, online = #SQ.onlineMembers(s), ownerName = s.ownerName,
        }
    end
    table.sort(list, function(a, b)
        local af, bf = a.count < a.max, b.count < b.max
        if af ~= bf then return af end
        if a.count ~= b.count then return a.count > b.count end
        return a.name:lower() < b.name:lower()
    end)
    return list
end

-- ---------------------------------------------------------------- permissions

function SQ.canUse(src)
    local groups, roles = SQ.get('useGroups'), SQ.get('useRoles')
    local hasGroups, hasRoles = groups and #groups > 0, roles and #roles > 0
    if not hasGroups and not hasRoles then return true end
    if SQ.isAdmin(src, true) then return true end
    if hasGroups and Bridge.inGroup(src, groups) then return true end
    if hasRoles and SQ.hasDiscordRole(src, roles) then return true end
    return false
end

-- ------------------------------------------------------------------ radio

function SQ.registerRadio(squad)
    if GetResourceState('pma-voice') ~= 'started' then return end
    local ch = SQ.radioChannel(squad)
    if SQ.registeredRadio and SQ.registeredRadio[ch] then return end
    SQ.registeredRadio = SQ.registeredRadio or {}
    SQ.registeredRadio[ch] = true
    pcall(function()
        exports['pma-voice']:addChannelCheck(ch, function(source)
            local s = SQ.squadOf(source)
            return s ~= nil and SQ.radioChannel(s) == ch
        end)
    end)
end

-- ------------------------------------------------------------------ creating

function SQ.validateLook(d, squad)
    local color = d.color
    if color ~= nil and not (type(color) == 'string' and color:match('^#%x%x%x%x%x%x$')) then return false, L('err.badcolor') end
    for _, key in ipairs({ 'photo', 'banner' }) do
        if d[key] ~= nil then
            local ok = SQ.validImage(d[key])
            if not ok then return false, L('err.badimage') end
        end
    end
    return true
end

function SQ.createSquad(src, d)
    local p = SQ.players[src]
    if not p then return false, L('err.notloaded') end
    if SQ.memberSquad[p.id] then return false, L('err.insquad') end
    if not SQ.canUse(src) then return false, L('err.noaccess') end
    d = type(d) == 'table' and d or {}

    local name = SQ.trim(d.name)
    if #name < SQ.get('nameMin') or #name > SQ.get('nameMax') then return false, L('err.namelen', SQ.get('nameMin'), SQ.get('nameMax')) end
    if name:find("[^%w %-_%.']") then return false, L('err.namechars') end
    if SQ.nameIndex[name:lower()] then return false, L('err.nametaken') end

    local tag = SQ.trim(d.tag or ''):upper()
    if tag == '' and SQ.get('tagRequired') then return false, L('err.tagrequired') end
    if tag ~= '' then
        if #tag > SQ.get('tagMax') or tag:find('[^%w]') then return false, L('err.taglen', SQ.get('tagMax')) end
        if SQ.tagIndex[tag] then return false, L('err.tagtaken') end
    end
    if SQ.hasBlocked(name) or SQ.hasBlocked(tag) then return false, L('err.blocked') end

    local ok, why = SQ.validateLook(d)
    if not ok then return false, why end

    local mode = SQ.get('squadMode')
    local permanent = (mode == 'permanent') or (mode == 'choice' and d.permanent == true)

    local privacy = d.privacy or 'open'
    if privacy ~= 'open' and privacy ~= 'password' and privacy ~= 'apply' then return false, L('err.badvalue') end
    if privacy == 'password' and not SQ.get('allowPassword') then return false, L('err.nopassword') end
    if privacy == 'apply' and not SQ.get('allowApply') then return false, L('err.noapply') end
    local pwhash, pwsalt = '', ''
    if privacy == 'password' then
        local pw = type(d.password) == 'string' and d.password or ''
        if #pw < 4 or #pw > 32 then return false, L('err.pwlen') end
        pwsalt = SQ.randomSalt()
        pwhash = SQ.hash(pw, pwsalt)
    end

    local maxMembers = SQ.clamp(math.floor(tonumber(d.maxMembers) or SQ.get('maxMembers')), 2, SQ.get('maxMembers'))

    local fee = SQ.get('createFee')
    if fee > 0 then
        if not Bridge.removeMoney(src, SQ.get('bankAccount'), fee, 'squad creation') then return false, L('err.fee', fee) end
    end

    local now = SQ.now()
    local squad = {
        id = 0, name = name, tag = tag, permanent = permanent, privacy = privacy, pwhash = pwhash, pwsalt = pwsalt,
        color = d.color or SQ.get('themeColor'), photo = d.photo or '', banner = d.banner or '',
        owner = p.id, ownerName = p.name, maxMembers = maxMembers,
        friendlyFire = (d.friendlyFire == true) or (d.friendlyFire == nil and SQ.get('friendlyFire')),
        bank = 0, radio = 0, ranks = defaultRanks(), bans = {}, created = now, lastActive = now,
        members = {}, applications = {}, cd = {},
    }
    squad.members[p.id] = { rankId = 0, joined = now, name = p.name, src = src }

    if permanent then
        squad.id = DB.insertSquad(squad)
        DB.saveMember(squad.id, p.id, 0, now, p.name)
    else
        SQ.nextTempId = SQ.nextTempId + 1
        squad.id = SQ.nextTempId
    end

    SQ.squads[squad.id] = squad
    SQ.memberSquad[p.id] = squad.id
    SQ.nameIndex[name:lower()] = squad.id
    if tag ~= '' then SQ.tagIndex[tag] = squad.id end
    SQ.registerRadio(squad)
    SQ.pushSquad(squad)
    SQ.log('squad', ('%s created the %s squad "%s"'):format(p.name, permanent and 'permanent' or 'temporary', name), src)
    hook('onCreate', squad, src)
    return true, squad.id
end

-- ------------------------------------------------------------------ members

function SQ.addMember(squad, src, rankId)
    local p = SQ.players[src]
    if not p then return false, L('err.notloaded') end
    if SQ.memberSquad[p.id] then return false, L('err.insquad') end
    if SQ.memberCount(squad) >= squad.maxMembers then return false, L('err.full') end
    if squad.bans[p.id] then return false, L('err.banned', squad.bans[p.id].reason or '') end
    local low = lowestRank(squad)
    local now = SQ.now()
    squad.members[p.id] = { rankId = rankId or (low and low.id) or 0, joined = now, name = p.name, src = src }
    squad.applications[p.id] = nil
    SQ.memberSquad[p.id] = squad.id
    if squad.permanent then DB.saveMember(squad.id, p.id, squad.members[p.id].rankId, now, p.name) end
    SQ.invites[src] = nil
    SQ.pushSquad(squad)
    SQ.squadNotify(squad, L('note.joined', p.name), 'info', src)
    SQ.log('squad', ('%s joined "%s"'):format(p.name, squad.name), src)
    hook('onJoin', squad, src)
    return true
end

local function pickSuccessor(squad, leavingId)
    local best, bestLevel, bestOnline, bestJoined
    for identifier, m in pairs(squad.members) do
        if identifier ~= leavingId then
            local lvl = SQ.levelOf(squad, identifier)
            local online = m.src ~= nil
            if not best
                or lvl > bestLevel
                or (lvl == bestLevel and online and not bestOnline)
                or (lvl == bestLevel and online == bestOnline and m.joined < bestJoined) then
                best, bestLevel, bestOnline, bestJoined = identifier, lvl, online, m.joined
            end
        end
    end
    return best
end

-- how = 'left', 'kicked', 'banned'
function SQ.removeMember(squad, identifier, how)
    local m = squad.members[identifier]
    if not m then return end
    local wasOwner = squad.owner == identifier
    local src = m.src

    if wasOwner then
        local successor = pickSuccessor(squad, identifier)
        if not successor then
            SQ.disband(squad, 'empty')
            return
        end
        squad.owner = successor
        squad.members[successor].rankId = 0
        squad.ownerName = squad.members[successor].name
        if squad.permanent then DB.saveMember(squad.id, successor, 0, squad.members[successor].joined, squad.ownerName) end
        SQ.squadNotify(squad, L('note.newowner', squad.ownerName), 'info')
    end

    squad.members[identifier] = nil
    SQ.memberSquad[identifier] = nil
    if squad.permanent then DB.deleteMember(identifier) end
    SQ.bountiesOnLeave(squad, identifier)

    if src then
        SQ.pushNone(src)
        TriggerClientEvent('squads:left', src, how)
    end

    -- a temporary squad with nobody left online and nobody waiting to reconnect ends
    if SQ.memberCount(squad) == 0 then
        SQ.disband(squad, 'empty')
        return
    end
    SQ.save(squad)
    SQ.pushSquad(squad)
    hook('onLeave', squad, src, identifier)
end

function SQ.disband(squad, reason)
    if not SQ.squads[squad.id] then return end
    SQ.squads[squad.id] = nil
    SQ.nameIndex[squad.name:lower()] = nil
    if squad.tag ~= '' then SQ.tagIndex[squad.tag] = nil end

    SQ.endWarsFor(squad.id, 'disband')
    SQ.refundSquadBounties(squad)
    SQ.orders[squad.id] = nil
    SQ.chat[squad.id] = nil

    -- whatever is left in the bank goes to the owner
    if squad.bank and squad.bank > 0 and reason ~= 'empty' then
        SQ.pay(squad.owner, SQ.get('bankAccount'), squad.bank, 'squad bank (disbanded)')
    elseif squad.bank and squad.bank > 0 then
        SQ.pay(squad.owner, SQ.get('bankAccount'), squad.bank, 'squad bank (disbanded)')
    end

    for identifier, m in pairs(squad.members) do
        SQ.memberSquad[identifier] = nil
        if m.src then
            SQ.pushNone(m.src)
            TriggerClientEvent('squads:left', m.src, 'disbanded')
            if reason ~= 'empty' then SQ.notify(m.src, L('note.disbanded', squad.name), 'warn') end
        end
    end
    if squad.permanent then DB.deleteSquad(squad.id) end
    SQ.log('squad', ('Squad "%s" ended (%s)'):format(squad.name, reason or 'disbanded'))
    hook('onDisband', squad)
end

function SQ.leave(src)
    local squad, p = SQ.squadOf(src)
    if not squad then return false, L('err.nosquad') end
    SQ.removeMember(squad, p.id, 'left')
    return true
end

-- ------------------------------------------------------------------ invites

function SQ.invite(src, targetSrc)
    local squad, p = SQ.squadOf(src)
    if not squad then return false, L('err.nosquad') end
    if not SQ.hasPerm(squad, p.id, 'invite') then return false, L('err.noperm') end
    targetSrc = tonumber(targetSrc)
    local t = targetSrc and SQ.players[targetSrc]
    if not t or targetSrc == src then return false, L('err.noplayer') end
    if SQ.memberSquad[t.id] then return false, L('err.targetinsquad') end
    if squad.bans[t.id] then return false, L('err.targetbanned') end
    if SQ.memberCount(squad) >= squad.maxMembers then return false, L('err.full') end
    if SQ.distance(src, targetSrc) > SQ.get('inviteDistance') then return false, L('err.toofar') end
    if not SQ.canUse(targetSrc) then return false, L('err.targetnoaccess') end
    local existing = SQ.invites[targetSrc]
    if existing and existing.expires > SQ.now() then return false, L('err.alreadyinvited') end

    local timeout = SQ.get('inviteTimeout')
    SQ.invites[targetSrc] = { squadId = squad.id, from = src, fromName = p.name, expires = SQ.now() + timeout }
    TriggerClientEvent('squads:invite', targetSrc, {
        squad = squad.name, tag = squad.tag, color = squad.color, from = p.name, seconds = timeout,
    })
    SQ.notify(src, L('note.invited', t.name), 'success')
    return true
end

function SQ.answerInvite(src, accept)
    local inv = SQ.invites[src]
    if not inv or inv.expires < SQ.now() then SQ.invites[src] = nil return false, L('err.noinvite') end
    SQ.invites[src] = nil
    if not accept then
        if SQ.players[inv.from] then SQ.notify(inv.from, L('note.declined', SQ.players[src] and SQ.players[src].name or '?'), 'warn') end
        return true
    end
    local squad = SQ.squads[inv.squadId]
    if not squad then return false, L('err.gone') end
    return SQ.addMember(squad, src)
end

-- ------------------------------------------------------------------ join / apply

function SQ.join(src, squadId, password)
    local p = SQ.players[src]
    if not p then return false, L('err.notloaded') end
    if not SQ.canUse(src) then return false, L('err.noaccess') end
    local squad = SQ.squads[tonumber(squadId)]
    if not squad then return false, L('err.gone') end
    if SQ.memberSquad[p.id] then return false, L('err.insquad') end
    if squad.privacy == 'apply' then return false, L('err.applyonly') end
    if squad.privacy == 'password' then
        if type(password) ~= 'string' or SQ.hash(password, squad.pwsalt) ~= squad.pwhash then
            return false, L('err.wrongpassword')
        end
    end
    return SQ.addMember(squad, src)
end

function SQ.apply(src, squadId)
    local p = SQ.players[src]
    if not p then return false, L('err.notloaded') end
    if not SQ.canUse(src) then return false, L('err.noaccess') end
    local squad = SQ.squads[tonumber(squadId)]
    if not squad then return false, L('err.gone') end
    if SQ.memberSquad[p.id] then return false, L('err.insquad') end
    if squad.privacy == 'open' then return false, L('err.openjoin') end
    if not SQ.get('allowApply') then return false, L('err.noapply') end
    if squad.bans[p.id] then return false, L('err.banned', squad.bans[p.id].reason or '') end
    if squad.applications[p.id] then return false, L('err.alreadyapplied') end
    if SQ.count(squad.applications) >= SQ.get('maxApplications') then return false, L('err.appsfull') end
    squad.applications[p.id] = { name = p.name, at = SQ.now(), src = src }
    SQ.pushSquad(squad)
    for _, m in ipairs(SQ.onlineMembers(squad)) do
        if SQ.hasPerm(squad, m.id, 'invite') then SQ.notify(m.src, L('note.newapplication', p.name), 'info') end
    end
    return true
end

function SQ.decideApplication(src, identifier, accept)
    local squad, p = SQ.squadOf(src)
    if not squad then return false, L('err.nosquad') end
    if not SQ.hasPerm(squad, p.id, 'invite') then return false, L('err.noperm') end
    local app = squad.applications[identifier]
    if not app then return false, L('err.noapp') end
    if not accept then
        squad.applications[identifier] = nil
        SQ.pushSquad(squad)
        return true
    end
    -- find the applicant (must be online to join)
    local targetSrc
    for s, pl in pairs(SQ.players) do if pl.id == identifier then targetSrc = s end end
    if not targetSrc then
        squad.applications[identifier] = nil
        SQ.pushSquad(squad)
        return false, L('err.applicantoffline')
    end
    local ok, err = SQ.addMember(squad, targetSrc)
    if ok then SQ.notify(targetSrc, L('note.accepted', squad.name), 'success') end
    return ok, err
end

-- ------------------------------------------------------------------ member admin

function SQ.memberAction(src, d)
    local squad, p = SQ.squadOf(src)
    if not squad then return false, L('err.nosquad') end
    if type(d) ~= 'table' or type(d.identifier) ~= 'string' then return false, L('err.badvalue') end
    local op, target = d.op, d.identifier
    local myLevel = SQ.levelOf(squad, p.id)

    if op == 'unban' then
        if not SQ.hasPerm(squad, p.id, 'kick') then return false, L('err.noperm') end
        if not squad.bans[target] then return false, L('err.badvalue') end
        squad.bans[target] = nil
        SQ.save(squad)
        SQ.pushSquad(squad)
        return true
    end

    local m = squad.members[target]
    if not m then return false, L('err.nomember') end

    if op == 'kick' or op == 'ban' then
        if not SQ.hasPerm(squad, p.id, 'kick') then return false, L('err.noperm') end
        if target == p.id then return false, L('err.self') end
        if target == squad.owner or SQ.levelOf(squad, target) >= myLevel then return false, L('err.higher') end
        if op == 'ban' then
            local reason = SQ.trim(d.reason or ''):sub(1, 80)
            if SQ.hasBlocked(reason) then return false, L('err.blocked') end
            squad.bans[target] = { name = m.name, reason = reason, by = p.name, at = SQ.now() }
        end
        local targetSrc = m.src
        SQ.removeMember(squad, target, op == 'ban' and 'banned' or 'kicked')
        if targetSrc then SQ.notify(targetSrc, L(op == 'ban' and 'note.banned' or 'note.kicked', squad.name), 'warn') end
        SQ.log('squad', ('%s %s %s in "%s"'):format(p.name, op == 'ban' and 'banned' or 'kicked', m.name, squad.name), src)
        return true
    elseif op == 'rank' then
        if squad.owner ~= p.id then return false, L('err.owneronly') end
        if target == squad.owner then return false, L('err.self') end
        local rank = rankById(squad, tonumber(d.rankId))
        if not rank then return false, L('err.badvalue') end
        m.rankId = rank.id
        if squad.permanent then DB.saveMember(squad.id, target, rank.id, m.joined, m.name) end
        SQ.pushSquad(squad)
        return true
    elseif op == 'transfer' then
        if squad.owner ~= p.id then return false, L('err.owneronly') end
        if target == p.id then return false, L('err.self') end
        local low = lowestRank(squad)
        squad.members[p.id].rankId = low and low.id or 0
        squad.owner = target
        squad.ownerName = m.name
        m.rankId = 0
        if squad.permanent then
            DB.saveMember(squad.id, p.id, squad.members[p.id].rankId, squad.members[p.id].joined, p.name)
            DB.saveMember(squad.id, target, 0, m.joined, m.name)
        end
        SQ.save(squad)
        SQ.pushSquad(squad)
        SQ.squadNotify(squad, L('note.newowner', m.name), 'info')
        return true
    end
    return false, L('err.badvalue')
end

-- ------------------------------------------------------------------ ranks

function SQ.saveRanks(src, list)
    local squad, p = SQ.squadOf(src)
    if not squad then return false, L('err.nosquad') end
    if squad.owner ~= p.id then return false, L('err.owneronly') end
    if type(list) ~= 'table' or #list < 1 or #list > SQ.get('maxRanks') then return false, L('err.ranklimit', SQ.get('maxRanks')) end

    local seenNames, seenIds, out = {}, {}, {}
    local nextId = 1
    for _, r in ipairs(squad.ranks) do if r.id >= nextId then nextId = r.id + 1 end end

    for _, r in ipairs(list) do
        if type(r) ~= 'table' then return false, L('err.badvalue') end
        local name = SQ.trim(r.name):sub(1, 20)
        if #name < 2 then return false, L('err.rankname') end
        if seenNames[name:lower()] or name:lower() == 'owner' then return false, L('err.rankdup') end
        if SQ.hasBlocked(name) then return false, L('err.blocked') end
        seenNames[name:lower()] = true
        local level = math.floor(tonumber(r.level) or 0)
        if level < 1 or level > 99 then return false, L('err.ranklevel') end
        local id = tonumber(r.id)
        if not id or not rankById(squad, id) or seenIds[id] then id = nextId nextId = nextId + 1 end
        seenIds[id] = true
        local perms = allPerms(false)
        if type(r.perms) == 'table' then
            for _, perm in ipairs(SquadPerms) do perms[perm] = r.perms[perm] == true end
        end
        out[#out + 1] = { id = id, name = name, level = level, perms = perms }
    end

    -- nobody may be left on a rank that was deleted
    local keep = {}
    for _, r in ipairs(out) do keep[r.id] = true end
    for identifier, m in pairs(squad.members) do
        if identifier ~= squad.owner and not keep[m.rankId] then return false, L('err.rankinuse') end
    end

    squad.ranks = out
    SQ.save(squad)
    SQ.pushSquad(squad)
    return true
end

-- ------------------------------------------------------------------ editing

function SQ.edit(src, d)
    local squad, p = SQ.squadOf(src)
    if not squad then return false, L('err.nosquad') end
    if type(d) ~= 'table' then return false, L('err.badvalue') end
    local function perm(name) return SQ.hasPerm(squad, p.id, name) end

    -- validate everything first so a bad value changes nothing
    local newName, newTag
    if d.name ~= nil or d.tag ~= nil then
        if not perm('edit_name') then return false, L('err.noperm') end
        if d.name ~= nil then
            newName = SQ.trim(d.name)
            if #newName < SQ.get('nameMin') or #newName > SQ.get('nameMax') then return false, L('err.namelen', SQ.get('nameMin'), SQ.get('nameMax')) end
            if newName:find("[^%w %-_%.']") then return false, L('err.namechars') end
            local owner = SQ.nameIndex[newName:lower()]
            if owner and owner ~= squad.id then return false, L('err.nametaken') end
            if SQ.hasBlocked(newName) then return false, L('err.blocked') end
        end
        if d.tag ~= nil then
            newTag = SQ.trim(d.tag):upper()
            if newTag == '' and SQ.get('tagRequired') then return false, L('err.tagrequired') end
            if newTag ~= '' then
                if #newTag > SQ.get('tagMax') or newTag:find('[^%w]') then return false, L('err.taglen', SQ.get('tagMax')) end
                local owner = SQ.tagIndex[newTag]
                if owner and owner ~= squad.id then return false, L('err.tagtaken') end
                if SQ.hasBlocked(newTag) then return false, L('err.blocked') end
            end
        end
    end
    if d.photo ~= nil then
        if not perm('edit_photo') then return false, L('err.noperm') end
        if not SQ.validImage(d.photo) then return false, L('err.badimage') end
    end
    if d.banner ~= nil then
        if not perm('edit_banner') then return false, L('err.noperm') end
        if not SQ.validImage(d.banner) then return false, L('err.badimage') end
    end
    if d.color ~= nil then
        if not perm('edit_color') then return false, L('err.noperm') end
        if not (type(d.color) == 'string' and d.color:match('^#%x%x%x%x%x%x$')) then return false, L('err.badcolor') end
    end

    local newPrivacy, pwhash, pwsalt, newMax, newFF, newRadio
    if d.privacy ~= nil or d.friendlyFire ~= nil or d.radio ~= nil then
        if not perm('edit_settings') then return false, L('err.noperm') end
    end
    if d.privacy ~= nil then
        newPrivacy = d.privacy
        if newPrivacy ~= 'open' and newPrivacy ~= 'password' and newPrivacy ~= 'apply' then return false, L('err.badvalue') end
        if newPrivacy == 'password' then
            if not SQ.get('allowPassword') then return false, L('err.nopassword') end
            if type(d.password) == 'string' and d.password ~= '' then
                if #d.password < 4 or #d.password > 32 then return false, L('err.pwlen') end
                pwsalt = SQ.randomSalt()
                pwhash = SQ.hash(d.password, pwsalt)
            elseif squad.privacy ~= 'password' then
                return false, L('err.pwlen')
            end
        elseif newPrivacy == 'apply' and not SQ.get('allowApply') then
            return false, L('err.noapply')
        end
    end
    if d.maxMembers ~= nil then
        if squad.owner ~= p.id then return false, L('err.owneronly') end
        newMax = math.floor(tonumber(d.maxMembers) or 0)
        if newMax < 2 or newMax > SQ.get('maxMembers') then return false, L('err.badvalue') end
        if newMax < SQ.memberCount(squad) then return false, L('err.sizetoosmall') end
    end
    if d.friendlyFire ~= nil then
        if type(d.friendlyFire) ~= 'boolean' then return false, L('err.badvalue') end
        newFF = d.friendlyFire
    end
    if d.radio ~= nil then
        newRadio = math.floor(tonumber(d.radio) or -1)
        local base = SQ.get('radioBase')
        if newRadio ~= 0 and (newRadio < base or newRadio > base + 9999) then return false, L('err.radiorange', base, base + 9999) end
    end

    -- apply
    if newName and newName ~= squad.name then
        SQ.nameIndex[squad.name:lower()] = nil
        squad.name = newName
        SQ.nameIndex[newName:lower()] = squad.id
    end
    if newTag ~= nil and newTag ~= squad.tag then
        if squad.tag ~= '' then SQ.tagIndex[squad.tag] = nil end
        squad.tag = newTag
        if newTag ~= '' then SQ.tagIndex[newTag] = squad.id end
    end
    if d.photo ~= nil then squad.photo = d.photo end
    if d.banner ~= nil then squad.banner = d.banner end
    if d.color ~= nil then squad.color = d.color end
    if newPrivacy then
        squad.privacy = newPrivacy
        if pwhash then squad.pwhash, squad.pwsalt = pwhash, pwsalt end
        if newPrivacy ~= 'password' then squad.pwhash, squad.pwsalt = '', '' end
    end
    if newMax then squad.maxMembers = newMax end
    if newFF ~= nil then squad.friendlyFire = newFF end
    if newRadio ~= nil then squad.radio = newRadio SQ.registerRadio(squad) end

    SQ.save(squad)
    SQ.pushSquad(squad)
    SQ.log('squad', ('%s edited "%s"'):format(p.name, squad.name), src)
    hook('onEdit', squad, src)
    return true
end

function SQ.setRally(src, clear)
    local squad, p = SQ.squadOf(src)
    if not squad then return false, L('err.nosquad') end
    if squad.owner ~= p.id then return false, L('err.owneronly') end
    if not SQ.get('rallyEnabled') then return false, L('err.disabled') end
    if clear then
        squad.rally = nil
    else
        local c = SQ.coords(src)
        if not c then return false, L('err.badvalue') end
        squad.rally = { x = c.x, y = c.y, z = c.z }
    end
    SQ.save(squad)
    SQ.pushSquad(squad)
    return true
end

function SQ.setRallyAt(src, x, y, z)
    local squad, p = SQ.squadOf(src)
    if not squad then return false, L('err.nosquad') end
    if squad.owner ~= p.id then return false, L('err.owneronly') end
    if not SQ.get('rallyEnabled') then return false, L('err.disabled') end
    x, y, z = tonumber(x), tonumber(y), tonumber(z)
    if not x or not y or not z then return false, L('err.badvalue') end
    squad.rally = { x = x, y = y, z = z }
    SQ.save(squad)
    SQ.pushSquad(squad)
    return true
end

-- ------------------------------------------------------------------ chat

function SQ.sendChat(src, message)
    local squad, p = SQ.squadOf(src)
    if not squad then return false, L('err.nosquad') end
    if not SQ.get('chatEnabled') then return false, L('err.disabled') end
    if type(message) ~= 'string' then return false, L('err.badvalue') end
    message = SQ.trim(message):sub(1, SQ.get('chatMaxLength'))
    if message == '' then return false, L('err.badvalue') end
    if not SQ.rate(src, 'chat', SQ.get('chatCooldown')) then return false, L('err.slowdown') end
    local entry = { name = p.name, msg = message, t = SQ.now(), id = p.id }
    local list = SQ.chat[squad.id] or {}
    SQ.chat[squad.id] = list
    list[#list + 1] = entry
    if #list > 50 then table.remove(list, 1) end
    for _, m in ipairs(SQ.onlineMembers(squad)) do
        TriggerClientEvent('squads:chat', m.src, entry)
    end
    SQ.taskProgress(src, 'messages', 1)
    return true
end
