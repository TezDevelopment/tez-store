Config = {}

-- Almost everything is changed IN GAME with /squadsadmin (saved in the database).
-- This file only holds what has to be known before the database loads.

Config.Framework = 'auto'      -- 'auto', 'esx', 'qb', 'qbox' or 'standalone'
Config.Locale    = 'en'        -- file in /locales
Config.Debug     = false

-- Default keys. Players can rebind them in Settings > Key Bindings > FiveM.
Config.Keys = {
    menu      = 'F9',
    quickChat = 'Y',
    invite    = 'J',
    ping      = 'MOUSE_MIDDLE',   -- tap = ping, double tap = enemy, hold = ping wheel
    farTags   = 'MOUSE_EXTRABTN1',-- hold (side mouse button) to double the nametag range
    pingAck   = 'LBRACKET',
    pingDibs  = 'RBRACKET',
    accept    = 'PAGEUP',
    decline   = 'PAGEDOWN',
}

-- Account names used by your framework
Config.Accounts = {
    bank = 'bank',
    cash = 'money',            -- ESX 'money', QBCore 'cash'
}

-- Optional: URL of a text file that contains only the newest version number (e.g. 2.0.1)
Config.VersionUrl = ''

-- Nearest GTA blip colours for custom squad colours (rgb -> blip colour id)
Config.BlipPalette = {
    { id = 1,  rgb = { 224, 50, 50 } },
    { id = 2,  rgb = { 114, 204, 114 } },
    { id = 3,  rgb = { 93, 182, 229 } },
    { id = 4,  rgb = { 255, 255, 255 } },
    { id = 5,  rgb = { 240, 200, 80 } },
    { id = 6,  rgb = { 194, 80, 80 } },
    { id = 7,  rgb = { 156, 110, 175 } },
    { id = 8,  rgb = { 255, 123, 196 } },
    { id = 17, rgb = { 238, 134, 40 } },
    { id = 38, rgb = { 35, 70, 190 } },
    { id = 40, rgb = { 90, 90, 90 } },
    { id = 53, rgb = { 40, 200, 160 } },
}
