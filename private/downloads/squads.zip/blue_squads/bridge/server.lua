-- Framework bridge (server). Edit this file to connect your own framework.
-- Every function the rest of the resource needs from your framework is here.

Bridge = { framework = 'standalone', ready = false }

local ESX, QBCore, Qbox

local function started(name) return GetResourceState(name) == 'started' end

local function account(a)
    if a == 'cash' then return Config.Accounts.cash end
    return Config.Accounts.bank
end

function Bridge.init()
    local fw = Config.Framework
    if fw == 'auto' then
        for _ = 1, 40 do
            if started('es_extended') then fw = 'esx' break end
            if started('qbx_core') then fw = 'qbox' break end
            if started('qb-core') then fw = 'qb' break end
            Wait(500)
        end
        if fw == 'auto' then fw = 'standalone' end
    end
    Bridge.framework = fw
    if fw == 'esx' then
        ESX = exports['es_extended']:getSharedObject()
        Config.Accounts.cash = 'money'
    elseif fw == 'qb' then
        QBCore = exports['qb-core']:GetCoreObject()
        Config.Accounts.cash = 'cash'
    elseif fw == 'qbox' then
        Qbox = exports.qbx_core
        Config.Accounts.cash = 'cash'
    end
    Bridge.ready = true
end

function Bridge.hasMoney() return Bridge.framework ~= 'standalone' end

-- Raw framework player object (or nil when the character is not loaded yet)
function Bridge.player(src)
    if Bridge.framework == 'esx' then return ESX.GetPlayerFromId(src) end
    if Bridge.framework == 'qb' then return QBCore.Functions.GetPlayer(src) end
    if Bridge.framework == 'qbox' then return Qbox:GetPlayer(src) end
    return GetPlayerName(src) and { standalone = true } or nil
end

function Bridge.identifier(src)
    local p = Bridge.player(src)
    if not p then return nil end
    if Bridge.framework == 'esx' then return p.identifier end
    if Bridge.framework == 'qb' or Bridge.framework == 'qbox' then return p.PlayerData.citizenid end
    return GetPlayerIdentifierByType(src, 'license')
end

function Bridge.name(src)
    local p = Bridge.player(src)
    if not p then return GetPlayerName(src) or ('Player ' .. tostring(src)) end
    if Bridge.framework == 'esx' then
        local ok, n = pcall(function() return p.getName() end)
        if ok and n and n ~= '' then return n end
    elseif Bridge.framework == 'qb' or Bridge.framework == 'qbox' then
        local ci = p.PlayerData.charinfo
        if ci then return (ci.firstname or '') .. ' ' .. (ci.lastname or '') end
    end
    return GetPlayerName(src) or ('Player ' .. tostring(src))
end

function Bridge.getMoney(src, acct)
    local p = Bridge.player(src)
    if not p then return 0 end
    local a = account(acct)
    if Bridge.framework == 'esx' then
        local acc = p.getAccount(a)
        return acc and acc.money or 0
    elseif Bridge.framework == 'qb' or Bridge.framework == 'qbox' then
        return p.PlayerData.money[a] or 0
    end
    return 0
end

function Bridge.addMoney(src, acct, amount, reason)
    local p = Bridge.player(src)
    if not p or amount <= 0 or not Bridge.hasMoney() then return false end
    local a = account(acct)
    if Bridge.framework == 'esx' then
        p.addAccountMoney(a, amount, reason or 'squads')
        return true
    end
    return p.Functions.AddMoney(a, amount, reason or 'squads') ~= false
end

function Bridge.removeMoney(src, acct, amount, reason)
    local p = Bridge.player(src)
    if not p or amount <= 0 or not Bridge.hasMoney() then return false end
    if Bridge.getMoney(src, acct) < amount then return false end
    local a = account(acct)
    if Bridge.framework == 'esx' then
        p.removeAccountMoney(a, amount, reason or 'squads')
        return true
    end
    return p.Functions.RemoveMoney(a, amount, reason or 'squads') ~= false
end

-- Is this player in one of the framework groups?
function Bridge.inGroup(src, groups)
    if not groups or #groups == 0 then return false end
    if Bridge.framework == 'esx' then
        local p = Bridge.player(src)
        local g = p and p.getGroup and p.getGroup()
        for _, name in ipairs(groups) do if g == name then return true end end
    elseif Bridge.framework == 'qb' then
        for _, name in ipairs(groups) do
            if QBCore.Functions.HasPermission(src, name) then return true end
        end
    end
    for _, name in ipairs(groups) do
        if IsPlayerAceAllowed(src, 'group.' .. name) then return true end
    end
    return false
end

-- Which death sources exist. The rest of the resource listens to all of them.
function Bridge.deathSource()
    if started('wasabi_ambulance') then return 'wasabi_ambulance' end
    if started('esx_ambulancejob') then return 'esx_ambulancejob' end
    if started('qb-ambulancejob') then return 'qb-ambulancejob' end
    if started('qbx_medical') then return 'qbx_medical' end
    return 'built-in (esx:onPlayerDeath / baseevents)'
end

-- ESX
AddEventHandler('esx:onPlayerDeath', function(data)
    local victim = source
    local killer = data and data.killedByPlayer and tonumber(data.killerServerId) or nil
    TriggerEvent('blue_squads:internalDeath', victim, killer)
end)

-- baseevents (QBCore, Qbox and most standalone servers)
AddEventHandler('baseevents:onPlayerKilled', function(killerId)
    TriggerEvent('blue_squads:internalDeath', source, tonumber(killerId))
end)
AddEventHandler('baseevents:onPlayerDied', function()
    TriggerEvent('blue_squads:internalDeath', source, nil)
end)

-- Loaded events
AddEventHandler('esx:playerLoaded', function(playerId)
    TriggerEvent('blue_squads:internalLoaded', playerId)
end)
AddEventHandler('QBCore:Server:PlayerLoaded', function(player)
    local id = player and player.PlayerData and player.PlayerData.source
    if id then TriggerEvent('blue_squads:internalLoaded', id) end
end)
RegisterNetEvent('qbx_core:server:playerLoaded', function()
    TriggerEvent('blue_squads:internalLoaded', source)
end)
