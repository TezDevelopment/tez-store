-- Run your own code when something happens to a squad.
-- Edit freely: nothing else in the resource depends on what you put here.

Hooks = {}

-- squad = { id, name, tag, owner, ... }
function Hooks.onCreate(squad, ownerSrc) end
function Hooks.onEdit(squad, bySrc) end
function Hooks.onJoin(squad, src) end
function Hooks.onLeave(squad, src, identifier) end
function Hooks.onDisband(squad) end
function Hooks.onWarStart(war, squadA, squadB) end
function Hooks.onWarEnd(war, winnerSquad) end   -- winnerSquad is nil on a draw
