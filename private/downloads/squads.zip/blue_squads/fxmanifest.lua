fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'blue_squads'
author 'Tez Development'
description 'Squads, ranks, KOS wars, bounties, squad bank, daily tasks, HUD, pings and an in-game admin panel'
version '2.0.0'

dependencies { 'oxmysql' }

shared_scripts {
    'config.lua',
    'locales/*.lua',
    'shared/shared.lua',
    'shared/schema.lua',
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'bridge/server.lua',
    'bridge/hooks.lua',
    'server/util.lua',
    'server/db.lua',
    'server/settings.lua',
    'server/squads.lua',
    'server/systems.lua',
    'server/admin.lua',
    'server/main.lua',
}

client_scripts {
    'bridge/client.lua',
    'client/main.lua',
    'client/world.lua',
    'client/pings.lua',
    'client/extras.lua',
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/core.js',
    'html/overlays.js',
    'html/menu.js',
    'html/pages.js',
    'html/pages2.js',
    'html/admin.js',
}

provide 'blue_squads_api'
