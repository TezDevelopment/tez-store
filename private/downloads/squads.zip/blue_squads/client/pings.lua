-- Pings: tap = ping what you aim at, double tap = mark an enemy, hold = ping wheel

local pings = {}           -- id -> ping
local wheelOpen = false
local pressed = false
local pressAt = 0
local lastTap = 0
local tapToken = 0

local function pingType(id)
    for _, t in ipairs(PingTypes) do if t.id == id then return t end end
    return PingTypes[1]
end

local function prefs() return (C.me and C.me.prefs) or {} end

-- ------------------------------------------------------------------ aiming

local function rotToDir(rot)
    local z, x = math.rad(rot.z), math.rad(rot.x)
    local c = math.abs(math.cos(x))
    return vector3(-math.sin(z) * c, math.cos(z) * c, math.sin(x))
end

-- returns coords, entity (or nil when the player aims at nothing)
local function aim()
    local range = math.min((C.settings and C.settings.pingRange) or 600.0, 800.0)
    local cam = GetGameplayCamCoord()
    local dir = rotToDir(GetGameplayCamRot(2))
    local dest = cam + dir * range
    local handle = StartExpensiveSynchronousShapeTestLosProbe(cam.x, cam.y, cam.z, dest.x, dest.y, dest.z, -1, PlayerPedId(), 7)
    local _, hit, coords, _, entity = GetShapeTestResult(handle)
    if hit ~= 1 then return nil end
    if entity and entity ~= 0 and not DoesEntityExist(entity) then entity = nil end
    return coords, entity
end

local function inMySquad(ped)
    if not C.squad or not IsPedAPlayer(ped) then return false end
    local srv = GetPlayerServerId(NetworkGetPlayerIndexFromPed(ped))
    for _, m in ipairs(C.squad.members) do if m.src == srv then return true end end
    return false
end

-- choose the ping that fits what the player is looking at
local function autoType(entity)
    if not entity then return 'go' end
    if IsEntityAVehicle(entity) then
        for seat = -1, 6 do
            local ped = GetPedInVehicleSeat(entity, seat)
            if ped ~= 0 and IsPedAPlayer(ped) and not inMySquad(ped) then return 'enemyveh' end
        end
        return 'vehicle'
    elseif IsEntityAPed(entity) then
        if inMySquad(entity) then return 'go' end
        return 'enemy'
    elseif IsEntityAnObject(entity) then
        return 'loot'
    end
    return 'go'
end

local function sendPing(kind)
    if not C.squad then return end
    local coords, entity = aim()
    if not coords then return C.toast(L('err.aimatsomething'), 'error') end
    kind = kind or autoType(entity)
    local net = 0
    if entity and NetworkGetEntityIsNetworked(entity) then net = NetworkGetNetworkIdFromEntity(entity) end
    TriggerServerEvent('squads:ping', { type = kind, x = coords.x, y = coords.y, z = coords.z, net = net })
end

-- ------------------------------------------------------------------ the key

local function closeWheel(pick)
    if not wheelOpen then return end
    wheelOpen = false
    C.nui('wheel', { open = false, pick = pick })
end

RegisterCommand('+squadping', function()
    if not C.ready or not C.squad or C.menuOpen or C.focusMode == 'chat' or C.focusMode == 'hud' then return end
    pressed = true
    pressAt = GetGameTimer()
    CreateThread(function()
        Wait(280)
        if pressed and not wheelOpen then
            wheelOpen = true
            C.focus('wheel')
            C.nui('wheel', { open = true, types = PingTypes })
        end
    end)
end, false)

RegisterCommand('-squadping', function()
    if not pressed then return end
    pressed = false
    if wheelOpen then
        closeWheel(true)   -- the menu answers with the highlighted ping through 'pingChoose'
        return
    end
    local now = GetGameTimer()
    if now - lastTap < 350 then
        lastTap = 0
        tapToken = tapToken + 1
        sendPing('enemy')
    else
        lastTap = now
        tapToken = tapToken + 1
        local token = tapToken
        CreateThread(function()
            Wait(260)
            if token == tapToken and lastTap ~= 0 then
                lastTap = 0
                sendPing(nil)
            end
        end)
    end
end, false)

RegisterNUICallback('pingChoose', function(d, cb)
    C.focus(nil)
    if d and d.id then sendPing(d.id) end
    cb({})
end)

-- the camera must not move while the wheel is open
CreateThread(function()
    while true do
        if wheelOpen then
            DisableControlAction(0, 1, true)
            DisableControlAction(0, 2, true)
            DisableControlAction(0, 24, true)
            DisableControlAction(0, 25, true)
            DisableControlAction(0, 142, true)
            Wait(0)
        else
            Wait(250)
        end
    end
end)

-- ------------------------------------------------------------- receiving

local function removePing(id)
    local p = pings[id]
    if p and p.blip and DoesBlipExist(p.blip) then RemoveBlip(p.blip) end
    pings[id] = nil
end

RegisterNetEvent('squads:ping', function(d)
    local t = pingType(d.type)
    local p = { d = d, t = t, expires = GetGameTimer() + d.dur * 1000, reacts = {} }
    local blip = AddBlipForCoord(d.x + 0.0, d.y + 0.0, d.z + 0.0)
    SetBlipSprite(blip, 1)
    SetBlipColour(blip, 3)
    SetBlipScale(blip, 0.8)
    PulseBlip(blip)
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentSubstringPlayerName(d.name .. ': ' .. t.label)
    EndTextCommandSetBlipName(blip)
    p.blip = blip
    if pings[d.id] then removePing(d.id) end
    pings[d.id] = p
    if prefs().pingAlerts ~= false then
        PlaySoundFrontend(-1, 'WAYPOINT_SET', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true)
    end
end)

RegisterNetEvent('squads:pingReact', function(d)
    local p = pings[d.id]
    if not p then return end
    p.reacts[#p.reacts + 1] = d.name .. (d.kind == 'dibs' and (' ' .. L('hud.dibs')) or (' ' .. L('hud.ack')))
    if prefs().pingAlerts ~= false then
        C.toast(d.name .. ' ' .. (d.kind == 'dibs' and L('hud.dibs') or L('hud.ack')), 'info')
    end
end)

local function latestOtherPing()
    local me = GetPlayerServerId(PlayerId())
    local best
    for id, p in pairs(pings) do
        if p.d.from ~= me and (not best or id > best) then best = id end
    end
    return best
end

local function react(kind)
    if not C.squad then return end
    local id = latestOtherPing()
    if not id then return end
    TriggerServerEvent('squads:pingReact', { id = id, kind = kind })
end

RegisterCommand('squadack', function() react('ack') end, false)
RegisterCommand('squaddibs', function() react('dibs') end, false)

-- ------------------------------------------------------------- drawing

CreateThread(function()
    RequestStreamedTextureDict('commonmenu', true)
    while true do
        local any = next(pings) ~= nil
        if not any then
            Wait(300)
        else
            Wait(0)
            local now = GetGameTimer()
            local myPos = GetEntityCoords(PlayerPedId())
            local cam = GetGameplayCamCoord()
            local camYaw = GetGameplayCamRot(2).z
            for id, p in pairs(pings) do
                if p.expires <= now then
                    removePing(id)
                else
                    local d = p.d
                    local x, y, z = d.x, d.y, d.z
                    if d.net and d.net > 0 and NetworkDoesNetworkIdExist(d.net) then
                        local ent = NetworkGetEntityFromNetworkId(d.net)
                        if ent and ent ~= 0 and DoesEntityExist(ent) then
                            local c = GetEntityCoords(ent)
                            x, y, z = c.x, c.y, c.z
                            SetBlipCoords(p.blip, x, y, z)
                        end
                    end
                    local r, g, b = p.t.color[1], p.t.color[2], p.t.color[3]
                    local dist = #(myPos - vector3(x, y, z))
                    local fade = math.min(255, math.floor((p.expires - now) / 1000 * 120))
                    local on, sx, sy = World3dToScreen2d(x, y, z + 1.0)
                    if on then
                        DrawMarker(2, x, y, z + 1.2, 0.0, 0.0, 0.0, 180.0, 0.0, 0.0, 0.35, 0.35, 0.35, r, g, b, math.max(60, fade), false, true, 2, false, nil, nil, false)
                        local label = p.t.label .. '  ~w~' .. math.floor(dist) .. 'm'
                        if #p.reacts > 0 then label = label .. '\n~w~' .. table.concat(p.reacts, ', ') end
                        SetTextScale(0.0, 0.32)
                        SetTextFont(4)
                        SetTextColour(r, g, b, 240)
                        SetTextOutline()
                        SetTextCentre(true)
                        BeginTextCommandDisplayText('STRING')
                        AddTextComponentSubstringPlayerName(d.name .. ': ' .. label)
                        EndTextCommandDisplayText(sx, sy - 0.035)
                    else
                        -- off screen: an arrow on a circle around the middle of the screen
                        local dx, dy = x - cam.x, y - cam.y
                        local worldAngle = math.deg(math.atan(-dx, dy))       -- 0 = north
                        local rel = math.rad(worldAngle - camYaw)
                        local ar = GetAspectRatio(false)
                        local px, py = 0.5 + math.sin(rel) * 0.32 / ar * 1.5, 0.5 - math.cos(rel) * 0.32
                        DrawSprite('commonmenu', 'arrowright', px, py, 0.014 / ar * 1.6, 0.025, math.deg(rel) - 90.0, r, g, b, 230)
                    end
                end
            end
        end
    end
end)

AddEventHandler('onResourceStop', function(name)
    if name ~= GetCurrentResourceName() then return end
    for id in pairs(pings) do removePing(id) end
end)

RegisterNetEvent('squads:left', function()
    for id in pairs(pings) do removePing(id) end
end)
