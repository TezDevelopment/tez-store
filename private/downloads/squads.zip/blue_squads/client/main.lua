-- Client core: state, requests to the server, the menu and the NUI bridge

C = {
    ready = false,
    settings = nil,   -- public settings from the admin panel
    me = nil,         -- { id, name, src, xp, level, prefs, isAdmin, canUse, money }
    squad = nil,      -- full squad view (nil when not in a squad)
    live = {},        -- teammates' live data
    menuOpen = false,
    focusMode = nil,  -- 'menu', 'chat', 'wheel', 'hud'
}

-- ------------------------------------------------------------------ requests

local pending, nextRid = {}, 0

function C.req(action, data)
    nextRid = nextRid + 1
    local rid = nextRid
    local p = promise.new()
    pending[rid] = p
    TriggerServerEvent('squads:req', rid, action, data or {})
    SetTimeout(8000, function()
        if pending[rid] then
            pending[rid] = nil
            p:resolve({ ok = false, payload = 'The server did not answer. Try again.' })
        end
    end)
    return Citizen.Await(p)
end

RegisterNetEvent('squads:res', function(rid, ok, payload)
    local p = pending[rid]
    if p then
        pending[rid] = nil
        p:resolve({ ok = ok, payload = payload })
    end
end)

-- -------------------------------------------------------------------- NUI

function C.nui(a, data)
    data = data or {}
    data.a = a
    SendNUIMessage(data)
end

function C.toast(message, kind)
    C.nui('toast', { message = message, kind = kind or 'info' })
end

RegisterNetEvent('squads:toast', function(message, kind) C.toast(message, kind) end)

-- focus handling: one place decides what the NUI is allowed to capture
function C.focus(mode)
    C.focusMode = mode
    if mode == 'menu' or mode == 'hud' then
        SetNuiFocus(true, true)
        SetNuiFocusKeepInput(false)
    elseif mode == 'chat' then
        SetNuiFocus(true, false)
        SetNuiFocusKeepInput(false)
    elseif mode == 'wheel' then
        SetNuiFocus(true, true)
        SetNuiFocusKeepInput(true)
    else
        SetNuiFocus(false, false)
        SetNuiFocusKeepInput(false)
    end
end

function C.openMenu(page)
    if not C.ready then return end
    if C.menuOpen then return end
    if not C.me.canUse then return C.toast(L('err.noaccess'), 'error') end
    C.menuOpen = true
    C.focus('menu')
    C.nui('menu', { open = true, page = page })
end

function C.closeMenu()
    if not C.menuOpen and C.focusMode ~= 'hud' then return end
    C.menuOpen = false
    C.focus(nil)
    C.nui('menu', { open = false })
end

-- ------------------------------------------------------------------ events

RegisterNetEvent('squads:init', function(payload)
    C.settings = payload.settings
    C.me = payload.me
    C.squad = payload.squad
    C.ready = true
    C.registerKeys()
    C.nui('init', payload)
    C.applySquad()
end)

RegisterNetEvent('squads:settings', function(settings)
    C.settings = settings
    C.nui('settings', { settings = settings })
end)

RegisterNetEvent('squads:squad', function(view)
    C.squad = view
    C.nui('squad', { squad = view })
    C.applySquad()
end)

RegisterNetEvent('squads:left', function(how)
    C.squad = nil
    C.live = {}
    C.nui('squad', { squad = nil })
    C.nui('live', { list = {} })
    C.applySquad()
end)

RegisterNetEvent('squads:live', function(list)
    C.live = list
    C.nui('live', { list = list })
end)

RegisterNetEvent('squads:chat', function(entry)
    C.nui('chat', { entry = entry })
end)

RegisterNetEvent('squads:invite', function(invite)
    C.nui('invite', { invite = invite })
    PlaySoundFrontend(-1, 'NAV_UP_DOWN', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true)
end)

RegisterNetEvent('squads:warScore', function(score)
    if C.squad and C.squad.war and C.squad.war.id == score.id then
        C.squad.war.ka, C.squad.war.kb = score.ka, score.kb
    end
    C.nui('warScore', { score = score })
end)

RegisterNetEvent('squads:warEnd', function(result)
    C.nui('warEnd', { result = result })
    PlaySoundFrontend(-1, 'CHECKPOINT_PERFECT', 'HUD_MINI_GAME_SOUNDSET', true)
end)

-- called whenever the squad changes
function C.applySquad()
    C.setRadio()
    if C.refreshBlips then C.refreshBlips() end
end

-- --------------------------------------------------------------------- radio

local lastChannel = 0

function C.setRadio()
    local want = 0
    if C.squad and C.settings and C.settings.radioEnabled then want = C.squad.radioChannel or 0 end
    if want ~= lastChannel then
        lastChannel = want
        if GetResourceState('pma-voice') == 'started' then
            pcall(function()
                exports['pma-voice']:setRadioChannel(want)
                if want > 0 then exports['pma-voice']:setVoiceProperty('radioEnabled', true) end
            end)
        end
        TriggerEvent('blue_squads:radioChanged', want)
    end
end

-- ----------------------------------------------------------------- NUI calls

RegisterNUICallback('close', function(_, cb)
    C.closeMenu()
    cb({})
end)

RegisterNUICallback('req', function(d, cb)
    if type(d) ~= 'table' or type(d.action) ~= 'string' then return cb({ ok = false, payload = 'Bad request' }) end
    cb(C.req(d.action, d.data))
end)

RegisterNUICallback('waypoint', function(d, cb)
    for _, m in ipairs(C.live) do
        if m.s == d.src then
            SetNewWaypoint(m.x + 0.0, m.y + 0.0)
            C.toast(L('note.waypoint'), 'success')
        end
    end
    cb({})
end)

RegisterNUICallback('waypointRally', function(_, cb)
    if C.squad and C.squad.rally then
        SetNewWaypoint(C.squad.rally.x + 0.0, C.squad.rally.y + 0.0)
        C.toast(L('note.waypoint'), 'success')
    end
    cb({})
end)

RegisterNUICallback('rallyWaypoint', function(_, cb)
    local blip = GetFirstBlipInfoId(8)
    if not DoesBlipExist(blip) then
        C.toast(L('err.nowaypoint'), 'error')
        return cb({ ok = false })
    end
    local c = GetBlipInfoIdCoord(blip)
    local found, z = GetGroundZFor_3dCoord(c.x, c.y, 1000.0, false)
    cb(C.req('rally', { x = c.x, y = c.y, z = found and z or c.z }))
end)

RegisterNUICallback('hudMode', function(d, cb)
    -- 'edit' lets the player drag/resize the HUD, 'click' lets them click teammates
    if d.on then
        C.menuOpen = false
        C.focus('hud')
    else
        C.focus(nil)
    end
    cb({})
end)

RegisterNUICallback('chatClose', function(_, cb)
    C.focus(nil)
    cb({})
end)

RegisterNUICallback('chatSend', function(d, cb)
    C.focus(nil)
    if type(d.msg) == 'string' and d.msg ~= '' then
        local res = C.req('chat', { msg = d.msg })
        if not res.ok then C.toast(res.payload, 'error') end
    end
    cb({})
end)

RegisterNUICallback('prefs', function(d, cb)
    if C.me and type(d) == 'table' then
        for k, v in pairs(d) do C.me.prefs[k] = v end
    end
    cb({})
end)

-- ---------------------------------------------------------- commands and keys

local keysRegistered = false

function C.keyType(key)
    return tostring(key):find('^MOUSE_') and 'MOUSE_BUTTON' or 'keyboard'
end

function C.registerKeys()
    if keysRegistered then return end
    keysRegistered = true
    local menuKey = (C.settings and C.settings.menuKey ~= '' and C.settings.menuKey) or Config.Keys.menu
    RegisterKeyMapping('squads', 'Squads: open menu', 'keyboard', menuKey)
    RegisterKeyMapping('squadchat', 'Squads: quick chat', 'keyboard', Config.Keys.quickChat)
    RegisterKeyMapping('squadinvite', 'Squads: invite the player you aim at', 'keyboard', Config.Keys.invite)
    RegisterKeyMapping('squadaccept', 'Squads: accept invite', 'keyboard', Config.Keys.accept)
    RegisterKeyMapping('squaddecline', 'Squads: decline invite', 'keyboard', Config.Keys.decline)
    RegisterKeyMapping('+squadping', 'Squads: ping (tap, double tap, hold)', C.keyType(Config.Keys.ping), Config.Keys.ping)
    RegisterKeyMapping('+squadfar', 'Squads: far nametags (hold)', C.keyType(Config.Keys.farTags), Config.Keys.farTags)
    RegisterKeyMapping('squadack', 'Squads: acknowledge latest ping', 'keyboard', Config.Keys.pingAck)
    RegisterKeyMapping('squaddibs', 'Squads: call dibs on latest ping', 'keyboard', Config.Keys.pingDibs)
end

RegisterCommand('squads', function()
    if C.menuOpen then C.closeMenu() else C.openMenu() end
end, false)

RegisterCommand('squadchat', function()
    if not C.ready or C.menuOpen or C.focusMode then return end
    if not C.squad then return C.toast(L('err.nosquad'), 'error') end
    if not C.settings.chatEnabled or not C.settings.quickChatEnabled then return end
    C.focus('chat')
    C.nui('quickchat', {})
end, false)

RegisterCommand('sqc', function(_, args, raw)
    if not C.ready then return end
    local msg = raw:gsub('^%S+%s*', '')
    if msg == '' then return end
    local res = C.req('chat', { msg = msg })
    if not res.ok then C.toast(res.payload, 'error') end
end, false)

RegisterCommand('squadaccept', function()
    if not C.ready then return end
    local res = C.req('inviteAnswer', { accept = true })
    C.nui('inviteDone', {})
    if not res.ok then C.toast(res.payload, 'error') end
end, false)

RegisterCommand('squaddecline', function()
    if not C.ready then return end
    C.req('inviteAnswer', { accept = false })
    C.nui('inviteDone', {})
end, false)

RegisterCommand('squadhud', function()
    if not C.ready or not C.squad then return end
    if C.focusMode == 'hud' then
        C.focus(nil)
        C.nui('hudMode', { click = false })
    else
        C.focus('hud')
        C.nui('hudMode', { click = true })
    end
end, false)

RegisterCommand('squadradar', function()
    if not C.ready then return end
    local on = not (C.me.prefs.radar ~= false)
    C.me.prefs.radar = on
    C.req('settingsSave', { radar = on })
    C.nui('prefs', { prefs = C.me.prefs })
end, false)

RegisterCommand('squadsadmin', function()
    if not C.ready then return end
    if not C.me.isAdmin then return C.toast(L('err.noperm'), 'error') end
    if C.menuOpen then return end
    C.menuOpen = true
    C.focus('menu')
    C.nui('menu', { open = true, page = 'admin' })
end, false)

-- ---------------------------------------------------------------- status loop

CreateThread(function()
    Bridge.waitLoaded()
    Wait(1500)
    TriggerServerEvent('squads:ready')

    local lastTalk, lastDown, lastSent = false, false, 0
    while true do
        Wait(400)
        if C.squad then
            local talk = (LocalPlayer.state.radioActive == true) or NetworkIsPlayerTalking(PlayerId())
            local down = Bridge.isDead()
            local t = GetGameTimer()
            if talk ~= lastTalk or down ~= lastDown or t - lastSent > 4000 then
                lastTalk, lastDown, lastSent = talk, down, t
                TriggerServerEvent('squads:status', { talk = talk, down = down })
            end
        end
    end
end)

AddEventHandler('onResourceStop', function(name)
    if name ~= GetCurrentResourceName() then return end
    SetNuiFocus(false, false)
end)
