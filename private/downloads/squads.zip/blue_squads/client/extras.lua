-- Inviting by aiming (J) or with ox_target / qb-target, and the leaders radio

local function can(perm)
    return C.squad ~= nil and C.squad.me and C.squad.me.perms and C.squad.me.perms[perm] == true
end

local function invite(serverId)
    if not serverId or serverId <= 0 then return C.toast(L('err.noplayer'), 'error') end
    local res = C.req('invite', { target = serverId })
    if not res.ok then C.toast(res.payload, 'error') end
end

-- the player closest to the middle of the screen, within 15 metres
local function aimedPlayer()
    local me = PlayerId()
    local myPos = GetEntityCoords(PlayerPedId())
    local camRot = GetGameplayCamRot(2)
    local z = math.rad(camRot.z)
    local fx, fy = -math.sin(z), math.cos(z)
    local best, bestScore
    for _, player in ipairs(GetActivePlayers()) do
        if player ~= me then
            local ped = GetPlayerPed(player)
            local pos = GetEntityCoords(ped)
            local dx, dy = pos.x - myPos.x, pos.y - myPos.y
            local dist = math.sqrt(dx * dx + dy * dy)
            if dist > 0.01 and dist <= 15.0 then
                local dot = (dx * fx + dy * fy) / dist
                if dot > 0.85 and (not bestScore or dot - dist * 0.01 > bestScore) then
                    best, bestScore = player, dot - dist * 0.01
                end
            end
        end
    end
    return best and GetPlayerServerId(best) or nil
end

RegisterCommand('squadinvite', function()
    if not C.ready then return end
    if not C.settings.targetInvite then return end
    if not C.squad then return C.toast(L('err.nosquad'), 'error') end
    if not can('invite') then return C.toast(L('err.noperm'), 'error') end
    local target = aimedPlayer()
    if not target then return C.toast(L('err.noaimedplayer'), 'error') end
    invite(target)
end, false)

-- ----------------------------------------------------------------- targeting

CreateThread(function()
    while not C.ready do Wait(1000) end
    if not C.settings.useTargetResource then return end

    if GetResourceState('ox_target') == 'started' then
        pcall(function()
            exports.ox_target:addGlobalPlayer({
                {
                    name = 'blue_squads_invite',
                    icon = 'fa-solid fa-user-plus',
                    label = L('target.invite'),
                    distance = 3.0,
                    canInteract = function(entity)
                        return can('invite') and IsPedAPlayer(entity)
                    end,
                    onSelect = function(data)
                        invite(GetPlayerServerId(NetworkGetPlayerIndexFromPed(data.entity)))
                    end,
                },
            })
        end)
    elseif GetResourceState('qb-target') == 'started' then
        pcall(function()
            exports['qb-target']:AddGlobalPlayer({
                options = {
                    {
                        type = 'client',
                        icon = 'fas fa-user-plus',
                        label = L('target.invite'),
                        canInteract = function(entity) return can('invite') and IsPedAPlayer(entity) end,
                        action = function(entity)
                            invite(GetPlayerServerId(NetworkGetPlayerIndexFromPed(entity)))
                        end,
                    },
                },
                distance = 3.0,
            })
        end)
    end
end)

-- ------------------------------------------------------------ leaders radio

local onLeaders = false

RegisterCommand('squadleaders', function()
    if not C.ready or not C.squad then return C.toast(L('err.nosquad'), 'error') end
    if not C.settings.leaderVoice or not C.settings.radioEnabled then return C.toast(L('err.disabled'), 'error') end
    if not C.squad.me.isOwner then return C.toast(L('err.owneronly'), 'error') end
    if GetResourceState('pma-voice') ~= 'started' then return C.toast(L('err.noradio'), 'error') end
    onLeaders = not onLeaders
    local channel = onLeaders and C.settings.leadersChannel or (C.squad.radioChannel or 0)
    pcall(function() exports['pma-voice']:setRadioChannel(channel) end)
    TriggerEvent('blue_squads:radioChanged', channel)
    C.toast(onLeaders and L('note.leadersjoin') or L('note.leadersleave'), 'info')
end, false)

RegisterNetEvent('squads:left', function() onLeaders = false end)

-- other radio scripts can read the channel with this export
exports('GetSquadChannel', function()
    return C.squad and C.squad.radioChannel or 0
end)
