-- In-world parts: nametags, map blips, mini radar, rally point, orders and the UAV

local blips = {}
local farHeld = false
local uavBlips = {}
local rallyBlip, rallyRadius, rallyKey

local function prefs() return (C.me and C.me.prefs) or {} end
local function setting(k) return C.settings and C.settings[k] end

local function memberBySrc(src)
    if not C.squad then return nil end
    for _, m in ipairs(C.squad.members) do
        if m.src == src then return m end
    end
end

local function nearestBlipColour(hex)
    local r, g, b = hexToRgb(hex)
    local best, bestD = 3, 1e9
    for _, c in ipairs(Config.BlipPalette) do
        local d = (c.rgb[1] - r) ^ 2 + (c.rgb[2] - g) ^ 2 + (c.rgb[3] - b) ^ 2
        if d < bestD then best, bestD = c.id, d end
    end
    return best
end

local function myServerId() return GetPlayerServerId(PlayerId()) end

-- ------------------------------------------------------------------ blips

local function clearBlips()
    for src, blip in pairs(blips) do
        if DoesBlipExist(blip) then RemoveBlip(blip) end
        blips[src] = nil
    end
end

local function updateBlips(list)
    if not C.squad or not setting('blipsEnabled') or prefs().blips == false then
        clearBlips()
        return
    end
    local me = myServerId()
    local seen = {}
    local colourHex = (prefs().blipColor and prefs().blipColor ~= '') and prefs().blipColor or C.squad.color
    local colour = nearestBlipColour(colourHex)

    for _, m in ipairs(list) do
        if m.s ~= me then
            seen[m.s] = true
            local blip = blips[m.s]
            if not blip or not DoesBlipExist(blip) then
                blip = AddBlipForCoord(m.x + 0.0, m.y + 0.0, m.z + 0.0)
                blips[m.s] = blip
                SetBlipAsShortRange(blip, false)
                SetBlipScale(blip, 0.85)
                ShowHeadingIndicatorOnBlip(blip, true)
            end
            SetBlipCoords(blip, m.x + 0.0, m.y + 0.0, m.z + 0.0)
            SetBlipSprite(blip, m.v and 225 or 1)
            SetBlipRotation(blip, math.ceil(m.r + 0.0))
            SetBlipColour(blip, m.d and 1 or colour)
            SetBlipFlashes(blip, m.d == true)
            local info = memberBySrc(m.s)
            local label = info and info.name or ('ID ' .. m.s)
            if m.d then label = label .. ' (' .. L('hud.down') .. ')'
            elseif m.v then label = label .. ' (' .. L('hud.vehicle') .. ')' end
            BeginTextCommandSetBlipName('STRING')
            AddTextComponentSubstringPlayerName(label)
            EndTextCommandSetBlipName(blip)
        end
    end
    for src, blip in pairs(blips) do
        if not seen[src] then
            if DoesBlipExist(blip) then RemoveBlip(blip) end
            blips[src] = nil
        end
    end
end

function C.refreshBlips()
    if not C.squad then clearBlips() end
    updateBlips(C.live or {})
end

RegisterNetEvent('squads:live', function(list) updateBlips(list) end)

-- ------------------------------------------------------------------ nametags

RegisterCommand('+squadfar', function() farHeld = true end, false)
RegisterCommand('-squadfar', function() farHeld = false end, false)

local function draw3d(x, y, z, text, scale, r, g, b)
    local on, sx, sy = World3dToScreen2d(x, y, z)
    if not on then return end
    SetTextScale(0.0, scale)
    SetTextFont(4)
    SetTextProportional(true)
    SetTextColour(r, g, b, 235)
    SetTextOutline()
    SetTextCentre(true)
    BeginTextCommandDisplayText('STRING')
    AddTextComponentSubstringPlayerName(text)
    EndTextCommandDisplayText(sx, sy)
end

CreateThread(function()
    while true do
        if C.squad and #C.live > 1 and prefs().tags ~= false then
            local me = myServerId()
            local myPos = GetEntityCoords(PlayerPedId())
            local limit = (setting('tagDistance') or 50.0) * (farHeld and (setting('tagFarMultiplier') or 2.0) or 1.0)
            local r, g, b = hexToRgb(C.squad.color)
            for _, m in ipairs(C.live) do
                if m.s ~= me then
                    local player = GetPlayerFromServerId(m.s)
                    if player ~= -1 then
                        local ped = GetPlayerPed(player)
                        if DoesEntityExist(ped) then
                            local pos = GetEntityCoords(ped)
                            local dist = #(myPos - pos)
                            if dist <= limit then
                                local info = memberBySrc(m.s)
                                local text = (C.squad.tag ~= '' and ('[' .. C.squad.tag .. '] ') or '') .. (info and info.name or '?')
                                if prefs().tagIds ~= false then text = text .. ' ~w~#' .. m.s end
                                if prefs().tagHealth ~= false then text = text .. ' ~w~' .. m.h .. '%' end
                                if m.d then text = text .. ' ~r~' .. L('hud.down') end
                                local scale = 0.32 - math.min(dist / limit, 1.0) * 0.1
                                draw3d(pos.x, pos.y, pos.z + 1.05, text, scale, r, g, b)
                            end
                        end
                    end
                end
            end
            Wait(0)
        else
            Wait(500)
        end
    end
end)

-- ------------------------------------------------------------------ radar

CreateThread(function()
    local wasOn = false
    while true do
        Wait(200)
        local on = C.squad and #C.live > 1 and setting('radarEnabled') and prefs().radar ~= false
        if on then
            wasOn = true
            local me = myServerId()
            local pos = GetEntityCoords(PlayerPedId())
            local yaw = math.rad(GetGameplayCamRot(2).z)
            local rx, ry = math.cos(yaw), math.sin(yaw)       -- right vector
            local fx, fy = -math.sin(yaw), math.cos(yaw)      -- forward vector
            local range = setting('radarRange') or 80.0
            local dots = {}
            for _, m in ipairs(C.live) do
                if m.s ~= me then
                    local dx, dy = m.x - pos.x, m.y - pos.y
                    local u, v = dx * rx + dy * ry, dx * fx + dy * fy
                    local dist = math.sqrt(u * u + v * v)
                    if dist <= range then
                        dots[#dots + 1] = { x = u / range, y = -v / range, d = m.d }
                    end
                end
            end
            C.nui('radar', { on = true, dots = dots })
        elseif wasOn then
            wasOn = false
            C.nui('radar', { on = false })
        end
    end
end)

-- ------------------------------------------------------------ rally and orders

local function clearRally()
    if rallyBlip and DoesBlipExist(rallyBlip) then RemoveBlip(rallyBlip) end
    if rallyRadius and DoesBlipExist(rallyRadius) then RemoveBlip(rallyRadius) end
    rallyBlip, rallyRadius, rallyKey = nil, nil, nil
end

local function syncRally()
    if not C.squad or not C.squad.rally or not setting('rallyEnabled') then return clearRally() end
    local r = C.squad.rally
    local key = ('%s:%s:%s:%s'):format(r.x, r.y, r.z, C.squad.color)
    if key == rallyKey then return end
    clearRally()
    rallyKey = key
    rallyBlip = AddBlipForCoord(r.x + 0.0, r.y + 0.0, r.z + 0.0)
    SetBlipSprite(rallyBlip, 38)
    SetBlipColour(rallyBlip, nearestBlipColour(C.squad.color))
    SetBlipScale(rallyBlip, 0.9)
    SetBlipAsShortRange(rallyBlip, false)
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentSubstringPlayerName(L('hud.rally'))
    EndTextCommandSetBlipName(rallyBlip)
end

RegisterNetEvent('squads:squad', function() syncRally() end)
RegisterNetEvent('squads:left', function() clearRally() end)

CreateThread(function()
    while true do
        if C.squad and C.squad.rally and setting('rallyEnabled') then
            local r = C.squad.rally
            local cr, cg, cb = hexToRgb(C.squad.color)
            local order = C.squad.order
            local radius = (setting('orderRadius') or 15.0)
            if order then
                DrawMarker(1, r.x + 0.0, r.y + 0.0, r.z - 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, radius * 2.0, radius * 2.0, 1.2,
                    cr, cg, cb, 90, false, false, 2, false, nil, nil, false)
            end
            DrawMarker(1, r.x + 0.0, r.y + 0.0, r.z - 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.2, 1.2, 40.0,
                cr, cg, cb, 70, false, false, 2, false, nil, nil, false)
            local myPos = GetEntityCoords(PlayerPedId())
            local dist = #(myPos - vector3(r.x, r.y, r.z))
            if dist < 250.0 then
                draw3d(r.x, r.y, r.z + 1.2, (order and (L('hud.order') .. ' ') or '') .. L('hud.rally') .. ' ~w~' .. math.floor(dist) .. 'm', 0.34, cr, cg, cb)
            end
            Wait(0)
        else
            Wait(800)
        end
    end
end)

-- ---------------------------------------------------------------------- UAV

local function clearUav()
    for i, blip in ipairs(uavBlips) do
        if DoesBlipExist(blip) then RemoveBlip(blip) end
        uavBlips[i] = nil
    end
end

RegisterNetEvent('squads:uav', function(points)
    clearUav()
    for _, p in ipairs(points) do
        local blip = AddBlipForCoord(p.x + 0.0, p.y + 0.0, p.z + 0.0)
        SetBlipSprite(blip, 1)
        SetBlipColour(blip, 1)
        SetBlipScale(blip, 1.0)
        SetBlipFlashes(blip, true)
        BeginTextCommandSetBlipName('STRING')
        AddTextComponentSubstringPlayerName(L('hud.enemy') .. ' ' .. (p.name or ''))
        EndTextCommandSetBlipName(blip)
        uavBlips[#uavBlips + 1] = blip
    end
end)

RegisterNetEvent('squads:armor', function(amount)
    local ped = PlayerPedId()
    SetPedArmour(ped, math.min(100, math.max(GetPedArmour(ped), tonumber(amount) or 100)))
    PlaySoundFrontend(-1, 'PICK_UP', 'HUD_FRONTEND_DEFAULT_SOUNDSET', true)
end)

AddEventHandler('onResourceStop', function(name)
    if name ~= GetCurrentResourceName() then return end
    clearBlips()
    clearRally()
    clearUav()
end)
