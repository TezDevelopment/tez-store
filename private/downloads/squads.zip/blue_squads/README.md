# blue_squads 2.0 (Tez Development)

An original squads system for FiveM. Works with ESX, QBCore, Qbox or standalone.

## Install

1. Make sure **oxmysql** is installed and started.
2. Put the `blue_squads` folder in `resources`. If the old version is there, delete it first.
3. In `server.cfg`, after oxmysql and your framework (and pma-voice if you use it):
   ```
   ensure blue_squads
   ```
4. Restart the server. All database tables are created automatically.
5. Give yourself admin: either be in an admin group (admin, god, superadmin, owner by default) or add
   `add_ace group.admin squads.admin allow` to server.cfg. Then type **/squadsadmin** in game.

## Keys (all rebindable in FiveM key bindings)

| Action | Default |
| --- | --- |
| Open menu | F9 or /squads |
| Quick chat | Y (or /sqc message) |
| Invite the player you aim at | J |
| Ping | Middle mouse: tap = ping, double tap = enemy, hold = ping wheel |
| Far nametags | Side mouse button (hold) |
| Acknowledge / dibs on a ping | [ and ] |
| Accept / decline invite | Page Up / Page Down |
| Click teammates in the HUD to set a waypoint | /squadhud |
| Toggle mini radar | /squadradar |
| Leaders radio (owners) | /squadleaders |

If a key does nothing, rebind it in Settings > Key Bindings > FiveM.

## Everything is changed in game

Open **/squadsadmin**. Every setting is there, saves instantly and needs no restart. `config.lua` only
holds default key names and the language.

## Optional

- Voice radio: needs pma-voice. Each squad gets its own channel.
- Logs: put a Discord webhook or Fivemanage key into the admin panel (Logs page) and press the test button.
- Discord roles for admin / access: add a bot token and server ID in the admin panel (Permissions page).
- Other scripts can hook in through `bridge/hooks.lua` and the exports `GetSquadOf`, `GetSquadRadioChannel` (server) and `GetSquadChannel` (client).
- Language: copy `locales/en.lua` to a new file, translate, and set `Config.Locale`.

## Notes

- Money features (bank, bounties, fees, rewards) need ESX, QBCore or Qbox. On standalone they are switched off.
- Kills are checked against real damage events (OneSync required). If kills never count on your server, turn off "Check kills against real damage" in the World page.
