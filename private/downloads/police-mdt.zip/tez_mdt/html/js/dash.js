// Dashboard, dispatch / CAD, live map, notifications
(function () {
  var M = window.M, $ = M.$, esc = M.esc;

  function statusOf(id) { var l = M.S.cfg.statuses; for (var i = 0; i < l.length; i++) if (l[i].id === id) return l[i]; return { id: id, label: id, code: '' }; }
  M.statusChip = function (id) { var s = statusOf(id); return M.chip(id, s.label + (s.code ? ' ' + s.code : '')); };
  function elapsed(ts) { var s = Math.max(0, M.now() - ts); return s < 3600 ? Math.floor(s / 60) + 'm ' + (s % 60) + 's' : Math.floor(s / 3600) + 'h ' + Math.floor((s % 3600) / 60) + 'm'; }
  var typeLabel = function (t) { return M.label(M.S.cfg.callTypes, t); };
  M.callType = typeLabel;

  function unitName(u) { return u.label || ('Unit ' + u.src); }

  // ================= DASHBOARD =================
  M.pages.home = function (host) {
    host.innerHTML = M.loading();
    M.rpc('dashboard').then(function (d) {
      if (!d || d.error) { host.innerHTML = M.errBox(d && d.error); return; }
      var me = M.S.me;
      var stat = function (n, label, page, bad) { return '<button class="card stat" data-go="' + page + '" style="text-align:left"><b' + (bad ? ' style="color:var(--bad)"' : '') + '>' + n + '</b><span>' + label + '</span></button>'; };
      var h = '<div class="grid g5">' + stat(d.unitsOnDuty, 'Active units', 'dispatch') + stat(d.openCalls, 'Open calls', 'dispatch', d.openCalls > 0 && d.calls.some(function (c) { return c.priority === 1; })) +
        stat(d.activeBolos, 'Active BOLOs', 'bolos') + stat(d.activeWarrants, 'Open warrants', 'warrants') + stat(d.reportsToReview + d.myDrafts, d.reportsToReview ? 'Reports pending review (' + d.reportsToReview + ') + your drafts (' + d.myDrafts + ')' : 'Your drafts', 'reports') + '</div>';
      h += '<div class="grid g2" style="margin-top:12px"><div>';
      h += '<div class="card"><h3>Quick actions</h3><div class="row">' +
        (M.can('call.create') ? '<button class="btn pri" data-q="call">New call</button>' : '') + '<button class="btn" data-q="person">Search person</button><button class="btn" data-q="vehicle">Search vehicle</button>' +
        (M.can('report.create') ? '<button class="btn" data-q="report">New report</button>' : '') + (M.can('bolo.create') ? '<button class="btn" data-q="bolo">New BOLO</button>' : '') + '</div></div>';
      h += '<div class="card" style="margin-top:12px"><h3>Live dispatch</h3>' + (d.calls.length ? d.calls.map(callCard).join('') : M.empty('No open calls', 'New 911 calls and calls you create show up here.')) + '</div>';
      h += '<div class="card" style="margin-top:12px"><h3>Recent activity</h3>' + (d.activity.length ? M.timeline(d.activity, function (a) { return [a.officer, M.ago(a.at), a.details]; }) : '<div class="m">No activity yet.</div>') + '</div>';
      h += '</div><div>';
      h += '<div class="card"><h3>You</h3>' + M.dl([['Name', me.name], ['Rank', me.grade], ['Department', me.dept], ['Callsign', me.callsign || 'None yet'], ['Badge', me.badge || 'None yet'], ['Role', me.roleLabel]]) +
        '<div class="fld"><label for="myst">Duty status</label><select id="myst">' + M.S.cfg.statuses.map(function (s) { return '<option value="' + s.id + '"' + (s.id === me.status ? ' selected' : '') + '>' + esc(s.label + (s.code ? ' (' + s.code + ')' : '')) + '</option>'; }).join('') + '</select></div></div>';
      h += '<div class="card" style="margin-top:12px"><h3>Unit roster</h3>' + rosterHtml(d.officers) + '</div>';
      h += '<div class="card" style="margin-top:12px"><h3>Announcements</h3>' + (d.announcements.length ? d.announcements.map(function (a) { return '<div class="li"><b>' + (a.pinned ? '📌 ' : '') + esc(a.title) + '</b><div class="m">' + esc(a.by_name) + ' · ' + M.ago(a.created_at) + '</div><div>' + esc(a.body) + '</div></div>'; }).join('') : '<div class="m">Nothing posted.</div>') + '</div>';
      h += '</div></div>';
      host.innerHTML = h;
      bindCalls(host);
      host.querySelectorAll('[data-go]').forEach(function (b) { b.onclick = function () { M.go(b.getAttribute('data-go')); }; });
      host.querySelectorAll('[data-q]').forEach(function (b) {
        b.onclick = function () { var q = b.getAttribute('data-q'); if (q === 'call') M.pages.newCall(); else if (q === 'person') M.go('persons'); else if (q === 'vehicle') M.go('vehicles'); else if (q === 'report') M.pages.editReport(); else M.pages.editBolo(); };
      });
      $('myst').onchange = function () { M.call('setStatus', { status: $('myst').value }, 'Status updated.').then(function () { M.S.me.status = $('myst').value; }); };
    });
  };

  function rosterHtml(list) {
    if (!list || !list.length) return M.empty('Nobody on duty', 'Officers appear here while they are in the city.');
    return '<table><thead><tr><th>Unit</th><th>Officer</th><th>Status</th><th>Since</th></tr></thead><tbody>' + list.map(function (o) {
      return '<tr><td class="mono"><b>' + esc(o.callsign || '----') + '</b></td><td>' + esc(o.name) + '<div class="m">' + esc(o.grade) + '</div></td><td>' + M.statusChip(o.status) + (o.callId ? '<div class="m">Call #' + o.callId + '</div>' : '') + '</td><td class="m">' + M.ago(o.statusAt) + '</td></tr>';
    }).join('') + '</tbody></table>';
  }
  M.rosterHtml = rosterHtml;

  function callCard(c, sel) {
    var units = c.units.length ? c.units.map(function (u) { return '<span class="chip info">' + esc(unitName(u)) + (u.role === 'primary' ? ' · primary' : '') + '</span>'; }).join(' ') : '<span class="chip warn">Awaiting assignment</span>';
    return '<button class="card callc p' + c.priority + (sel ? ' sel' : '') + '" data-call="' + c.id + '"><div class="row">' + M.prio(c.priority) + ' <b>' + esc(typeLabel(c.type)) + '</b> <span class="m">#' + c.id + '</span><span class="sp"></span><span class="m mono">' + elapsed(c.at) + '</span></div>' +
      '<div style="margin:4px 0">' + esc(c.msg) + '</div><div class="m">' + esc(c.location || 'Location from map pin') + '</div><div class="row" style="margin-top:6px">' + units + '</div></button>';
  }
  M.callCard = callCard;
  function bindCalls(root) { root.querySelectorAll('[data-call]').forEach(function (b) { b.onclick = function () { M.pages.openCall(Number(b.getAttribute('data-call'))); }; }); }

  // ================= DISPATCH / CAD =================
  M.pages.dispatch = function (host) {
    var tab = 'open';
    function draw() {
      host.innerHTML = '<div class="bar"><div class="tabs" style="margin:0;flex:1"><button class="tab ' + (tab === 'open' ? 'on' : '') + '" data-t="open">Open calls</button><button class="tab ' + (tab === 'closed' ? 'on' : '') + '" data-t="closed">Closed calls</button></div>' +
        '<button class="btn" data-go="map">Map view</button>' + (M.can('call.create') ? '<button class="btn pri" id="nc">New call</button>' : '') + '</div><div id="dpb"></div>';
      host.querySelectorAll('[data-t]').forEach(function (b) { b.onclick = function () { tab = b.getAttribute('data-t'); draw(); }; });
      host.querySelector('[data-go]').onclick = function () { M.go('map'); };
      var nc = $('nc'); if (nc) nc.onclick = function () { M.pages.newCall(); };
      var body = $('dpb');
      if (tab === 'closed') {
        M.table(body, {
          sort: 'created', placeholder: 'Search closed calls…',
          load: function (st) { return M.rpc('listCalls', M.pay(st, { status: 'closed' })); },
          cols: [{ label: 'Call', sort: 'id', render: function (r) { return '#' + r.id; } }, { label: 'Priority', sort: 'priority', render: function (r) { return M.prio(r.priority); } }, { label: 'Type', render: function (r) { return esc(typeLabel(r.type)); } }, { label: 'Description', render: function (r) { return esc(r.msg); } }, { label: 'Location', render: function (r) { return esc(r.location || '-'); } }, { label: 'Opened', sort: 'created', render: function (r) { return M.fdate(r.created_at); } }, { label: 'Closed by', render: function (r) { return esc(r.closed_by || '-'); } }],
          onRow: function (r) { M.pages.openCall(r.id); }, empty: ['No closed calls']
        });
        return;
      }
      body.innerHTML = M.loading();
      M.rpc('getDispatch').then(function (d) {
        if (!d || d.error) { body.innerHTML = M.errBox(d && d.error); return; }
        var types = '<option value="">All types</option>' + M.S.cfg.callTypes.map(function (t) { return '<option value="' + t.id + '">' + esc(t.label) + '</option>'; }).join('');
        body.innerHTML = '<div class="grid g2"><div><div class="bar"><select id="fp"><option value="">All priorities</option><option>1</option><option>2</option><option>3</option><option>4</option></select><select id="ft">' + types + '</select><span class="m">' + d.calls.length + ' open</span></div><div id="cl"></div></div><div class="card"><h3>Units</h3>' + rosterHtml(d.officers) + '</div></div>';
        var paint = function () {
          var p = $('fp').value, t = $('ft').value;
          var l = d.calls.filter(function (c) { return (!p || String(c.priority) === p) && (!t || c.type === t); });
          $('cl').innerHTML = l.length ? l.map(function (c) { return callCard(c); }).join('') : M.empty('No open calls', 'Nothing matches this filter.');
          bindCalls($('cl'));
        };
        $('fp').onchange = paint; $('ft').onchange = paint; paint();
      });
    }
    draw();
    M.S.polls.push(function () { if (M.S.page === 'dispatch' && tab === 'open' && !M.isOpen() && $('modal').classList.contains('hidden')) draw(); });
  };

  M.pages.newCall = function (pre) {
    pre = pre || {};
    M.form({
      title: 'New call', submit: 'Create call', draft: 'call', values: { priority: 2, type: 'other', msg: pre.msg || '' },
      fields: [
        { key: 'type', label: 'Call type', type: 'select', options: M.S.cfg.callTypes.map(function (t) { return [t.id, t.label]; }) },
        { key: 'priority', label: 'Priority', type: 'select', options: [[1, '1 - Urgent'], [2, '2 - High'], [3, '3 - Routine'], [4, '4 - Low']] },
        { key: 'msg', label: 'What is happening', type: 'textarea', req: true, rows: 3 },
        { key: 'location', label: 'Location / street', req: true, hint: 'The map pin uses where you are standing.' },
        { key: 'caller', label: 'Caller (optional)' }
      ],
      onSubmit: function (v) {
        v.priority = Number(v.priority);
        return M.call('createCall', v, 'Call created.').then(function (r) { if (r) { if (M.S.page === 'dispatch' || M.S.page === 'home') M.go(M.S.page); M.pages.openCall(r.id); } return !!r; });
      }
    });
  };

  M.pages.openCall = function (id) {
    M.open(function () {
      M.rpc('getCall', { id: id }).then(function (c) {
        if (!c || c.error) { M.drawer('Call', M.errBox(c && c.error)); return; }
        var me = M.S.me, mine = c.units.some(function (u) { return u.src === me.src; }), open = c.status === 'open';
        var body = '<div class="row">' + M.prio(c.priority) + ' ' + M.chip(c.status) + (c.kind === 'panic' ? ' <span class="chip bad">PANIC</span>' : '') + '</div>' +
          M.dl([['Type', typeLabel(c.type)], ['Description', c.msg], ['Location', c.location || 'Map pin'], ['Caller', c.caller], ['Opened', M.fdate(c.at) + ' (' + elapsed(c.at) + ' ago)'], ['Closed', c.closedAt ? M.fdate(c.closedAt) + ' by ' + (c.closedBy || '') : ''], ['Report', c.report_id ? '<a href="#" id="lr">R-' + c.report_id + '</a>' : 'None linked', true]]);
        body += M.sec('Responding units') + (c.units.length ? c.units.map(function (u) { return '<div class="li row">' + esc(unitName(u)) + ' <span class="chip ' + (u.role === 'primary' ? 'info' : 'mute') + '">' + (u.role === 'primary' ? 'Primary' : 'Assisting') + '</span><span class="sp"></span>' + (open && M.can('call.manage') && u.src ? '<button class="btn sm" data-rm="' + u.src + '">Remove</button>' : '') + '</div>'; }).join('') : '<div class="m">No units assigned.</div>');
        body += M.sec('Status history') + M.timeline((c.timeline || []).slice().reverse(), function (t) { return [t.by, M.fdate(t.at), t.text]; });
        var acts = [];
        if (open) {
          acts.push({ text: mine ? 'Leave call' : 'Attach me', cls: 'pri', show: M.can('call.respond'), fn: function () { M.call('attachCall', { id: id }).then(function (r) { if (r) M.pages.openCall(id); }); } });
          acts.push({ text: 'Waypoint', fn: function () { M.call('waypointCall', { id: id }, 'Waypoint set.'); } });
          acts.push({ text: 'Add note', show: M.can('call.respond'), fn: function () { M.reason('Add note', 'Dispatcher / officer note', 'Add note', function (t) { M.call('addCallNote', { id: id, text: t }).then(function () { M.pages.openCall(id); }); }, 2); } });
          acts.push({ text: 'Edit', show: M.can('call.manage'), fn: function () { editCall(c); } });
          acts.push({ text: 'Assign unit', show: M.can('call.manage'), fn: function () { assignUnit(c); } });
          acts.push({ text: 'Link report', show: M.can('call.respond'), fn: function () { linkReport(c); } });
          acts.push({ text: 'Close call', cls: 'danger', show: M.can('call.respond') && (mine || M.can('call.manage')), fn: function () { M.reason('Close call', 'How was it resolved?', 'Close call', function (t) { M.call('closeCall', { id: id, note: t }, 'Call closed.').then(function () { M.closeDrawer(); if (M.S.page === 'dispatch' || M.S.page === 'home') M.go(M.S.page); }); }, 3); } });
        }
        M.drawer('Call #' + c.id, body, acts);
        var lr = $('lr'); if (lr) lr.onclick = function (e) { e.preventDefault(); M.pages.openReport(c.report_id); };
        $('drawer').querySelectorAll('[data-rm]').forEach(function (b) { b.onclick = function () { M.call('assignUnit', { id: id, unit: Number(b.getAttribute('data-rm')), remove: true }).then(function () { M.pages.openCall(id); }); }; });
      });
    });
  };

  function editCall(c) {
    M.form({
      title: 'Edit call #' + c.id, submit: 'Save changes', values: { type: c.type, priority: c.priority, msg: c.msg, location: c.location },
      fields: [
        { key: 'type', label: 'Call type', type: 'select', options: M.S.cfg.callTypes.map(function (t) { return [t.id, t.label]; }) },
        { key: 'priority', label: 'Priority', type: 'select', options: [[1, '1 - Urgent'], [2, '2 - High'], [3, '3 - Routine'], [4, '4 - Low']] },
        { key: 'msg', label: 'Description', type: 'textarea', req: true, rows: 3 }, { key: 'location', label: 'Location' }
      ],
      onSubmit: function (v) { v.id = c.id; v.priority = Number(v.priority); return M.call('updateCall', v, 'Call updated.').then(function (r) { if (r) M.pages.openCall(c.id); return !!r; }); }
    });
  }
  function assignUnit(c) {
    M.rpc('roster').then(function (r) {
      var list = (r && r.officers) || [];
      if (!list.length) return M.toast('Nobody is on duty.', 'warn');
      M.form({
        title: 'Assign unit to call #' + c.id, submit: 'Assign',
        fields: [{ key: 'unit', label: 'Unit', type: 'select', options: list.map(function (o) { return [o.src, (o.callsign ? o.callsign + ' · ' : '') + o.name + ' (' + statusOf(o.status).label + ')']; }) }, { key: 'role', label: 'Role', type: 'select', options: [['assist', 'Assisting'], ['primary', 'Primary']] }],
        onSubmit: function (v) { return M.call('assignUnit', { id: c.id, unit: Number(v.unit), role: v.role }, 'Unit assigned.').then(function (x) { if (x) M.pages.openCall(c.id); return !!x; }); }
      });
    });
  }
  function linkReport(c) {
    M.form({ title: 'Link report to call #' + c.id, submit: 'Link', fields: [{ key: 'rid', label: 'Report number', type: 'number', req: true, hint: 'The number after R- on the report.' }],
      onSubmit: function (v) { return M.call('linkCallReport', { id: c.id, report_id: v.rid }, 'Report linked.').then(function (x) { if (x) M.pages.openCall(c.id); return !!x; }); } });
  }

  // ================= LIVE MAP =================
  // Stylised outline of San Andreas. Coordinates are game coordinates, so pins are in the right place.
  var LAND = [[-2300, 3300], [-3200, 1600], [-3000, 400], [-2100, -400], [-1800, -1200], [-1500, -2200], [-1100, -3000], [-100, -3000], [900, -2800], [1700, -2400], [2600, -1500], [3100, -300], [3100, 1000], [2500, 2500], [2800, 3600], [3200, 4500], [2400, 5300], [1800, 5900], [1000, 6600], [-200, 6900], [-1500, 6400], [-2300, 5300], [-2700, 4300]];
  var PLACES = [['Downtown', 200, -900], ['Vinewood', 300, 350], ['Vespucci', -1200, -1050], ['Mirror Park', 1000, -600], ['Davis', 100, -1700], ['LSIA', -1100, -2800], ['Sandy Shores', 1850, 3700], ['Grapeseed', 1700, 4900], ['Paleto Bay', -150, 6200], ['Mt Chiliad', 450, 5550], ['Harmony', 600, 2700], ['Fort Zancudo', -2100, 3100]];
  var X0 = -3600, Y1 = 7600, W = 7200, H = 11000;
  var px = function (x) { return x - X0; }, py = function (y) { return Y1 - y; };

  M.pages.map = function (host) {
    var show = { calls: true, units: true };
    var data = null;
    host.innerHTML = '<div class="bar"><label class="chk"><input type="checkbox" id="mc" checked><span>Calls</span></label><label class="chk"><input type="checkbox" id="mu" checked><span>Units</span></label><span class="sp"></span><span class="m">Stylised map. Pins use real game coordinates.</span><button class="btn" id="ml">List view</button></div><div id="mb"></div>';
    var mode = 'map';
    function paint() {
      if (!data) return;
      var h;
      if (mode === 'list') {
        h = '<div class="grid g2e"><div class="card"><h3>Calls</h3>' + (data.calls.length ? data.calls.map(function (c) { return callCard(c); }).join('') : M.empty('No open calls')) + '</div><div class="card"><h3>Units</h3>' + rosterHtml(data.officers) + '</div></div>';
        $('mb').innerHTML = h; bindCalls($('mb')); return;
      }
      var svg = '<svg viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="Live map" style="max-height:640px;margin:0 auto"><rect width="' + W + '" height="' + H + '" fill="#0a1626"/>';
      for (var gx = 0; gx <= W; gx += 1000) svg += '<line x1="' + gx + '" y1="0" x2="' + gx + '" y2="' + H + '" stroke="#12233a" stroke-width="8"/>';
      for (var gy = 0; gy <= H; gy += 1000) svg += '<line x1="0" y1="' + gy + '" x2="' + W + '" y2="' + gy + '" stroke="#12233a" stroke-width="8"/>';
      svg += '<polygon points="' + LAND.map(function (p) { return px(p[0]) + ',' + py(p[1]); }).join(' ') + '" fill="#13253d" stroke="#2a4b75" stroke-width="22"/>';
      PLACES.forEach(function (p) { svg += '<text x="' + px(p[1]) + '" y="' + py(p[2]) + '" fill="#5f7a9c" font-size="170" text-anchor="middle">' + p[0] + '</text>'; });
      if (show.calls) data.calls.forEach(function (c) {
        var col = c.priority === 1 ? '#DC4545' : c.priority === 2 ? '#E6A23C' : '#399BFF';
        svg += '<g class="pin" data-call="' + c.id + '" style="cursor:pointer"><circle cx="' + px(c.x) + '" cy="' + py(c.y) + '" r="150" fill="' + col + '" fill-opacity=".25" stroke="' + col + '" stroke-width="22"/><text x="' + px(c.x) + '" y="' + (py(c.y) + 60) + '" fill="#fff" font-size="150" font-weight="700" text-anchor="middle">' + c.id + '</text></g>';
      });
      if (show.units) data.officers.forEach(function (o) {
        var me = o.src === data.me;
        svg += '<g><rect x="' + (px(o.x) - 85) + '" y="' + (py(o.y) - 85) + '" width="170" height="170" rx="30" fill="' + (me ? '#24B47E' : '#2675D8') + '" stroke="#fff" stroke-width="14"/><text x="' + px(o.x) + '" y="' + (py(o.y) - 120) + '" fill="#fff" font-size="140" text-anchor="middle">' + esc(o.callsign || o.name.split(' ')[0]) + '</text></g>';
      });
      svg += '</svg>';
      $('mb').innerHTML = '<div class="grid g2"><div class="mapbox">' + svg + '</div><div class="card"><h3>Open calls</h3>' + (data.calls.length ? data.calls.map(function (c) { return callCard(c); }).join('') : M.empty('No open calls')) + '<div class="legend" style="margin-top:8px"><span>● Priority 1 red</span><span>● Priority 2 amber</span><span>● Priority 3+ blue</span><span>■ Unit (you in green)</span></div></div></div>';
      bindCalls($('mb'));
      $('mb').querySelectorAll('.pin').forEach(function (g) { g.onclick = function () { M.pages.openCall(Number(g.getAttribute('data-call'))); }; });
    }
    function load() { M.rpc('getMap').then(function (d) { if (!d || d.error) { $('mb').innerHTML = M.errBox(d && d.error); return; } data = d; paint(); }); }
    $('mc').onchange = function () { show.calls = $('mc').checked; paint(); };
    $('mu').onchange = function () { show.units = $('mu').checked; paint(); };
    $('ml').onclick = function () { mode = mode === 'map' ? 'list' : 'map'; $('ml').textContent = mode === 'map' ? 'List view' : 'Map view'; paint(); };
    $('mb').innerHTML = M.loading(); load();
    M.S.polls.push(function () { if (M.S.page === 'map') load(); });
  };

  // ================= NOTIFICATIONS =================
  M.pages.notifs = function (host) {
    host.innerHTML = M.loading();
    M.rpc('notifications').then(function (r) {
      if (!r || r.error) { host.innerHTML = M.errBox(r && r.error); return; }
      host.innerHTML = '<div class="bar"><b>' + r.list.length + ' notification' + (r.list.length === 1 ? '' : 's') + '</b><span class="sp"></span><button class="btn" id="mr">Mark all read</button></div>' +
        '<div class="card" style="padding:0">' + (r.list.length ? r.list.map(function (n, i) { return '<div class="nt ' + (n.unread ? 'un' : '') + '" data-i="' + i + '" tabindex="0"><div class="sp"><b>' + esc(n.title) + '</b>' + (n.unread ? ' <span class="chip info">New</span>' : '') + '<div class="m">' + esc(n.body || '') + '</div></div><span class="m">' + M.ago(n.at) + '</span></div>'; }).join('') : M.empty('You are all caught up', 'Warrant approvals, BOLOs, report reviews and lab results land here.')) + '</div>';
      $('mr').onclick = function () { M.rpc('markNotifsRead').then(function () { M.setUnread(0); M.go('notifs'); }); };
      host.querySelectorAll('.nt').forEach(function (e) {
        var go = function () { var n = r.list[Number(e.getAttribute('data-i'))]; M.openLink(n.page, n.link); };
        e.onclick = go; e.onkeydown = function (ev) { if (ev.key === 'Enter') go(); };
      });
    });
  };
})();
