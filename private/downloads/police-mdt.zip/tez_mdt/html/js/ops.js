// Incident reports, evidence, tow / impound, court cases
(function () {
  var M = window.M, $ = M.$, esc = M.esc, money = M.money;
  var ids = function (s) { return String(s || '').split(/[\s,]+/).map(function (x) { return Number(String(x).replace(/\D/g, '')); }).filter(Boolean); };
  var RSTAT = [['all', 'All'], ['draft', 'Drafts'], ['submitted', 'Submitted'], ['returned', 'Returned'], ['approved', 'Approved']];

  // ================= REPORTS =================
  M.pages.reports = function (host, params) {
    M.table(host, {
      sort: 'created', placeholder: 'Search title, officer, location or R-number', q: params && params.q || '',
      filters: [{ key: 'status', label: 'Status', options: RSTAT, value: params && params.status || 'all' }, { key: 'type', label: 'Type', options: [['all', 'All types']].concat(M.S.cfg.reportTypes.map(function (t) { return [t.id, t.label]; })) }],
      bar: function (bar) {
        var mine = M.el('<label class="chk"><input type="checkbox" id="rmine"><span>Only mine</span></label>'); bar.appendChild(mine);
        if (M.can('report.create')) { var b = M.el('<button class="btn pri">New report</button>'); b.onclick = function () { M.pages.editReport(); }; bar.appendChild(b); }
      },
      load: function (st) { return M.rpc('listReports', M.pay(st, { mine: $('rmine') && $('rmine').checked })); }, empty: ['No reports', 'Start one with New report.'],
      cols: [{ label: 'ID', sort: 'id', render: function (r) { return 'R-' + r.id; } }, { label: 'Title', sort: 'title', render: function (r) { return '<b>' + esc(r.title) + '</b>'; } }, { label: 'Type', sort: 'type', render: function (r) { return esc(M.label(M.S.cfg.reportTypes, r.type)); } }, { label: 'Status', sort: 'status', render: function (r) { return M.chip(r.status); } }, { label: 'Author', sort: 'author', render: function (r) { return esc(r.author_name); } }, { label: 'Location', render: function (r) { return esc(r.location || '-'); } }, { label: 'Created', sort: 'created', render: function (r) { return M.fdate(r.created_at); } }],
      onRow: function (r) { M.pages.openReport(r.id); }
    });
    var cb = $('rmine'); if (cb) cb.onchange = function () { M.go('reports'); };
  };

  M.pages.editReport = function (r) {
    r = r || {};
    var vals = r.id ? { type: r.type, title: r.title, narrative: r.narrative, involved: r.involved, people: r.people, vehicles: r.vehicles, witnesses: r.witnesses, assisting: r.assisting, location: r.location, call_id: r.call_id, occurred_at: r.occurred_at, evidence: (r.evidence || []).map(function (e) { return 'E-' + e; }).join(', '), attachments: r.attachments } : { type: 'incident', occurred_at: M.now() };
    var title = r.id ? 'Edit report R-' + r.id : 'New incident report';
    M.form({
      title: title, wide: true, draft: r.id ? 'report-' + r.id : 'report-new', values: vals, submit: 'Submit for review',
      extraButtons: [{ text: 'Save draft', extra: { submit: false } }],
      fields: [
        { key: 'type', label: 'Incident type', type: 'select', options: M.S.cfg.reportTypes.map(function (t) { return [t.id, t.label]; }) }, { key: 'occurred_at', label: 'Date and time', type: 'datetime', now: true },
        { key: 'title', label: 'Title', req: true, max: 120, full: true }, { key: 'location', label: 'Location' }, { key: 'call_id', label: 'Linked call number', type: 'number' },
        { key: 'assisting', label: 'Assisting officers' }, { key: 'involved', label: 'Involved parties (names not in the city)' },
        { key: 'people', label: 'Involved people from the city database', type: 'people' }, { key: 'vehicles', label: 'Vehicle plates', type: 'lines', placeholder: 'One plate per line' },
        { key: 'witnesses', label: 'Witnesses', full: true }, { key: 'evidence', label: 'Evidence numbers', placeholder: 'E-12, E-14' },
        { key: 'narrative', label: 'Narrative', type: 'textarea', rows: 8, hint: 'Required before you can submit. Drafts can stay short.' },
        { key: 'attachments', label: 'Attachment links (images or files)', type: 'lines', placeholder: 'One https:// link per line' }
      ],
      onSubmit: function (v) {
        v.submit = v.submit === false ? false : true;
        if (r.id) { v.id = r.id; v.expected = r.version; }
        return M.call('saveReport', v).then(function (res) {
          if (!res) return false;
          M.toast(res.status === 'submitted' ? 'Report submitted for review.' : 'Draft saved.', 'ok');
          if (M.S.page === 'reports') M.go('reports'); M.pages.openReport(res.id); return true;
        });
      }
    });
  };

  M.pages.openReport = function (id) {
    M.open(function () {
      M.rpc('getReport', { id: id }).then(function (r) {
        if (!r || r.error) { M.drawer('Report', M.errBox(r && r.error)); return; }
        var cur = 'view';
        function draw() {
          var b = '<div class="row">' + M.chip(r.status) + '<span class="chip mute">Version ' + r.version + '</span></div>' +
            '<div class="tabs" style="margin-top:10px">' + [['view', 'Report'], ['links', 'Linked records'], ['ver', 'Versions', r.versions.length], ['com', 'Comments', r.comments.length]].map(function (t) { return '<button class="tab ' + (cur === t[0] ? 'on' : '') + '" data-t="' + t[0] + '">' + t[1] + (t[2] ? '<span class="n">' + t[2] + '</span>' : '') + '</button>'; }).join('') + '</div><div id="rb"></div>';
          M.drawer('R-' + r.id + ' ' + r.title, b, [
            { text: 'Copy summary', fn: function () { M.copy('INCIDENT REPORT R-' + r.id + '\n' + r.title + '\nType: ' + M.label(M.S.cfg.reportTypes, r.type) + '\nWhen: ' + M.fdate(r.occurred_at) + '\nWhere: ' + (r.location || '-') + '\nAuthor: ' + r.author_name + '\nStatus: ' + r.status + '\n\n' + (r.narrative || '')); } },
            { text: 'Edit', cls: 'pri', show: r.canEdit, fn: function () { M.pages.editReport(r); } },
            { text: 'Approve', cls: 'ok', show: r.canReview, fn: function () { M.reason('Approve report', 'Optional comment for the officer', 'Approve', function (t) { M.call('reviewReport', { id: id, decision: 'approve', comment: t }, 'Report approved.').then(function () { M.pages.openReport(id); }); }, 0); } },
            { text: 'Return', show: r.canReview, fn: function () { M.reason('Return report', 'What needs to change?', 'Return to officer', function (t) { M.call('reviewReport', { id: id, decision: 'return', comment: t }, 'Report returned.').then(function () { M.pages.openReport(id); }); }); } },
            { text: 'Delete draft', cls: 'danger', show: r.status === 'draft' && r.canEdit, fn: function () { M.confirm('Delete this draft?', 'It cannot be recovered.', 'Delete draft', function () { M.call('deleteDraft', { id: id }, 'Draft deleted.').then(function () { M.closeDrawer(); if (M.S.page === 'reports') M.go('reports'); }); }, true); } }
          ]);
          $('drawer').querySelectorAll('[data-t]').forEach(function (t) { t.onclick = function () { cur = t.getAttribute('data-t'); draw(); }; });
          body();
        }
        function body() {
          var h = '', t = $('rb');
          if (cur === 'view') {
            h = M.dl([['Type', M.label(M.S.cfg.reportTypes, r.type)], ['When', M.fdate(r.occurred_at)], ['Location', r.location], ['Author', r.author_name], ['Assisting', r.assisting], ['Involved', r.involved], ['Witnesses', r.witnesses], ['Submitted', r.submitted_at ? M.fdate(r.submitted_at) : 'Not yet submitted'], ['Reviewed by', r.reviewed_by]]);
            if (r.people.length) h += M.sec('People') + r.people.map(function (p) { return '<div class="li">' + M.linkPerson(p.identifier, p.name) + '</div>'; }).join('');
            if (r.vehicles.length) h += M.sec('Vehicles') + '<div class="row">' + r.vehicles.map(function (p) { return M.plateLink(p); }).join(' ') + '</div>';
            if (r.evidence.length) h += M.sec('Evidence') + '<div class="row">' + r.evidence.map(function (e) { return '<button class="btn sm" data-e="' + e + '">E-' + e + '</button>'; }).join('') + '</div>';
            h += M.sec('Narrative') + '<div class="li" style="white-space:pre-wrap">' + esc(r.narrative || 'No narrative yet.') + '</div>';
            if (r.attachments.length) h += M.sec('Attachments') + r.attachments.map(function (a) { return '<div class="li"><div class="mono m" style="word-break:break-all">' + esc(a) + '</div><img src="' + esc(a) + '" alt="Attachment" style="max-width:100%;border-radius:6px;margin-top:6px" onerror="this.style.display=\'none\'"></div>'; }).join('');
          } else if (cur === 'links') {
            var L = r.linked;
            h = M.sec('Calls') + (L.calls.length ? L.calls.map(function (c) { return '<div class="li clk" data-call="' + c.id + '">Call #' + c.id + ' ' + esc(c.msg) + '</div>'; }).join('') : '<div class="m">None.</div>') +
              M.sec('Citations') + (L.citations.length ? L.citations.map(function (c) { return '<div class="li clk" data-c="' + c.id + '">C-' + c.id + ' ' + esc(c.person_name) + ' ' + M.chip(c.status) + ' ' + money(c.fine) + '</div>'; }).join('') : '<div class="m">None.</div>') +
              M.sec('Arrests') + (L.bookings.length ? L.bookings.map(function (c) { return '<div class="li clk" data-b="' + c.id + '">B-' + c.id + ' ' + esc(c.person_name) + ' ' + M.chip(c.status) + '</div>'; }).join('') : '<div class="m">None.</div>') +
              M.sec('Warrants') + (L.warrants.length ? L.warrants.map(function (c) { return '<div class="li clk" data-w="' + c.id + '">W-' + c.id + ' ' + esc(c.citizen_name) + ' ' + M.chip(c.status) + '</div>'; }).join('') : '<div class="m">None.</div>');
          } else if (cur === 'ver') h = M.timeline(r.versions, function (v) { return ['Version ' + v.version, M.fdate(v.at), v.edited_by + ': ' + v.title]; });
          else {
            h = r.comments.length ? r.comments.map(function (c) { return '<div class="li"><div class="row"><b>' + esc(c.by_name) + '</b> ' + (c.kind === 'return' ? '<span class="chip warn">Returned</span>' : c.kind === 'approve' ? '<span class="chip ok">Approved</span>' : '') + '<span class="sp"></span><span class="m">' + M.fdate(c.at) + '</span></div>' + esc(c.text) + '</div>'; }).join('') : '<div class="m">No comments yet.</div>';
            if (r.status !== 'draft') h += '<div style="margin-top:10px"><button class="btn" id="ac">Add comment</button></div>';
          }
          t.innerHTML = h;
          t.querySelectorAll('[data-e]').forEach(function (e) { e.onclick = function () { M.pages.openEvidence(Number(e.getAttribute('data-e'))); }; });
          t.querySelectorAll('[data-call]').forEach(function (e) { e.onclick = function () { M.pages.openCall(Number(e.getAttribute('data-call'))); }; });
          t.querySelectorAll('[data-c]').forEach(function (e) { e.onclick = function () { M.pages.openCitation(Number(e.getAttribute('data-c'))); }; });
          t.querySelectorAll('[data-b]').forEach(function (e) { e.onclick = function () { M.pages.openBooking(Number(e.getAttribute('data-b'))); }; });
          t.querySelectorAll('[data-w]').forEach(function (e) { e.onclick = function () { M.pages.openWarrant(Number(e.getAttribute('data-w'))); }; });
          var ac = $('ac'); if (ac) ac.onclick = function () { M.reason('Add comment', 'Comment', 'Post comment', function (x) { M.call('addReportComment', { id: id, text: x }, 'Comment added.').then(function () { M.pages.openReport(id); }); }, 2); };
        }
        draw();
      });
    });
  };

  // ================= EVIDENCE =================
  M.pages.evidence = function (host, params) {
    M.table(host, {
      sort: 'created', placeholder: 'Search description, custodian or location', q: params && params.q || '',
      filters: [{ key: 'category', label: 'Category', options: [['all', 'All categories']].concat(M.S.cfg.evidenceCategories.map(function (c) { return [c, c]; })) }, { key: 'status', label: 'Status', options: [['all', 'Any status'], ['collected', 'Collected'], ['analyzing', 'In lab'], ['analyzed', 'Analysed']] }, { key: 'disposition', label: 'Disposition', options: [['all', 'Any disposition']].concat(M.S.cfg.evidenceDispositions.map(function (c) { return [c, c]; })) }],
      bar: function (bar) { if (M.can('evidence.collect')) { var b = M.el('<button class="btn pri">Log evidence</button>'); b.onclick = newEvidence; bar.appendChild(b); } },
      load: function (st) { return M.rpc('listEvidence', M.pay(st)); }, empty: ['No evidence logged', 'Use /scan at a scene or log an item by hand.'],
      cols: [{ label: 'ID', sort: 'id', render: function (r) { return 'E-' + r.id; } }, { label: 'Description', render: function (r) { return '<b>' + esc(r.description) + '</b>'; } }, { label: 'Category', sort: 'category', render: function (r) { return esc(r.category); } }, { label: 'Status', sort: 'status', render: function (r) { return M.chip(r.status, r.status === 'analyzing' ? 'In lab' : null); } }, { label: 'Disposition', render: function (r) { return esc(r.disposition || '-'); } }, { label: 'Custodian', sort: 'custodian', render: function (r) { return esc(r.custodian || '-'); } }, { label: 'Collected', sort: 'created', render: function (r) { return M.fdate(r.at); } }],
      onRow: function (r) { M.pages.openEvidence(r.id); }
    });
  };
  function newEvidence() {
    M.form({
      title: 'Log evidence', submit: 'Log evidence', values: { category: 'Other' },
      fields: [{ key: 'description', label: 'Description', req: true, full: true, max: 200 }, { key: 'category', label: 'Category', type: 'select', options: M.S.cfg.evidenceCategories }, { key: 'storage', label: 'Storage location' }, { key: 'report_id', label: 'Linked report number', type: 'number' }, { key: 'attachments', label: 'Photo / file links', type: 'lines' }],
      onSubmit: function (v) { return M.call('createEvidence', v, 'Evidence logged.').then(function (r) { if (r) { if (M.S.page === 'evidence') M.go('evidence'); M.pages.openEvidence(r.id); } return !!r; }); }
    });
  }
  var CEV = { collected: 'Collected', transfer: 'Transferred', location: 'Moved', lab_submit: 'Sent to lab', lab_result: 'Lab result', disposition: 'Disposition', link: 'Linked' };
  M.pages.openEvidence = function (id) {
    M.open(function () {
      M.rpc('getEvidence', { id: id }).then(function (e) {
        if (!e || e.error) { M.drawer('Evidence', M.errBox(e && e.error)); return; }
        var h = '<div class="row">' + M.chip(e.status, e.status === 'analyzing' ? 'In lab' : null) + ' <span class="chip mute">' + esc(e.category) + '</span> <span class="chip mute">' + esc(e.disposition || 'Stored') + '</span></div>';
        if (e.status === 'analyzing') h += '<div class="alert info">Lab result due in about ' + Math.max(1, Math.ceil((e.readyAt - e.serverNow) / 60)) + ' minute(s).</div>';
        if (e.result) h += '<div class="alert ' + (e.result.match ? 'danger' : 'info') + '">' + (e.result.match ? 'Match found: ' + esc(e.result.match) : 'No match on file') + ' <span class="mono">' + esc(e.result.code || '') + '</span></div>';
        h += M.dl([['Description', e.description], ['Custodian', e.custodian], ['Storage', e.storage], ['Collected by', e.by], ['Collected', M.fdate(e.at)], ['Report', e.report_id ? '<a href="#" id="er">R-' + e.report_id + '</a>' : '', true], ['Weapon', e.result && e.result.weapon]]);
        if (e.attachments && e.attachments.length) h += M.sec('Attachments') + e.attachments.map(function (a) { return '<div class="li"><div class="mono m" style="word-break:break-all">' + esc(a) + '</div></div>'; }).join('');
        h += M.sec('Chain of custody') + M.timeline(e.custody, function (c) { return [CEV[c.event] || c.event, M.fdate(c.at), c.by_name + (c.detail ? ': ' + c.detail : '')]; });
        M.drawer('Evidence E-' + e.id, h, [
          { text: 'Send to lab', cls: 'pri', show: e.lab && e.status === 'collected' && M.can('evidence.collect'), fn: function () { M.call('sendToLab', { id: id }, 'Sent to the lab.').then(function () { M.pages.openEvidence(id); }); } },
          { text: 'Re-check result', show: e.status === 'analyzed' && M.can('evidence.collect'), fn: function () { M.call('recheckEvidence', { id: id }, 'Result re-checked.').then(function () { M.pages.openEvidence(id); }); } },
          { text: 'Transfer', show: e.canTransfer, fn: function () { transfer(e); } },
          { text: 'Move', show: e.canTransfer, fn: function () { M.form({ title: 'Storage location', submit: 'Save', values: { storage: e.storage }, fields: [{ key: 'storage', label: 'New location', req: true }], onSubmit: function (v) { v.id = id; return M.call('setEvidenceStorage', v, 'Moved.').then(function (r) { if (r) M.pages.openEvidence(id); return !!r; }); } }); } },
          { text: 'Link report', fn: function () { M.form({ title: 'Link to report', submit: 'Link', fields: [{ key: 'report_id', label: 'Report number', type: 'number', req: true }], onSubmit: function (v) { v.id = id; return M.call('linkEvidenceReport', v, 'Linked.').then(function (r) { if (r) M.pages.openEvidence(id); return !!r; }); } }); } },
          { text: 'Disposition', cls: 'danger', show: M.can('evidence.dispose'), fn: function () { M.form({ title: 'Evidence disposition', submit: 'Record', fields: [{ key: 'disposition', label: 'Disposition', type: 'select', options: M.S.cfg.evidenceDispositions.filter(function (d) { return d !== 'In lab'; }) }, { key: 'note', label: 'Note for the record', type: 'textarea', req: true }], onSubmit: function (v) { v.id = id; return M.call('disposeEvidence', v, 'Recorded.').then(function (r) { if (r) M.pages.openEvidence(id); return !!r; }); } }); } }
        ]);
        var er = $('er'); if (er) er.onclick = function (ev) { ev.preventDefault(); M.pages.openReport(e.report_id); };
      });
    });
  };
  function transfer(e) {
    M.rpc('listOfficers', { page: 1, active: 'on' }).then(function (r) {
      var list = (r && r.rows) || [];
      if (!list.length) return M.toast('Could not load officers.', 'bad');
      M.form({ title: 'Transfer E-' + e.id, submit: 'Transfer custody', fields: [{ key: 'to', label: 'New custodian', type: 'select', options: list.map(function (o) { return [o.identifier, o.name + (o.callsign ? ' (' + o.callsign + ')' : '')]; }) }, { key: 'note', label: 'Reason / note' }],
        onSubmit: function (v) { v.id = e.id; return M.call('transferEvidence', v, 'Custody transferred.').then(function (x) { if (x) M.pages.openEvidence(e.id); return !!x; }); } });
    });
  }

  // ================= IMPOUND =================
  M.pages.impound = function (host, params) {
    M.table(host, {
      sort: 'created', placeholder: 'Search plate, owner or reason', q: params && params.q || '',
      filters: [{ key: 'status', label: 'Status', options: [['impounded', 'In impound'], ['released', 'Released'], ['all', 'All']] }],
      bar: function (bar) { if (M.can('impound.create')) { var b = M.el('<button class="btn pri">Impound vehicle</button>'); b.onclick = function () { M.pages.newImpound(); }; bar.appendChild(b); } },
      load: function (st) { return M.rpc('listImpounds', M.pay(st)); }, empty: ['No vehicles in the impound'],
      cols: [{ label: 'ID', sort: 'id', render: function (r) { return 'I-' + r.id; } }, { label: 'Plate', sort: 'plate', render: function (r) { return M.plateLink(r.plate); } }, { label: 'Owner', render: function (r) { return r.owner_identifier ? M.linkPerson(r.owner_identifier, r.owner_name) : esc(r.owner_name || '-'); } }, { label: 'Reason', render: function (r) { return esc(r.reason); } }, { label: 'Fee', sort: 'fee', render: function (r) { return money(r.fee); } }, { label: 'Status', sort: 'status', render: function (r) { return M.chip(r.status); } }, { label: 'Officer', render: function (r) { return esc(r.officer_name); } }, { label: 'Date', sort: 'created', render: function (r) { return M.fdate(r.created_at); } },
        { label: '', render: function (r) { return r.status === 'impounded' && M.can('impound.release') ? '<button class="btn sm" data-rel="' + r.id + '">Release</button>' : ''; } }],
      onRow: function (r) { M.pages.openVehicle(r.plate); }
    });
    host.addEventListener('click', function (ev) {
      var b = ev.target.closest && ev.target.closest('[data-rel]'); if (!b) return; ev.stopPropagation();
      M.confirm('Release this vehicle?', 'The owner can collect it. This is logged.', 'Release', function () { M.call('releaseImpound', { id: Number(b.getAttribute('data-rel')) }, 'Vehicle released.').then(function () { M.go('impound'); }); });
    }, true);
  };
  M.pages.newImpound = function (plate) {
    M.form({
      title: 'Impound vehicle', submit: 'Impound', values: { plate: plate }, draft: 'impound',
      fields: [{ key: 'plate', label: 'Plate', type: 'plate', req: true }, { key: 'reason', label: 'Reason', type: 'textarea', req: true, rows: 3 }, { key: 'location', label: 'Where it was taken from' }, { key: 'fee', label: 'Impound fee', type: 'number', min: 0, max: 100000 }, { key: 'report_id', label: 'Linked report number', type: 'number' }],
      onSubmit: function (v) { return M.call('createImpound', v, 'Vehicle impounded.').then(function (r) { if (r && M.S.page === 'impound') M.go('impound'); return !!r; }); }
    });
  };

  // ================= COURT CASES =================
  M.pages.cases = function (host, params) {
    if (!M.S.cfg.court) { host.innerHTML = M.empty('Court cases are turned off', 'Set Config.Court.enabled = true in config.lua to use them.'); return; }
    M.table(host, {
      sort: 'created', placeholder: 'Search title, judge or lawyers', q: params && params.q || '',
      filters: [{ key: 'status', label: 'Status', options: [['all', 'All'], ['open', 'Open'], ['hearing', 'Hearing set'], ['closed', 'Closed'], ['appealed', 'Appealed']] }],
      bar: function (bar) { if (M.can('case.manage')) { var b = M.el('<button class="btn pri">Open case</button>'); b.onclick = function () { editCase(); }; bar.appendChild(b); } },
      load: function (st) { return M.rpc('listCases', M.pay(st)); }, empty: ['No cases'],
      cols: [{ label: 'Case', sort: 'id', render: function (r) { return 'CASE-' + r.id; } }, { label: 'Title', sort: 'title', render: function (r) { return '<b>' + esc(r.title) + '</b>'; } }, { label: 'Status', sort: 'status', render: function (r) { return M.chip(r.status); } }, { label: 'Judge', render: function (r) { return esc(r.judge || '-'); } }, { label: 'Prosecutor', render: function (r) { return esc(r.prosecutor || '-'); } }, { label: 'Defense', render: function (r) { return esc(r.defense || '-'); } }, { label: 'Next hearing', render: function (r) { return r.nextHearing ? M.fdate(r.nextHearing) : '-'; } }, { label: 'Opened', sort: 'created', render: function (r) { return M.fday(r.created_at); } }],
      onRow: function (r) { M.pages.openCase(r.id); }
    });
  };
  function linkOf(c) { var L = c.links || {}; return { reports: (L.reports || []).join(', '), citations: (L.citations || []).join(', '), bookings: (L.bookings || []).join(', '), evidence: (L.evidence || []).join(', ') }; }
  function editCase(c) {
    c = c || {};
    var l = linkOf(c);
    M.form({
      title: c.id ? 'Edit case ' + c.id : 'Open a case', wide: true, submit: 'Save case', draft: c.id ? 'case-' + c.id : 'case-new',
      values: { title: c.title, parties: c.parties, judge: c.judge, prosecutor: c.prosecutor, defense: c.defense, status: c.status || 'open', outcome: c.outcome, sentence: c.sentence, lr: l.reports, lc: l.citations, lb: l.bookings, le: l.evidence },
      fields: [{ key: 'title', label: 'Case title', req: true, full: true }, { key: 'parties', label: 'Parties', type: 'people' }, { key: 'judge', label: 'Judge' }, { key: 'prosecutor', label: 'Prosecutor' }, { key: 'defense', label: 'Defense' }]
        .concat(c.id ? [{ key: 'status', label: 'Status', type: 'select', options: [['open', 'Open'], ['hearing', 'Hearing set'], ['closed', 'Closed'], ['appealed', 'Appealed']] }, { key: 'outcome', label: 'Outcome', type: 'textarea', rows: 3 }, { key: 'sentence', label: 'Sentence / disposition', type: 'textarea', rows: 3 }] : [])
        .concat([{ key: 'lr', label: 'Linked report numbers' }, { key: 'lc', label: 'Linked citation numbers' }, { key: 'lb', label: 'Linked booking numbers' }, { key: 'le', label: 'Linked evidence numbers' }]),
      onSubmit: function (v) {
        v.links = { reports: ids(v.lr), citations: ids(v.lc), bookings: ids(v.lb), evidence: ids(v.le) };
        if (c.id) { v.id = c.id; v.expected = c.updated_at; }
        return M.call(c.id ? 'updateCase' : 'createCase', v, 'Case saved.').then(function (r) { if (!r) return false; if (M.S.page === 'cases') M.go('cases'); M.pages.openCase(c.id || r.id); return true; });
      }
    });
  }
  M.pages.openCase = function (id) {
    M.open(function () {
      M.rpc('getCase', { id: id }).then(function (c) {
        if (!c || c.error) { M.drawer('Case', M.errBox(c && c.error)); return; }
        var L = c.links, h = '<div class="row">' + M.chip(c.status) + '</div>' + M.dl([['Title', c.title], ['Judge', c.judge], ['Prosecutor', c.prosecutor], ['Defense', c.defense], ['Outcome', c.outcome], ['Sentence', c.sentence], ['Opened by', c.created_by + ' · ' + M.fday(c.created_at)]]);
        h += M.sec('Parties') + (c.parties.length ? c.parties.map(function (p) { return '<div class="li">' + M.linkPerson(p.identifier, p.name) + '</div>'; }).join('') : '<div class="m">None added.</div>');
        h += M.sec('Linked records') + '<div class="row">' + (L.reports || []).map(function (x) { return '<button class="btn sm" data-r="' + x + '">R-' + x + '</button>'; }).concat((L.citations || []).map(function (x) { return '<button class="btn sm" data-c="' + x + '">C-' + x + '</button>'; })).concat((L.bookings || []).map(function (x) { return '<button class="btn sm" data-b="' + x + '">B-' + x + '</button>'; })).concat((L.evidence || []).map(function (x) { return '<button class="btn sm" data-e="' + x + '">E-' + x + '</button>'; })).join('') + '</div>';
        h += M.sec('Hearings') + M.timeline(c.hearings, function (x) { return [M.fdate(x.at), '', x.note || 'Hearing']; });
        h += M.sec('Appeal history') + M.timeline(c.appeals, function (x) { return [x.by, M.fdate(x.at), x.note]; });
        M.drawer('CASE-' + c.id, h, [
          { text: 'Edit', cls: 'pri', show: c.canManage, fn: function () { editCase(c); } },
          { text: 'Schedule hearing', show: c.canManage, fn: function () { M.form({ title: 'Schedule hearing', submit: 'Schedule', fields: [{ key: 'at', label: 'Date and time', type: 'datetime', req: true }, { key: 'note', label: 'Note', full: true }], onSubmit: function (v) { v.id = id; return M.call('addHearing', v, 'Hearing scheduled.').then(function (r) { if (r) M.pages.openCase(id); return !!r; }); } }); } },
          { text: 'File appeal', show: c.canManage, fn: function () { M.reason('File appeal', 'What was filed?', 'File appeal', function (t) { M.call('addAppeal', { id: id, note: t }, 'Appeal recorded.').then(function () { M.pages.openCase(id); }); }); } }
        ]);
        var d = $('drawer');
        d.querySelectorAll('[data-r]').forEach(function (e) { e.onclick = function () { M.pages.openReport(Number(e.getAttribute('data-r'))); }; });
        d.querySelectorAll('[data-c]').forEach(function (e) { e.onclick = function () { M.pages.openCitation(Number(e.getAttribute('data-c'))); }; });
        d.querySelectorAll('[data-b]').forEach(function (e) { e.onclick = function () { M.pages.openBooking(Number(e.getAttribute('data-b'))); }; });
        d.querySelectorAll('[data-e]').forEach(function (e) { e.onclick = function () { M.pages.openEvidence(Number(e.getAttribute('data-e'))); }; });
      });
    });
  };
})();
