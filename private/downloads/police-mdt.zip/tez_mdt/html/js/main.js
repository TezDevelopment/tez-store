// Shell: navigation, header, search, notifications, messages from the game
(function () {
  var M = window.M, $ = M.$, esc = M.esc, S = M.S;
  var NAV = [
    ['MAIN', [['home', 'Dashboard', 'home'], ['dispatch', 'Dispatch / CAD', 'radio'], ['map', 'Live Map', 'map'], ['notifs', 'Notifications', 'bell']]],
    ['RECORDS', [['persons', 'Person Search', 'user'], ['vehicles', 'Vehicle Search', 'car'], ['warrants', 'Warrants', 'gavel'], ['bolos', 'BOLOs', 'flag'], ['citations', 'Citations', 'ticket'], ['bookings', 'Arrests / Booking', 'cuffs']]],
    ['OPERATIONS', [['reports', 'Incident Reports', 'file'], ['evidence', 'Evidence', 'box'], ['impound', 'Tow / Impound', 'tow'], ['cases', 'Court Cases', 'scale']]],
    ['ADMIN', [['officers', 'Officer Directory', 'users'], ['dept', 'Department', 'shield'], ['settings', 'Settings', 'gear'], ['audit', 'Audit Logs', 'log']]]
  ];
  var TITLES = {};
  var GUARD = { evidence: 'evidence.view', impound: 'vehicle.view', cases: 'case.view', officers: 'officers.view', audit: 'audit.view' };

  function visible(key) { return !GUARD[key] || M.can(GUARD[key]); }
  function buildNav() {
    var h = '';
    NAV.forEach(function (g) {
      var items = g[1].filter(function (i) { return visible(i[0]); });
      if (!items.length) return;
      h += '<div class="ng">' + g[0] + '</div>';
      items.forEach(function (i) { TITLES[i[0]] = i[1]; h += '<button class="nb" data-p="' + i[0] + '">' + M.ico(i[2]) + '<span>' + i[1] + '</span>' + (i[0] === 'dispatch' ? '<b class="bd hidden" id="bd-dispatch"></b>' : '') + '</button>'; });
    });
    $('nav').innerHTML = h;
    $('nav').querySelectorAll('.nb').forEach(function (b) { b.onclick = function () { M.go(b.getAttribute('data-p')); }; });
  }

  M.go = function (page, params) {
    if (!visible(page)) page = 'home';
    S.page = page; S.polls = [];
    $('nav').querySelectorAll('.nb').forEach(function (b) { b.classList.toggle('on', b.getAttribute('data-p') === page); });
    $('title').textContent = TITLES[page] || 'Dashboard';
    if (!M.isOpen()) M.closeDrawer();
    var host = $('page'); host.scrollTop = 0;
    var fn = M.pages[page];
    if (fn) fn(host, params || {});
  };
  // a notification or search hit knows a page and an id
  M.openLink = function (page, id) {
    var open = { warrants: 'openWarrant', bolos: 'openBolo', reports: 'openReport', evidence: 'openEvidence', dispatch: 'openCall', vehicles: 'openVehicle', cases: 'openCase', persons: 'openPerson' }[page];
    if (page && TITLES[page]) M.go(page);
    if (open && id != null) { var v = /^\d+$/.test(String(id)) ? Number(id) : id; setTimeout(function () { M.pages[open](v); }, 60); }
  };

  M.setUnread = function (n) {
    S.unread = n;
    $('bell').innerHTML = M.ico('bell') + (n ? '<b class="bd">' + (n > 9 ? '9+' : n) + '</b>' : '');
  };
  $('bell').onclick = function () { M.go('notifs'); };
  function pollNotifs() { M.rpc('notifications').then(function (r) { if (r && !r.error) M.setUnread(r.unread || 0); }); }
  function pollCalls() {
    M.rpc('getDispatch').then(function (r) {
      var b = $('bd-dispatch'); if (!b || !r || r.error) return;
      var n = (r.calls || []).length; b.textContent = n; b.classList.toggle('hidden', !n);
    });
  }

  // global search
  var gsT;
  $('gs').oninput = function () {
    clearTimeout(gsT);
    var q = $('gs').value.trim(), out = $('gsOut');
    if (q.length < 2) { out.classList.add('hidden'); return; }
    gsT = setTimeout(function () {
      M.rpc('globalSearch', { q: q }).then(function (r) {
        if (!r || r.error) return;
        var h = '', add = function (t, arr, f) { if (arr && arr.length) h += '<div class="gsg">' + t + '</div>' + arr.map(f).join(''); };
        add('PEOPLE', r.people, function (p) { return '<button class="gsi" data-k="persons" data-id="' + esc(p.identifier) + '"><b>' + esc(p.name) + '</b> <span class="m">' + esc(p.dateofbirth || '') + '</span></button>'; });
        add('VEHICLES', r.vehicles, function (v) { return '<button class="gsi" data-k="vehicles" data-id="' + esc(v.plate) + '"><b class="mono">' + esc(v.plate) + '</b></button>'; });
        add('REPORTS', r.reports, function (x) { return '<button class="gsi" data-k="reports" data-id="' + x.id + '">R-' + x.id + ' ' + esc(x.title) + ' ' + M.chip(x.status) + '</button>'; });
        add('CALLS', r.calls, function (x) { return '<button class="gsi" data-k="dispatch" data-id="' + x.id + '">#' + x.id + ' ' + esc(x.msg) + '</button>'; });
        add('BOLOS', r.bolos, function (x) { return '<button class="gsi" data-k="bolos" data-id="' + x.id + '">B-' + x.id + ' ' + esc(x.title) + '</button>'; });
        add('EVIDENCE', r.evidence, function (x) { return '<button class="gsi" data-k="evidence" data-id="' + x.id + '">E-' + x.id + ' ' + esc(x.description) + '</button>'; });
        out.innerHTML = h || '<div class="empty">No results</div>';
        out.classList.remove('hidden');
        out.querySelectorAll('.gsi').forEach(function (b) { b.onclick = function () { out.classList.add('hidden'); $('gs').value = ''; M.openLink(b.getAttribute('data-k'), b.getAttribute('data-id')); }; });
      });
    }, 280);
  };
  document.addEventListener('click', function (e) { if (!e.target.closest('#gsWrap')) $('gsOut').classList.add('hidden'); });

  // clock
  setInterval(function () {
    var d = new Date();
    $('clk').textContent = d.toLocaleTimeString([], { hour12: false });
    $('dte').textContent = d.toLocaleDateString([], { weekday: 'short', month: 'short', day: 'numeric' });
  }, 1000);

  // keyboard
  document.addEventListener('keydown', function (e) {
    if (e.key !== 'Escape') return;
    if (!$('panic').classList.contains('hidden')) { $('panic').classList.add('hidden'); return; }
    if (!$('modal').classList.contains('hidden')) { M.closeModal(); return; }
    if (M.isOpen()) { M.closeDrawer(); return; }
    M.post('close', {});
  });
  $('close').onclick = function () { M.post('close', {}); };

  var timers = [];
  function start(msg) {
    $('root').classList.remove('hidden');
    M.rpc('bootstrap').then(function (b) {
      if (!b || b.error) { M.toast((b && b.error) || 'The MDT could not start. Check the server console.', 'bad'); return; }
      S.cfg = b.cfg; S.me = b.me; S.brand = b.brand;
      $('b-name').textContent = (b.brand && b.brand.name) || 'TEZ POLICE';
      $('b-sub').textContent = (b.brand && b.brand.sub) || 'Mobile Data Terminal';
      $('w-name').textContent = b.me.name; $('w-sub').textContent = (b.me.callsign ? b.me.callsign + ' · ' : '') + b.me.grade;
      try { if (localStorage.getItem('tezmdt:compact') === '1') document.body.classList.add('compact'); } catch (e) { }
      buildNav(); M.setUnread(0); pollNotifs(); pollCalls();
      var page = msg && msg.page && M.pages[msg.page] ? msg.page : 'home';
      M.go(page, { q: msg && msg.q });
      timers.forEach(clearInterval); timers = [
        setInterval(function () { pollNotifs(); pollCalls(); S.polls.forEach(function (f) { try { f(); } catch (e) { } }); }, 12000)
      ];
    });
  }

  var panicCall = null;
  window.addEventListener('message', function (ev) {
    var m = ev.data || {};
    if (m.action === 'open') start(m);
    else if (m.action === 'close') { $('root').classList.add('hidden'); M.closeModal(); M.closeDrawer(); timers.forEach(clearInterval); timers = []; }
    else if (m.action === 'goto' && S.me) M.go(m.page && M.pages[m.page] ? m.page : S.page, { q: m.q });
    else if (m.action === 'newCall') { M.toast('New call: ' + (m.call && m.call.msg || ''), 'warn'); pollCalls(); if (S.page === 'dispatch' || S.page === 'home') M.go(S.page); }
    else if (m.action === 'bolo') { M.toast('New BOLO issued.', 'warn'); pollNotifs(); }
    else if (m.action === 'notif') { M.toast((m.notif && m.notif.title) || 'Notification', 'info'); pollNotifs(); }
    else if (m.action === 'panic') { panicCall = m.call; $('p-who').textContent = m.call ? m.call.caller : ''; $('panic').classList.remove('hidden'); }
  });
  $('p-no').onclick = function () { $('panic').classList.add('hidden'); };
  $('p-go').onclick = function () { if (panicCall) M.rpc('waypointCall', { id: panicCall.id }); $('panic').classList.add('hidden'); if (panicCall) { M.go('dispatch'); M.pages.openCall(panicCall.id); } };
})();
