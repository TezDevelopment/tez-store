// Officer directory, department management, settings, audit log
(function () {
  var M = window.M, $ = M.$, esc = M.esc;

  // ================= OFFICER DIRECTORY =================
  M.pages.officers = function (host, params) {
    M.table(host, {
      sort: 'name', dir: 'asc', placeholder: 'Search name, callsign or badge', q: params && params.q || '',
      filters: [{ key: 'active', label: 'Employment', options: [['on', 'Active'], ['off', 'Separated'], ['all', 'All']] }],
      bar: function (bar) { if (M.can('officers.manage')) { var b = M.el('<button class="btn pri">Onboard officer</button>'); b.onclick = onboard; bar.appendChild(b); } },
      load: function (st) { return M.rpc('listOfficers', M.pay(st)); }, empty: ['No officers found'],
      cols: [{ label: 'Name', sort: 'name', render: function (r) { return '<b>' + esc(r.name) + '</b>'; } }, { label: 'Callsign', sort: 'callsign', render: function (r) { return '<span class="mono">' + esc(r.callsign || '-') + '</span>'; } }, { label: 'Badge', sort: 'badge', render: function (r) { return esc(r.badge || '-'); } }, { label: 'Rank', sort: 'grade', render: function (r) { return esc(r.grade); } }, { label: 'Division', render: function (r) { return esc(r.division || '-'); } }, { label: 'Supervisor', render: function (r) { return esc(r.supervisor || '-'); } }, { label: 'Duty', render: function (r) { return r.active == 0 ? M.chip('closed', 'Separated') : (r.online ? M.chip('active', 'In city') : M.chip('stored', 'Offline')); } }],
      onRow: function (r) { M.pages.openOfficer(r.identifier); }
    });
  };
  function onboard() {
    M.form({ title: 'Onboard officer', submit: 'Onboard', fields: [{ key: 'id', label: 'Citizen', type: 'person', req: true, hint: 'They start at the lowest rank.' }, { key: 'badge', label: 'Badge number' }, { key: 'division', label: 'Division' }],
      onSubmit: function (v) { return M.call('hireOfficer', v, 'Officer onboarded.').then(function (r) { if (r) M.go('officers'); return !!r; }); } });
  }
  M.pages.openOfficer = function (id) {
    M.open(function () {
      M.rpc('getOfficer', { id: id }).then(function (o) {
        if (!o || o.error) { M.drawer('Officer', M.errBox(o && o.error)); return; }
        var h = '<div class="row">' + (o.active == 0 ? M.chip('closed', 'Separated') : M.chip('active', 'Employed')) + '<span class="chip info">' + esc(o.grade) + '</span></div>' +
          M.dl([['Name', o.name], ['Callsign', o.callsign], ['Badge', o.badge], ['Division', o.division], ['Supervisor', o.supervisor], ['Certifications', o.certs], ['Permission role', (o.roles.filter(function (r) { return r.id === o.role; })[0] || {}).label || 'By rank'], ['Notes', o.note]]);
        h += M.sec('Recent activity') + M.timeline(o.activity, function (a) { return [a.action, M.fdate(a.at), a.details]; });
        M.drawer(o.name, h, [
          { text: 'Edit details', cls: 'pri', show: o.canManage, fn: function () { edit(o); } },
          { text: 'Change rank', show: o.canManage, fn: function () { M.form({ title: 'Change rank', submit: 'Set rank', values: { grade: o.gradeNum }, fields: [{ key: 'grade', label: 'New rank', type: 'select', options: o.grades.map(function (g) { return [g.grade, g.label]; }) }], onSubmit: function (v) { return M.call('setRank', { id: id, grade: Number(v.grade) }, 'Rank changed.').then(function (r) { if (r) M.pages.openOfficer(id); return !!r; }); } }); } },
          { text: 'Separate', cls: 'danger', show: o.canManage && o.active != 0, fn: function () { M.reason('Separate officer', 'Reason for the record', 'Separate', function (t) { M.call('separateOfficer', { id: id, reason: t }, 'Officer separated.').then(function () { M.closeDrawer(); M.go('officers'); }); }); } }
        ]);
      });
    });
  };
  function edit(o) {
    M.form({
      title: 'Edit ' + o.name, submit: 'Save', wide: true, values: { callsign: o.callsign, badge: o.badge, division: o.division, supervisor: o.supervisor, role: o.role || '', certs: o.certs, note: o.note, active: o.active != 0 },
      fields: [{ key: 'callsign', label: 'Callsign', max: 12 }, { key: 'badge', label: 'Badge number', max: 12 }, { key: 'division', label: 'Division' }, { key: 'supervisor', label: 'Supervisor' },
        { key: 'role', label: 'Permission role', type: 'select', options: [['', 'By rank (default)']].concat(o.roles.map(function (r) { return [r.id, r.label]; })) }, { key: 'active', label: 'Employment', type: 'checkbox', text: 'Active' }, { key: 'certs', label: 'Certifications', full: true }, { key: 'note', label: 'Notes', full: true }],
      onSubmit: function (v) { v.id = o.identifier; return M.call('updateOfficer', v, 'Saved.').then(function (r) { if (r) M.pages.openOfficer(o.identifier); return !!r; }); }
    });
  }

  // ================= DEPARTMENT MANAGEMENT =================
  M.pages.dept = function (host) {
    host.innerHTML = '<div class="bar"><b>Announcements</b><span class="sp"></span>' + (M.can('dept.manage') ? '<button class="btn pri" id="na">New announcement</button>' : '') + '</div><div id="al">' + M.loading() + '</div>' +
      '<div class="sec">Roles and permissions</div><div id="rl"></div>';
    function load() {
      M.rpc('listAnnouncements').then(function (r) {
        if (!r || r.error) { $('al').innerHTML = M.errBox(r && r.error); return; }
        $('al').innerHTML = r.rows.length ? r.rows.map(function (a) { return '<div class="card" style="margin-bottom:8px"><div class="row"><b>' + (a.pinned ? '📌 ' : '') + esc(a.title) + '</b><span class="sp"></span><span class="m">' + esc(a.by_name) + ' · ' + M.fdate(a.created_at) + (a.expires_at ? ' · expires ' + M.fday(a.expires_at) : '') + '</span>' + (r.canManage ? '<button class="btn sm danger" data-d="' + a.id + '">Remove</button>' : '') + '</div><div style="white-space:pre-wrap">' + esc(a.body) + '</div></div>'; }).join('') : M.empty('No announcements', 'Post one for the whole department.');
        $('al').querySelectorAll('[data-d]').forEach(function (b) { b.onclick = function () { M.confirm('Remove announcement?', 'It disappears for everyone.', 'Remove', function () { M.call('deleteAnnouncement', { id: Number(b.getAttribute('data-d')) }, 'Removed.').then(load); }, true); }; });
      });
    }
    load();
    var na = $('na'); if (na) na.onclick = function () {
      M.form({ title: 'New announcement', submit: 'Post', draft: 'announce', fields: [{ key: 'title', label: 'Title', req: true, full: true, max: 120 }, { key: 'body', label: 'Message', type: 'textarea', req: true, rows: 5 }, { key: 'days', label: 'Show for (days, blank = until removed)', type: 'number', min: 1 }, { key: 'pinned', label: 'Pin to the top', type: 'checkbox', text: 'Pinned' }],
        onSubmit: function (v) { return M.call('createAnnouncement', v, 'Announcement posted.').then(function (r) { if (r) load(); return !!r; }); } });
    };
    if (M.can('settings.view')) {
      M.rpc('getSettings').then(function (s) {
        if (!s || s.error) return;
        $('rl').innerHTML = '<div class="grid g2e">' + s.roles.map(function (r) { return '<div class="card"><h3>' + esc(r.label) + '</h3>' + (r.inherit ? '<div class="note">Includes everything from ' + esc(r.inherit) + '.</div>' : '') + '<div class="row">' + (r.perms || []).map(function (p) { return '<span class="chip mute">' + esc(p) + '</span>'; }).join('') + '</div></div>'; }).join('') + '</div>';
      });
    } else $('rl').innerHTML = '<div class="m">Command can view the role list.</div>';
  };

  // ================= SETTINGS =================
  M.pages.settings = function (host) {
    var compact = false, sound = true;
    try { compact = localStorage.getItem('tezmdt:compact') === '1'; sound = localStorage.getItem('tezmdt:quiet') !== '1'; } catch (e) { }
    host.innerHTML = '<div class="grid g2e"><div class="card"><h3>Your display</h3><label class="chk"><input type="checkbox" id="sc"' + (compact ? ' checked' : '') + '><span>Compact tables</span></label><div class="note">Saved on this computer only.</div></div><div class="card"><h3>Department settings</h3><div id="ds">' + M.loading() + '</div></div></div>';
    $('sc').onchange = function () { document.body.classList.toggle('compact', $('sc').checked); try { localStorage.setItem('tezmdt:compact', $('sc').checked ? '1' : '0'); } catch (e) { } };
    if (!M.can('settings.view')) { $('ds').innerHTML = '<div class="m">Command and administrators can view the department settings.</div>'; return; }
    M.rpc('getSettings').then(function (s) {
      if (!s || s.error) { $('ds').innerHTML = M.errBox(s && s.error); return; }
      $('ds').innerHTML = M.dl([['Police jobs', s.jobs.join(', ')], ['Warrant approval', s.warrantApproval ? 'Required' : 'Not required'], ['Warrant length', s.warrantDays + ' days'], ['Court cases', s.court ? 'On' : 'Off'], ['Charges in catalogue', s.charges], ['Keep calls', s.retention.calls + ' days'], ['Keep audit log', s.retention.log + ' days'], ['Keep notifications', s.retention.notifications + ' days']]) + '<div class="note">' + esc(s.note) + '</div>';
    });
  };

  // ================= AUDIT LOG =================
  M.pages.audit = function (host, params) {
    M.rpc('auditActions').then(function (a) {
      var acts = [['all', 'All actions']].concat(((a && a.actions) || []).map(function (x) { return [x, x]; }));
      M.table(host, {
        sort: 'at', placeholder: 'Search officer or details', q: params && params.q || '',
        filters: [{ key: 'action', label: 'Action', options: acts }, { key: 'hideViews', label: 'Views', options: [['1', 'Hide views'], ['', 'Show views']] }],
        load: function (st) { var p = M.pay(st); p.hideViews = st.f.hideViews === '1'; return M.rpc('listAudit', p); }, empty: ['Nothing logged'],
        cols: [{ label: 'Time', sort: 'at', render: function (r) { return M.fdate(r.at); } }, { label: 'Officer', sort: 'officer', render: function (r) { return esc(r.officer); } }, { label: 'Action', sort: 'action', render: function (r) { return '<span class="chip info">' + esc(r.action) + '</span>'; } }, { label: 'Details', render: function (r) { return esc(r.details); } }, { label: 'Record', render: function (r) { return r.entity ? '<span class="m mono">' + esc(r.entity) + ' ' + esc(r.entity_id || '') + '</span>' : ''; } }]
      });
    });
  };
})();
