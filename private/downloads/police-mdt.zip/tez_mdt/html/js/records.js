// Person, vehicle, warrant, BOLO, citation and booking pages
(function () {
  var M = window.M, $ = M.$, esc = M.esc;
  var money = M.money;

  function summaryOf(title, lines) { return title + '\n' + lines.filter(Boolean).join('\n'); }
  function copyBtn(fn) { return { text: 'Copy summary', fn: function () { M.copy(fn()); } }; }
  function charges(l) { return (l || []).map(function (c) { return typeof c === 'string' ? c : c.label; }).join(', '); }

  // ================= PEOPLE =================
  M.pages.persons = function (host, params) {
    M.table(host, {
      q: params && params.q || '', sort: 'name', dir: 'asc', placeholder: 'Name, ID, date of birth, phone, address, or DNA-/FNG-/BAL- code',
      empty: ['Search for a person', 'Type at least two characters. You can also search a DNA, fingerprint or ballistic code.'],
      load: function (st) { return st.q.length < 2 ? Promise.resolve({ rows: [], total: 0, pages: 1 }) : M.rpc('searchPersons', M.pay(st)); },
      cols: [
        { label: 'Name', sort: 'name', render: function (r) { return '<b>' + esc(r.name) + '</b>'; } }, { label: 'Date of birth', render: function (r) { return esc(r.dob || '-'); } },
        { label: 'Phone', render: function (r) { return esc(r.phone || '-'); } }, { label: 'Address', render: function (r) { return esc(r.address || '-'); } },
        { label: 'Alerts', render: function (r) { return (r.warrants ? '<span class="chip bad">' + r.warrants + ' warrant' + (r.warrants > 1 ? 's' : '') + '</span> ' : '') + (r.flags ? '<span class="chip warn">' + r.flags + ' flag' + (r.flags > 1 ? 's' : '') + '</span>' : (r.warrants ? '' : '<span class="m">None</span>')); } }
      ],
      onRow: function (r) { M.pages.openPerson(r.identifier); }
    });
  };

  M.pages.openPerson = function (id, tab) {
    M.open(function () {
      M.rpc('getPerson', { identifier: id }).then(function (p) {
        if (!p || p.error) { M.drawer('Person', M.errBox(p && p.error)); return; }
        var cur = tab || 'overview';
        var tabs = [['overview', 'Overview'], ['records', 'History', p.records.length], ['cites', 'Citations', p.citations.length], ['book', 'Arrests', p.bookings.length], ['war', 'Warrants', p.warrants.length], ['veh', 'Vehicles', p.vehicles.length], ['rep', 'Reports', p.reports.length], ['bio', 'Forensics']];
        if (p.cases && p.cases.length) tabs.push(['cases', 'Cases', p.cases.length]);
        if (p.access) tabs.push(['acc', 'Access log']);
        function draw() {
          var b = (p.alerts || []).map(function (a) { return '<div class="alert ' + (a.level === 'danger' ? 'danger' : 'warn') + '">⚠ ' + esc(a.text) + '</div>'; }).join('');
          b += '<div class="tabs">' + tabs.map(function (t) { return '<button class="tab ' + (cur === t[0] ? 'on' : '') + '" data-t="' + t[0] + '">' + t[1] + (t[2] ? '<span class="n">' + t[2] + '</span>' : '') + '</button>'; }).join('') + '</div><div id="pt"></div>';
          M.drawer(p.name, b, [
            { text: 'New citation', show: M.can('citation.create'), fn: function () { M.pages.newCitation({ identifier: p.identifier, name: p.name }); } },
            { text: 'Book / arrest', show: M.can('booking.create'), cls: 'pri', fn: function () { M.pages.newBooking({ identifier: p.identifier, name: p.name }); } },
            { text: 'Warrant', show: M.can('warrant.create'), fn: function () { M.pages.newWarrant({ identifier: p.identifier, name: p.name }); } },
            { text: 'Flag', show: M.can('person.edit'), fn: function () { flagPerson(p); } }
          ]);
          $('drawer').querySelectorAll('[data-t]').forEach(function (t) { t.onclick = function () { cur = t.getAttribute('data-t'); draw(); }; });
          body();
        }
        function listOf(items, f) { return items.length ? items.map(f).join('') : '<div class="m">Nothing on record.</div>'; }
        function body() {
          var h = '', t = $('pt');
          if (cur === 'overview') {
            var m = p.meta || {};
            h = M.sec('Verified server data') + M.dl([['Legal name', p.name + ' <span class="verified">server</span>', true], ['Server ID', p.identifier], ['Date of birth', p.dob], ['Sex', p.sex], ['Height', p.height], ['Occupation', p.job], ['Phone', p.serverPhone], ['Licences', (p.licenses || []).join(', ') || 'None on file'], ['Licence points', p.points + ' / ' + M.S.cfg.suspendPoints + (p.suspended ? ' (suspended)' : '')]]);
            h += M.sec('Officer-entered details') + M.dl([['Phone', m.phone], ['Address', m.address], ['Aliases', m.aliases], ['Notes', m.note], ['Last updated', m.updated_at ? M.fdate(m.updated_at) + ' by ' + (m.updated_by || '') : 'Never']]);
            if (M.can('person.edit')) h += '<button class="btn" id="em">Edit officer-entered details</button>';
            h += M.sec('Flags') + listOf(p.flags, function (f) { return '<div class="li row"><span class="chip warn">' + esc(f.label) + '</span><span class="sp">' + esc(f.note || '') + ' <span class="m">' + esc(f.by_name) + ' · ' + M.ago(f.created_at) + '</span></span>' + (M.can('person.edit') ? '<button class="btn sm" data-uf="' + f.id + '">Clear</button>' : '') + '</div>'; });
            h += '<div style="margin-top:12px"><button class="btn sm" id="cp">Copy profile summary</button></div>';
          } else if (cur === 'records') h = listOf(p.records, function (r) { return '<div class="li"><div class="row"><b>' + esc(r.title) + '</b> ' + (r.voided ? '<span class="chip bad">Voided</span>' : '') + '<span class="sp"></span><span class="m">' + M.fdate(r.created_at) + '</span></div><div class="m">' + esc(charges(r.charges)) + (r.fine ? ' · ' + money(r.fine) : '') + (r.jail ? ' · ' + r.jail + ' min' : '') + ' · ' + esc(r.officer_name) + '</div></div>'; });
          else if (cur === 'cites') h = listOf(p.citations, function (c) { return '<div class="li clk" data-c="' + c.id + '"><div class="row"><b>C-' + c.id + '</b> ' + M.chip(c.status) + '<span class="sp"></span>' + money(c.fine) + '</div><div class="m">' + esc(charges(c.violations)) + ' · ' + M.fdate(c.created_at) + '</div></div>'; });
          else if (cur === 'book') h = listOf(p.bookings, function (c) { return '<div class="li clk" data-b="' + c.id + '"><div class="row"><b>B-' + c.id + '</b> ' + M.chip(c.status) + '<span class="sp"></span><span class="m">' + esc(c.disposition || '') + '</span></div><div class="m">' + esc(charges(c.charges)) + ' · ' + M.fdate(c.created_at) + '</div></div>'; });
          else if (cur === 'war') h = listOf(p.warrants, function (w) { return '<div class="li clk" data-w="' + w.id + '"><div class="row"><b>W-' + w.id + '</b> ' + M.chip(w.status) + ' <span class="m">' + esc(M.label(M.S.cfg.warrantTypes, w.type)) + '</span><span class="sp"></span><span class="m">' + M.fdate(w.created_at) + '</span></div><div class="m">' + esc(w.reason) + '</div></div>'; });
          else if (cur === 'veh') h = listOf(p.vehicles, function (v) { return '<div class="li clk" data-v="' + esc(v.plate) + '"><div class="row"><b class="mono">' + esc(v.plate) + '</b><span class="sp"></span>' + (v.flag ? '<span class="chip bad">' + esc(v.flag) + '</span> ' : '') + (v.impounded ? '<span class="chip warn">Impounded</span>' : '') + '</div><div class="m">' + esc(M.vname(v)) + ' · ' + esc(M.colorName(v.color)) + '</div></div>'; });
          else if (cur === 'rep') h = listOf(p.reports, function (r) { return '<div class="li clk" data-r="' + r.id + '"><div class="row"><b>R-' + r.id + '</b> ' + M.chip(r.status) + '<span class="sp"></span><span class="m">' + M.fdate(r.created_at) + '</span></div>' + esc(r.title) + '</div>'; });
          else if (cur === 'cases') h = listOf(p.cases, function (c) { return '<div class="li clk" data-k="' + c.id + '"><b>Case ' + c.id + '</b> ' + M.chip(c.status) + ' ' + esc(c.title) + '</div>'; });
          else if (cur === 'acc') h = M.timeline(p.access, function (a) { return [a.officer, M.fdate(a.at), a.details]; });
          else if (cur === 'bio') {
            h = M.sec('DNA') + (p.dna ? '<div class="li"><b class="mono">' + esc(p.dna.code) + '</b><div class="m">Taken by ' + esc(p.dna.taken_by) + ' · ' + M.fdate(p.dna.taken_at) + '</div></div>' : '<div class="m">No sample on file.</div>') +
              M.sec('Fingerprints') + (p.prints ? '<div class="li"><b class="mono">' + esc(p.prints.code) + '</b><div class="m">Taken by ' + esc(p.prints.taken_by) + ' · ' + M.fdate(p.prints.taken_at) + '</div></div>' : '<div class="m">No prints on file.</div>') +
              (M.can('person.edit') ? '<div class="row" style="margin-top:8px"><button class="btn sm" data-bio="takeDNA">Take DNA</button><button class="btn sm" data-bio="takePrints">Take prints</button><button class="btn sm" data-bio="testGSR">Test GSR</button></div><div class="note">The person must be online and close to you.</div>' : '') +
              M.sec('Registered weapons') + listOf(p.weapons, function (w) { return '<div class="li row"><span class="sp"><b>' + esc(w.label) + '</b> <span class="mono m">' + esc(w.code) + '</span><div class="m">Registered by ' + esc(w.registered_by) + ' · ' + M.fdate(w.created_at) + '</div></span>' + (M.can('record.delete') ? '<button class="btn sm" data-rw="' + w.id + '">Remove</button>' : '') + '</div>'; }) +
              (M.can('person.edit') ? '<button class="btn sm" id="aw" style="margin-top:6px">Register weapon</button>' : '');
          }
          t.innerHTML = h;
          t.querySelectorAll('[data-c]').forEach(function (e) { e.onclick = function () { M.pages.openCitation(Number(e.getAttribute('data-c'))); }; });
          t.querySelectorAll('[data-b]').forEach(function (e) { e.onclick = function () { M.pages.openBooking(Number(e.getAttribute('data-b'))); }; });
          t.querySelectorAll('[data-w]').forEach(function (e) { e.onclick = function () { M.pages.openWarrant(Number(e.getAttribute('data-w'))); }; });
          t.querySelectorAll('[data-v]').forEach(function (e) { e.onclick = function () { M.pages.openVehicle(e.getAttribute('data-v')); }; });
          t.querySelectorAll('[data-r]').forEach(function (e) { e.onclick = function () { M.pages.openReport(Number(e.getAttribute('data-r'))); }; });
          t.querySelectorAll('[data-k]').forEach(function (e) { e.onclick = function () { M.pages.openCase(Number(e.getAttribute('data-k'))); }; });
          t.querySelectorAll('[data-uf]').forEach(function (e) { e.onclick = function () { M.call('unflagPerson', { id: Number(e.getAttribute('data-uf')) }, 'Flag cleared.').then(function () { M.pages.openPerson(id, cur); }); }; });
          t.querySelectorAll('[data-rw]').forEach(function (e) { e.onclick = function () { M.confirm('Remove weapon registration?', 'This removes the record. It cannot be undone.', 'Remove', function () { M.call('removeWeapon', { id: Number(e.getAttribute('data-rw')) }, 'Removed.').then(function () { M.pages.openPerson(id, cur); }); }, true); }; });
          t.querySelectorAll('[data-bio]').forEach(function (e) { e.onclick = function () { M.call(e.getAttribute('data-bio'), { identifier: id }).then(function (r) { if (!r) return; M.toast(e.getAttribute('data-bio') === 'testGSR' ? (r.positive ? 'GSR test POSITIVE (' + r.minutes + ' min ago).' : 'GSR test negative.') : 'Sample recorded.', 'ok'); M.pages.openPerson(id, 'bio'); }); }; });
          var em = $('em'); if (em) em.onclick = function () { editMeta(p); };
          var aw = $('aw'); if (aw) aw.onclick = function () { M.form({ title: 'Register weapon', submit: 'Register', fields: [{ key: 'weapon', label: 'Weapon', type: 'select', options: M.S.cfg.weapons.map(function (w) { return [w.name, w.label]; }) }], onSubmit: function (v) { v.identifier = id; return M.call('registerWeapon', v, 'Weapon registered.').then(function (r) { if (r) M.pages.openPerson(id, 'bio'); return !!r; }); } }); };
          var cp = $('cp'); if (cp) cp.onclick = function () { M.copy(summaryOf('PERSON: ' + p.name, ['ID: ' + p.identifier, 'DOB: ' + (p.dob || '-'), 'Active warrants: ' + p.warrants.filter(function (w) { return w.status === 'active'; }).length, 'Flags: ' + (p.flags.map(function (f) { return f.label; }).join(', ') || 'None'), 'Licence points: ' + p.points])); };
        }
        draw();
      });
    });
  };
  function editMeta(p) {
    var m = p.meta || {};
    M.form({
      title: 'Officer-entered details', submit: 'Save', values: m,
      fields: [{ key: 'phone', label: 'Phone' }, { key: 'address', label: 'Address' }, { key: 'aliases', label: 'Aliases', full: true }, { key: 'note', label: 'Notes', type: 'textarea', hint: 'These are officer notes, not server data.' }],
      onSubmit: function (v) { v.identifier = p.identifier; v.expected = m.updated_at || null; return M.call('savePersonMeta', v, 'Saved.').then(function (r) { if (r) M.pages.openPerson(p.identifier); return !!r; }); }
    });
  }
  function flagPerson(p) {
    M.form({ title: 'Flag ' + p.name, submit: 'Add flag', fields: [{ key: 'flag', label: 'Flag', type: 'select', options: M.S.cfg.citizenFlags.map(function (f) { return [f.id, f.label]; }) }, { key: 'note', label: 'Note', hint: 'Why is this flag needed?' }],
      onSubmit: function (v) { v.identifier = p.identifier; return M.call('flagPerson', v, 'Flag added.').then(function (r) { if (r) M.pages.openPerson(p.identifier); return !!r; }); } });
  }

  // ================= VEHICLES =================
  M.pages.vehicles = function (host, params) {
    var tbl;
    tbl = M.table(host, {
      q: params && params.q || '', sort: 'plate', dir: 'asc', placeholder: 'Plate, VIN or owner name',
      empty: ['Search for a vehicle', 'Type a plate, a VIN (starts with TZ) or the owner name.'],
      load: function (st) { return st.q.length < 2 ? Promise.resolve({ rows: [], total: 0, pages: 1 }) : M.rpc('searchVehicles', M.pay(st)); },
      after: function (res) { if (res.unregistered && !res.rows.length) setTimeout(function () { M.pages.openVehicle(res.unregistered.plate); }, 0); },
      bar: function (bar) {
        var f = M.el('<input type="text" id="vf" placeholder="Filter these results by model or colour" aria-label="Filter results by model or colour" style="min-width:260px">');
        bar.appendChild(f); f.oninput = function () { tbl.reload(); };
      },
      clientFilter: function (r) { var f = ($('vf') && $('vf').value || '').toLowerCase(); return !f || (M.vname(r) + ' ' + M.colorName(r.color)).toLowerCase().indexOf(f) >= 0; },
      cols: [
        { label: 'Plate', sort: 'plate', render: function (r) { return '<b class="mono">' + esc(r.plate) + '</b>'; } }, { label: 'Vehicle', render: function (r) { return esc(M.vname(r)); } },
        { label: 'Colour', render: function (r) { return esc(M.colorName(r.color)); } }, { label: 'Owner', render: function (r) { return M.linkPerson(r.ownerIdentifier, r.owner); } },
        { label: 'Status', render: function (r) { return (r.flag ? '<span class="chip bad">' + esc(r.flag.label) + '</span> ' : '') + (r.bolo ? '<span class="chip warn">BOLO</span> ' : '') + (r.impounded ? '<span class="chip warn">Impounded</span> ' : '') + (r.registration !== 'valid' ? '<span class="chip warn">Reg ' + esc(r.registration) + '</span> ' : '') + (!r.flag && !r.bolo && !r.impounded && r.registration === 'valid' ? '<span class="chip ok">Clear</span>' : ''); } }
      ],
      onRow: function (r) { M.pages.openVehicle(r.plate); }
    });
    var note = M.el('<div class="note">Model and colour are matched on this page only. The server search covers plate, VIN and owner.</div>'); host.appendChild(note);
  };
  M.pages.openVehicle = function (plate) {
    M.open(function () {
      M.rpc('getVehicle', { plate: plate }).then(function (v) {
        if (!v || v.error) { M.drawer('Vehicle', M.errBox(v && v.error)); return; }
        var veh = v.vehicle || {}, meta = v.meta || {}, b = '';
        if (v.flag) b += '<div class="alert danger">⚠ ' + esc(v.flag.label) + (v.flag.note ? ': ' + esc(v.flag.note) : '') + '</div>';
        (v.bolos || []).forEach(function (x) { b += '<div class="alert warn">Active BOLO B-' + x.id + ': ' + esc(x.title) + '</div>'; });
        if (veh.impounded) b += '<div class="alert warn">Currently impounded</div>';
        if (!v.registered) b += '<div class="alert info">This plate is not registered in the city database.</div>';
        b += M.sec('Verified server data') + M.dl([['Plate', v.plate], ['Make / model', v.registered ? M.vname(veh) : ''], ['Colour', v.registered ? M.colorName(veh.color) : ''], ['VIN', veh.vin], ['Registered owner', veh.ownerIdentifier ? M.linkPerson(veh.ownerIdentifier, veh.owner) : '', true]]);
        b += M.sec('Officer-entered status') + M.dl([['Registration', meta.registration || 'valid'], ['Insurance', meta.insurance || 'valid'], ['Notes', meta.note], ['Last updated', meta.updated_at ? M.fdate(meta.updated_at) + ' by ' + (meta.updated_by || '') : 'Never']]);
        b += M.sec('Impound history') + (v.impounds.length ? v.impounds.map(function (i) { return '<div class="li"><b>I-' + i.id + '</b> ' + M.chip(i.status) + ' ' + esc(i.reason) + '<div class="m">' + M.fdate(i.created_at) + (i.fee ? ' · ' + money(i.fee) : '') + '</div></div>'; }).join('') : '<div class="m">None.</div>');
        b += M.sec('Citations') + (v.citations.length ? v.citations.map(function (c) { return '<div class="li clk" data-c="' + c.id + '"><b>C-' + c.id + '</b> ' + M.chip(c.status) + ' ' + esc(c.person_name) + ' <span class="m">' + money(c.fine) + '</span></div>'; }).join('') : '<div class="m">None.</div>');
        b += M.sec('Linked reports') + (v.reports.length ? v.reports.map(function (r) { return '<div class="li clk" data-r="' + r.id + '"><b>R-' + r.id + '</b> ' + esc(r.title) + '</div>'; }).join('') : '<div class="m">None.</div>');
        M.drawer(v.plate, b, [
          { text: 'Edit status / notes', show: M.can('vehicle.edit'), fn: function () { editVMeta(v); } },
          { text: v.flag ? 'Clear flag' : 'Flag vehicle', show: M.can('vehicle.edit'), fn: function () { if (v.flag) M.call('unflagVehicle', { plate: v.plate }, 'Flag cleared.').then(function () { M.pages.openVehicle(v.plate); }); else flagVeh(v); } },
          { text: 'New BOLO', show: M.can('bolo.create'), fn: function () { M.pages.editBolo({ kind: 'vehicle', plate: v.plate }); } },
          { text: 'Impound', show: M.can('impound.create'), fn: function () { M.pages.newImpound(v.plate); } },
          { text: 'Citation', show: M.can('citation.create') && veh.ownerIdentifier, fn: function () { M.pages.newCitation({ identifier: veh.ownerIdentifier, name: veh.owner }, v.plate); } }
        ]);
        $('drawer').querySelectorAll('[data-c]').forEach(function (e) { e.onclick = function () { M.pages.openCitation(Number(e.getAttribute('data-c'))); }; });
        $('drawer').querySelectorAll('[data-r]').forEach(function (e) { e.onclick = function () { M.pages.openReport(Number(e.getAttribute('data-r'))); }; });
      });
    });
  };
  function editVMeta(v) {
    var m = v.meta || {};
    M.form({
      title: 'Vehicle status for ' + v.plate, submit: 'Save', values: m,
      fields: [{ key: 'registration', label: 'Registration', type: 'select', options: [['valid', 'Valid'], ['expired', 'Expired'], ['suspended', 'Suspended'], ['none', 'None']] }, { key: 'insurance', label: 'Insurance', type: 'select', options: [['valid', 'Valid'], ['expired', 'Expired'], ['none', 'None']] }, { key: 'note', label: 'Notes', type: 'textarea', hint: 'Officer-entered. Not verified server data.' }],
      onSubmit: function (x) { x.plate = v.plate; x.expected = m.updated_at || null; return M.call('saveVehicleMeta', x, 'Saved.').then(function (r) { if (r) M.pages.openVehicle(v.plate); return !!r; }); }
    });
  }
  function flagVeh(v) {
    M.form({ title: 'Flag ' + v.plate, submit: 'Flag vehicle', fields: [{ key: 'flag', label: 'Flag', type: 'select', options: M.S.cfg.vehicleFlags.map(function (f) { return [f.id, f.label]; }) }, { key: 'note', label: 'Note' }],
      onSubmit: function (x) { x.plate = v.plate; return M.call('flagVehicle', x, 'Vehicle flagged.').then(function (r) { if (r) M.pages.openVehicle(v.plate); return !!r; }); } });
  }

  // ================= WARRANTS =================
  var WSTAT = [['active', 'Active'], ['pending', 'Pending approval'], ['draft', 'My drafts'], ['served', 'Served'], ['expired', 'Expired'], ['recalled', 'Recalled'], ['denied', 'Denied'], ['all', 'All']];
  M.pages.warrants = function (host, params) {
    M.table(host, {
      sort: 'created', placeholder: 'Search by name or W-number', q: params && params.q || '',
      filters: [{ key: 'status', label: 'Status', options: WSTAT, value: params && params.status || 'active' }],
      bar: function (bar) { if (M.can('warrant.create')) { var b = M.el('<button class="btn pri">New warrant</button>'); b.onclick = function () { M.pages.newWarrant(); }; bar.appendChild(b); } },
      load: function (st) { return M.rpc('listWarrants', M.pay(st)); }, empty: ['No warrants match', 'Change the status filter to see more.'],
      cols: [{ label: 'ID', sort: 'id', render: function (r) { return 'W-' + r.id; } }, { label: 'Subject', sort: 'name', render: function (r) { return M.linkPerson(r.citizen_identifier, r.citizen_name); } }, { label: 'Type', sort: 'type', render: function (r) { return esc(M.label(M.S.cfg.warrantTypes, r.type)); } }, { label: 'Status', sort: 'status', render: function (r) { return M.chip(r.status); } }, { label: 'Issued by', render: function (r) { return esc(r.issued_by); } }, { label: 'Expires', sort: 'expires', render: function (r) { return r.expires_at ? M.fday(r.expires_at) : '-'; } }, { label: 'Created', sort: 'created', render: function (r) { return M.fdate(r.created_at); } }],
      onRow: function (r) { M.pages.openWarrant(r.id); }
    });
  };
  M.pages.newWarrant = function (person) {
    M.form({
      title: 'New warrant', submit: M.S.cfg.warrantApproval && !M.can('warrant.approve') ? 'Submit for approval' : 'Issue warrant', draft: 'warrant', wide: true,
      values: { identifier: person, type: 'arrest', days: 14 },
      extraButtons: [{ text: 'Save as draft', extra: { draft: true } }],
      fields: [{ key: 'identifier', label: 'Subject', type: 'person', req: true }, { key: 'type', label: 'Warrant type', type: 'select', options: M.S.cfg.warrantTypes.map(function (t) { return [t.id, t.label]; }) },
        { key: 'reason', label: 'Legal basis / roleplay reason', type: 'textarea', req: true, rows: 5, hint: 'At least a full sentence.' }, { key: 'days', label: 'Valid for (days)', type: 'number', min: 1, max: 365 }, { key: 'report_id', label: 'Linked report number', type: 'number' }],
      onSubmit: function (v) { return M.call('createWarrant', v, 'Warrant saved.').then(function (r) { if (r) { if (M.S.page === 'warrants') M.go('warrants', { status: r.status }); M.pages.openWarrant(r.id); } return !!r; }); }
    });
  };
  M.pages.openWarrant = function (id) {
    M.open(function () {
      M.rpc('getWarrant', { id: id }).then(function (w) {
        if (!w || w.error) { M.drawer('Warrant', M.errBox(w && w.error)); return; }
        var mine = w.issued_by_identifier === M.S.me.identifier;
        var b = '<div class="row">' + M.chip(w.status) + '</div>' + M.dl([['Subject', M.linkPerson(w.citizen_identifier, w.citizen_name), true], ['Type', M.label(M.S.cfg.warrantTypes, w.type)], ['Legal basis', w.reason], ['Issued by', w.issued_by], ['Approved by', w.approved_by ? w.approved_by + ' · ' + M.fdate(w.approved_at) : ''], ['Created', M.fdate(w.created_at)], ['Expires', w.expires_at ? M.fday(w.expires_at) : ''], ['Report', w.report_id ? '<a href="#" id="wr">R-' + w.report_id + '</a>' : '', true], ['Outcome', w.outcome], ['Note', w.note]]);
        b += M.sec('History') + M.timeline(w.history, function (h) { return [h.officer, M.fdate(h.at), h.details]; });
        M.drawer('Warrant W-' + w.id, b, [
          { text: 'Submit', cls: 'pri', show: w.status === 'draft' && mine, fn: function () { M.call('submitWarrant', { id: id }, 'Submitted.').then(function () { M.pages.openWarrant(id); }); } },
          { text: 'Edit', show: (w.status === 'draft' || w.status === 'pending') && (mine || w.canApprove), fn: function () { M.form({ title: 'Edit warrant W-' + id, submit: 'Save', values: { type: w.type, reason: w.reason, report_id: w.report_id }, fields: [{ key: 'type', label: 'Type', type: 'select', options: M.S.cfg.warrantTypes.map(function (t) { return [t.id, t.label]; }) }, { key: 'reason', label: 'Legal basis', type: 'textarea', req: true, rows: 5 }, { key: 'report_id', label: 'Report number', type: 'number' }], onSubmit: function (v) { v.id = id; v.expected = w.updated_at; return M.call('updateWarrant', v, 'Saved.').then(function (r) { if (r) M.pages.openWarrant(id); return !!r; }); } }); } },
          { text: 'Approve', cls: 'ok', show: w.status === 'pending' && w.canApprove, fn: function () { M.call('approveWarrant', { id: id, expected: w.updated_at }, 'Approved.').then(function () { M.pages.openWarrant(id); }); } },
          { text: 'Deny', cls: 'danger', show: w.status === 'pending' && w.canApprove, fn: function () { M.reason('Deny warrant', 'Why is it denied?', 'Deny', function (t) { M.call('denyWarrant', { id: id, reason: t }, 'Denied.').then(function () { M.pages.openWarrant(id); }); }); } },
          { text: 'Mark served', cls: 'ok', show: w.status === 'active' && M.can('person.edit'), fn: function () { M.reason('Serve warrant', 'How was it served?', 'Mark served', function (t) { M.call('serveWarrant', { id: id, outcome: t }, 'Warrant served.').then(function () { M.pages.openWarrant(id); }); }); } },
          { text: 'Recall', cls: 'danger', show: w.status === 'active' && M.can('warrant.recall'), fn: function () { M.reason('Recall warrant', 'Why is it recalled?', 'Recall', function (t) { M.call('recallWarrant', { id: id, reason: t }, 'Recalled.').then(function () { M.pages.openWarrant(id); }); }); } }
        ]);
        var wr = $('wr'); if (wr) wr.onclick = function (e) { e.preventDefault(); M.pages.openReport(w.report_id); };
      });
    });
  };

  // ================= BOLOs =================
  M.pages.bolos = function (host, params) {
    M.table(host, {
      sort: 'created', placeholder: 'Search title, plate or description', q: params && params.q || '',
      filters: [{ key: 'status', label: 'Status', options: [['active', 'Active'], ['expired', 'Expired'], ['found', 'Found'], ['cancelled', 'Cancelled'], ['all', 'All']] }, { key: 'kind', label: 'Type', options: [['all', 'All types']].concat(M.S.cfg.boloTypes.map(function (t) { return [t.id, t.label]; })) }],
      bar: function (bar) { if (M.can('bolo.create')) { var b = M.el('<button class="btn pri">New BOLO</button>'); b.onclick = function () { M.pages.editBolo(); }; bar.appendChild(b); } },
      load: function (st) { return M.rpc('listBolos', M.pay(st)); }, empty: ['No BOLOs', 'Nothing matches these filters.'],
      cols: [{ label: 'ID', sort: 'id', render: function (r) { return 'B-' + r.id; } }, { label: 'Priority', sort: 'priority', render: function (r) { return M.prio(r.priority); } }, { label: 'Type', render: function (r) { return esc(M.label(M.S.cfg.boloTypes, r.kind)); } }, { label: 'Title', sort: 'title', render: function (r) { return '<b>' + esc(r.title) + '</b>'; } }, { label: 'Plate', render: function (r) { return M.plateLink(r.plate); } }, { label: 'Status', render: function (r) { return M.chip(r.status); } }, { label: 'Issued by', render: function (r) { return esc(r.issued_by); } }, { label: 'Expires', sort: 'expires', render: function (r) { return M.fdate(r.expires_at); } }],
      onRow: function (r) { M.pages.openBolo(r.id); }
    });
  };
  M.pages.editBolo = function (pre) {
    pre = pre || {};
    M.form({
      title: 'New BOLO', submit: 'Issue BOLO', draft: 'bolo', wide: true, values: { kind: pre.kind || 'person', priority: 2, hours: M.S.cfg.boloHours || 24, plate: pre.plate },
      fields: [{ key: 'kind', label: 'Type', type: 'select', options: M.S.cfg.boloTypes.map(function (t) { return [t.id, t.label]; }) }, { key: 'priority', label: 'Priority', type: 'select', options: [[1, '1 - Urgent'], [2, '2 - High'], [3, '3 - Routine']] },
        { key: 'title', label: 'Subject / headline', req: true, max: 120 }, { key: 'plate', label: 'Plate (vehicles)', type: 'plate' }, { key: 'description', label: 'Description and reason', type: 'textarea', req: true }, { key: 'location', label: 'Last known location' }, { key: 'hours', label: 'Expires in (hours)', type: 'number', min: 1, max: 720 },
        { key: 'image', label: 'Image link (optional)', type: 'url', hint: 'A link that starts with https://' }, { key: 'report_id', label: 'Linked report number', type: 'number' }],
      onSubmit: function (v) { v.priority = Number(v.priority); return M.call('createBolo', v, 'BOLO issued.').then(function (r) { if (r) { if (M.S.page === 'bolos') M.go('bolos'); M.pages.openBolo(r.id); } return !!r; }); }
    });
  };
  M.pages.openBolo = function (id) {
    M.open(function () {
      M.rpc('getBolo', { id: id }).then(function (b) {
        if (!b || b.error) { M.drawer('BOLO', M.errBox(b && b.error)); return; }
        var h = '<div class="row">' + M.prio(b.priority) + ' ' + M.chip(b.status) + '</div>';
        if (b.image) h += '<img src="' + esc(b.image) + '" alt="BOLO image" style="max-width:100%;border-radius:6px;margin:10px 0" onerror="this.style.display=\'none\'">';
        h += M.dl([['Type', M.label(M.S.cfg.boloTypes, b.kind)], ['Description', b.description], ['Plate', b.plate ? M.plateLink(b.plate) : '', true], ['Last seen', b.location], ['Issued by', b.issued_by], ['Created', M.fdate(b.created_at)], ['Expires', M.fdate(b.expires_at)], ['Report', b.report_id ? 'R-' + b.report_id : '']]);
        h += M.sec('Updates') + M.timeline((b.updates || []).slice().reverse(), function (u) { return [u.by, M.fdate(u.at), u.text]; });
        var open = b.status === 'active' && M.can('bolo.create');
        M.drawer('BOLO B-' + b.id, h, [
          { text: 'Add update', cls: 'pri', show: open, fn: function () { M.reason('BOLO update', 'What changed?', 'Post update', function (t) { M.call('addBoloUpdate', { id: id, text: t }, 'Update posted.').then(function () { M.pages.openBolo(id); }); }); } },
          { text: 'Extend 12h', show: (b.status === 'active' || b.status === 'expired') && M.can('bolo.create'), fn: function () { M.call('extendBolo', { id: id, hours: 12 }, 'Extended.').then(function () { M.pages.openBolo(id); }); } },
          { text: 'Mark found', cls: 'ok', show: open, fn: function () { M.confirm('Mark as found?', 'This closes the BOLO.', 'Mark found', function () { M.call('closeBolo', { id: id, status: 'found' }, 'BOLO closed.').then(function () { M.pages.openBolo(id); }); }); } },
          { text: 'Cancel BOLO', cls: 'danger', show: open, fn: function () { M.confirm('Cancel this BOLO?', 'Officers will stop seeing it.', 'Cancel BOLO', function () { M.call('closeBolo', { id: id, status: 'cancelled' }, 'BOLO cancelled.').then(function () { M.pages.openBolo(id); }); }, true); } }
        ]);
        $('drawer').querySelectorAll('[data-plate]');
      });
    });
  };

  // ================= CITATIONS =================
  M.pages.citations = function (host, params) {
    M.table(host, {
      sort: 'created', placeholder: 'Search name, plate or C-number', q: params && params.q || '',
      filters: [{ key: 'status', label: 'Status', options: [['all', 'All'], ['unpaid', 'Unpaid'], ['paid', 'Paid'], ['waived', 'Waived'], ['voided', 'Voided']] }],
      bar: function (bar) { if (M.can('citation.create')) { var b = M.el('<button class="btn pri">New citation</button>'); b.onclick = function () { M.pages.newCitation(); }; bar.appendChild(b); } },
      load: function (st) { return M.rpc('listCitations', M.pay(st)); }, empty: ['No citations'],
      cols: [{ label: 'ID', sort: 'id', render: function (r) { return 'C-' + r.id; } }, { label: 'Person', sort: 'name', render: function (r) { return M.linkPerson(r.person_identifier, r.person_name); } }, { label: 'Violations', render: function (r) { return esc(charges(r.violations)); } }, { label: 'Fine', sort: 'fine', render: function (r) { return money(r.fine); } }, { label: 'Plate', render: function (r) { return M.plateLink(r.plate); } }, { label: 'Status', sort: 'status', render: function (r) { return M.chip(r.status); } }, { label: 'Officer', render: function (r) { return esc(r.officer_name); } }, { label: 'Date', sort: 'created', render: function (r) { return M.fdate(r.created_at); } }],
      onRow: function (r) { M.pages.openCitation(r.id); }
    });
  };
  M.pages.newCitation = function (person, plate) {
    M.form({
      title: 'New citation', submit: 'Issue citation', draft: 'citation', wide: true, values: { identifier: person, plate: plate },
      fields: [{ key: 'identifier', label: 'Person cited', type: 'person', req: true }, { key: 'plate', label: 'Vehicle plate (if any)', type: 'plate' }, { key: 'charges', label: 'Violations', type: 'charges', citeOnly: true, req: true },
        { key: 'narrative', label: 'Narrative', type: 'textarea', req: true }, { key: 'location', label: 'Location' }, { key: 'report_id', label: 'Linked report number', type: 'number' }, { key: 'call_id', label: 'Linked call number', type: 'number' }],
      onSubmit: function (v) { return M.call('createCitation', v).then(function (r) { if (!r) return false; M.toast('Citation C-' + r.id + ' issued for ' + money(r.fine) + (r.paid ? ' (paid)' : '') + '.', 'ok'); if (r.suspended) M.toast('Licence points reached the limit. Licence suspended.', 'warn'); if (M.S.page === 'citations') M.go('citations'); M.pages.openCitation(r.id); return true; }); }
    });
  };
  M.pages.openCitation = function (id) {
    M.open(function () {
      M.rpc('getCitation', { id: id }).then(function (c) {
        if (!c || c.error) { M.drawer('Citation', M.errBox(c && c.error)); return; }
        var v = (c.violations || []);
        var b = '<div class="row">' + M.chip(c.status) + '</div>' + M.dl([['Person', M.linkPerson(c.person_identifier, c.person_name), true], ['Violations', charges(v)], ['Fine', money(c.fine)], ['Points', c.points], ['Vehicle', c.plate ? M.plateLink(c.plate) : '', true], ['Location', c.location], ['Narrative', c.narrative], ['Issued by', c.officer_name], ['Date', M.fdate(c.created_at)], ['Void reason', c.void_reason], ['Report', c.report_id ? 'R-' + c.report_id : '']]);
        b += M.sec('Review and void history') + M.timeline(c.history, function (h) { return [h.officer, M.fdate(h.at), h.details]; });
        M.drawer('Citation C-' + c.id, b, [
          copyBtn(function () { return summaryOf('CITATION C-' + c.id, ['Person: ' + c.person_name, 'Violations: ' + charges(v), 'Fine: ' + money(c.fine), 'Location: ' + (c.location || '-'), 'Officer: ' + c.officer_name, 'Date: ' + M.fdate(c.created_at), 'Status: ' + c.status]); }),
          { text: 'Mark paid', cls: 'ok', show: c.status === 'unpaid' && M.can('citation.payment'), fn: function () { M.call('setCitationPayment', { id: id, status: 'paid' }, 'Marked paid.').then(function () { M.pages.openCitation(id); }); } },
          { text: 'Waive', show: c.status === 'unpaid' && M.can('citation.payment'), fn: function () { M.confirm('Waive this fine?', 'The citation stays on record but the fine is cancelled.', 'Waive', function () { M.call('setCitationPayment', { id: id, status: 'waived' }, 'Waived.').then(function () { M.pages.openCitation(id); }); }); } },
          { text: 'Void', cls: 'danger', show: c.status !== 'voided' && M.can('citation.void'), fn: function () { M.reason('Void citation', 'Reason for voiding', 'Void citation', function (t) { M.call('voidCitation', { id: id, reason: t }).then(function (r) { if (r) { M.toast(r.refundDue ? 'Voided. The fine was paid and could not be refunded automatically.' : 'Citation voided.', r.refundDue ? 'warn' : 'ok'); M.pages.openCitation(id); } }); }, 5); } }
        ]);
      });
    });
  };

  // ================= BOOKINGS =================
  M.pages.bookings = function (host, params) {
    M.table(host, {
      sort: 'created', placeholder: 'Search name or B-number', q: params && params.q || '',
      filters: [{ key: 'status', label: 'Status', options: [['all', 'All'], ['pending', 'Pending review'], ['approved', 'Approved'], ['returned', 'Returned'], ['voided', 'Voided']] }],
      bar: function (bar) { if (M.can('booking.create')) { var b = M.el('<button class="btn pri">New booking</button>'); b.onclick = function () { M.pages.newBooking(); }; bar.appendChild(b); } },
      load: function (st) { return M.rpc('listBookings', M.pay(st)); }, empty: ['No bookings'],
      cols: [{ label: 'ID', sort: 'id', render: function (r) { return 'B-' + r.id; } }, { label: 'Subject', sort: 'name', render: function (r) { return M.linkPerson(r.person_identifier, r.person_name); } }, { label: 'Charges', render: function (r) { return esc(charges(r.charges)); } }, { label: 'Fine', render: function (r) { return money(r.fine); } }, { label: 'Jail', render: function (r) { return r.jail ? r.jail + ' min' : '-'; } }, { label: 'Status', sort: 'status', render: function (r) { return M.chip(r.status); } }, { label: 'Disposition', render: function (r) { return esc(r.disposition || '-'); } }, { label: 'Date', sort: 'created', render: function (r) { return M.fdate(r.created_at); } }],
      onRow: function (r) { M.pages.openBooking(r.id); }
    });
  };
  M.pages.newBooking = function (person) {
    M.form({
      title: 'Arrest and booking', submit: 'Book subject', draft: 'booking', wide: true, values: { identifier: person, disposition: M.S.cfg.bookingDispositions[0] },
      fields: [{ key: 'identifier', label: 'Subject', type: 'person', req: true }, { key: 'charges', label: 'Charges', type: 'charges', req: true }, { key: 'narrative', label: 'Arrest narrative', type: 'textarea', req: true, rows: 5 },
        { key: 'assisting', label: 'Assisting officers' }, { key: 'location', label: 'Arrest location' }, { key: 'disposition', label: 'Disposition', type: 'select', options: M.S.cfg.bookingDispositions }, { key: 'evidence', label: 'Evidence numbers', placeholder: 'E-12, E-14', hint: 'Numbers from the Evidence page.' },
        { key: 'report_id', label: 'Linked report number', type: 'number' }, { key: 'image', label: 'Booking photo link (optional)', type: 'url' }],
      onSubmit: function (v) { return M.call('createBooking', v).then(function (r) { if (!r) return false; M.toast('Booking B-' + r.id + ' saved. ' + money(r.fine) + (r.jail ? ', ' + r.jail + ' min' : '') + (r.status === 'pending' ? ' (waiting for review)' : ''), 'ok'); if (M.S.page === 'bookings') M.go('bookings'); M.pages.openBooking(r.id); return true; }); }
    });
  };
  M.pages.openBooking = function (id) {
    M.open(function () {
      M.rpc('getBooking', { id: id }).then(function (bk) {
        if (!bk || bk.error) { M.drawer('Booking', M.errBox(bk && bk.error)); return; }
        var mine = bk.officer_identifier === M.S.me.identifier;
        var h = '<div class="row">' + M.chip(bk.status) + '</div>';
        if (bk.image) h += '<img src="' + esc(bk.image) + '" alt="Booking photo" style="max-width:100%;border-radius:6px;margin:10px 0" onerror="this.style.display=\'none\'">';
        h += M.dl([['Subject', M.linkPerson(bk.person_identifier, bk.person_name), true], ['Charges', charges(bk.charges)], ['Fine', money(bk.fine)], ['Sentence', bk.jail ? bk.jail + ' minutes' : 'None'], ['Points', bk.points], ['Disposition', bk.disposition], ['Narrative', bk.narrative], ['Arresting officer', bk.officer_name], ['Assisting', bk.assisting], ['Location', bk.location], ['Evidence', (bk.evidence || []).map(function (e) { return 'E-' + e; }).join(', ')], ['Report', bk.report_id ? 'R-' + bk.report_id : ''], ['Date', M.fdate(bk.created_at)], ['Review note', bk.review_note]]);
        h += M.sec('History') + M.timeline(bk.history, function (x) { return [x.officer, M.fdate(x.at), x.details]; });
        M.drawer('Booking B-' + bk.id, h, [
          copyBtn(function () { return summaryOf('BOOKING B-' + bk.id, ['Subject: ' + bk.person_name, 'Charges: ' + charges(bk.charges), 'Fine: ' + money(bk.fine), 'Sentence: ' + (bk.jail || 0) + ' min', 'Arresting officer: ' + bk.officer_name, 'Disposition: ' + (bk.disposition || '-'), 'Date: ' + M.fdate(bk.created_at)]); }),
          { text: 'Approve', cls: 'ok', show: bk.status === 'pending' && M.can('booking.review'), fn: function () { M.call('reviewBooking', { id: id, decision: 'approve' }, 'Approved.').then(function () { M.pages.openBooking(id); }); } },
          { text: 'Return to officer', show: bk.status === 'pending' && M.can('booking.review'), fn: function () { M.reason('Return booking', 'What needs fixing?', 'Return', function (t) { M.call('reviewBooking', { id: id, decision: 'return', note: t }, 'Returned.').then(function () { M.pages.openBooking(id); }); }); } },
          { text: 'Fix and resubmit', cls: 'pri', show: bk.status === 'returned' && mine, fn: function () { M.form({ title: 'Fix booking B-' + id, submit: 'Resubmit', values: { narrative: bk.narrative, disposition: bk.disposition, evidence: (bk.evidence || []).map(function (e) { return 'E-' + e; }).join(', ') }, fields: [{ key: 'narrative', label: 'Narrative', type: 'textarea', req: true, rows: 5 }, { key: 'disposition', label: 'Disposition', type: 'select', options: M.S.cfg.bookingDispositions }, { key: 'evidence', label: 'Evidence numbers' }], onSubmit: function (v) { v.id = id; return M.call('updateBooking', v, 'Resubmitted.').then(function (r) { if (r) M.pages.openBooking(id); return !!r; }); } }); } },
          { text: 'Void', cls: 'danger', show: bk.status !== 'voided' && M.can('booking.review'), fn: function () { M.reason('Void booking', 'Reason for voiding', 'Void booking', function (t) { M.call('voidBooking', { id: id, reason: t }, 'Booking voided.').then(function () { M.pages.openBooking(id); }); }, 5); } }
        ]);
      });
    });
  };
})();
