// Tez MDT v3 - core helpers and UI kit. Made by Tez Development
(function () {
  var M = window.M = { S: { page: 'home', cfg: null, me: null, drawer: [], unread: 0, polls: [] }, pages: {} };
  var RES = (typeof GetParentResourceName === 'function') ? GetParentResourceName() : 'tez_mdt';
  var $ = M.$ = function (id) { return document.getElementById(id); };

  M.esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]; }); };
  var esc = M.esc;
  M.fdate = function (ts) { return ts ? new Date(ts * 1000).toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) : '-'; };
  M.fday = function (ts) { return ts ? new Date(ts * 1000).toLocaleDateString([], { year: 'numeric', month: 'short', day: 'numeric' }) : '-'; };
  M.money = function (n) { return '$' + Number(n || 0).toLocaleString(); };
  M.now = function () { return Math.floor(Date.now() / 1000); };
  M.ago = function (ts) {
    if (!ts) return '-';
    var s = Math.max(0, M.now() - ts);
    if (s < 60) return s + 's ago'; if (s < 3600) return Math.floor(s / 60) + 'm ago';
    if (s < 86400) return Math.floor(s / 3600) + 'h ago'; return Math.floor(s / 86400) + 'd ago';
  };
  M.el = function (html) { var d = document.createElement('div'); d.innerHTML = html.trim(); return d.firstChild; };
  M.can = function (p) { var pe = M.S.me && M.S.me.perms || []; return pe.indexOf('*') >= 0 || pe.indexOf(p) >= 0; };
  M.label = function (list, id) { for (var i = 0; i < (list || []).length; i++) { var v = list[i]; if (typeof v === 'object' ? v.id === id : v === id) return typeof v === 'object' ? v.label : v; } return id; };

  var COLORS = ['Black', 'Graphite', 'Black steel', 'Dark silver', 'Silver', 'Blue silver', 'Steel', 'Shadow silver', 'Stone silver', 'Midnight silver', 'Gun metal', 'Anthracite', 'Matte black', 'Matte grey', 'Matte light grey', 'Util black', 'Util black poly', 'Util dark silver', 'Util silver', 'Util gun metal', 'Util shadow silver', 'Worn black', 'Worn graphite', 'Worn silver grey', 'Worn silver', 'Worn blue silver', 'Worn shadow silver', 'Red', 'Torino red', 'Formula red', 'Blaze red', 'Grace red', 'Garnet red', 'Sunset red', 'Cabernet red', 'Wine red', 'Candy red', 'Hot pink', 'Pfister pink', 'Salmon pink', 'Sunrise orange', 'Orange', 'Bright orange', 'Gold', 'Bronze', 'Yellow', 'Race yellow', 'Dew yellow', 'Dark green', 'Racing green', 'Sea green', 'Olive green', 'Bright green', 'Gasoline green', 'Lime green', 'Midnight blue', 'Galaxy blue', 'Dark blue', 'Saxon blue', 'Blue', 'Mariner blue', 'Harbor blue', 'Diamond blue', 'Surf blue', 'Nautical blue', 'Racing blue', 'Ultra blue', 'Light blue'];
  M.colorName = function (i) { return i == null ? '-' : (COLORS[i] || ('Colour ' + i)); };
  M.vname = function (v) { return v.modelName || (v.model ? ('Model ' + v.model) : 'Unknown'); };

  var ICON = {
    home: 'M3 11l9-8 9 8v10h-6v-6H9v6H3z', radio: 'M4 9a8 8 0 0116 0M7 12a5 5 0 0110 0M12 15v6M9 21h6', map: 'M3 6l6-3 6 3 6-3v15l-6 3-6-3-6 3zM9 3v15M15 6v15',
    bell: 'M6 16V11a6 6 0 0112 0v5l2 2H4zM10 21h4', user: 'M12 12a4 4 0 100-8 4 4 0 000 8zM4 21a8 8 0 0116 0', car: 'M4 16v-4l2-5h12l2 5v4M4 16h16M7 19v-3M17 19v-3',
    gavel: 'M13 4l7 7M10 7l7 7M3 21l8-8M9 5l-3 3 9 9 3-3', flag: 'M5 21V4h12l-2 4 2 4H5', ticket: 'M3 8a2 2 0 002-2h14a2 2 0 002 2v8a2 2 0 00-2 2H5a2 2 0 00-2-2zM9 6v12',
    cuffs: 'M7 15a4 4 0 100-8 4 4 0 000 8zM17 17a4 4 0 100-8 4 4 0 000 8zM10 11h4', file: 'M6 3h9l4 4v14H6zM14 3v5h5M9 13h7M9 17h7', box: 'M3 7l9-4 9 4v10l-9 4-9-4zM3 7l9 4 9-4M12 11v10',
    tow: 'M3 15h13V8H8l-3 4zM16 11h3l2 3v1h-5M7 18a2 2 0 100-4 2 2 0 000 4zM17 18a2 2 0 100-4 2 2 0 000 4z', scale: 'M12 3v18M5 7h14M5 7l-3 7a3 3 0 006 0zM19 7l-3 7a3 3 0 006 0z',
    users: 'M9 11a3 3 0 100-6 3 3 0 000 6zM3 20a6 6 0 0112 0M17 11a3 3 0 100-6M21 20a6 6 0 00-4-5.6', shield: 'M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z', gear: 'M12 15a3 3 0 100-6 3 3 0 000 6zM19 12l2-1-2-4-2 1-2-1-1-2h-4l-1 2-2 1-2-1-2 4 2 1v2l-2 1 2 4 2-1 2 1 1 2h4l1-2 2-1 2 1 2-4-2-1z', log: 'M5 4h14v16H5zM8 9h8M8 13h8M8 17h5'
  };
  M.ico = function (n) { return '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="' + (ICON[n] || ICON.file) + '"/></svg>'; };

  // ----- talking to the server -----
  var MUT = /^(create|save|update|add|set|approve|deny|recall|serve|submit|review|void|close|assign|attach|link|dispose|transfer|release|send|take|test|register|flag|unflag|hire|separate|extend|delete|remove|mark|recheck)/;
  M.post = function (name, body) {
    return fetch('https://' + RES + '/' + name, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body || {}) })
      .then(function (r) { return r.json(); }).catch(function () { return null; });
  };
  M.rpc = function (name, payload) {
    payload = payload || {};
    if (MUT.test(name) && !payload._key) payload._key = name + ':' + Date.now() + ':' + Math.random().toString(36).slice(2, 9);
    return M.post('rpc', { name: name, payload: payload });
  };
  // calls the server and shows an error toast when something went wrong. Resolves with the result or null.
  M.call = function (name, payload, okMsg) {
    return M.rpc(name, payload).then(function (r) {
      if (!r) { M.toast('No answer from the server. Try again.', 'bad'); return null; }
      if (r.error) { M.toast(r.error, 'bad'); return null; }
      if (okMsg) M.toast(okMsg, 'ok');
      return r;
    });
  };

  M.toast = function (msg, kind) {
    var t = M.el('<div class="toast ' + (kind || '') + '" role="status">' + esc(msg) + '</div>');
    $('toasts').appendChild(t);
    setTimeout(function () { t.remove(); }, 4200);
  };

  // ----- chips -----
  var CHIP = {
    active: 'ok', open: 'info', approved: 'ok', served: 'ok', paid: 'ok', released: 'mute', found: 'ok', analyzed: 'ok', stored: 'mute', available: 'ok',
    pending: 'warn', submitted: 'warn', unpaid: 'warn', draft: 'mute', analyzing: 'warn', hearing: 'warn', enroute: 'info', onscene: 'info', busy: 'warn', returned: 'warn', appealed: 'warn',
    denied: 'bad', recalled: 'bad', voided: 'bad', expired: 'mute', cancelled: 'mute', closed: 'mute', waived: 'mute', emergency: 'bad', out: 'mute', impounded: 'warn', collected: 'info'
  };
  M.chip = function (status, text) {
    var s = String(status || '');
    return '<span class="chip ' + (CHIP[s] || 'mute') + '">' + esc(text || (s.charAt(0).toUpperCase() + s.slice(1))) + '</span>';
  };
  M.prio = function (p) { var n = Number(p) || 2; return '<span class="chip ' + (n === 1 ? 'bad' : n === 2 ? 'warn' : n === 3 ? 'info' : 'mute') + '">P' + n + '</span>'; };

  // ----- states -----
  M.empty = function (title, hint) { return '<div class="empty"><b>' + esc(title) + '</b>' + esc(hint || '') + '</div>'; };
  M.loading = function () { return '<div class="load">Loading…</div>'; };
  M.errBox = function (m) { return '<div class="err">' + esc(m || 'Something went wrong.') + ' Try again in a moment.</div>'; };

  // ----- modal / confirm -----
  M.closeModal = function () { var m = $('modal'); m.classList.add('hidden'); m.innerHTML = ''; if (M._modalKey) M._modalKey = null; };
  M.modal = function (title, bodyHtml, buttons, opts) {
    opts = opts || {};
    var m = $('modal');
    m.innerHTML = '<div class="mb' + (opts.wide ? ' wide' : '') + '"><div class="mh">' + esc(title) + '</div><div class="mc">' + bodyHtml + '</div><div class="mf"></div></div>';
    m.classList.remove('hidden');
    var foot = m.querySelector('.mf');
    (buttons || []).forEach(function (b) {
      var btn = M.el('<button class="btn ' + (b.cls || '') + '">' + esc(b.text) + '</button>');
      btn.onclick = function () { if (b.fn) b.fn(btn); else M.closeModal(); };
      foot.appendChild(btn);
    });
    var first = m.querySelector('input,textarea,select,button.btn');
    if (first) setTimeout(function () { try { first.focus(); } catch (e) { } }, 20);
    return m;
  };
  M.confirm = function (title, text, okText, fn, danger) {
    M.modal(title, '<p>' + esc(text) + '</p>', [
      { text: 'Cancel' },
      { text: okText || 'Confirm', cls: danger ? 'danger' : 'pri', fn: function () { M.closeModal(); fn(); } }
    ]);
  };
  // asks for a short reason and then runs fn(reason)
  M.reason = function (title, label, okText, fn, min) {
    var m = M.modal(title, '<div class="fld"><label for="rs">' + esc(label) + '</label><textarea id="rs"></textarea><div class="bad" id="rsE"></div></div>', [
      { text: 'Cancel' },
      { text: okText, cls: 'pri', fn: function () {
        var v = $('rs').value.trim();
        if (v.length < (min || 3)) { $('rsE').textContent = 'Write at least a few words.'; return; }
        M.closeModal(); fn(v);
      } }
    ]);
    return m;
  };

  // ----- drawer -----
  M.drawer = function (title, bodyHtml, actions, onBack) {
    var d = $('drawer');
    d.classList.remove('hidden');
    d.innerHTML = '<div class="dh"><button class="btn sm" id="dBack" title="Back" aria-label="Back">‹</button><h2>' + esc(title) + '</h2><button class="btn sm" id="dX" aria-label="Close details">✕</button></div><div class="db">' + bodyHtml + '</div><div class="df" id="dF"></div>';
    $('dX').onclick = M.closeDrawer;
    $('dBack').onclick = function () { M.S.drawer.pop(); var prev = M.S.drawer.pop(); if (prev) prev(); else M.closeDrawer(); };
    (actions || []).forEach(function (a) {
      if (a.show === false) return;
      var b = M.el('<button class="btn ' + (a.cls || '') + '">' + esc(a.text) + '</button>');
      b.onclick = function () { a.fn(b); };
      $('dF').appendChild(b);
    });
    return d;
  };
  M.closeDrawer = function () { $('drawer').classList.add('hidden'); $('drawer').innerHTML = ''; M.S.drawer = []; };
  // opens a drawer through a loader so "back" can re-run the previous one
  M.open = function (fn) { M.S.drawer.push(fn); $('drawer').classList.remove('hidden'); $('drawer').innerHTML = '<div class="db">' + M.loading() + '</div>'; fn(); };
  M.isOpen = function () { return !$('drawer').classList.contains('hidden'); };

  M.dl = function (pairs) {
    return '<dl>' + pairs.filter(function (p) { return p && p[1] != null && p[1] !== ''; }).map(function (p) { return '<dt>' + esc(p[0]) + '</dt><dd>' + (p[2] ? p[1] : esc(p[1])) + '</dd>'; }).join('') + '</dl>';
  };
  M.sec = function (t) { return '<div class="sec">' + esc(t) + '</div>'; };
  M.timeline = function (items, f) {
    if (!items || !items.length) return '<div class="m">Nothing yet.</div>';
    return '<div class="tl">' + items.map(function (i) { var r = f(i); return '<div><b>' + esc(r[0]) + '</b> <span class="m">' + esc(r[1]) + '</span><br>' + esc(r[2]) + '</div>'; }).join('') + '</div>';
  };

  // ----- clipboard / print summary -----
  M.copy = function (text) {
    var t = document.createElement('textarea'); t.value = text; t.style.position = 'fixed'; t.style.opacity = '0';
    document.body.appendChild(t); t.select();
    var ok = false; try { ok = document.execCommand('copy'); } catch (e) { }
    t.remove(); M.toast(ok ? 'Summary copied. Paste it anywhere.' : 'Could not copy. Select the text instead.', ok ? 'ok' : 'bad');
  };

  // ----- sortable, filterable, paged table -----
  // cfg: { cols:[{key,label,sort,render(row)}], load(state)->Promise(result), filters:[{key,label,options:[[v,l]],value}], search:true, placeholder, onRow(row), empty:[title,hint], actions:html }
  M.table = function (host, cfg) {
    var st = { page: 1, sort: cfg.sort || '', dir: cfg.dir || 'desc', q: cfg.q || '', f: {} };
    (cfg.filters || []).forEach(function (f) { st.f[f.key] = f.value != null ? f.value : f.options[0][0]; });
    var bar = M.el('<div class="bar"></div>'), box = M.el('<div></div>');
    host.innerHTML = ''; host.appendChild(bar); host.appendChild(box);
    var qi;
    if (cfg.search !== false) {
      qi = M.el('<input type="search" aria-label="Search" placeholder="' + esc(cfg.placeholder || 'Search…') + '">');
      qi.value = st.q; bar.appendChild(qi);
      var tm; qi.oninput = function () { clearTimeout(tm); tm = setTimeout(function () { st.q = qi.value.trim(); st.page = 1; run(); }, 260); };
      qi.onkeydown = function (e) { if (e.key === 'Enter') { clearTimeout(tm); st.q = qi.value.trim(); st.page = 1; run(); } };
    }
    (cfg.filters || []).forEach(function (f) {
      var s = M.el('<select aria-label="' + esc(f.label) + '">' + f.options.map(function (o) { return '<option value="' + esc(o[0]) + '"' + (String(o[0]) === String(st.f[f.key]) ? ' selected' : '') + '>' + esc(o[1]) + '</option>'; }).join('') + '</select>');
      s.onchange = function () { st.f[f.key] = s.value; st.page = 1; run(); };
      bar.appendChild(s);
    });
    bar.appendChild(M.el('<span class="sp"></span>'));
    if (cfg.bar) cfg.bar(bar, run);
    var seq = 0;
    function run() {
      var my = ++seq;
      box.innerHTML = M.loading();
      cfg.load(st).then(function (res) {
        if (my !== seq) return;
        if (!res) { box.innerHTML = M.errBox('The server did not answer.'); return; }
        if (res.error) { box.innerHTML = M.errBox(res.error); return; }
        var rows = res.rows || [];
        if (cfg.after) cfg.after(res, st);
        if (cfg.clientFilter) rows = rows.filter(cfg.clientFilter);
        if (!rows.length) { box.innerHTML = M.empty((cfg.empty || ['Nothing here yet'])[0], (cfg.empty || [])[1] || (st.q ? 'Try a different search.' : '')); return; }
        var h = '<div class="tw"><table><thead><tr>' + cfg.cols.map(function (c) {
          var on = c.sort && st.sort === c.sort;
          return '<th' + (c.sort ? ' class="s" tabindex="0" data-s="' + c.sort + '" aria-sort="' + (on ? (st.dir === 'asc' ? 'ascending' : 'descending') : 'none') + '"' : '') + '>' + esc(c.label) + (on ? '<span class="ar">' + (st.dir === 'asc' ? '▲' : '▼') + '</span>' : '') + '</th>';
        }).join('') + '</tr></thead><tbody>' + rows.map(function (r, i) {
          return '<tr' + (cfg.onRow ? ' class="clk" tabindex="0"' : '') + ' data-i="' + i + '">' + cfg.cols.map(function (c) { return '<td>' + (c.render ? c.render(r) : esc(r[c.key])) + '</td>'; }).join('') + '</tr>';
        }).join('') + '</tbody></table></div>';
        var pages = res.pages || 1;
        h += '<div class="pg"><span>' + (res.total != null ? res.total + ' result' + (res.total === 1 ? '' : 's') : '') + '</span><span class="sp"></span><button class="btn sm" data-pg="-1"' + (st.page <= 1 ? ' disabled' : '') + '>Previous</button><span>Page ' + st.page + ' of ' + pages + '</span><button class="btn sm" data-pg="1"' + (st.page >= pages ? ' disabled' : '') + '>Next</button></div>';
        box.innerHTML = h;
        box.querySelectorAll('th.s').forEach(function (th) {
          var go = function () { var k = th.getAttribute('data-s'); if (st.sort === k) st.dir = st.dir === 'asc' ? 'desc' : 'asc'; else { st.sort = k; st.dir = 'asc'; } run(); };
          th.onclick = go; th.onkeydown = function (e) { if (e.key === 'Enter') go(); };
        });
        box.querySelectorAll('[data-pg]').forEach(function (b) { b.onclick = function () { st.page += Number(b.getAttribute('data-pg')); run(); }; });
        if (cfg.onRow) box.querySelectorAll('tbody tr').forEach(function (tr) {
          var go = function () { cfg.onRow(rows[Number(tr.getAttribute('data-i'))]); };
          tr.onclick = go; tr.onkeydown = function (e) { if (e.key === 'Enter') go(); };
        });
      });
    }
    run();
    return { reload: run, state: st };
  };
  M.pay = function (st, extra) {
    var p = { page: st.page, sort: st.sort, dir: st.dir, q: st.q };
    for (var k in st.f) p[k] = st.f[k];
    for (var k2 in (extra || {})) p[k2] = extra[k2];
    return p;
  };

  // ----- form builder -----
  // field: {key,label,type:text|textarea|select|number|checkbox|datetime|person|plate|charges|lines|url,options:[[v,l]],req,hint,full,rows,value,min,max}
  M.form = function (opts) {
    var draftKey = opts.draft ? ('tezmdt:draft:' + opts.draft) : null;
    var saved = null;
    if (draftKey) { try { saved = JSON.parse(localStorage.getItem(draftKey) || 'null'); } catch (e) { } }
    var vals = Object.assign({}, opts.values || {});
    var html = '';
    if (saved) html += '<div class="alert info" id="drNote">Restored your unsaved work from earlier. <button class="btn sm" id="drClr" type="button">Start fresh</button></div>';
    html += '<div class="fg">' + opts.fields.map(function (f) {
      var cls = 'fld' + (f.full || f.type === 'textarea' || f.type === 'charges' || f.type === 'lines' ? ' full' : '');
      return '<div class="' + cls + '"><label for="f_' + f.key + '">' + esc(f.label) + (f.req ? ' *' : '') + '</label><div id="w_' + f.key + '"></div>' + (f.hint ? '<div class="hint">' + esc(f.hint) + '</div>' : '') + '<div class="bad" id="e_' + f.key + '"></div></div>';
    }).join('') + '</div>';
    var modal = M.modal(opts.title, html, [], { wide: opts.wide });
    var getters = {};
    var allOpts = function (o) { return o.map(function (x) { return Array.isArray(x) ? x : [x, x]; }); };
    opts.fields.forEach(function (f) {
      var w = $('w_' + f.key), v = (saved && saved[f.key] != null) ? saved[f.key] : vals[f.key];
      var t = f.type || 'text', inp;
      if (t === 'textarea') { w.innerHTML = '<textarea id="f_' + f.key + '" rows="' + (f.rows || 4) + '"></textarea>'; inp = w.firstChild; inp.value = v || ''; getters[f.key] = function () { return inp.value.trim(); }; }
      else if (t === 'select') {
        w.innerHTML = '<select id="f_' + f.key + '">' + allOpts(f.options).map(function (o) { return '<option value="' + esc(o[0]) + '">' + esc(o[1]) + '</option>'; }).join('') + '</select>';
        inp = w.firstChild; if (v != null) inp.value = v; getters[f.key] = function () { return inp.value; };
      } else if (t === 'number') { w.innerHTML = '<input id="f_' + f.key + '" type="number"' + (f.min != null ? ' min="' + f.min + '"' : '') + (f.max != null ? ' max="' + f.max + '"' : '') + '>'; inp = w.firstChild; inp.value = v == null ? '' : v; getters[f.key] = function () { return inp.value === '' ? null : Number(inp.value); }; }
      else if (t === 'checkbox') { w.innerHTML = '<label class="chk"><input id="f_' + f.key + '" type="checkbox"><span>' + esc(f.text || 'Yes') + '</span></label>'; inp = w.querySelector('input'); inp.checked = !!v; getters[f.key] = function () { return inp.checked; }; }
      else if (t === 'datetime') {
        w.innerHTML = '<input id="f_' + f.key + '" type="datetime-local">'; inp = w.firstChild;
        var ts = v || (f.now ? M.now() : null);
        if (ts) { var d = new Date(ts * 1000); d.setMinutes(d.getMinutes() - d.getTimezoneOffset()); inp.value = d.toISOString().slice(0, 16); }
        getters[f.key] = function () { return inp.value ? Math.floor(new Date(inp.value).getTime() / 1000) : null; };
      } else if (t === 'person') {
        var cur = (v && typeof v === 'object') ? v : (v ? { identifier: v, name: v } : null);
        w.innerHTML = '<div class="pick"><input id="f_' + f.key + '" type="search" placeholder="Type a name or ID…" autocomplete="off"><div class="pickout hidden"></div></div>';
        inp = w.querySelector('input'); var out = w.querySelector('.pickout');
        if (cur) inp.value = cur.name || cur.identifier;
        var tm2; inp.oninput = function () {
          cur = null; clearTimeout(tm2);
          if (inp.value.trim().length < 2) { out.classList.add('hidden'); return; }
          tm2 = setTimeout(function () {
            M.rpc('searchPersons', { q: inp.value.trim(), page: 1 }).then(function (r) {
              var rows = (r && r.rows) || [];
              out.innerHTML = rows.length ? rows.slice(0, 8).map(function (p, i) { return '<button type="button" class="gsi" data-i="' + i + '"><b>' + esc(p.name) + '</b> <span class="m">' + esc(p.dob || '') + '</span></button>'; }).join('') : '<div class="empty">No match</div>';
              out.classList.remove('hidden');
              out.querySelectorAll('[data-i]').forEach(function (b) { b.onclick = function () { cur = rows[Number(b.getAttribute('data-i'))]; inp.value = cur.name; out.classList.add('hidden'); }; });
            });
          }, 260);
        };
        getters[f.key] = function () { return cur ? cur.identifier : null; };
        getters[f.key].raw = function () { return cur; };
      } else if (t === 'people') {
        var chosenP = []; (v || []).forEach(function (x) { chosenP.push(typeof x === 'object' ? x : { identifier: x, name: x }); });
        w.innerHTML = '<div class="pick"><input id="f_' + f.key + '" type="search" placeholder="Search a name, then click to add…" autocomplete="off"><div class="pickout hidden"></div></div><div class="row" id="ch_' + f.key + '" style="margin-top:6px"></div>';
        inp = w.querySelector('input'); var out2 = w.querySelector('.pickout'), chips = $('ch_' + f.key);
        var drawChips = function () {
          chips.innerHTML = chosenP.map(function (p, i) { return '<span class="chip info">' + esc(p.name) + ' <button type="button" class="btn sm" data-x="' + i + '" aria-label="Remove ' + esc(p.name) + '">✕</button></span>'; }).join('');
          chips.querySelectorAll('[data-x]').forEach(function (b) { b.onclick = function () { chosenP.splice(Number(b.getAttribute('data-x')), 1); drawChips(); if (draftKey) saveDraft(); }; });
        };
        drawChips();
        var tm3; inp.oninput = function () {
          clearTimeout(tm3);
          if (inp.value.trim().length < 2) { out2.classList.add('hidden'); return; }
          tm3 = setTimeout(function () {
            M.rpc('searchPersons', { q: inp.value.trim(), page: 1 }).then(function (r) {
              var rows = (r && r.rows) || [];
              out2.innerHTML = rows.length ? rows.slice(0, 8).map(function (p, i) { return '<button type="button" class="gsi" data-i="' + i + '"><b>' + esc(p.name) + '</b> <span class="m">' + esc(p.dob || '') + '</span></button>'; }).join('') : '<div class="empty">No match</div>';
              out2.classList.remove('hidden');
              out2.querySelectorAll('[data-i]').forEach(function (b) { b.onclick = function () { var p = rows[Number(b.getAttribute('data-i'))]; if (!chosenP.some(function (c) { return c.identifier === p.identifier; })) chosenP.push({ identifier: p.identifier, name: p.name }); inp.value = ''; out2.classList.add('hidden'); drawChips(); if (draftKey) saveDraft(); }; });
            });
          }, 260);
        };
        getters[f.key] = function () { return chosenP.map(function (p) { return p.identifier; }); };
        getters[f.key].full = function () { return chosenP.slice(); };
      } else if (t === 'charges') {
        var chosen = {}; (v || []).forEach(function (id) { chosen[id] = true; });
        var list = (M.S.cfg.charges || []).filter(function (c) { return !f.citeOnly || c.cite; });
        w.innerHTML = '<div class="cl">' + list.map(function (c) { return '<label class="chk"><input type="checkbox" data-c="' + esc(c.id) + '"' + (chosen[c.id] ? ' checked' : '') + '><span class="sp"><b>' + esc(c.label) + '</b> <span class="m">' + M.money(c.fine) + (c.jail ? ' · ' + c.jail + ' min' : '') + (c.points ? ' · ' + c.points + ' pts' : '') + '</span></span></label>'; }).join('') + '</div><div class="note" id="tot_' + f.key + '"></div>';
        var upd = function () {
          var f2 = 0, j = 0, p = 0;
          w.querySelectorAll('input:checked').forEach(function (i) { var c = list.filter(function (x) { return x.id === i.getAttribute('data-c'); })[0]; if (c) { f2 += c.fine; j += c.jail || 0; p += c.points || 0; } });
          $('tot_' + f.key).textContent = 'Total: ' + M.money(f2) + (j ? ' · ' + j + ' min jail' : '') + (p ? ' · ' + p + ' points' : '');
        };
        w.addEventListener('change', upd); upd();
        getters[f.key] = function () { var o = []; w.querySelectorAll('input:checked').forEach(function (i) { o.push(i.getAttribute('data-c')); }); return o; };
        inp = w;
      } else if (t === 'lines') {
        w.innerHTML = '<textarea id="f_' + f.key + '" rows="' + (f.rows || 3) + '" placeholder="' + esc(f.placeholder || 'One per line') + '"></textarea>'; inp = w.firstChild;
        inp.value = Array.isArray(v) ? v.join('\n') : (v || '');
        getters[f.key] = function () { return inp.value.split(/[\n,]+/).map(function (s) { return s.trim(); }).filter(Boolean); };
      } else {
        w.innerHTML = '<input id="f_' + f.key + '" type="' + (t === 'url' ? 'url' : 'text') + '"' + (f.max ? ' maxlength="' + f.max + '"' : '') + (f.placeholder ? ' placeholder="' + esc(f.placeholder) + '"' : '') + '>';
        inp = w.firstChild; inp.value = v == null ? '' : v;
        getters[f.key] = function () { var s = inp.value.trim(); return t === 'plate' ? s.toUpperCase() : s; };
      }
      if (draftKey && inp && t !== 'person') { inp.addEventListener('input', saveDraft); inp.addEventListener('change', saveDraft); }
    });
    function collect() { var o = {}; opts.fields.forEach(function (f) { o[f.key] = getters[f.key](); }); return o; }
    function saveDraft() {
      if (!draftKey) return;
      try { var o = collect(); opts.fields.forEach(function (f) { if (f.type === 'people') o[f.key] = getters[f.key].full(); }); localStorage.setItem(draftKey, JSON.stringify(o)); } catch (e) { }
    }
    var clr = $('drClr'); if (clr) clr.onclick = function () { try { localStorage.removeItem(draftKey); } catch (e) { } M.closeModal(); M.form(Object.assign({}, opts)); };
    function submit(extra, btn) {
      var o = collect(), bad = false;
      opts.fields.forEach(function (f) {
        var e = $('e_' + f.key); e.textContent = '';
        var val = o[f.key];
        if (f.req && (val == null || val === '' || (Array.isArray(val) && !val.length))) { e.textContent = 'This field is required.'; bad = true; }
      });
      if (bad) return;
      Object.assign(o, extra || {});
      btn.disabled = true;
      Promise.resolve(opts.onSubmit(o)).then(function (ok) {
        btn.disabled = false;
        if (ok) { try { if (draftKey) localStorage.removeItem(draftKey); } catch (e) { } M.closeModal(); }
      });
    }
    var foot = modal.querySelector('.mf');
    foot.appendChild(M.el('<span class="sp"></span>'));
    var cancel = M.el('<button class="btn" type="button">Cancel</button>'); cancel.onclick = M.closeModal; foot.appendChild(cancel);
    (opts.extraButtons || []).forEach(function (b) {
      var btn = M.el('<button class="btn" type="button">' + esc(b.text) + '</button>'); btn.onclick = function () { submit(b.extra, btn); }; foot.appendChild(btn);
    });
    var ok = M.el('<button class="btn pri" type="button">' + esc(opts.submit || 'Save') + '</button>'); ok.onclick = function () { submit({}, ok); }; foot.appendChild(ok);
    return { collect: collect, getters: getters };
  };

  // person label helper for tables
  M.linkPerson = function (id, name) { return '<a href="#" data-person="' + esc(id) + '" class="plink">' + esc(name) + '</a>'; };
  document.addEventListener('click', function (e) {
    var a = e.target.closest && e.target.closest('[data-person]');
    if (a) { e.preventDefault(); e.stopPropagation(); M.pages.openPerson(a.getAttribute('data-person')); }
    var v = e.target.closest && e.target.closest('[data-plate]');
    if (v) { e.preventDefault(); e.stopPropagation(); M.pages.openVehicle(v.getAttribute('data-plate')); }
  });
  M.plateLink = function (p) { return p ? '<a href="#" data-plate="' + esc(p) + '" class="plink mono">' + esc(p) + '</a>' : '<span class="m">-</span>'; };
})();
