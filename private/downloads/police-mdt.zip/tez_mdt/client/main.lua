local ESX = exports['es_extended']:getSharedObject()

local open = false
local revealed = {}       -- evidence shown after a scan: [id] = { type, coords }
local revealUntil = 0
local collecting = false

local HashToName = {}
for name in pairs(Config.Weapons) do HashToName[GetHashKey(name)] = name end

-- ============================================================
--  MDT tablet
-- ============================================================
local function setOpen(state, extra)
  open = state
  SetNuiFocus(state, state)
  if state then
    SendNUIMessage({ action = 'open', page = extra and extra.page or nil, q = extra and extra.q or nil })
  else
    SendNUIMessage({ action = 'close' })
  end
end

local function tryOpen(extra)
  if open then
    if extra then SendNUIMessage({ action = 'goto', page = extra.page, q = extra.q }) end
    return
  end
  ESX.TriggerServerCallback('tez_mdt:canOpen', function(ok)
    if ok then setOpen(true, extra) else ESX.ShowNotification('You do not have access to the MDT.') end
  end)
end

RegisterCommand('mdt', function() tryOpen(nil) end, false)
RegisterKeyMapping('mdt', 'Open the police MDT', 'keyboard', Config.OpenKey)

local function addModelNames(node, depth)
  depth = depth or 0
  if type(node) ~= 'table' or depth > 5 then return end
  if type(node.model) == 'number' then
    local name = GetDisplayNameFromVehicleModel(node.model)
    local label = GetLabelText(name)
    node.modelName = (label and label ~= 'NULL') and label or name
  end
  for _, v in pairs(node) do
    if type(v) == 'table' then addModelNames(v, depth + 1) end
  end
end

RegisterNUICallback('close', function(_, cb)
  setOpen(false)
  cb('ok')
end)

RegisterNUICallback('rpc', function(d, cb)
  ESX.TriggerServerCallback('tez_mdt:rpc', function(res)
    if type(res) == 'table' then addModelNames(res) end
    if res == nil then res = { empty = true } end
    cb(res)
  end, d.name, d.payload or {})
end)

-- ============================================================
--  dispatch: calls, panic, BOLOs
-- ============================================================
local blips = {}

local function callBlip(c, color, sprite, scale)
  local blip = AddBlipForCoord(c.x + 0.0, c.y + 0.0, 0.0)
  SetBlipSprite(blip, sprite)
  SetBlipColour(blip, color)
  SetBlipScale(blip, scale)
  SetBlipFlashes(blip, true)
  SetBlipAsShortRange(blip, false)
  BeginTextCommandSetBlipName('STRING')
  AddTextComponentString(('#%d %s'):format(c.id, c.kind == 'panic' and 'Officer needs help' or 'Dispatch call'))
  EndTextCommandSetBlipName(blip)
  SetTimeout(Config.DispatchBlipSeconds * 1000, function() RemoveBlip(blip) end)
end

RegisterNetEvent('tez_mdt:client:newCall', function(c)
  PlaySoundFrontend(-1, 'Event_Message_Purple', 'GTAO_FM_Events_Soundset', true)
  local tag = c.priority == 1 and '~r~PRIORITY 1~s~' or '~b~Dispatch~s~'
  ESX.ShowNotification(('%s: %s'):format(tag, c.msg))
  callBlip(c, c.priority == 1 and 1 or 3, 161, 1.0)
  if open then SendNUIMessage({ action = 'newCall', call = c }) end
end)

RegisterNetEvent('tez_mdt:client:panic', function(c)
  PlaySoundFrontend(-1, 'Beep_Red', 'DLC_HEIST_HACKING_SNAKE_SOUNDS', true)
  ESX.ShowNotification('~r~OFFICER NEEDS HELP~s~: ' .. c.caller)
  callBlip(c, 1, 526, 1.4)
  SetNewWaypoint(c.x + 0.0, c.y + 0.0)
  if open then SendNUIMessage({ action = 'panic', call = c }) end
end)

RegisterNetEvent('tez_mdt:client:bolo', function(title, plate)
  PlaySoundFrontend(-1, 'Event_Message_Purple', 'GTAO_FM_Events_Soundset', true)
  ESX.ShowNotification(('~y~BOLO~s~: %s%s'):format(title, plate and (' (' .. plate .. ')') or ''))
  if open then SendNUIMessage({ action = 'bolo' }) end
end)

RegisterNetEvent('tez_mdt:client:notif', function(n)
  if open then SendNUIMessage({ action = 'notif', notif = n }) end
end)

RegisterNetEvent('tez_mdt:client:waypoint', function(x, y)
  SetNewWaypoint(x + 0.0, y + 0.0)
  ESX.ShowNotification('Waypoint set to the call.')
end)

local function streetNow()
  local c = GetEntityCoords(PlayerPedId())
  local s, cross = GetStreetNameAtCoord(c.x, c.y, c.z)
  local name = GetStreetNameFromHashKey(s)
  local x = cross ~= 0 and GetStreetNameFromHashKey(cross) or ''
  if x ~= '' then name = name .. ' / ' .. x end
  return name
end

RegisterCommand('911', function(_, args)
  TriggerServerEvent('tez_mdt:server:call', table.concat(args, ' '), GetEntityCoords(PlayerPedId()), false, streetNow())
end, false)

RegisterCommand('911a', function(_, args)
  TriggerServerEvent('tez_mdt:server:call', table.concat(args, ' '), GetEntityCoords(PlayerPedId()), true, streetNow())
end, false)

RegisterCommand('panic', function()
  TriggerServerEvent('tez_mdt:server:panic')
end, false)

-- ============================================================
--  plate reader: runs the nearest vehicle's plate through the MDT
-- ============================================================
local function targetVehicle()
  local ped = PlayerPedId()
  local c = GetEntityCoords(ped)
  local own = GetVehiclePedIsIn(ped, false)
  if own ~= 0 then
    local from = GetEntityCoords(own)
    local to = GetOffsetFromEntityInWorldCoords(own, 0.0, 12.0, 0.0)
    local ray = StartShapeTestCapsule(from.x, from.y, from.z, to.x, to.y, to.z, 2.0, 2, own, 7)
    for _ = 1, 10 do
      local state, hit, _, _, ent = GetShapeTestResult(ray)
      if state ~= 1 then
        if hit == 1 and ent ~= 0 and IsEntityAVehicle(ent) then return ent end
        return nil
      end
      Wait(0)
    end
    return nil
  end
  local v = GetClosestVehicle(c.x, c.y, c.z, 6.0, 0, 71)
  if v ~= 0 then return v end
  return nil
end

RegisterCommand('plate', function()
  local veh = targetVehicle()
  if not veh then return ESX.ShowNotification('No vehicle in front of you.') end
  local plate = (GetVehicleNumberPlateText(veh) or ''):gsub('%s+$', ''):gsub('^%s+', '')
  tryOpen({ page = 'vehicles', q = plate })
end, false)
RegisterKeyMapping('plate', 'Police: run the plate of the vehicle in front', 'keyboard', Config.PlateKey)

-- ============================================================
--  evidence: scanning and collecting
-- ============================================================
RegisterCommand('scan', function()
  ESX.TriggerServerCallback('tez_mdt:scan', function(list)
    if list == nil then return ESX.ShowNotification('Only police can scan for evidence.') end
    revealed = {}
    for _, e in ipairs(list) do revealed[e.id] = { type = e.type, coords = vector3(e.x, e.y, e.z) } end
    revealUntil = GetGameTimer() + Config.ScanSeconds * 1000
    if #list == 0 then ESX.ShowNotification('You find nothing of interest.')
    else ESX.ShowNotification(('You mark %d piece(s) of evidence.'):format(#list)) end
  end)
end, false)

local function drawText3D(c, text)
  SetTextScale(0.32, 0.32)
  SetTextFont(4)
  SetTextProportional(true)
  SetTextColour(255, 255, 255, 230)
  SetTextOutline()
  SetTextCentre(true)
  SetDrawOrigin(c.x, c.y, c.z + 0.35, 0)
  BeginTextCommandDisplayText('STRING')
  AddTextComponentSubstringPlayerName(text)
  EndTextCommandDisplayText(0.0, 0.0)
  ClearDrawOrigin()
end

local EVIDENCE_LOOK = {
  casing = { 91, 151, 255, 'Shell casing' },
  blood  = { 255, 91, 110, 'Blood' },
  print  = { 120, 255, 190, 'Fingerprint' },
}

CreateThread(function()
  while true do
    if next(revealed) ~= nil then
      if GetGameTimer() > revealUntil then
        revealed = {}
      else
        local ped = PlayerPedId()
        local pc = GetEntityCoords(ped)
        local nearestId, nearestD
        for id, e in pairs(revealed) do
          local d = #(pc - e.coords)
          if d < 25.0 then
            local look = EVIDENCE_LOOK[e.type] or EVIDENCE_LOOK.casing
            DrawMarker(28, e.coords.x, e.coords.y, e.coords.z + 0.02, 0, 0, 0, 0, 0, 0, 0.12, 0.12, 0.12, look[1], look[2], look[3], 200, false, false, 2, false, nil, nil, false)
            if d < 6.0 then drawText3D(e.coords, look[4]) end
            if not nearestD or d < nearestD then nearestId, nearestD = id, d end
          end
        end
        if nearestId and nearestD <= Config.CollectDistance and not collecting then
          ESX.ShowHelpNotification('Press ~INPUT_CONTEXT~ to bag this evidence')
          if IsControlJustPressed(0, 38) then
            collecting = true
            local id = nearestId
            local dict = 'amb@medic@standing@kneel@base'
            RequestAnimDict(dict)
            local t = GetGameTimer()
            while not HasAnimDictLoaded(dict) and GetGameTimer() - t < 2000 do Wait(10) end
            TaskPlayAnim(ped, dict, 'base', 8.0, -8.0, 3500, 1, 0.0, false, false, false)
            Wait(3500)
            ClearPedTasks(ped)
            TriggerServerEvent('tez_mdt:server:collect', id)
            revealed[id] = nil
            collecting = false
          end
        end
      end
      Wait(0)
    else
      Wait(500)
    end
  end
end)

-- ============================================================
--  evidence: leaving it behind
-- ============================================================
-- shell casings
CreateThread(function()
  local lastShot = 0
  while true do
    local ped = PlayerPedId()
    if IsPedArmed(ped, 4) then
      Wait(0)
      if IsPedShooting(ped) and GetGameTimer() - lastShot > 400 then
        lastShot = GetGameTimer()
        local name = HashToName[GetSelectedPedWeapon(ped)]
        if name then
          local c = GetEntityCoords(ped)
          local spot = vector3(c.x + (math.random() - 0.5) * 1.6, c.y + (math.random() - 0.5) * 1.6, c.z - 0.95)
          TriggerServerEvent('tez_mdt:server:casing', name, spot)
        end
      end
    else
      Wait(500)
    end
  end
end)

-- blood drops when hurt
CreateThread(function()
  local last = GetEntityHealth(PlayerPedId())
  while true do
    Wait(200)
    local ped = PlayerPedId()
    local hp = GetEntityHealth(ped)
    if hp < last and (last - hp) >= 4 and hp > 100 then
      local c = GetEntityCoords(ped)
      TriggerServerEvent('tez_mdt:server:blood', vector3(c.x, c.y, c.z - 0.95))
    end
    last = hp
  end
end)

-- fingerprints on the vehicle you just got out of
CreateThread(function()
  local last = 0
  while true do
    Wait(500)
    local ped = PlayerPedId()
    local veh = GetVehiclePedIsIn(ped, false)
    if last ~= 0 and veh == 0 and DoesEntityExist(last) then
      local c = GetEntityCoords(last)
      TriggerServerEvent('tez_mdt:server:print', vector3(c.x, c.y, c.z - 0.6))
    end
    last = veh
  end
end)

AddEventHandler('onResourceStop', function(res)
  if res == GetCurrentResourceName() and open then SetNuiFocus(false, false) end
end)
