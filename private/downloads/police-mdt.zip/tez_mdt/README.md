# Tez MDT v3 (by Tez Development)

Police MDT / CAD for ESX Legacy. Dispatch, live map, people and vehicle records, warrants with approval, BOLOs,
citations, arrests and booking, incident reports with review, evidence with chain of custody, tow/impound,
court cases, officer directory, announcements, notifications and a full audit log.

## Install (new or upgrading from v2)
1. Delete the old `tez_mdt` folder from `resources` and put this one in its place.
2. Open phpMyAdmin, pick your database, open the **SQL** tab, paste all of `sql/install.sql` and press **Go**.
   It is safe to run again. It upgrades a v2 database and keeps your data. Needs MariaDB (XAMPP has it).
3. In `server.cfg`, make sure these are in this order: `ensure oxmysql`, `ensure es_extended`, `ensure tez_mdt`.
4. Restart the server (or `restart tez_mdt`). Watch the console: it warns if a v3 table is missing.
5. Join with a police job and press **F7** (or type `/mdt`).

## Settings (config.lua)
- `Config.Jobs`: which jobs can open the MDT (default `police`, `sheriff`).
- `Config.GradeRoles`: which rank gets which role (officer / supervisor / command). Admin group = administrator.
- `Config.Roles`: what each role may do. Edit freely.
- `Config.WarrantApproval`: warrants wait for a supervisor when true.
- `Config.Court.enabled`: turn court cases on or off.
- `Config.Charges`: your charge and fine list (`cite = true` makes it available for citations).
- `Config.Webhook`: Discord webhook link for warrants and BOLOs (optional).

## Commands and keys
F7 / `/mdt` open, `/911 message`, `/911a message` (anonymous), `/panic`, `/scan` (evidence), PageDown runs the plate in front.

## Honest notes
- The live map is a stylised outline. Pins use real game coordinates, so they are in the right place.
- Vehicle search on the server covers plate, VIN and owner. Model and colour filter the results already on screen.
- Court cases, impound and officer fields are roleplay records. They do not change your other scripts unless you hook `Config.OnJail` / `OnImpound`.
- Needs `oxmysql`, `es_extended` (Legacy). Tables are created by `sql/install.sql`.
