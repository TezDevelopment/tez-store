-- Tez MDT v3 - core: helpers, roles, audit, notifications, dispatch engine, request entry point
-- Made by Tez Development

local ESX = exports['es_extended']:getSharedObject()
TezMDT = { ESX = ESX, RPCs = {}, Perm = {} }
local T = TezMDT

-- ============================================================
--  small helpers
-- ============================================================
local function now() return os.time() end
local function trim(s)
  s = tostring(s or '')
  s = s:gsub('^%s+', '')
  s = s:gsub('%s+$', '')
  return s
end
local function clip(s, n) return trim(s):sub(1, n) end
local function normPlate(s) return (tostring(s or ''):upper():gsub('%s+', '')) end
local function hex8(s) return string.format('%08X', GetHashKey(s) & 0xFFFFFFFF) end
local function fullName(row) return ((row.firstname or '?') .. ' ' .. (row.lastname or '?')) end
local function decode(s, fallback)
  if not s or s == '' then return fallback end
  local ok, d = pcall(json.decode, s)
  if ok and d ~= nil then return d end
  return fallback
end
local function likeArg(q)
  q = tostring(q or ''):gsub('[\\%%_]', function(c) return '\\' .. c end)
  return '%' .. q .. '%'
end
local function intOrNil(v)
  v = tonumber(v)
  if v and v > 0 then return math.floor(v) end
  return nil
end
local function near(a, b, dist)
  local pa, pb = GetPlayerPed(a), GetPlayerPed(b)
  if pa == 0 or pb == 0 then return false end
  return #(GetEntityCoords(pa) - GetEntityCoords(pb)) <= dist
end

T.now, T.trim, T.clip, T.normPlate, T.fullName, T.decode, T.like, T.intOrNil, T.near =
  now, trim, clip, normPlate, fullName, decode, likeArg, intOrNil, near
T.dnaCode = function(identifier) return 'DNA-' .. hex8('dna:' .. identifier .. Config.Salt) end
T.balCode = function(identifier, weapon) return 'BAL-' .. hex8('bal:' .. identifier .. ':' .. weapon .. Config.Salt) end
T.fngCode = function(identifier) return 'FNG-' .. hex8('fng:' .. identifier .. Config.Salt) end
T.vin = function(plate) return 'TZ' .. hex8('vin1:' .. plate .. Config.Salt) .. hex8('vin2:' .. plate .. Config.Salt):sub(1, 7) end

-- lookup tables from config
T.chargeById, T.flagLabel, T.vflagLabel, T.statusById = {}, {}, {}, {}
for _, c in ipairs(Config.Charges) do T.chargeById[c.id] = c end
for _, f in ipairs(Config.CitizenFlags) do T.flagLabel[f.id] = f.label end
for _, f in ipairs(Config.VehicleFlags) do T.vflagLabel[f.id] = f.label end
for _, s in ipairs(Config.Statuses) do T.statusById[s.id] = s end
T.weaponList = {}
for name, label in pairs(Config.Weapons) do T.weaponList[#T.weaponList + 1] = { name = name, label = label } end
table.sort(T.weaponList, function(a, b) return a.label < b.label end)

-- ============================================================
--  database facts (which optional tables/columns exist)
-- ============================================================
T.has = { phone = false, licenses = false }
T.Grades = {}   -- [job][grade] = label

MySQL.ready(function()
  local c = MySQL.scalar.await("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'users' AND COLUMN_NAME = 'phone_number'")
  T.has.phone = (tonumber(c) or 0) > 0
  local l = MySQL.scalar.await("SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'user_licenses'")
  T.has.licenses = (tonumber(l) or 0) > 0
  local rows = MySQL.query.await('SELECT job_name, grade, label FROM job_grades') or {}
  for _, r in ipairs(rows) do
    T.Grades[r.job_name] = T.Grades[r.job_name] or {}
    T.Grades[r.job_name][tonumber(r.grade)] = r.label
  end
  local missing = MySQL.scalar.await("SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'tez_mdt_calls'")
  if (tonumber(missing) or 0) == 0 then
    print('^1[tez_mdt] The v3 database tables are missing. Run sql/install.sql in phpMyAdmin, then restart the resource.^7')
  end
end)

-- ============================================================
--  roles and permissions
-- ============================================================
local RolePerms = {}
local function resolveRole(name, seen)
  local set = {}
  local r = Config.Roles[name]
  if not r then return set end
  seen = seen or {}
  if seen[name] then return set end
  seen[name] = true
  if r.inherit then
    for k in pairs(resolveRole(r.inherit, seen)) do set[k] = true end
  end
  for _, p in ipairs(r.perms or {}) do set[p] = true end
  return set
end
for name in pairs(Config.Roles) do RolePerms[name] = resolveRole(name) end

local Meta = {}   -- cached officer rows
function T.meta(identifier)
  local m = Meta[identifier]
  if m then return m end
  m = MySQL.single.await('SELECT identifier, callsign, badge, division, supervisor, certs, role, active, note, last_notif FROM tez_mdt_officers WHERE identifier = ?', { identifier })
  if not m then
    m = { identifier = identifier, callsign = '', active = 1, last_notif = 0 }
  end
  Meta[identifier] = m
  return m
end
function T.dropMeta(identifier) Meta[identifier] = nil end

local RoleCache = {}
local function roleOf(x)
  local jobName, grade = x.job.name, tonumber(x.job.grade) or 0
  local c = RoleCache[x.identifier]
  if c and c.at > now() - 20 and c.job == jobName and c.grade == grade then return c.role end
  local role
  local group = x.getGroup and x.getGroup() or 'user'
  if Config.AdminGroups[group] then
    role = 'admin'
  else
    role = T.meta(x.identifier).role
    if not role or role == '' or not Config.Roles[role] then role = Config.GradeRoles[grade] or 'officer' end
  end
  RoleCache[x.identifier] = { role = role, at = now(), job = jobName, grade = grade }
  return role
end
function T.dropRole(identifier) RoleCache[identifier] = nil end

local function canUse(x) return x and x.job and Config.Jobs[x.job.name] == true end
local function can(x, perm)
  if not canUse(x) then return false end
  if not perm then return true end
  local set = RolePerms[roleOf(x)]
  return set ~= nil and (set['*'] == true or set[perm] == true)
end
T.canUse, T.can, T.roleOf = canUse, can, roleOf
T.rankOf = function(x) return tonumber(x.job.grade) or 0 end
T.isSenior = function(x) return canUse(x) and (can(x, 'record.delete') or (tonumber(x.job.grade) or 0) >= Config.SeniorGrade) end

function T.permList(x)
  local set = RolePerms[roleOf(x)] or {}
  if set['*'] then return { '*' } end
  local out = {}
  for k in pairs(set) do out[#out + 1] = k end
  table.sort(out)
  return out
end

function T.gradeLabel(job, grade)
  local g = T.Grades[job]
  return (g and g[tonumber(grade)]) or ('Grade ' .. tostring(grade))
end

-- ============================================================
--  officers, status, callsigns
-- ============================================================
local Status, StatusAt = {}, {}
T.Status, T.StatusAt = Status, StatusAt

function T.officers()
  local out = {}
  for _, x in pairs(ESX.GetExtendedPlayers()) do
    if canUse(x) then out[#out + 1] = x end
  end
  return out
end
function T.toOfficers(event, ...)
  for _, x in ipairs(T.officers()) do TriggerClientEvent(event, x.source, ...) end
end
local function callsignOf(x) return T.meta(x.identifier).callsign or '' end
T.callsignOf = callsignOf
function T.officerLabel(x)
  local c = callsignOf(x)
  if c ~= '' then return c .. ' ' .. x.getName() end
  return x.getName()
end

-- ============================================================
--  audit log, notifications, webhook
-- ============================================================
local function whoOf(x)
  if type(x) == 'table' then return x.getName(), x.identifier end
  return tostring(x or 'System'), nil
end

function T.log(x, action, details, entity, entityId)
  local name, ident = whoOf(x)
  MySQL.insert('INSERT INTO tez_mdt_log (officer, action, details, at, officer_identifier, entity, entity_id) VALUES (?, ?, ?, ?, ?, ?, ?)',
    { name, clip(action, 32), clip(details, 255), now(), ident, entity and clip(entity, 16) or nil, entityId and clip(tostring(entityId), 60) or nil })
end

local Viewed = {}
function T.logView(x, entity, id)
  local k = x.source .. ':' .. entity .. ':' .. tostring(id)
  local t = now()
  if Viewed[k] and t - Viewed[k] < 60 then return end
  Viewed[k] = t
  T.log(x, 'VIEW', ('Opened %s %s'):format(entity, tostring(id)), entity, id)
end

function T.webhook(title, desc, color)
  if not Config.Webhook or Config.Webhook == '' then return end
  PerformHttpRequest(Config.Webhook, function() end, 'POST', json.encode({
    username = 'Tez MDT',
    embeds = { { title = title, description = desc, color = color or 5961727, footer = { text = 'Tez MDT by Tez Development' } } },
  }), { ['Content-Type'] = 'application/json' })
end

-- spec = { type, title, body, perm, target (identifier), page, id }
function T.notify(spec)
  MySQL.insert('INSERT INTO tez_mdt_notifs (type, title, body, perm, target, link_page, link_id, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
    { clip(spec.type or 'system', 16), clip(spec.title, 120), clip(spec.body or '', 255), spec.perm, spec.target, spec.page, spec.id and tostring(spec.id) or nil, now() })
  for _, x in ipairs(T.officers()) do
    local ok = (spec.target and spec.target == x.identifier) or (not spec.target and can(x, spec.perm))
    if ok then TriggerClientEvent('tez_mdt:client:notif', x.source, { title = spec.title, body = spec.body, type = spec.type, page = spec.page, id = spec.id }) end
  end
end

-- ============================================================
--  paging and filters
-- ============================================================
function T.Where()
  local o = { parts = {}, args = {} }
  function o:add(sql, ...)
    self.parts[#self.parts + 1] = sql
    for _, a in ipairs({ ... }) do self.args[#self.args + 1] = a end
  end
  function o:sql() return #self.parts > 0 and (' WHERE ' .. table.concat(self.parts, ' AND ')) or '' end
  function o:with(...)
    local a = {}
    for i, v in ipairs(self.args) do a[i] = v end
    for _, v in ipairs({ ... }) do a[#a + 1] = v end
    return a
  end
  return o
end

-- sorts = { key = 'column expression' }
function T.paging(p, sorts, default)
  local per = Config.PerPage
  local page = math.max(1, math.floor(tonumber(p.page) or 1))
  local col = sorts[tostring(p.sort or '')] or sorts[default]
  local dir = (p.dir == 'asc') and 'ASC' or 'DESC'
  return per, (page - 1) * per, ('ORDER BY %s %s'):format(col, dir), page
end

function T.pageResult(rows, total, page)
  return { rows = rows or {}, total = tonumber(total) or 0, page = page, per = Config.PerPage }
end

-- ============================================================
--  dispatch engine (calls are saved in the database)
-- ============================================================
local Calls = {}
T.Calls = Calls

local function addTimeline(c, by, text)
  c.timeline[#c.timeline + 1] = { at = now(), by = by, text = clip(text, 160) }
  if #c.timeline > 60 then table.remove(c.timeline, 1) end
end
T.addTimeline = addTimeline

local function publicCall(c)
  local units = {}
  for s, u in pairs(c.units) do units[#units + 1] = { src = s, label = u.label, role = u.role } end
  table.sort(units, function(a, b) return a.src < b.src end)
  return {
    id = c.id, kind = c.kind, type = c.type, msg = c.msg, location = c.location, x = c.x, y = c.y,
    caller = c.caller, at = c.at, priority = c.priority, status = c.status, units = units,
    timeline = c.timeline, report_id = c.report_id, closedAt = c.closedAt, closedBy = c.closedBy,
  }
end
T.publicCall = publicCall

local function persistCall(c)
  local labels = {}
  for _, u in pairs(c.units) do labels[#labels + 1] = u.label end
  MySQL.update('UPDATE tez_mdt_calls SET type = ?, priority = ?, msg = ?, location = ?, status = ?, units = ?, timeline = ?, report_id = ?, closed_at = ?, closed_by = ? WHERE id = ?',
    { c.type, c.priority, c.msg, c.location, c.status, json.encode(labels), json.encode(c.timeline), c.report_id, c.closedAt, c.closedBy, c.id })
end
T.persistCall = persistCall

function T.createCall(o)
  local t = now()
  local c = {
    kind = o.kind or 'call', type = o.type or 'other', msg = clip(o.msg, 255), location = clip(o.location or '', 120),
    x = o.coords.x + 0.0, y = o.coords.y + 0.0, caller = clip(o.caller or 'Unknown', 80), at = t, priority = o.priority or 2,
    status = 'open', units = {}, timeline = {},
  }
  addTimeline(c, c.caller, 'Call created')
  c.id = MySQL.insert.await('INSERT INTO tez_mdt_calls (kind, type, priority, msg, location, x, y, caller, status, units, timeline, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
    { c.kind, c.type, c.priority, c.msg, c.location, c.x, c.y, c.caller, 'open', '[]', json.encode(c.timeline), t })
  Calls[c.id] = c
  T.toOfficers('tez_mdt:client:newCall', publicCall(c))
  return c
end

function T.openCalls()
  local out = {}
  for _, c in pairs(Calls) do
    if c.status == 'open' then out[#out + 1] = publicCall(c) end
  end
  table.sort(out, function(a, b)
    if a.priority ~= b.priority then return a.priority < b.priority end
    return a.at > b.at
  end)
  return out
end

local function unitCallId(src)
  for id, c in pairs(Calls) do
    if c.status == 'open' and c.units[src] then return id end
  end
  return nil
end
T.unitCallId = unitCallId

function T.setStatus(src, id)
  Status[src] = id
  StatusAt[src] = now()
end

function T.closeCall(c, by, text)
  c.status, c.closedAt, c.closedBy = 'closed', now(), by
  addTimeline(c, by, text or 'Call closed')
  for s in pairs(c.units) do
    local st = Status[s]
    if st == 'enroute' or st == 'onscene' then T.setStatus(s, 'available') end
  end
  persistCall(c)
end

CreateThread(function()
  while true do
    Wait(30000)
    local t = now()
    local limit = t - Config.CallLifetimeMinutes * 60
    for id, c in pairs(Calls) do
      if c.status == 'open' and c.at < limit then T.closeCall(c, 'System', 'Closed automatically (no activity)') end
      if c.status ~= 'open' and (c.closedAt or 0) < t - 600 then Calls[id] = nil end
    end
  end
end)

-- panic: used by the key command and by the Emergency status
local LastPanic = {}
function T.panic(src, x)
  local t = now()
  if LastPanic[src] and t - LastPanic[src] < Config.PanicCooldown then return false end
  LastPanic[src] = t
  local coords = GetEntityCoords(GetPlayerPed(src))
  local label = T.officerLabel(x)
  local c = T.createCall({ kind = 'panic', type = 'other', msg = 'OFFICER NEEDS HELP: ' .. label, coords = coords, caller = label, priority = 1 })
  c.units[src] = { label = label, role = 'primary' }
  T.setStatus(src, 'emergency')
  T.toOfficers('tez_mdt:client:panic', publicCall(c))
  T.log(x, 'PANIC', 'Panic button pressed')
  T.notify({ type = 'panic', title = 'Officer needs help', body = label, perm = 'call.respond', page = 'dispatch', id = c.id })
  T.webhook('Officer needs help', ('%s pressed the panic button.'):format(label), 15158332)
  return true
end

AddEventHandler('esx:playerDropped', function(src)
  Status[src], StatusAt[src], LastPanic[src] = nil, nil, nil
  for _, c in pairs(Calls) do c.units[src] = nil end
end)

-- ============================================================
--  request entry point
-- ============================================================
-- T.rpc(name, permission, function(src, x, payload) ... end)
function T.rpc(name, perm, fn)
  T.RPCs[name] = fn
  T.Perm[name] = perm
end

ESX.RegisterServerCallback('tez_mdt:canOpen', function(src, cb)
  cb(canUse(ESX.GetPlayerFromId(src)))
end)

local Bucket = {}
local Done = {}
CreateThread(function()
  while true do
    Wait(60000)
    local t = now()
    for k, v in pairs(Done) do
      if v.at < t - 180 then Done[k] = nil end
    end
  end
end)

ESX.RegisterServerCallback('tez_mdt:rpc', function(src, cb, name, payload)
  local x = ESX.GetPlayerFromId(src)
  if not canUse(x) then return cb({ error = 'You are not allowed to use the MDT.' }) end
  local fn = T.RPCs[name]
  if not fn then return cb({ error = 'Unknown request.' }) end

  -- allow short bursts, refill 10 per second
  local nowMs = GetGameTimer()
  local b = Bucket[src] or { tokens = 20, at = nowMs }
  b.tokens = math.min(20, b.tokens + (nowMs - b.at) / 100)
  b.at = nowMs
  if b.tokens < 1 then Bucket[src] = b; return cb({ error = 'Slow down a little.' }) end
  b.tokens = b.tokens - 1
  Bucket[src] = b

  local need = T.Perm[name]
  if need and not can(x, need) then
    T.log(x, 'DENIED', ('Tried %s without permission (%s)'):format(name, need))
    return cb({ error = 'You do not have permission to do that.' })
  end

  payload = type(payload) == 'table' and payload or {}
  local key = payload._key and (src .. ':' .. tostring(payload._key):sub(1, 40)) or nil
  if key and Done[key] then return cb(Done[key].res) end

  local ok, res = pcall(fn, src, x, payload)
  if not ok then
    print(('^1[tez_mdt] %s failed: %s^7'):format(tostring(name), tostring(res)))
    return cb({ error = 'Something went wrong. Check the server console.' })
  end
  if key and type(res) == 'table' and not res.error then Done[key] = { res = res, at = now() } end
  cb(res)
end)

-- housekeeping: remove old data
CreateThread(function()
  Wait(20000)
  while true do
    local r = Config.Retention or {}
    local t = now()
    if (r.calls or 0) > 0 then MySQL.update("DELETE FROM tez_mdt_calls WHERE status = 'closed' AND created_at < ?", { t - r.calls * 86400 }) end
    if (r.log or 0) > 0 then MySQL.update('DELETE FROM tez_mdt_log WHERE at < ?', { t - r.log * 86400 }) end
    if (r.notifications or 0) > 0 then MySQL.update('DELETE FROM tez_mdt_notifs WHERE created_at < ?', { t - r.notifications * 86400 }) end
    Wait(3600000)
  end
end)
