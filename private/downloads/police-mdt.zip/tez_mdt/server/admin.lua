-- Tez MDT v3 - bootstrap, dashboard, search, notifications, announcements, officers, audit, map
-- Made by Tez Development

local ESX = exports['es_extended']:getSharedObject()
local T = TezMDT
local now, clip, decode, fullName, like, normPlate = T.now, T.clip, T.decode, T.fullName, T.like, T.normPlate
local rpc = T.rpc

-- ---------- bootstrap: everything the screen needs to draw itself ----------
rpc('bootstrap', nil, function(src, x, p)
  local m = T.meta(x.identifier)
  local role = T.roleOf(x)
  return {
    brand = Config.Brand,
    me = {
      src = src, identifier = x.identifier, name = x.getName(), callsign = m.callsign or '', badge = m.badge or '',
      role = role, roleLabel = (Config.Roles[role] or {}).label or role, perms = T.permList(x),
      grade = T.gradeLabel(x.job.name, x.job.grade), gradeNum = tonumber(x.job.grade) or 0, dept = x.job.label or x.job.name,
      status = T.Status[src] or 'available',
    },
    cfg = {
      callTypes = Config.CallTypes, statuses = Config.Statuses, charges = Config.Charges, warrantTypes = Config.WarrantTypes,
      bookingDispositions = Config.BookingDispositions, reportTypes = Config.ReportTypes, boloTypes = Config.BoloTypes,
      evidenceCategories = Config.EvidenceCategories, evidenceDispositions = Config.EvidenceDispositions,
      vehicleFlags = Config.VehicleFlags, citizenFlags = Config.CitizenFlags, suspendPoints = Config.SuspendPoints,
      court = Config.Court and Config.Court.enabled or false, weapons = T.weaponList, warrantApproval = Config.WarrantApproval,
      perPage = Config.PerPage,
    },
    serverNow = now(),
  }
end)

-- ---------- dashboard ----------
rpc('dashboard', 'person.view', function(src, x, p)
  local t = now()
  local day = t - 86400
  local one = function(sql, ...) return tonumber(MySQL.scalar.await(sql, { ... })) or 0 end
  local d = {
    openCalls = #T.openCalls(),
    unitsOnDuty = #T.officers(),
    activeWarrants = one("SELECT COUNT(*) FROM tez_mdt_warrants WHERE status = 'active'"),
    pendingWarrants = one("SELECT COUNT(*) FROM tez_mdt_warrants WHERE status = 'pending'"),
    activeBolos = one("SELECT COUNT(*) FROM tez_mdt_bolos WHERE status = 'active'"),
    reportsToReview = one("SELECT COUNT(*) FROM tez_mdt_reports WHERE status = 'submitted'"),
    myDrafts = one("SELECT COUNT(*) FROM tez_mdt_reports WHERE status IN ('draft','returned') AND author_identifier = ?", x.identifier),
    citations24 = one('SELECT COUNT(*) FROM tez_mdt_citations WHERE created_at > ?', day),
    bookings24 = one('SELECT COUNT(*) FROM tez_mdt_bookings WHERE created_at > ?', day),
    impounded = one("SELECT COUNT(*) FROM tez_mdt_impounds WHERE status = 'impounded'"),
    evidenceInLab = one("SELECT COUNT(*) FROM tez_mdt_evidence WHERE status = 'analyzing'"),
  }
  d.announcements = MySQL.query.await('SELECT id, title, body, by_name, pinned, created_at FROM tez_mdt_announcements WHERE expires_at IS NULL OR expires_at > ? ORDER BY pinned DESC, id DESC LIMIT 5', { t }) or {}
  d.calls = {}
  for i, c in ipairs(T.openCalls()) do if i <= 6 then d.calls[#d.calls + 1] = c end end
  d.activity = MySQL.query.await("SELECT officer, action, details, at FROM tez_mdt_log WHERE action <> 'VIEW' ORDER BY id DESC LIMIT 8") or {}
  d.officers = T.rosterList()
  return d
end)

-- ---------- global search (people, vehicles, reports, calls, bolos, evidence) ----------
rpc('globalSearch', 'person.view', function(src, x, p)
  local q = clip(p.q, 40)
  if #q < 2 then return { people = {}, vehicles = {}, reports = {}, calls = {}, bolos = {}, evidence = {} } end
  local out = { people = {}, vehicles = {}, reports = {}, calls = {}, bolos = {}, evidence = {} }
  if T.can(x, 'person.view') then
    out.people = MySQL.query.await("SELECT identifier, firstname, lastname, dateofbirth FROM users WHERE CONCAT(firstname, ' ', lastname) LIKE ? OR identifier LIKE ? LIMIT 5", { like(q), like(q) }) or {}
    for _, r in ipairs(out.people) do r.name = fullName(r) end
  end
  if T.can(x, 'vehicle.view') then
    out.vehicles = MySQL.query.await("SELECT REPLACE(plate, ' ', '') AS plate, owner FROM owned_vehicles WHERE REPLACE(plate, ' ', '') LIKE ? LIMIT 5", { like(normPlate(q)) }) or {}
  end
  local n = tonumber((q:gsub('^[A-Za-z]%-?', '')))
  out.reports = MySQL.query.await("SELECT id, title, status FROM tez_mdt_reports WHERE (status <> 'draft' OR author_identifier = ?) AND (title LIKE ? OR id = ?) ORDER BY id DESC LIMIT 5", { x.identifier, like(q), n or 0 }) or {}
  out.calls = MySQL.query.await('SELECT id, msg, status FROM tez_mdt_calls WHERE msg LIKE ? OR id = ? ORDER BY id DESC LIMIT 5', { like(q), n or 0 }) or {}
  out.bolos = MySQL.query.await('SELECT id, title, status FROM tez_mdt_bolos WHERE title LIKE ? OR plate LIKE ? ORDER BY id DESC LIMIT 5', { like(q), like(normPlate(q)) }) or {}
  if T.can(x, 'evidence.view') then
    out.evidence = MySQL.query.await('SELECT id, description, category FROM tez_mdt_evidence WHERE description LIKE ? OR id = ? ORDER BY id DESC LIMIT 5', { like(q), n or 0 }) or {}
  end
  return out
end)

-- ---------- notifications ----------
local function visibleNotifs(x, limit)
  local rows = MySQL.query.await('SELECT id, type, title, body, perm, target, link_page, link_id, created_at FROM tez_mdt_notifs WHERE created_at > ? ORDER BY id DESC LIMIT 120', { now() - Config.Retention.notifications * 86400 }) or {}
  local out = {}
  for _, r in ipairs(rows) do
    local ok = (r.target and r.target == x.identifier) or (not r.target and T.can(x, r.perm))
    if ok then
      out[#out + 1] = { id = r.id, type = r.type, title = r.title, body = r.body, page = r.link_page, link = r.link_id, at = r.created_at }
      if #out >= limit then break end
    end
  end
  return out
end

rpc('notifications', nil, function(src, x, p)
  local list = visibleNotifs(x, 40)
  local seen = tonumber(T.meta(x.identifier).last_notif) or 0
  local unread = 0
  for _, n in ipairs(list) do n.unread = n.id > seen; if n.unread then unread = unread + 1 end end
  return { list = list, unread = unread }
end)

rpc('markNotifsRead', nil, function(src, x, p)
  local top = tonumber(MySQL.scalar.await('SELECT MAX(id) FROM tez_mdt_notifs')) or 0
  MySQL.update.await('INSERT INTO tez_mdt_officers (identifier, callsign, last_notif) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE last_notif = VALUES(last_notif)', { x.identifier, T.meta(x.identifier).callsign or '', top })
  T.dropMeta(x.identifier)
  return { ok = true }
end)

-- ---------- announcements ----------
rpc('listAnnouncements', 'person.view', function(src, x, p)
  return { rows = MySQL.query.await('SELECT id, title, body, by_name, pinned, created_at, expires_at FROM tez_mdt_announcements WHERE expires_at IS NULL OR expires_at > ? ORDER BY pinned DESC, id DESC LIMIT 50', { now() }) or {}, canManage = T.can(x, 'dept.manage') }
end)

rpc('createAnnouncement', 'dept.manage', function(src, x, p)
  local title, body = clip(p.title, 120), clip(p.body, 2000)
  if #title < 3 or #body < 3 then return { error = 'Add a title and a message.' } end
  local days = tonumber(p.days)
  local id = MySQL.insert.await('INSERT INTO tez_mdt_announcements (title, body, by_name, pinned, created_at, expires_at) VALUES (?, ?, ?, ?, ?, ?)',
    { title, body, T.officerLabel(x), p.pinned and 1 or 0, now(), days and days > 0 and (now() + math.floor(days) * 86400) or nil })
  T.log(x, 'ANNOUNCE', 'Posted announcement: ' .. title, 'announce', id)
  T.notify({ type = 'announce', title = 'Announcement: ' .. title, body = clip(body, 120), perm = 'person.view', page = 'home', id = id })
  return { ok = true, id = id }
end)

rpc('deleteAnnouncement', 'dept.manage', function(src, x, p)
  MySQL.update.await('DELETE FROM tez_mdt_announcements WHERE id = ?', { tonumber(p.id) or 0 })
  T.log(x, 'ANNOUNCE', 'Removed announcement ' .. tostring(p.id), 'announce', p.id)
  return { ok = true }
end)

-- ---------- officer directory and department management ----------
local function meOnline(identifier)
  local px = ESX.GetPlayerFromIdentifier(identifier)
  return px
end

rpc('listOfficers', 'officers.view', function(src, x, p)
  local jobs, marks = {}, {}
  for j in pairs(Config.Jobs) do jobs[#jobs + 1] = j; marks[#marks + 1] = '?' end
  local per, off, order, page = T.paging(p, { name = 'u.lastname', grade = 'u.job_grade', callsign = 'o.callsign', badge = 'o.badge' }, 'name')
  local w = T.Where()
  w:add('u.job IN (' .. table.concat(marks, ',') .. ')')
  local args = {}
  for _, j in ipairs(jobs) do args[#args + 1] = j end
  if p.active == 'off' then w:add('COALESCE(o.active, 1) = 0') elseif p.active ~= 'all' then w:add('COALESCE(o.active, 1) = 1') end
  local q = clip(p.q, 40)
  if #q >= 1 then w:add("(CONCAT(u.firstname, ' ', u.lastname) LIKE ? OR o.callsign LIKE ? OR o.badge LIKE ?)", like(q), like(q), like(q)) end
  local where = w:sql()
  local a = {}
  for _, v in ipairs(args) do a[#a + 1] = v end
  for _, v in ipairs(w:with()) do a[#a + 1] = v end
  -- w:with() already holds the q args; the job args come first because the IN() is the first part
  local from = ' FROM users u LEFT JOIN tez_mdt_officers o ON o.identifier = u.identifier'
  local total = tonumber(MySQL.scalar.await('SELECT COUNT(*)' .. from .. where, a)) or 0
  local b = {}
  for _, v in ipairs(a) do b[#b + 1] = v end
  b[#b + 1] = per; b[#b + 1] = off
  local rows = MySQL.query.await('SELECT u.identifier, u.firstname, u.lastname, u.job, u.job_grade, o.callsign, o.badge, o.division, o.supervisor, o.certs, o.role, COALESCE(o.active, 1) AS active, o.last_seen' .. from .. where .. ' ' .. order .. ' LIMIT ? OFFSET ?', b) or {}
  for _, r in ipairs(rows) do
    r.name = fullName(r)
    r.grade = T.gradeLabel(r.job, r.job_grade)
    r.online = meOnline(r.identifier) ~= nil
    r.firstname, r.lastname = nil, nil
  end
  return T.pageResult(rows, total, page)
end)

rpc('getOfficer', 'officers.view', function(src, x, p)
  local u = MySQL.single.await('SELECT identifier, firstname, lastname, job, job_grade FROM users WHERE identifier = ?', { tostring(p.id or '') })
  if not u or not Config.Jobs[u.job] then return { error = 'Officer not found.' } end
  local m = MySQL.single.await('SELECT * FROM tez_mdt_officers WHERE identifier = ?', { u.identifier }) or {}
  local out = {
    identifier = u.identifier, name = fullName(u), job = u.job, grade = T.gradeLabel(u.job, u.job_grade), gradeNum = tonumber(u.job_grade) or 0,
    callsign = m.callsign or '', badge = m.badge, division = m.division, supervisor = m.supervisor, certs = m.certs, role = m.role,
    active = (m.active == nil) and 1 or m.active, note = m.note, lastSeen = m.last_seen,
    canManage = T.can(x, 'officers.manage'),
  }
  out.activity = MySQL.query.await("SELECT action, details, at FROM tez_mdt_log WHERE officer_identifier = ? AND action <> 'VIEW' ORDER BY id DESC LIMIT 15", { u.identifier }) or {}
  local g = {}
  for grade, label in pairs(T.Grades[u.job] or {}) do g[#g + 1] = { grade = grade, label = label } end
  table.sort(g, function(a, b) return a.grade < b.grade end)
  out.grades = g
  out.roles = {}
  for id, r in pairs(Config.Roles) do out.roles[#out.roles + 1] = { id = id, label = r.label } end
  table.sort(out.roles, function(a, b) return a.id < b.id end)
  return out
end)

local function upsertOfficer(identifier, f)
  MySQL.update.await('INSERT INTO tez_mdt_officers (identifier, callsign, badge, division, supervisor, certs, role, active, note) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE callsign = VALUES(callsign), badge = VALUES(badge), division = VALUES(division), supervisor = VALUES(supervisor), certs = VALUES(certs), role = VALUES(role), active = VALUES(active), note = VALUES(note)',
    { identifier, f.callsign, f.badge, f.division, f.supervisor, f.certs, f.role, f.active, f.note })
  T.dropMeta(identifier); T.dropRole(identifier)
end

rpc('updateOfficer', 'officers.manage', function(src, x, p)
  local id = tostring(p.id or '')
  local u = MySQL.single.await('SELECT identifier, job, job_grade FROM users WHERE identifier = ?', { id })
  if not u or not Config.Jobs[u.job] then return { error = 'Officer not found.' } end
  local old = MySQL.single.await('SELECT * FROM tez_mdt_officers WHERE identifier = ?', { id }) or {}
  local callsign = clip(p.callsign, 12):upper()
  if callsign ~= '' then
    local dup = MySQL.scalar.await('SELECT identifier FROM tez_mdt_officers WHERE callsign = ? AND identifier <> ? LIMIT 1', { callsign, id })
    if dup then return { error = 'That callsign is already used by another officer.' } end
  end
  local role = clip(p.role, 16)
  if role ~= '' and not Config.Roles[role] then return { error = 'Unknown role.' } end
  if role == 'admin' and T.roleOf(x) ~= 'admin' then return { error = 'Only an administrator can give the administrator role.' } end
  upsertOfficer(id, {
    callsign = callsign, badge = clip(p.badge, 12), division = clip(p.division, 40), supervisor = clip(p.supervisor, 80),
    certs = clip(p.certs, 200), role = role ~= '' and role or nil, active = (p.active == false or p.active == 0) and 0 or 1, note = clip(p.note, 200),
  })
  local changed = {}
  if (old.callsign or '') ~= callsign then changed[#changed + 1] = 'callsign ' .. callsign end
  if (old.role or '') ~= role then changed[#changed + 1] = 'role ' .. (role ~= '' and role or 'default') end
  T.log(x, 'OFFICER', ('Updated officer %s (%s)'):format(id, #changed > 0 and table.concat(changed, ', ') or 'details'), 'officer', id)
  return { ok = true }
end)

rpc('setRank', 'officers.manage', function(src, x, p)
  local id = tostring(p.id or '')
  local grade = math.floor(tonumber(p.grade) or -1)
  local u = MySQL.single.await('SELECT identifier, job, job_grade FROM users WHERE identifier = ?', { id })
  if not u or not Config.Jobs[u.job] then return { error = 'Officer not found.' } end
  if not (T.Grades[u.job] or {})[grade] then return { error = 'Unknown rank.' } end
  if id == x.identifier then return { error = 'You cannot change your own rank.' } end
  local admin = T.roleOf(x) == 'admin'
  if not admin and (grade >= (tonumber(x.job.grade) or 0) or (tonumber(u.job_grade) or 0) >= (tonumber(x.job.grade) or 0)) then
    return { error = 'You can only change ranks below your own.' }
  end
  local px = meOnline(id)
  if px then px.setJob(u.job, grade) else MySQL.update.await('UPDATE users SET job_grade = ? WHERE identifier = ?', { grade, id }) end
  T.dropRole(id)
  T.log(x, 'OFFICER', ('Rank change for %s: %s'):format(id, T.gradeLabel(u.job, grade)), 'officer', id)
  T.notify({ type = 'system', title = 'Your rank changed', body = T.gradeLabel(u.job, grade), target = id })
  return { ok = true }
end)

rpc('hireOfficer', 'officers.manage', function(src, x, p)
  local id = tostring(p.id or '')
  local u = MySQL.single.await('SELECT identifier, firstname, lastname, job FROM users WHERE identifier = ?', { id })
  if not u then return { error = 'No citizen with that ID.' } end
  if Config.Jobs[u.job] then return { error = 'They already work for the department.' } end
  local job = Config.Jobs[x.job.name] and x.job.name or 'police'
  local px = meOnline(id)
  if px then px.setJob(job, 0) else MySQL.update.await('UPDATE users SET job = ?, job_grade = 0 WHERE identifier = ?', { job, id }) end
  upsertOfficer(id, { callsign = '', badge = clip(p.badge, 12), division = clip(p.division, 40), supervisor = nil, certs = nil, role = nil, active = 1, note = 'Onboarded by ' .. x.getName() })
  T.log(x, 'OFFICER', ('Onboarded %s'):format(fullName(u)), 'officer', id)
  return { ok = true }
end)

rpc('separateOfficer', 'officers.manage', function(src, x, p)
  local id = tostring(p.id or '')
  local u = MySQL.single.await('SELECT identifier, firstname, lastname, job, job_grade FROM users WHERE identifier = ?', { id })
  if not u or not Config.Jobs[u.job] then return { error = 'Officer not found.' } end
  if id == x.identifier then return { error = 'You cannot remove yourself.' } end
  local admin = T.roleOf(x) == 'admin'
  if not admin and (tonumber(u.job_grade) or 0) >= (tonumber(x.job.grade) or 0) then return { error = 'You can only remove officers ranked below you.' } end
  local reason = clip(p.reason, 160)
  if #reason < 3 then return { error = 'Write the reason for the record.' } end
  local px = meOnline(id)
  if px then px.setJob('unemployed', 0) else MySQL.update.await("UPDATE users SET job = 'unemployed', job_grade = 0 WHERE identifier = ?", { id }) end
  MySQL.update.await('UPDATE tez_mdt_officers SET active = 0, note = ? WHERE identifier = ?', { 'Separated: ' .. reason, id })
  T.dropMeta(id); T.dropRole(id)
  T.log(x, 'OFFICER', ('Separated %s: %s'):format(fullName(u), reason), 'officer', id)
  return { ok = true }
end)

-- ---------- audit log ----------
rpc('listAudit', 'audit.view', function(src, x, p)
  local per, off, order, page = T.paging(p, { id = 'id', at = 'at', officer = 'officer', action = 'action' }, 'at')
  local w = T.Where()
  if p.action and p.action ~= 'all' then w:add('action = ?', tostring(p.action)) end
  if p.hideViews then w:add("action <> 'VIEW'") end
  if p.entity and p.entity ~= '' then w:add('entity = ?', clip(p.entity, 16)) end
  if p.entity_id and p.entity_id ~= '' then w:add('entity_id = ?', clip(p.entity_id, 60)) end
  local q = clip(p.q, 40)
  if #q >= 1 then w:add('(officer LIKE ? OR details LIKE ?)', like(q), like(q)) end
  local total = tonumber(MySQL.scalar.await('SELECT COUNT(*) FROM tez_mdt_log' .. w:sql(), w:with())) or 0
  local rows = MySQL.query.await('SELECT id, officer, action, details, at, entity, entity_id FROM tez_mdt_log' .. w:sql() .. ' ' .. order .. ' LIMIT ? OFFSET ?', w:with(per, off)) or {}
  return T.pageResult(rows, total, page)
end)

rpc('auditActions', 'audit.view', function()
  local rows = MySQL.query.await('SELECT DISTINCT action FROM tez_mdt_log ORDER BY action') or {}
  local out = {}
  for _, r in ipairs(rows) do out[#out + 1] = r.action end
  return { actions = out }
end)

-- ---------- live map ----------
rpc('getMap', 'person.view', function(src, x, p)
  return { calls = T.openCalls(), officers = T.rosterList(), me = src }
end)

-- ---------- department settings (read only view of the config that matters) ----------
rpc('getSettings', 'settings.view', function(src, x, p)
  local roles = {}
  for id, r in pairs(Config.Roles) do roles[#roles + 1] = { id = id, label = r.label, inherit = r.inherit, perms = r.perms } end
  table.sort(roles, function(a, b) return a.id < b.id end)
  local jobs = {}
  for j in pairs(Config.Jobs) do jobs[#jobs + 1] = j end
  return {
    roles = roles, jobs = jobs, gradeRoles = Config.GradeRoles, warrantApproval = Config.WarrantApproval, warrantDays = Config.WarrantDays,
    court = Config.Court and Config.Court.enabled or false, retention = Config.Retention, charges = #Config.Charges,
    note = 'These values live in config.lua. Edit the file and run "restart tez_mdt" to change them.',
  }
end)
