-- Tez MDT v3 - dispatch/CAD, BOLOs, incident reports, evidence, impound, court
-- Made by Tez Development

local ESX = exports['es_extended']:getSharedObject()
local T = TezMDT
local now, clip, decode, fullName, like, normPlate, intOrNil = T.now, T.clip, T.decode, T.fullName, T.like, T.normPlate, T.intOrNil
local rpc, stale = T.rpc, nil
local Calls = T.Calls

local function getUser(identifier)
  return MySQL.single.await('SELECT identifier, firstname, lastname, job, job_grade FROM users WHERE identifier = ?', { tostring(identifier or '') })
end

local function oneOf(list, value, default)
  for _, v in ipairs(list) do
    local id = type(v) == 'table' and v.id or v
    if id == value then return id end
  end
  return default
end

local function labelOf(list, id)
  for _, v in ipairs(list) do
    if type(v) == 'table' and v.id == id then return v.label end
  end
  return id
end

local function staleCheck(row, p, col)
  if p.expected ~= nil and tonumber(p.expected) ~= (tonumber(row[col or 'updated_at']) or 0) then
    return { error = 'Someone changed this while you were editing. Close it and open it again.' }
  end
end

-- ============================================================
--  DISPATCH / CAD
-- ============================================================
local function rosterList()
  local out = {}
  for _, x in ipairs(T.officers()) do
    local ped = GetPlayerPed(x.source)
    local c = ped ~= 0 and GetEntityCoords(ped) or vector3(0.0, 0.0, 0.0)
    local m = T.meta(x.identifier)
    out[#out + 1] = {
      src = x.source, name = x.getName(), callsign = m.callsign or '', badge = m.badge or '',
      grade = T.gradeLabel(x.job.name, x.job.grade), dept = x.job.label or x.job.name,
      status = T.Status[x.source] or 'available', statusAt = T.StatusAt[x.source] or now(),
      x = c.x, y = c.y, callId = T.unitCallId(x.source),
    }
  end
  table.sort(out, function(a, b)
    local ka = a.callsign ~= '' and a.callsign or ('~' .. a.name)
    local kb = b.callsign ~= '' and b.callsign or ('~' .. b.name)
    return ka < kb
  end)
  return out
end
T.rosterList = rosterList

local function loadCall(id)
  id = tonumber(id) or 0
  local c = Calls[id]
  if c then return T.publicCall(c), c end
  local r = MySQL.single.await('SELECT * FROM tez_mdt_calls WHERE id = ?', { id })
  if not r then return nil end
  local units = {}
  for _, l in ipairs(decode(r.units, {})) do units[#units + 1] = { label = l } end
  return {
    id = r.id, kind = r.kind, type = r.type, msg = r.msg, location = r.location, x = r.x, y = r.y, caller = r.caller, at = r.created_at,
    priority = r.priority, status = r.status, units = units, timeline = decode(r.timeline, {}), report_id = r.report_id,
    closedAt = r.closed_at, closedBy = r.closed_by,
  }
end

rpc('getDispatch', 'person.view', function(src, x, p)
  return { calls = T.openCalls(), officers = rosterList(), me = src }
end)

rpc('listCalls', 'person.view', function(src, x, p)
  if p.status == 'closed' then
    local per, off, order, page = T.paging(p, { id = 'id', created = 'created_at', priority = 'priority' }, 'created')
    local w = T.Where()
    w:add("status = 'closed'")
    local q = clip(p.q, 40)
    if #q >= 1 then
      local n = tonumber((q:gsub('^[Cc]%-?', '')))
      if n then w:add('(id = ? OR msg LIKE ? OR location LIKE ?)', n, like(q), like(q)) else w:add('(msg LIKE ? OR location LIKE ?)', like(q), like(q)) end
    end
    local total = MySQL.scalar.await('SELECT COUNT(*) FROM tez_mdt_calls' .. w:sql(), w:with()) or 0
    local rows = MySQL.query.await('SELECT id, kind, type, priority, msg, location, caller, created_at, closed_at, closed_by, report_id FROM tez_mdt_calls' .. w:sql() .. ' ' .. order .. ' LIMIT ? OFFSET ?', w:with(per, off)) or {}
    return T.pageResult(rows, total, page)
  end
  return { calls = T.openCalls() }
end)

rpc('getCall', 'person.view', function(src, x, p)
  local c = loadCall(p.id)
  if not c then return { error = 'Call not found.' } end
  T.logView(x, 'call', c.id)
  return c
end)

rpc('createCall', 'call.create', function(src, x, p)
  local msg = clip(p.msg, 240)
  if #msg < 5 then return { error = 'Describe what is happening (at least a few words).' } end
  local ped = GetPlayerPed(src)
  local coords = ped ~= 0 and GetEntityCoords(ped) or vector3(0.0, 0.0, 0.0)
  if T.can(x, 'call.manage') and tonumber(p.x) and tonumber(p.y) then coords = vector3(tonumber(p.x) + 0.0, tonumber(p.y) + 0.0, 0.0) end
  local pr = math.max(1, math.min(4, math.floor(tonumber(p.priority) or 2)))
  local c = T.createCall({
    kind = 'mdt', type = oneOf(Config.CallTypes, p.type, 'other'), msg = msg, coords = coords,
    caller = clip(p.caller, 80) ~= '' and clip(p.caller, 80) or ('Created by ' .. x.getName()), priority = pr, location = clip(p.location, 120),
  })
  T.log(x, 'CALL', ('Created call #%d: %s'):format(c.id, msg), 'call', c.id)
  return { ok = true, id = c.id }
end)

rpc('updateCall', 'call.manage', function(src, x, p)
  local _, c = loadCall(p.id)
  if not c or c.status ~= 'open' then return { error = 'That call is not open.' } end
  local changes = {}
  local pr = tonumber(p.priority)
  if pr and math.floor(pr) ~= c.priority then
    c.priority = math.max(1, math.min(4, math.floor(pr)))
    changes[#changes + 1] = 'priority ' .. c.priority
  end
  local ty = oneOf(Config.CallTypes, p.type, c.type)
  if ty ~= c.type then c.type = ty; changes[#changes + 1] = 'type ' .. labelOf(Config.CallTypes, ty) end
  local msg = clip(p.msg, 240)
  if #msg >= 5 and msg ~= c.msg then c.msg = msg; changes[#changes + 1] = 'description' end
  local loc = clip(p.location, 120)
  if p.location ~= nil and loc ~= c.location then c.location = loc; changes[#changes + 1] = 'location' end
  if #changes == 0 then return { ok = true } end
  T.addTimeline(c, x.getName(), 'Updated ' .. table.concat(changes, ', '))
  T.persistCall(c)
  T.log(x, 'CALL', ('Edited call #%d (%s)'):format(c.id, table.concat(changes, ', ')), 'call', c.id)
  return { ok = true }
end)

local function setUnitOnCall(c, src, role, who, label)
  c.units[src] = { label = label, role = role }
  if T.Status[src] ~= 'emergency' then T.setStatus(src, 'enroute') end
  T.addTimeline(c, who, label .. ' assigned (' .. role .. ')')
  T.persistCall(c)
end

rpc('attachCall', 'call.respond', function(src, x, p)
  local _, c = loadCall(p.id)
  if not c or c.status ~= 'open' then return { error = 'That call is no longer open.' } end
  if c.units[src] then
    c.units[src] = nil
    if T.Status[src] == 'enroute' or T.Status[src] == 'onscene' then T.setStatus(src, 'available') end
    T.addTimeline(c, x.getName(), T.officerLabel(x) .. ' left the call')
    T.persistCall(c)
  else
    local role = next(c.units) and 'assist' or 'primary'
    setUnitOnCall(c, src, role, x.getName(), T.officerLabel(x))
    TriggerClientEvent('tez_mdt:client:waypoint', src, c.x, c.y)
  end
  return { ok = true }
end)

rpc('assignUnit', 'call.manage', function(src, x, p)
  local _, c = loadCall(p.id)
  if not c or c.status ~= 'open' then return { error = 'That call is no longer open.' } end
  local unit = tonumber(p.unit)
  local ux = unit and ESX.GetPlayerFromId(unit)
  if not ux or not T.canUse(ux) then return { error = 'That unit is not on duty.' } end
  if p.remove then
    c.units[unit] = nil
    if T.Status[unit] == 'enroute' or T.Status[unit] == 'onscene' then T.setStatus(unit, 'available') end
    T.addTimeline(c, x.getName(), T.officerLabel(ux) .. ' removed from the call')
    T.persistCall(c)
  else
    local role = (p.role == 'primary') and 'primary' or 'assist'
    if role == 'primary' then
      for _, u in pairs(c.units) do if u.role == 'primary' then u.role = 'assist' end end
    end
    setUnitOnCall(c, unit, role, x.getName(), T.officerLabel(ux))
    TriggerClientEvent('tez_mdt:client:waypoint', unit, c.x, c.y)
    TriggerClientEvent('tez_mdt:client:newCall', unit, T.publicCall(c))
  end
  T.log(x, 'CALL', ('Changed units on call #%d'):format(c.id), 'call', c.id)
  return { ok = true }
end)

rpc('addCallNote', 'call.respond', function(src, x, p)
  local _, c = loadCall(p.id)
  if not c or c.status ~= 'open' then return { error = 'That call is not open.' } end
  local text = clip(p.text, 160)
  if #text < 2 then return { error = 'Write a note first.' } end
  T.addTimeline(c, T.officerLabel(x), 'Note: ' .. text)
  T.persistCall(c)
  return { ok = true }
end)

rpc('linkCallReport', 'call.respond', function(src, x, p)
  local _, c = loadCall(p.id)
  if not c then return { error = 'Call not found.' } end
  local rid = T.validReport(p.report_id)
  if not rid then return { error = 'That report does not exist.' } end
  if c.status == 'open' then
    c.report_id = rid
    T.addTimeline(c, x.getName(), ('Linked to report R-%d'):format(rid))
    T.persistCall(c)
  else
    MySQL.update.await('UPDATE tez_mdt_calls SET report_id = ? WHERE id = ?', { rid, tonumber(p.id) })
  end
  T.log(x, 'CALL', ('Linked call #%s to report R-%d'):format(tostring(p.id), rid), 'call', p.id)
  return { ok = true }
end)

rpc('closeCall', 'call.respond', function(src, x, p)
  local _, c = loadCall(p.id)
  if not c or c.status ~= 'open' then return { error = 'That call is already closed.' } end
  if not c.units[src] and not T.can(x, 'call.manage') then return { error = 'Only a unit on the call or a dispatcher can close it.' } end
  local note = clip(p.note, 120)
  T.closeCall(c, x.getName(), note ~= '' and ('Call closed: ' .. note) or 'Call closed')
  T.log(x, 'CALL', ('Closed call #%d'):format(c.id), 'call', c.id)
  return { ok = true }
end)

rpc('waypointCall', 'call.respond', function(src, x, p)
  local c = loadCall(p.id)
  if not c then return { error = 'Call not found.' } end
  TriggerClientEvent('tez_mdt:client:waypoint', src, c.x, c.y)
  return { ok = true }
end)

rpc('setStatus', nil, function(src, x, p)
  local id = tostring(p.status or '')
  if not T.statusById[id] then return { error = 'Unknown status.' } end
  T.setStatus(src, id)
  if id == 'emergency' then T.panic(src, x) end
  return { ok = true }
end)

rpc('roster', 'person.view', function() return { officers = rosterList() } end)

-- ============================================================
--  BOLOs
-- ============================================================
CreateThread(function()
  Wait(12000)
  while true do
    MySQL.update("UPDATE tez_mdt_bolos SET status = 'expired' WHERE status = 'active' AND expires_at < ?", { now() })
    Wait(60000)
  end
end)

local BOLO_SORT = { id = 'id', created = 'created_at', expires = 'expires_at', priority = 'priority', title = 'title' }

rpc('listBolos', 'person.view', function(src, x, p)
  local per, off, order, page = T.paging(p, BOLO_SORT, 'created')
  local w = T.Where()
  local st = tostring(p.status or 'active')
  if st ~= 'all' then w:add('status = ?', st) end
  if p.kind and p.kind ~= 'all' then w:add('kind = ?', tostring(p.kind)) end
  local q = clip(p.q, 40)
  if #q >= 1 then
    local n = tonumber((q:gsub('^[Bb]%-?', '')))
    if n then w:add('(id = ? OR title LIKE ? OR plate LIKE ?)', n, like(q), like(normPlate(q))) else w:add('(title LIKE ? OR plate LIKE ? OR description LIKE ?)', like(q), like(normPlate(q)), like(q)) end
  end
  local total = MySQL.scalar.await('SELECT COUNT(*) FROM tez_mdt_bolos' .. w:sql(), w:with()) or 0
  local rows = MySQL.query.await('SELECT id, kind, title, plate, priority, location, issued_by, status, created_at, expires_at, image FROM tez_mdt_bolos' .. w:sql() .. ' ' .. order .. ' LIMIT ? OFFSET ?', w:with(per, off)) or {}
  return T.pageResult(rows, total, page)
end)

rpc('getBolo', 'person.view', function(src, x, p)
  local b = MySQL.single.await('SELECT * FROM tez_mdt_bolos WHERE id = ?', { tonumber(p.id) or 0 })
  if not b then return { error = 'BOLO not found.' } end
  b.updates = decode(b.updates, {})
  return b
end)

rpc('createBolo', 'bolo.create', function(src, x, p)
  local kind = oneOf(Config.BoloTypes, p.kind, 'person')
  local title = clip(p.title, 120)
  if #title < 3 then return { error = 'Give the BOLO a title.' } end
  local desc = clip(p.description, 1500)
  if #desc < 5 then return { error = 'Describe who or what to look for.' } end
  local plate = normPlate(p.plate):sub(1, 12)
  if plate == '' then plate = nil end
  local image = clip(p.image, 255)
  if image ~= '' and not image:match('^https?://') then return { error = 'The image link must start with http:// or https://' } end
  local hours = math.max(1, math.min(720, tonumber(p.hours) or Config.BoloHours))
  local pr = math.max(1, math.min(3, math.floor(tonumber(p.priority) or 2)))
  local t = now()
  local id = MySQL.insert.await('INSERT INTO tez_mdt_bolos (kind, title, description, plate, issued_by, created_at, expires_at, priority, location, image, report_id, updates, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
    { kind, title, desc, plate, T.officerLabel(x), t, t + hours * 3600, pr, clip(p.location, 120), image ~= '' and image or nil, T.validReport(p.report_id), '[]', t })
  T.log(x, 'BOLO', ('New BOLO B-%d: %s'):format(id, title), 'bolo', id)
  T.toOfficers('tez_mdt:client:bolo', title, plate)
  T.notify({ type = 'bolo', title = 'New BOLO: ' .. title, body = clip(desc, 120), perm = 'person.view', page = 'bolos', id = id })
  T.webhook('New BOLO', ('**%s**\n%s%s'):format(title, desc, plate and ('\nPlate: ' .. plate) or ''), 15844367)
  return { ok = true, id = id }
end)

rpc('addBoloUpdate', 'bolo.create', function(src, x, p)
  local b = MySQL.single.await("SELECT * FROM tez_mdt_bolos WHERE id = ? AND status = 'active'", { tonumber(p.id) or 0 })
  if not b then return { error = 'That BOLO is not active.' } end
  local text = clip(p.text, 300)
  if #text < 3 then return { error = 'Write the update.' } end
  local ups = decode(b.updates, {})
  ups[#ups + 1] = { at = now(), by = T.officerLabel(x), text = text }
  MySQL.update.await('UPDATE tez_mdt_bolos SET updates = ?, updated_at = ? WHERE id = ?', { json.encode(ups), now(), b.id })
  T.log(x, 'BOLO', ('Updated BOLO B-%d'):format(b.id), 'bolo', b.id)
  T.notify({ type = 'bolo', title = 'BOLO update: ' .. b.title, body = text, perm = 'person.view', page = 'bolos', id = b.id })
  return { ok = true }
end)

rpc('extendBolo', 'bolo.create', function(src, x, p)
  local hours = math.max(1, math.min(720, tonumber(p.hours) or 12))
  MySQL.update.await("UPDATE tez_mdt_bolos SET expires_at = expires_at + ?, status = 'active', updated_at = ? WHERE id = ? AND status IN ('active', 'expired')", { hours * 3600, now(), tonumber(p.id) or 0 })
  T.log(x, 'BOLO', ('Extended BOLO B-%s by %d hours'):format(tostring(p.id), hours), 'bolo', p.id)
  return { ok = true }
end)

rpc('closeBolo', 'bolo.create', function(src, x, p)
  local b = MySQL.single.await('SELECT issued_by, status FROM tez_mdt_bolos WHERE id = ?', { tonumber(p.id) or 0 })
  if not b or b.status ~= 'active' then return { error = 'That BOLO is not active.' } end
  local status = (p.status == 'found') and 'found' or 'cancelled'
  MySQL.update.await("UPDATE tez_mdt_bolos SET status = ?, updated_at = ? WHERE id = ? AND status = 'active'", { status, now(), tonumber(p.id) })
  T.log(x, 'BOLO', ('BOLO B-%s marked %s'):format(tostring(p.id), status), 'bolo', p.id)
  return { ok = true }
end)

-- ============================================================
--  INCIDENT REPORTS  (draft > submitted > returned / approved)
-- ============================================================
local REPORT_SORT = { id = 'r.id', title = 'r.title', status = 'r.status', type = 'r.type', created = 'r.created_at', author = 'r.author_name' }

rpc('listReports', 'person.view', function(src, x, p)
  local per, off, order, page = T.paging(p, REPORT_SORT, 'created')
  local w = T.Where()
  w:add("(r.status <> 'draft' OR r.author_identifier = ?)", x.identifier)
  local st = tostring(p.status or 'all')
  if st ~= 'all' then w:add('r.status = ?', st) end
  if p.type and p.type ~= 'all' then w:add('r.type = ?', tostring(p.type)) end
  if p.mine then w:add('r.author_identifier = ?', x.identifier) end
  local q = clip(p.q, 60)
  if #q >= 1 then
    local n = tonumber((q:gsub('^[Rr]%-?', '')))
    if n then w:add('(r.id = ? OR r.title LIKE ? OR r.author_name LIKE ?)', n, like(q), like(q)) else w:add('(r.title LIKE ? OR r.author_name LIKE ? OR r.location LIKE ? OR r.involved LIKE ?)', like(q), like(q), like(q), like(q)) end
  end
  local total = MySQL.scalar.await('SELECT COUNT(*) FROM tez_mdt_reports r' .. w:sql(), w:with()) or 0
  local rows = MySQL.query.await('SELECT r.id, r.type, r.title, r.status, r.author_name, r.location, r.created_at, r.submitted_at, r.version, r.call_id FROM tez_mdt_reports r' .. w:sql() .. ' ' .. order .. ' LIMIT ? OFFSET ?', w:with(per, off)) or {}
  return T.pageResult(rows, total, page)
end)

local function nameList(identifiers)
  local out = {}
  for _, id in ipairs(identifiers) do
    local u = getUser(id)
    out[#out + 1] = { identifier = id, name = u and fullName(u) or id }
  end
  return out
end

rpc('getReport', 'person.view', function(src, x, p)
  local r = MySQL.single.await('SELECT * FROM tez_mdt_reports WHERE id = ?', { tonumber(p.id) or 0 })
  if not r or (r.status == 'draft' and r.author_identifier ~= x.identifier) then return { error = 'Report not found.' } end
  T.logView(x, 'report', r.id)
  local id = tostring(r.id)
  local evIds = decode(r.evidence, {})
  r.people = nameList(decode(r.people, {}))
  r.vehicles = decode(r.vehicles, {})
  r.evidence = evIds
  r.attachments = decode(r.attachments, {})
  r.versions = MySQL.query.await('SELECT version, title, edited_by, at FROM tez_mdt_report_versions WHERE report_id = ? ORDER BY version DESC LIMIT 30', { r.id }) or {}
  r.comments = MySQL.query.await('SELECT by_name, kind, text, at FROM tez_mdt_report_comments WHERE report_id = ? ORDER BY id', { r.id }) or {}
  r.linked = {
    citations = MySQL.query.await('SELECT id, person_name, fine, status FROM tez_mdt_citations WHERE report_id = ?', { r.id }) or {},
    bookings = MySQL.query.await('SELECT id, person_name, status FROM tez_mdt_bookings WHERE report_id = ?', { r.id }) or {},
    warrants = MySQL.query.await('SELECT id, citizen_name, type, status FROM tez_mdt_warrants WHERE report_id = ?', { r.id }) or {},
    calls = MySQL.query.await('SELECT id, msg FROM tez_mdt_calls WHERE report_id = ? OR id = ?', { r.id, r.call_id or 0 }) or {},
  }
  r.canEdit = (r.author_identifier == x.identifier) and (r.status == 'draft' or r.status == 'returned')
  r.canReview = T.can(x, 'report.review') and r.status == 'submitted'
  return r
end)

local function cleanPeople(list)
  local out, seen = {}, {}
  for _, id in ipairs(type(list) == 'table' and list or {}) do
    id = tostring(id)
    if not seen[id] and #out < 20 and MySQL.scalar.await('SELECT identifier FROM users WHERE identifier = ?', { id }) then
      seen[id] = true; out[#out + 1] = id
    end
  end
  return out
end

local function cleanPlates(list)
  local out, seen = {}, {}
  for _, pl in ipairs(type(list) == 'table' and list or {}) do
    pl = normPlate(pl):sub(1, 12)
    if #pl >= 2 and not seen[pl] and #out < 12 then seen[pl] = true; out[#out + 1] = pl end
  end
  return out
end

local function cleanUrls(list)
  local out = {}
  for _, u in ipairs(type(list) == 'table' and list or {}) do
    u = clip(u, 255)
    if u:match('^https?://') and #out < 6 then out[#out + 1] = u end
  end
  return out
end

rpc('saveReport', 'report.create', function(src, x, p)
  local title = clip(p.title, 120)
  if #title < 3 then return { error = 'Give the report a title.' } end
  local narrative = clip(p.narrative, 8000)
  local submit = p.submit == true
  if submit and #narrative < 20 then return { error = 'A submitted report needs a proper narrative (at least a couple of sentences).' } end
  local kind = oneOf(Config.ReportTypes, p.type, 'incident')
  local t = now()
  local callId = intOrNil(p.call_id)
  if callId and not MySQL.scalar.await('SELECT id FROM tez_mdt_calls WHERE id = ?', { callId }) then callId = nil end
  local occurred = tonumber(p.occurred_at) or t
  if occurred > t then occurred = t end
  local fields = {
    kind, title, narrative, clip(p.involved, 500), json.encode(T.evidenceIds(p.evidence)), json.encode(cleanPeople(p.people)), json.encode(cleanPlates(p.vehicles)),
    clip(p.witnesses, 500), json.encode(cleanUrls(p.attachments)), clip(p.assisting, 200), clip(p.location, 120), callId, math.floor(occurred),
  }

  if p.id then
    local r = MySQL.single.await('SELECT * FROM tez_mdt_reports WHERE id = ?', { tonumber(p.id) or 0 })
    if not r then return { error = 'Report not found.' } end
    if r.author_identifier ~= x.identifier then return { error = 'Only the author can edit a report.' } end
    if r.status ~= 'draft' and r.status ~= 'returned' then return { error = 'A submitted report cannot be edited. Ask a supervisor to return it.' } end
    local s = staleCheck(r, p, 'version')
    if s then return s end
    local newStatus = submit and 'submitted' or r.status
    local ver = (tonumber(r.version) or 1) + 1
    MySQL.update.await('UPDATE tez_mdt_reports SET type = ?, title = ?, narrative = ?, involved = ?, evidence = ?, people = ?, vehicles = ?, witnesses = ?, attachments = ?, assisting = ?, location = ?, call_id = ?, occurred_at = ?, status = ?, version = ?, updated_at = ?, submitted_at = COALESCE(submitted_at, ?) WHERE id = ?',
      { fields[1], fields[2], fields[3], fields[4], fields[5], fields[6], fields[7], fields[8], fields[9], fields[10], fields[11], fields[12], fields[13], newStatus, ver, t, submit and t or nil, r.id })
    MySQL.insert('INSERT INTO tez_mdt_report_versions (report_id, version, title, narrative, edited_by, at) VALUES (?, ?, ?, ?, ?, ?)', { r.id, ver, title, narrative, x.getName(), t })
    T.log(x, 'REPORT', ('%s report R-%d (v%d)'):format(submit and 'Submitted' or 'Saved', r.id, ver), 'report', r.id)
    if submit then
      T.notify({ type = 'report', title = 'Report submitted for review', body = title, perm = 'report.review', page = 'reports', id = r.id })
    end
    return { ok = true, id = r.id, status = newStatus, version = ver }
  end

  local status = submit and 'submitted' or 'draft'
  local id = MySQL.insert.await('INSERT INTO tez_mdt_reports (type, title, narrative, involved, evidence, people, vehicles, witnesses, attachments, assisting, location, call_id, occurred_at, status, author_identifier, author_name, created_at, submitted_at, version, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)',
    { fields[1], fields[2], fields[3], fields[4], fields[5], fields[6], fields[7], fields[8], fields[9], fields[10], fields[11], fields[12], fields[13], status, x.identifier, x.getName(), t, submit and t or nil, t })
  MySQL.insert('INSERT INTO tez_mdt_report_versions (report_id, version, title, narrative, edited_by, at) VALUES (?, ?, ?, ?, ?, ?)', { id, 1, title, narrative, x.getName(), t })
  if callId then
    local _, c = loadCall(callId)
    if c and c.status == 'open' then c.report_id = id; T.addTimeline(c, x.getName(), ('Linked to report R-%d'):format(id)); T.persistCall(c) else MySQL.update('UPDATE tez_mdt_calls SET report_id = ? WHERE id = ?', { id, callId }) end
  end
  T.log(x, 'REPORT', ('%s report R-%d: %s'):format(submit and 'Submitted' or 'Started', id, title), 'report', id)
  if submit then T.notify({ type = 'report', title = 'Report submitted for review', body = title, perm = 'report.review', page = 'reports', id = id }) end
  return { ok = true, id = id, status = status, version = 1 }
end)

rpc('deleteDraft', 'report.create', function(src, x, p)
  local r = MySQL.single.await('SELECT id, status, author_identifier FROM tez_mdt_reports WHERE id = ?', { tonumber(p.id) or 0 })
  if not r or r.status ~= 'draft' or r.author_identifier ~= x.identifier then return { error = 'Only your own drafts can be deleted.' } end
  MySQL.update.await('DELETE FROM tez_mdt_reports WHERE id = ?', { r.id })
  MySQL.update.await('DELETE FROM tez_mdt_report_versions WHERE report_id = ?', { r.id })
  T.log(x, 'REPORT', ('Deleted draft R-%d'):format(r.id), 'report', r.id)
  return { ok = true }
end)

rpc('reviewReport', 'report.review', function(src, x, p)
  local r = MySQL.single.await('SELECT * FROM tez_mdt_reports WHERE id = ?', { tonumber(p.id) or 0 })
  if not r or r.status ~= 'submitted' then return { error = 'This report is not waiting for review.' } end
  local comment = clip(p.comment, 500)
  local t = now()
  if p.decision == 'approve' then
    MySQL.update.await("UPDATE tez_mdt_reports SET status = 'approved', reviewed_by = ?, updated_at = ? WHERE id = ?", { x.getName(), t, r.id })
    if comment ~= '' then MySQL.insert('INSERT INTO tez_mdt_report_comments (report_id, by_name, kind, text, at) VALUES (?, ?, ?, ?, ?)', { r.id, x.getName(), 'approve', comment, t }) end
    MySQL.insert('INSERT INTO tez_mdt_report_comments (report_id, by_name, kind, text, at) VALUES (?, ?, ?, ?, ?)', { r.id, x.getName(), 'approve', 'Approved', t })
    T.log(x, 'REVIEW', ('Approved report R-%d'):format(r.id), 'report', r.id)
    T.notify({ type = 'report', title = 'Report approved', body = r.title, target = r.author_identifier, page = 'reports', id = r.id })
  else
    if #comment < 3 then return { error = 'Tell the officer what needs to change.' } end
    MySQL.update.await("UPDATE tez_mdt_reports SET status = 'returned', reviewed_by = ?, updated_at = ? WHERE id = ?", { x.getName(), t, r.id })
    MySQL.insert('INSERT INTO tez_mdt_report_comments (report_id, by_name, kind, text, at) VALUES (?, ?, ?, ?, ?)', { r.id, x.getName(), 'return', comment, t })
    T.log(x, 'REVIEW', ('Returned report R-%d'):format(r.id), 'report', r.id)
    T.notify({ type = 'report', title = 'Report returned to you', body = comment, target = r.author_identifier, page = 'reports', id = r.id })
  end
  return { ok = true }
end)

rpc('addReportComment', 'person.view', function(src, x, p)
  local r = MySQL.single.await('SELECT id, author_identifier, status FROM tez_mdt_reports WHERE id = ?', { tonumber(p.id) or 0 })
  if not r or r.status == 'draft' then return { error = 'Report not found.' } end
  if r.author_identifier ~= x.identifier and not T.can(x, 'report.review') then return { error = 'Only the author or a supervisor can comment.' } end
  local text = clip(p.text, 500)
  if #text < 2 then return { error = 'Write a comment first.' } end
  MySQL.insert.await('INSERT INTO tez_mdt_report_comments (report_id, by_name, kind, text, at) VALUES (?, ?, ?, ?, ?)', { r.id, x.getName(), 'comment', text, now() })
  T.log(x, 'REPORT', ('Commented on report R-%d'):format(r.id), 'report', r.id)
  return { ok = true }
end)

-- ============================================================
--  EVIDENCE with chain of custody
-- ============================================================
local function custody(id, event, by, detail)
  MySQL.insert('INSERT INTO tez_mdt_custody (evidence_id, event, by_name, detail, at) VALUES (?, ?, ?, ?, ?)', { id, event, by, clip(detail or '', 200), now() })
end

local function analyze(kind, d)
  if kind == 'casing' then
    local m = MySQL.single.await('SELECT w.owner_identifier AS identifier, u.firstname, u.lastname FROM tez_mdt_weapons w LEFT JOIN users u ON u.identifier = w.owner_identifier WHERE w.code = ? LIMIT 1', { d.ballistic })
    return { kind = 'casing', weapon = d.weaponLabel, code = d.ballistic, match = m and fullName(m) or nil, matchIdentifier = m and m.identifier or nil }
  end
  if kind == 'print' then
    local m = MySQL.single.await('SELECT u.identifier, u.firstname, u.lastname FROM tez_mdt_prints n JOIN users u ON u.identifier = n.identifier WHERE n.code = ? LIMIT 1', { d.code })
    return { kind = 'print', code = d.code, match = m and fullName(m) or nil, matchIdentifier = m and m.identifier or nil }
  end
  local m = MySQL.single.await('SELECT u.identifier, u.firstname, u.lastname FROM tez_mdt_dna n JOIN users u ON u.identifier = n.identifier WHERE n.code = ? LIMIT 1', { d.dna })
  return { kind = 'blood', code = d.dna, match = m and fullName(m) or nil, matchIdentifier = m and m.identifier or nil }
end

local function refreshEvidence(row)
  if row.status == 'analyzing' and row.analysis_ready_at and now() >= row.analysis_ready_at then
    local res = analyze(row.type, decode(row.details, {}))
    MySQL.update.await("UPDATE tez_mdt_evidence SET status = 'analyzed', result = ?, disposition = 'Stored', updated_at = ? WHERE id = ?", { json.encode(res), now(), row.id })
    custody(row.id, 'lab_result', 'Lab', res.match and ('Match found: ' .. res.match) or 'No match on file')
    row.status, row.result, row.disposition = 'analyzed', json.encode(res), 'Stored'
    if res.match then
      T.notify({ type = 'evidence', title = 'Lab result: match found', body = ('Evidence E-%d matches %s'):format(row.id, res.match), perm = 'evidence.view', page = 'evidence', id = row.id })
    end
  end
end

local EV_SORT = { id = 'id', category = 'category', status = 'status', created = 'collected_at', custodian = 'custodian' }
local EV_COLS = 'id, type, category, description, status, disposition, custodian, storage, report_id, collected_by_name, collected_at, analysis_ready_at, details, result'

local function evidenceRow(r)
  refreshEvidence(r)
  return {
    id = r.id, type = r.type, category = r.category, description = r.description, status = r.status, disposition = r.disposition,
    custodian = r.custodian, storage = r.storage, report_id = r.report_id, by = r.collected_by_name, at = r.collected_at,
    readyAt = r.analysis_ready_at, serverNow = now(), lab = (r.type == 'casing' or r.type == 'blood' or r.type == 'print'),
    result = (r.status == 'analyzed') and decode(r.result, nil) or nil,
  }
end

rpc('listEvidence', 'evidence.view', function(src, x, p)
  local per, off, order, page = T.paging(p, EV_SORT, 'created')
  local w = T.Where()
  if p.status and p.status ~= 'all' then w:add('status = ?', tostring(p.status)) end
  if p.category and p.category ~= 'all' then w:add('category = ?', tostring(p.category)) end
  if p.disposition and p.disposition ~= 'all' then w:add('disposition = ?', tostring(p.disposition)) end
  local q = clip(p.q, 40)
  if #q >= 1 then
    local n = tonumber((q:gsub('^[Ee]%-?', '')))
    if n then w:add('(id = ? OR description LIKE ? OR custodian LIKE ?)', n, like(q), like(q)) else w:add('(description LIKE ? OR custodian LIKE ? OR storage LIKE ?)', like(q), like(q), like(q)) end
  end
  local total = MySQL.scalar.await('SELECT COUNT(*) FROM tez_mdt_evidence' .. w:sql(), w:with()) or 0
  local rows = MySQL.query.await('SELECT ' .. EV_COLS .. ' FROM tez_mdt_evidence' .. w:sql() .. ' ' .. order .. ' LIMIT ? OFFSET ?', w:with(per, off)) or {}
  local out = {}
  for _, r in ipairs(rows) do out[#out + 1] = evidenceRow(r) end
  return T.pageResult(out, total, page)
end)

rpc('getEvidence', 'evidence.view', function(src, x, p)
  local r = MySQL.single.await('SELECT * FROM tez_mdt_evidence WHERE id = ?', { tonumber(p.id) or 0 })
  if not r then return { error = 'Evidence not found.' } end
  T.logView(x, 'evidence', r.id)
  local row = evidenceRow(r)
  row.attachments = decode(r.attachments, {})
  row.custody = MySQL.query.await('SELECT event, by_name, detail, at FROM tez_mdt_custody WHERE evidence_id = ? ORDER BY id', { r.id }) or {}
  row.canTransfer = T.can(x, 'evidence.transfer') or r.custodian == x.getName()
  return row
end)

rpc('createEvidence', 'evidence.collect', function(src, x, p)
  local desc = clip(p.description, 200)
  if #desc < 3 then return { error = 'Describe the item.' } end
  local cat = oneOf(Config.EvidenceCategories, p.category, 'Other')
  local t = now()
  local id = MySQL.insert.await('INSERT INTO tez_mdt_evidence (type, details, x, y, z, collected_by_identifier, collected_by_name, collected_at, status, category, description, report_id, storage, custodian, disposition, attachments, updated_at) VALUES (?, ?, 0, 0, 0, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
    { 'manual', '{}', x.identifier, x.getName(), t, 'collected', cat, desc, T.validReport(p.report_id), clip(p.storage, 120), x.getName(), 'Stored', json.encode(cleanUrls(p.attachments)), t })
  custody(id, 'collected', x.getName(), 'Logged by hand: ' .. desc)
  T.log(x, 'EVIDENCE', ('Logged evidence E-%d: %s'):format(id, desc), 'evidence', id)
  return { ok = true, id = id }
end)

rpc('transferEvidence', 'evidence.view', function(src, x, p)
  local r = MySQL.single.await('SELECT * FROM tez_mdt_evidence WHERE id = ?', { tonumber(p.id) or 0 })
  if not r then return { error = 'Evidence not found.' } end
  if not (T.can(x, 'evidence.transfer') or r.custodian == x.getName()) then return { error = 'Only the current custodian or a supervisor can transfer this.' } end
  if r.disposition == 'Destroyed' or r.disposition == 'Released to owner' then return { error = 'This evidence has already been closed out.' } end
  local to = getUser(p.to)
  if not to or not Config.Jobs[to.job] then return { error = 'Pick an officer to hand it to.' } end
  local name = fullName(to)
  MySQL.update.await('UPDATE tez_mdt_evidence SET custodian = ?, updated_at = ? WHERE id = ?', { name, now(), r.id })
  custody(r.id, 'transfer', x.getName(), ('Transferred to %s. %s'):format(name, clip(p.note, 120)))
  T.log(x, 'EVIDENCE', ('Transferred E-%d to %s'):format(r.id, name), 'evidence', r.id)
  T.notify({ type = 'evidence', title = 'Evidence transferred to you', body = ('E-%d from %s'):format(r.id, x.getName()), target = to.identifier, page = 'evidence', id = r.id })
  return { ok = true }
end)

rpc('setEvidenceStorage', 'evidence.view', function(src, x, p)
  local r = MySQL.single.await('SELECT * FROM tez_mdt_evidence WHERE id = ?', { tonumber(p.id) or 0 })
  if not r then return { error = 'Evidence not found.' } end
  if not (T.can(x, 'evidence.transfer') or r.custodian == x.getName()) then return { error = 'Only the current custodian or a supervisor can move this.' } end
  local s = staleCheck(r, p)
  if s then return s end
  local loc = clip(p.storage, 120)
  MySQL.update.await('UPDATE tez_mdt_evidence SET storage = ?, updated_at = ? WHERE id = ?', { loc, now(), r.id })
  custody(r.id, 'location', x.getName(), 'Storage location: ' .. loc)
  T.log(x, 'EVIDENCE', ('Moved E-%d to %s'):format(r.id, loc), 'evidence', r.id)
  return { ok = true }
end)

rpc('linkEvidenceReport', 'evidence.view', function(src, x, p)
  local r = MySQL.single.await('SELECT id, custodian FROM tez_mdt_evidence WHERE id = ?', { tonumber(p.id) or 0 })
  if not r then return { error = 'Evidence not found.' } end
  local rid = T.validReport(p.report_id)
  if not rid then return { error = 'That report does not exist.' } end
  MySQL.update.await('UPDATE tez_mdt_evidence SET report_id = ?, updated_at = ? WHERE id = ?', { rid, now(), r.id })
  custody(r.id, 'link', x.getName(), ('Linked to report R-%d'):format(rid))
  T.log(x, 'EVIDENCE', ('Linked E-%d to report R-%d'):format(r.id, rid), 'evidence', r.id)
  return { ok = true }
end)

rpc('disposeEvidence', 'evidence.dispose', function(src, x, p)
  local r = MySQL.single.await('SELECT * FROM tez_mdt_evidence WHERE id = ?', { tonumber(p.id) or 0 })
  if not r then return { error = 'Evidence not found.' } end
  local d = oneOf(Config.EvidenceDispositions, p.disposition, nil)
  if not d or d == 'In lab' then return { error = 'Pick a disposition.' } end
  local note = clip(p.note, 160)
  if #note < 3 then return { error = 'Write a short note for the record.' } end
  MySQL.update.await('UPDATE tez_mdt_evidence SET disposition = ?, updated_at = ? WHERE id = ?', { d, now(), r.id })
  custody(r.id, 'disposition', x.getName(), d .. '. ' .. note)
  T.log(x, 'EVIDENCE', ('E-%d disposition: %s'):format(r.id, d), 'evidence', r.id)
  return { ok = true }
end)

rpc('sendToLab', 'evidence.collect', function(src, x, p)
  local row = MySQL.single.await('SELECT id, status, type FROM tez_mdt_evidence WHERE id = ?', { tonumber(p.id) or 0 })
  if not row then return { error = 'Evidence not found.' } end
  if row.type ~= 'casing' and row.type ~= 'blood' and row.type ~= 'print' then return { error = 'Only scene samples can be sent to the lab.' } end
  if row.status ~= 'collected' then return { error = 'This evidence has already been sent to the lab.' } end
  if Config.Lab.required and #(GetEntityCoords(GetPlayerPed(src)) - Config.Lab.coords) > Config.Lab.radius then
    return { error = 'You must be at the lab to submit evidence.' }
  end
  MySQL.update.await("UPDATE tez_mdt_evidence SET status = 'analyzing', analysis_ready_at = ?, disposition = 'In lab', updated_at = ? WHERE id = ?", { now() + Config.LabMinutes * 60, now(), row.id })
  custody(row.id, 'lab_submit', x.getName(), 'Sent to the lab')
  T.log(x, 'LAB', ('Sent evidence E-%d to the lab'):format(row.id), 'evidence', row.id)
  return { ok = true }
end)

rpc('recheckEvidence', 'evidence.collect', function(src, x, p)
  local row = MySQL.single.await('SELECT id, type, details, status FROM tez_mdt_evidence WHERE id = ?', { tonumber(p.id) or 0 })
  if not row or row.status ~= 'analyzed' then return { error = 'Nothing to re-check yet.' } end
  local res = analyze(row.type, decode(row.details, {}))
  MySQL.update.await('UPDATE tez_mdt_evidence SET result = ?, updated_at = ? WHERE id = ?', { json.encode(res), now(), row.id })
  custody(row.id, 'lab_result', x.getName(), res.match and ('Re-checked: match with ' .. res.match) or 'Re-checked: no match on file')
  return { ok = true }
end)

-- ============================================================
--  TOW / IMPOUND
-- ============================================================
local IMP_SORT = { id = 'id', plate = 'plate', status = 'status', created = 'created_at', fee = 'fee' }

rpc('listImpounds', 'vehicle.view', function(src, x, p)
  local per, off, order, page = T.paging(p, IMP_SORT, 'created')
  local w = T.Where()
  local st = tostring(p.status or 'impounded')
  if st ~= 'all' then w:add('status = ?', st) end
  local q = clip(p.q, 40)
  if #q >= 1 then w:add('(plate LIKE ? OR owner_name LIKE ? OR reason LIKE ?)', like(normPlate(q)), like(q), like(q)) end
  local total = MySQL.scalar.await('SELECT COUNT(*) FROM tez_mdt_impounds' .. w:sql(), w:with()) or 0
  local rows = MySQL.query.await('SELECT id, plate, model, owner_identifier, owner_name, reason, location, officer_name, fee, status, created_at, released_at, released_by, report_id FROM tez_mdt_impounds' .. w:sql() .. ' ' .. order .. ' LIMIT ? OFFSET ?', w:with(per, off)) or {}
  return T.pageResult(rows, total, page)
end)

rpc('createImpound', 'impound.create', function(src, x, p)
  local plate = normPlate(p.plate):sub(1, 12)
  if #plate < 2 then return { error = 'Enter the plate of the vehicle.' } end
  local reason = clip(p.reason, 200)
  if #reason < 5 then return { error = 'Write the reason for the impound.' } end
  if (tonumber(MySQL.scalar.await("SELECT COUNT(*) FROM tez_mdt_impounds WHERE plate = ? AND status = 'impounded'", { plate })) or 0) > 0 then
    return { error = 'That vehicle is already impounded.' }
  end
  local own = MySQL.single.await("SELECT ov.owner, ov.vehicle, u.firstname, u.lastname FROM owned_vehicles ov LEFT JOIN users u ON u.identifier = ov.owner WHERE REPLACE(ov.plate, ' ', '') = ? LIMIT 1", { plate })
  local model = own and decode(own.vehicle, {}).model or nil
  local fee = math.max(0, math.min(100000, math.floor(tonumber(p.fee) or 0)))
  local id = MySQL.insert.await('INSERT INTO tez_mdt_impounds (plate, model, owner_identifier, owner_name, reason, location, officer_name, fee, report_id, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
    { plate, model, own and own.owner or nil, own and fullName(own) or 'Unregistered', reason, clip(p.location, 120), x.getName(), fee, T.validReport(p.report_id), 'impounded', now() })
  T.log(x, 'IMPOUND', ('Impounded %s (I-%d): %s'):format(plate, id, reason), 'impound', id)
  T.log(x, 'IMPOUND', ('Vehicle %s impounded'):format(plate), 'vehicle', plate)
  pcall(Config.OnImpound, plate)
  return { ok = true, id = id }
end)

rpc('releaseImpound', 'impound.release', function(src, x, p)
  local r = MySQL.single.await('SELECT * FROM tez_mdt_impounds WHERE id = ?', { tonumber(p.id) or 0 })
  if not r or r.status ~= 'impounded' then return { error = 'That vehicle is not in the impound.' } end
  MySQL.update.await("UPDATE tez_mdt_impounds SET status = 'released', released_by = ?, released_at = ? WHERE id = ?", { x.getName(), now(), r.id })
  T.log(x, 'IMPOUND', ('Released %s (I-%d)'):format(r.plate, r.id), 'impound', r.id)
  return { ok = true }
end)

-- ============================================================
--  COURT / CASES  (optional)
-- ============================================================
local function courtOn() return Config.Court and Config.Court.enabled end

local CASE_SORT = { id = 'id', title = 'title', status = 'status', created = 'created_at' }
local CASE_STATUS = { 'open', 'hearing', 'closed', 'appealed' }

rpc('listCases', 'case.view', function(src, x, p)
  if not courtOn() then return { error = 'Court cases are turned off on this server.' } end
  local per, off, order, page = T.paging(p, CASE_SORT, 'created')
  local w = T.Where()
  if p.status and p.status ~= 'all' then w:add('status = ?', tostring(p.status)) end
  local q = clip(p.q, 40)
  if #q >= 1 then
    local n = tonumber((q:gsub('^[Cc][Aa][Ss][Ee]%-?[%d]*%-?', '')))
    if n then w:add('(id = ? OR title LIKE ? OR judge LIKE ?)', n, like(q), like(q)) else w:add('(title LIKE ? OR judge LIKE ? OR prosecutor LIKE ? OR defense LIKE ?)', like(q), like(q), like(q), like(q)) end
  end
  local total = MySQL.scalar.await('SELECT COUNT(*) FROM tez_mdt_cases' .. w:sql(), w:with()) or 0
  local rows = MySQL.query.await('SELECT id, title, status, judge, prosecutor, defense, created_by, created_at, hearings FROM tez_mdt_cases' .. w:sql() .. ' ' .. order .. ' LIMIT ? OFFSET ?', w:with(per, off)) or {}
  for _, r in ipairs(rows) do
    local nextAt
    for _, h in ipairs(decode(r.hearings, {})) do
      if h.at and h.at > now() and (not nextAt or h.at < nextAt) then nextAt = h.at end
    end
    r.nextHearing = nextAt
    r.hearings = nil
  end
  return T.pageResult(rows, total, page)
end)

local function cleanLinks(l)
  l = type(l) == 'table' and l or {}
  local out = { reports = {}, citations = {}, bookings = {}, evidence = {} }
  local tbl = { reports = 'tez_mdt_reports', citations = 'tez_mdt_citations', bookings = 'tez_mdt_bookings', evidence = 'tez_mdt_evidence' }
  for key, tname in pairs(tbl) do
    for _, v in ipairs(type(l[key]) == 'table' and l[key] or {}) do
      local id = intOrNil(v)
      if id and #out[key] < 30 and MySQL.scalar.await('SELECT id FROM ' .. tname .. ' WHERE id = ?', { id }) then out[key][#out[key] + 1] = id end
    end
  end
  return out
end

rpc('getCase', 'case.view', function(src, x, p)
  if not courtOn() then return { error = 'Court cases are turned off on this server.' } end
  local c = MySQL.single.await('SELECT * FROM tez_mdt_cases WHERE id = ?', { tonumber(p.id) or 0 })
  if not c then return { error = 'Case not found.' } end
  T.logView(x, 'case', c.id)
  c.parties = nameList(decode(c.parties, {}))
  c.links = decode(c.links, { reports = {}, citations = {}, bookings = {}, evidence = {} })
  c.hearings = decode(c.hearings, {})
  c.appeals = decode(c.appeals, {})
  c.canManage = T.can(x, 'case.manage')
  return c
end)

rpc('createCase', 'case.manage', function(src, x, p)
  if not courtOn() then return { error = 'Court cases are turned off on this server.' } end
  local title = clip(p.title, 120)
  if #title < 3 then return { error = 'Give the case a title.' } end
  local t = now()
  local id = MySQL.insert.await('INSERT INTO tez_mdt_cases (title, status, parties, judge, prosecutor, defense, links, hearings, appeals, created_by, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
    { title, 'open', json.encode(cleanPeople(p.parties)), clip(p.judge, 80), clip(p.prosecutor, 80), clip(p.defense, 80), json.encode(cleanLinks(p.links)), '[]', '[]', x.getName(), t, t })
  T.log(x, 'CASE', ('Opened case %d: %s'):format(id, title), 'case', id)
  return { ok = true, id = id }
end)

rpc('updateCase', 'case.manage', function(src, x, p)
  if not courtOn() then return { error = 'Court cases are turned off on this server.' } end
  local c = MySQL.single.await('SELECT * FROM tez_mdt_cases WHERE id = ?', { tonumber(p.id) or 0 })
  if not c then return { error = 'Case not found.' } end
  local s = staleCheck(c, p)
  if s then return s end
  local title = clip(p.title, 120)
  if #title < 3 then title = c.title end
  MySQL.update.await('UPDATE tez_mdt_cases SET title = ?, status = ?, parties = ?, judge = ?, prosecutor = ?, defense = ?, links = ?, outcome = ?, sentence = ?, updated_at = ? WHERE id = ?',
    { title, oneOf(CASE_STATUS, p.status, c.status), json.encode(cleanPeople(p.parties)), clip(p.judge, 80), clip(p.prosecutor, 80), clip(p.defense, 80), json.encode(cleanLinks(p.links)), clip(p.outcome, 1500), clip(p.sentence, 1000), now(), c.id })
  T.log(x, 'CASE', ('Updated case %d'):format(c.id), 'case', c.id)
  return { ok = true }
end)

rpc('addHearing', 'case.manage', function(src, x, p)
  if not courtOn() then return { error = 'Court cases are turned off on this server.' } end
  local c = MySQL.single.await('SELECT id, hearings, status FROM tez_mdt_cases WHERE id = ?', { tonumber(p.id) or 0 })
  if not c then return { error = 'Case not found.' } end
  local at = tonumber(p.at)
  if not at or at < now() - 86400 then return { error = 'Pick a date and time for the hearing.' } end
  local h = decode(c.hearings, {})
  h[#h + 1] = { at = math.floor(at), note = clip(p.note, 200), by = x.getName() }
  table.sort(h, function(a, b) return a.at < b.at end)
  MySQL.update.await("UPDATE tez_mdt_cases SET hearings = ?, status = CASE WHEN status = 'open' THEN 'hearing' ELSE status END, updated_at = ? WHERE id = ?", { json.encode(h), now(), c.id })
  T.log(x, 'CASE', ('Scheduled a hearing on case %d'):format(c.id), 'case', c.id)
  return { ok = true }
end)

rpc('addAppeal', 'case.manage', function(src, x, p)
  if not courtOn() then return { error = 'Court cases are turned off on this server.' } end
  local c = MySQL.single.await('SELECT id, appeals FROM tez_mdt_cases WHERE id = ?', { tonumber(p.id) or 0 })
  if not c then return { error = 'Case not found.' } end
  local note = clip(p.note, 300)
  if #note < 3 then return { error = 'Write what was filed.' } end
  local a = decode(c.appeals, {})
  a[#a + 1] = { at = now(), note = note, by = x.getName() }
  MySQL.update.await("UPDATE tez_mdt_cases SET appeals = ?, status = 'appealed', updated_at = ? WHERE id = ?", { json.encode(a), now(), c.id })
  T.log(x, 'CASE', ('Appeal filed on case %d'):format(c.id), 'case', c.id)
  return { ok = true }
end)
