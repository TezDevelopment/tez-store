-- Tez MDT v3 - people, vehicles, warrants, citations, arrests and booking
-- Made by Tez Development

local ESX = exports['es_extended']:getSharedObject()
local T = TezMDT
local now, clip, decode, fullName, like, normPlate, intOrNil = T.now, T.clip, T.decode, T.fullName, T.like, T.normPlate, T.intOrNil
local rpc = T.rpc

local function userCols()
  return 'u.identifier, u.firstname, u.lastname, u.dateofbirth, u.sex, u.height, u.job, u.job_grade' .. (T.has.phone and ', u.phone_number' or '')
end

local function getUser(identifier)
  return MySQL.single.await('SELECT ' .. userCols() .. ' FROM users u WHERE u.identifier = ?', { tostring(identifier or '') })
end

local function pointsOf(identifier)
  return tonumber(MySQL.scalar.await('SELECT COALESCE(SUM(points), 0) FROM tez_mdt_records WHERE citizen_identifier = ? AND voided = 0', { identifier })) or 0
end
T.pointsOf = pointsOf

local function stale(row, p, col)
  col = col or 'updated_at'
  if p.expected ~= nil and tonumber(p.expected) ~= (tonumber(row[col]) or 0) then
    return { error = 'Someone changed this record while you were editing. Close it and open it again.' }
  end
  return nil
end
T.stale = stale

local function validReport(id)
  id = intOrNil(id)
  if not id then return nil end
  if MySQL.scalar.await('SELECT id FROM tez_mdt_reports WHERE id = ?', { id }) then return id end
  return nil
end
T.validReport = validReport

local function chargeTotals(ids, citeOnly)
  local fine, jail, points, labels, used = 0, 0, 0, {}, {}
  for _, cid in ipairs(type(ids) == 'table' and ids or {}) do
    local c = T.chargeById[cid]
    if c and not used[cid] and (not citeOnly or c.cite) then
      used[cid] = true
      fine = fine + c.fine; jail = jail + c.jail; points = points + (c.points or 0)
      labels[#labels + 1] = c.label
    end
  end
  return fine, jail, points, labels, used
end

-- ============================================================
--  PEOPLE
-- ============================================================
rpc('searchPersons', 'person.view', function(src, x, p)
  local q = clip(p.q, 40)
  if #q < 2 then return T.pageResult({}, 0, 1) end
  T.log(x, 'SEARCH', 'Person search: ' .. q, 'search')
  local per, off, _, page = T.paging(p, { name = 'u.lastname' }, 'name')
  local up = q:upper()
  local from, w = ' FROM users u LEFT JOIN tez_mdt_person_meta m ON m.identifier = u.identifier', T.Where()
  if up:sub(1, 4) == 'DNA-' then
    from = ' FROM tez_mdt_dna c JOIN users u ON u.identifier = c.identifier LEFT JOIN tez_mdt_person_meta m ON m.identifier = u.identifier'
    w:add('c.code = ?', up)
  elseif up:sub(1, 4) == 'FNG-' then
    from = ' FROM tez_mdt_prints c JOIN users u ON u.identifier = c.identifier LEFT JOIN tez_mdt_person_meta m ON m.identifier = u.identifier'
    w:add('c.code = ?', up)
  elseif up:sub(1, 4) == 'BAL-' then
    from = ' FROM tez_mdt_weapons c JOIN users u ON u.identifier = c.owner_identifier LEFT JOIN tez_mdt_person_meta m ON m.identifier = u.identifier'
    w:add('c.code = ?', up)
  else
    local l = like(q)
    local parts = "CONCAT(u.firstname, ' ', u.lastname) LIKE ? OR u.identifier LIKE ? OR u.dateofbirth LIKE ? OR m.phone LIKE ? OR m.address LIKE ? OR m.aliases LIKE ?"
    local args = { l, l, l, l, l, l }
    if T.has.phone then parts = parts .. ' OR u.phone_number LIKE ?'; args[#args + 1] = l end
    w:add('(' .. parts .. ')')
    for _, a in ipairs(args) do w.args[#w.args + 1] = a end
  end
  local total = MySQL.scalar.await('SELECT COUNT(DISTINCT u.identifier)' .. from .. w:sql(), w:with()) or 0
  local rows = MySQL.query.await(
    'SELECT DISTINCT ' .. userCols() .. ', m.phone AS meta_phone, m.address, ' ..
    "(SELECT COUNT(*) FROM tez_mdt_warrants w WHERE w.citizen_identifier = u.identifier AND w.status = 'active') AS warrants, " ..
    '(SELECT COUNT(*) FROM tez_mdt_flags f WHERE f.citizen_identifier = u.identifier) AS flags' ..
    from .. w:sql() .. ' ORDER BY u.lastname, u.firstname LIMIT ? OFFSET ?', w:with(per, off)) or {}
  local out = {}
  for _, r in ipairs(rows) do
    out[#out + 1] = { identifier = r.identifier, name = fullName(r), dob = r.dateofbirth, sex = r.sex, phone = r.meta_phone or r.phone_number, address = r.address, warrants = tonumber(r.warrants) or 0, flags = tonumber(r.flags) or 0 }
  end
  return T.pageResult(out, total, page)
end)

rpc('getPerson', 'person.view', function(src, x, p)
  local id = tostring(p.identifier or '')
  local u = getUser(id)
  if not u then return { error = 'That person was not found.' } end
  T.logView(x, 'person', id)

  local records = MySQL.query.await('SELECT id, type, title, details, charges, fine, jail, points, officer_name, created_at, ref_type, ref_id, voided FROM tez_mdt_records WHERE citizen_identifier = ? ORDER BY id DESC LIMIT 80', { id }) or {}
  for _, r in ipairs(records) do r.charges = decode(r.charges, {}) end
  local citations = MySQL.query.await('SELECT id, violations, fine, points, status, location, officer_name, created_at FROM tez_mdt_citations WHERE person_identifier = ? ORDER BY id DESC LIMIT 40', { id }) or {}
  for _, c in ipairs(citations) do c.violations = decode(c.violations, {}) end
  local bookings = MySQL.query.await('SELECT id, charges, fine, jail, status, disposition, officer_name, created_at FROM tez_mdt_bookings WHERE person_identifier = ? ORDER BY id DESC LIMIT 40', { id }) or {}
  for _, b in ipairs(bookings) do b.charges = decode(b.charges, {}) end
  local warrants = MySQL.query.await("SELECT id, type, reason, issued_by, status, created_at, expires_at FROM tez_mdt_warrants WHERE citizen_identifier = ? AND status <> 'draft' ORDER BY id DESC LIMIT 30", { id }) or {}
  local reports = MySQL.query.await("SELECT id, type, title, status, created_at FROM tez_mdt_reports WHERE people LIKE ? AND status <> 'draft' ORDER BY id DESC LIMIT 25", { '%"' .. id .. '"%' }) or {}
  local cases = {}
  if Config.Court.enabled then
    cases = MySQL.query.await('SELECT id, title, status, created_at FROM tez_mdt_cases WHERE parties LIKE ? ORDER BY id DESC LIMIT 15', { '%"' .. id .. '"%' }) or {}
  end

  local vehRows = MySQL.query.await('SELECT plate, vehicle FROM owned_vehicles WHERE owner = ? LIMIT 40', { id }) or {}
  local vehicles = {}
  for _, v in ipairs(vehRows) do
    local d = decode(v.vehicle, {})
    local np = normPlate(v.plate)
    local fl = MySQL.single.await('SELECT flag, note FROM tez_mdt_vflags WHERE plate = ?', { np })
    local imp = MySQL.scalar.await("SELECT COUNT(*) FROM tez_mdt_impounds WHERE plate = ? AND status = 'impounded'", { np })
    vehicles[#vehicles + 1] = { plate = v.plate, model = d.model, color = d.color1, flag = fl and (T.vflagLabel[fl.flag] or fl.flag) or nil, impounded = (tonumber(imp) or 0) > 0 }
  end

  local flags = MySQL.query.await('SELECT id, flag, note, by_name, created_at FROM tez_mdt_flags WHERE citizen_identifier = ? ORDER BY id', { id }) or {}
  for _, f in ipairs(flags) do f.label = T.flagLabel[f.flag] or f.flag end
  local meta = MySQL.single.await('SELECT phone, address, aliases, note, updated_by, updated_at FROM tez_mdt_person_meta WHERE identifier = ?', { id })
  local licenses = {}
  if T.has.licenses then
    for _, l in ipairs(MySQL.query.await('SELECT type FROM user_licenses WHERE owner = ?', { id }) or {}) do licenses[#licenses + 1] = l.type end
  end
  local points = pointsOf(id)
  local suspended = points >= Config.SuspendPoints
  local activeWarrants = 0
  for _, w in ipairs(warrants) do if w.status == 'active' then activeWarrants = activeWarrants + 1 end end

  local alerts = {}
  if activeWarrants > 0 then alerts[#alerts + 1] = { level = 'danger', text = ('%d active warrant(s)'):format(activeWarrants) } end
  for _, f in ipairs(flags) do alerts[#alerts + 1] = { level = 'warn', text = f.label .. (f.note and f.note ~= '' and (': ' .. f.note) or '') } end
  if suspended then alerts[#alerts + 1] = { level = 'warn', text = 'Driving licence suspended' } end

  local access
  if T.can(x, 'audit.view') then
    access = MySQL.query.await("SELECT officer, action, details, at FROM tez_mdt_log WHERE entity = 'person' AND entity_id = ? ORDER BY id DESC LIMIT 12", { id }) or {}
  end

  return {
    identifier = u.identifier, name = fullName(u), dob = u.dateofbirth, sex = u.sex, height = u.height, job = u.job,
    serverPhone = u.phone_number, meta = meta, licenses = licenses, records = records, citations = citations, bookings = bookings,
    warrants = warrants, reports = reports, cases = cases, vehicles = vehicles,
    weapons = MySQL.query.await('SELECT id, weapon, label, code, registered_by, created_at FROM tez_mdt_weapons WHERE owner_identifier = ?', { id }) or {},
    dna = MySQL.single.await('SELECT taken_by, taken_at, code FROM tez_mdt_dna WHERE identifier = ?', { id }),
    prints = MySQL.single.await('SELECT taken_by, taken_at, code FROM tez_mdt_prints WHERE identifier = ?', { id }),
    flags = flags, points = points, suspended = suspended, alerts = alerts, access = access,
  }
end)

rpc('savePersonMeta', 'person.edit', function(src, x, p)
  local id = tostring(p.identifier or '')
  if not getUser(id) then return { error = 'That person was not found.' } end
  local cur = MySQL.single.await('SELECT updated_at FROM tez_mdt_person_meta WHERE identifier = ?', { id })
  if cur then
    local s = stale(cur, p)
    if s then return s end
  end
  local t = now()
  MySQL.update.await('INSERT INTO tez_mdt_person_meta (identifier, phone, address, aliases, note, updated_by, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE phone = VALUES(phone), address = VALUES(address), aliases = VALUES(aliases), note = VALUES(note), updated_by = VALUES(updated_by), updated_at = VALUES(updated_at)',
    { id, clip(p.phone, 24), clip(p.address, 160), clip(p.aliases, 200), clip(p.note, 2000), x.getName(), t })
  T.log(x, 'EDIT', 'Updated officer notes on a person', 'person', id)
  return { ok = true, updated_at = t }
end)

rpc('flagPerson', 'person.edit', function(src, x, p)
  local flag = tostring(p.flag or '')
  if not T.flagLabel[flag] then return { error = 'Unknown flag.' } end
  local id = tostring(p.identifier or '')
  if not getUser(id) then return { error = 'That person was not found.' } end
  MySQL.update.await('INSERT INTO tez_mdt_flags (citizen_identifier, flag, note, by_name, created_at) VALUES (?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE note = VALUES(note), by_name = VALUES(by_name), created_at = VALUES(created_at)',
    { id, flag, clip(p.note, 160), x.getName(), now() })
  T.log(x, 'FLAG', 'Flagged a person: ' .. T.flagLabel[flag], 'person', id)
  return { ok = true }
end)

rpc('unflagPerson', 'person.edit', function(src, x, p)
  local row = MySQL.single.await('SELECT citizen_identifier, flag FROM tez_mdt_flags WHERE id = ?', { tonumber(p.id) or 0 })
  if not row then return { error = 'Flag not found.' } end
  MySQL.update.await('DELETE FROM tez_mdt_flags WHERE id = ?', { tonumber(p.id) })
  T.log(x, 'FLAG', 'Removed a person flag: ' .. (T.flagLabel[row.flag] or row.flag), 'person', row.citizen_identifier)
  return { ok = true }
end)

-- ---------- samples taken in person ----------
local function presentTarget(src, p)
  local target = ESX.GetPlayerFromIdentifier(tostring(p.identifier or ''))
  if not target then return nil, 'The person must be here with you to do this.' end
  if not T.near(src, target.source, 4.0) then return nil, 'You are too far from them.' end
  return target
end

rpc('takeDNA', 'person.edit', function(src, x, p)
  local target, err = presentTarget(src, p)
  if not target then return { error = err } end
  MySQL.update.await('INSERT INTO tez_mdt_dna (identifier, code, taken_by, taken_at) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE code = VALUES(code), taken_by = VALUES(taken_by), taken_at = VALUES(taken_at)',
    { target.identifier, T.dnaCode(target.identifier), x.getName(), now() })
  target.showNotification('A DNA sample was taken from you.')
  T.log(x, 'DNA', 'DNA sample taken from ' .. target.getName(), 'person', target.identifier)
  return { ok = true }
end)

rpc('takePrints', 'person.edit', function(src, x, p)
  local target, err = presentTarget(src, p)
  if not target then return { error = err } end
  MySQL.update.await('INSERT INTO tez_mdt_prints (identifier, code, taken_by, taken_at) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE code = VALUES(code), taken_by = VALUES(taken_by), taken_at = VALUES(taken_at)',
    { target.identifier, T.fngCode(target.identifier), x.getName(), now() })
  target.showNotification('Your fingerprints were taken.')
  T.log(x, 'PRINTS', 'Fingerprints taken from ' .. target.getName(), 'person', target.identifier)
  return { ok = true }
end)

rpc('testGSR', 'person.edit', function(src, x, p)
  local target, err = presentTarget(src, p)
  if not target then return { error = err } end
  local at = T.LastFired[target.source]
  local positive = at ~= nil and (now() - at) <= Config.GSRMinutes * 60
  MySQL.insert.await(
    'INSERT INTO tez_mdt_records (citizen_identifier, type, title, details, charges, fine, jail, points, officer_identifier, officer_name, created_at) VALUES (?, ?, ?, ?, ?, 0, 0, 0, ?, ?, ?)',
    { target.identifier, 'note', 'Gunshot residue test: ' .. (positive and 'POSITIVE' or 'NEGATIVE'), 'Test carried out at the scene.', '[]', x.identifier, x.getName(), now() })
  T.log(x, 'GSR', ('Residue test on %s: %s'):format(target.getName(), positive and 'positive' or 'negative'), 'person', target.identifier)
  return { ok = true, positive = positive, minutes = at and math.floor((now() - at) / 60) or nil }
end)

rpc('registerWeapon', 'person.edit', function(src, x, p)
  local weapon = tostring(p.weapon or '')
  if not Config.Weapons[weapon] then return { error = 'Unknown weapon.' } end
  local id = tostring(p.identifier or '')
  if not getUser(id) then return { error = 'That person was not found.' } end
  MySQL.update.await('INSERT IGNORE INTO tez_mdt_weapons (owner_identifier, weapon, label, code, registered_by, created_at) VALUES (?, ?, ?, ?, ?, ?)',
    { id, weapon, Config.Weapons[weapon], T.balCode(id, weapon), x.getName(), now() })
  T.log(x, 'WEAPON', 'Registered a ' .. Config.Weapons[weapon], 'person', id)
  return { ok = true }
end)

rpc('removeWeapon', 'record.delete', function(src, x, p)
  MySQL.update.await('DELETE FROM tez_mdt_weapons WHERE id = ?', { tonumber(p.id) or 0 })
  T.log(x, 'WEAPON', 'Removed weapon registration #' .. tostring(p.id), 'weapon', p.id)
  return { ok = true }
end)

-- ============================================================
--  VEHICLES
-- ============================================================
local function vehicleRows(rows)
  local out = {}
  if #rows == 0 then return out end
  for _, r in ipairs(rows) do
    local d = decode(r.vehicle, {})
    local np = normPlate(r.plate)
    local flag = MySQL.single.await('SELECT flag, note FROM tez_mdt_vflags WHERE plate = ?', { np })
    local bolo = MySQL.single.await("SELECT id, title FROM tez_mdt_bolos WHERE plate = ? AND status = 'active' AND expires_at > ? LIMIT 1", { np, now() })
    local imp = MySQL.scalar.await("SELECT COUNT(*) FROM tez_mdt_impounds WHERE plate = ? AND status = 'impounded'", { np })
    local vm = MySQL.single.await('SELECT registration, insurance FROM tez_mdt_vehicle_meta WHERE plate = ?', { np })
    out[#out + 1] = {
      plate = r.plate, model = d.model, color = d.color1, vin = T.vin(np), owner = fullName(r), ownerIdentifier = r.owner,
      flag = flag and { flag = flag.flag, label = T.vflagLabel[flag.flag] or flag.flag, note = flag.note } or nil,
      bolo = bolo, impounded = (tonumber(imp) or 0) > 0,
      registration = vm and vm.registration or 'valid', insurance = vm and vm.insurance or 'valid',
      ownerWarrants = tonumber(r.warrants) or 0,
    }
  end
  return out
end

local VEH_SELECT = "SELECT ov.plate, ov.vehicle, ov.owner, u.firstname, u.lastname, (SELECT COUNT(*) FROM tez_mdt_warrants w WHERE w.citizen_identifier = ov.owner AND w.status = 'active') AS warrants FROM owned_vehicles ov LEFT JOIN users u ON u.identifier = ov.owner"

rpc('searchVehicles', 'vehicle.view', function(src, x, p)
  local q = clip(p.q, 40)
  if #q < 2 then return T.pageResult({}, 0, 1) end
  T.log(x, 'SEARCH', 'Vehicle search: ' .. q, 'search')
  local per, off, _, page = T.paging(p, { plate = 'ov.plate' }, 'plate')
  local np = normPlate(q)
  local rows, total

  if np:sub(1, 2) == 'TZ' and #np >= 8 then
    -- VIN search: VINs are generated from the plate, so compare them one by one
    local all = MySQL.query.await('SELECT plate FROM owned_vehicles LIMIT 20000') or {}
    local hit
    for _, r in ipairs(all) do
      if T.vin(normPlate(r.plate)):find(np, 1, true) then hit = r.plate; break end
    end
    rows = hit and (MySQL.query.await(VEH_SELECT .. " WHERE REPLACE(ov.plate, ' ', '') = ? LIMIT 1", { normPlate(hit) }) or {}) or {}
    total = #rows
  else
    local w = T.Where()
    w:add("(REPLACE(ov.plate, ' ', '') LIKE ? OR CONCAT(u.firstname, ' ', u.lastname) LIKE ?)", like(np), like(q))
    total = MySQL.scalar.await('SELECT COUNT(*) FROM owned_vehicles ov LEFT JOIN users u ON u.identifier = ov.owner' .. w:sql(), w:with()) or 0
    rows = MySQL.query.await(VEH_SELECT .. w:sql() .. ' ORDER BY ov.plate LIMIT ? OFFSET ?', w:with(per, off)) or {}
  end

  local res = T.pageResult(vehicleRows(rows), total, page)
  if #res.rows == 0 and #np >= 4 then
    local flag = MySQL.single.await('SELECT flag, note FROM tez_mdt_vflags WHERE plate = ?', { np })
    local bolo = MySQL.single.await("SELECT id, title FROM tez_mdt_bolos WHERE plate = ? AND status = 'active' AND expires_at > ? LIMIT 1", { np, now() })
    res.unregistered = { plate = np, flag = flag and { label = T.vflagLabel[flag.flag] or flag.flag, note = flag.note } or nil, bolo = bolo }
  end
  return res
end)

rpc('getVehicle', 'vehicle.view', function(src, x, p)
  local np = normPlate(p.plate)
  if #np < 2 then return { error = 'Enter a plate.' } end
  T.logView(x, 'vehicle', np)
  local rows = MySQL.query.await(VEH_SELECT .. " WHERE REPLACE(ov.plate, ' ', '') = ? LIMIT 1", { np }) or {}
  local v = vehicleRows(rows)[1]
  local meta = MySQL.single.await('SELECT registration, insurance, note, updated_by, updated_at FROM tez_mdt_vehicle_meta WHERE plate = ?', { np })
  local likePlate = '%"' .. np .. '"%'
  return {
    plate = v and v.plate or np, registered = v ~= nil, vehicle = v, meta = meta,
    flag = (function()
      local f = MySQL.single.await('SELECT flag, note, by_name, created_at FROM tez_mdt_vflags WHERE plate = ?', { np })
      if f then f.label = T.vflagLabel[f.flag] or f.flag end
      return f
    end)(),
    bolos = MySQL.query.await("SELECT id, title, kind, priority, expires_at FROM tez_mdt_bolos WHERE plate = ? AND status = 'active' AND expires_at > ?", { np, now() }) or {},
    impounds = MySQL.query.await('SELECT id, reason, location, fee, status, created_at, released_at FROM tez_mdt_impounds WHERE plate = ? ORDER BY id DESC LIMIT 10', { np }) or {},
    citations = MySQL.query.await('SELECT id, person_name, violations, fine, status, created_at FROM tez_mdt_citations WHERE plate = ? ORDER BY id DESC LIMIT 15', { np }) or {},
    reports = MySQL.query.await("SELECT id, type, title, status, created_at FROM tez_mdt_reports WHERE vehicles LIKE ? AND status <> 'draft' ORDER BY id DESC LIMIT 15", { likePlate }) or {},
  }
end)

rpc('saveVehicleMeta', 'vehicle.edit', function(src, x, p)
  local np = normPlate(p.plate)
  if #np < 2 then return { error = 'Enter a plate.' } end
  local okReg = { valid = true, expired = true, suspended = true, none = true }
  local okIns = { valid = true, expired = true, none = true }
  local reg = okReg[p.registration] and p.registration or 'valid'
  local ins = okIns[p.insurance] and p.insurance or 'valid'
  local cur = MySQL.single.await('SELECT updated_at FROM tez_mdt_vehicle_meta WHERE plate = ?', { np })
  if cur then
    local s = stale(cur, p)
    if s then return s end
  end
  local t = now()
  MySQL.update.await('INSERT INTO tez_mdt_vehicle_meta (plate, registration, insurance, note, updated_by, updated_at) VALUES (?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE registration = VALUES(registration), insurance = VALUES(insurance), note = VALUES(note), updated_by = VALUES(updated_by), updated_at = VALUES(updated_at)',
    { np, reg, ins, clip(p.note, 1000), x.getName(), t })
  T.log(x, 'EDIT', ('Updated vehicle notes for %s'):format(np), 'vehicle', np)
  return { ok = true, updated_at = t }
end)

rpc('flagVehicle', 'vehicle.edit', function(src, x, p)
  local plate = normPlate(p.plate):sub(1, 12)
  local flag = tostring(p.flag or '')
  if #plate < 2 or not T.vflagLabel[flag] then return { error = 'Pick a plate and a flag.' } end
  MySQL.update.await('INSERT INTO tez_mdt_vflags (plate, flag, note, by_name, created_at) VALUES (?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE flag = VALUES(flag), note = VALUES(note), by_name = VALUES(by_name), created_at = VALUES(created_at)',
    { plate, flag, clip(p.note, 160), x.getName(), now() })
  T.log(x, 'VEHICLE', ('Plate %s flagged %s'):format(plate, T.vflagLabel[flag]), 'vehicle', plate)
  if flag == 'stolen' or flag == 'wanted' then
    T.notify({ type = 'vehicle', title = 'Vehicle flagged: ' .. T.vflagLabel[flag], body = plate, perm = 'vehicle.view', page = 'vehicles', id = plate })
  end
  return { ok = true }
end)

rpc('unflagVehicle', 'vehicle.edit', function(src, x, p)
  local plate = normPlate(p.plate)
  MySQL.update.await('DELETE FROM tez_mdt_vflags WHERE plate = ?', { plate })
  T.log(x, 'VEHICLE', ('Cleared flag on %s'):format(plate), 'vehicle', plate)
  return { ok = true }
end)

-- ============================================================
--  WARRANTS  (draft > pending > active > served / expired / recalled / denied)
-- ============================================================
local WARRANT_SORT = { id = 'w.id', name = 'w.citizen_name', status = 'w.status', type = 'w.type', expires = 'w.expires_at', created = 'w.created_at' }
local WARRANT_COLS = 'w.id, w.citizen_identifier, w.citizen_name, w.type, w.reason, w.issued_by, w.approved_by, w.status, w.created_at, w.expires_at, w.report_id, w.updated_at'

rpc('listWarrants', 'person.view', function(src, x, p)
  local per, off, order, page = T.paging(p, WARRANT_SORT, 'created')
  local w = T.Where()
  local st = tostring(p.status or 'active')
  if st ~= 'all' then w:add('w.status = ?', st) end
  w:add("(w.status <> 'draft' OR w.issued_by_identifier = ?)", x.identifier)
  local q = clip(p.q, 40)
  if #q >= 1 then
    local n = tonumber((q:gsub('^[Ww]%-?', '')))
    if n then w:add('(w.id = ? OR w.citizen_name LIKE ?)', n, like(q)) else w:add('w.citizen_name LIKE ?', like(q)) end
  end
  local total = MySQL.scalar.await('SELECT COUNT(*) FROM tez_mdt_warrants w' .. w:sql(), w:with()) or 0
  local rows = MySQL.query.await('SELECT ' .. WARRANT_COLS .. ' FROM tez_mdt_warrants w' .. w:sql() .. ' ' .. order .. ' LIMIT ? OFFSET ?', w:with(per, off)) or {}
  return T.pageResult(rows, total, page)
end)

rpc('getWarrant', 'person.view', function(src, x, p)
  local id = tonumber(p.id) or 0
  local row = MySQL.single.await('SELECT w.*, w.reason AS basis FROM tez_mdt_warrants w WHERE w.id = ?', { id })
  if not row or (row.status == 'draft' and row.issued_by_identifier ~= x.identifier) then return { error = 'Warrant not found.' } end
  T.logView(x, 'warrant', id)
  row.history = MySQL.query.await("SELECT officer, action, details, at FROM tez_mdt_log WHERE entity = 'warrant' AND entity_id = ? ORDER BY id DESC LIMIT 30", { tostring(id) }) or {}
  row.canApprove = T.can(x, 'warrant.approve')
  return row
end)

local function warrantStatusFor(x, draft)
  if draft then return 'draft' end
  if Config.WarrantApproval and not T.can(x, 'warrant.approve') then return 'pending' end
  return 'active'
end

local function expiryFor(days)
  days = tonumber(days) or Config.WarrantDays
  if days <= 0 then return nil end
  return now() + math.min(days, 365) * 86400
end

rpc('createWarrant', 'warrant.create', function(src, x, p)
  local reason = clip(p.reason, 1500)
  if #reason < 10 then return { error = 'Write the legal basis for the warrant (at least a sentence).' } end
  local kind = 'arrest'
  for _, t in ipairs(Config.WarrantTypes) do if t.id == p.type then kind = t.id end end
  local u = getUser(p.identifier)
  if not u then return { error = 'Pick the person this warrant is for.' } end
  local st = warrantStatusFor(x, p.draft == true)
  local t = now()
  local approvedBy = (st == 'active') and x.getName() or nil
  local id = MySQL.insert.await('INSERT INTO tez_mdt_warrants (citizen_identifier, citizen_name, type, reason, issued_by, issued_by_identifier, status, approved_by, approved_at, expires_at, report_id, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
    { u.identifier, fullName(u), kind, reason, x.getName(), x.identifier, st, approvedBy, approvedBy and t or nil, (st == 'active') and expiryFor(p.days) or nil, validReport(p.report_id), t, t })
  T.log(x, 'WARRANT', ('Created %s warrant W-%d for %s (%s)'):format(kind, id, fullName(u), st), 'warrant', id)
  if st == 'pending' then
    T.notify({ type = 'warrant', title = 'Warrant needs approval', body = ('%s for %s'):format(kind, fullName(u)), perm = 'warrant.approve', page = 'warrants', id = id })
  elseif st == 'active' then
    T.webhook('Warrant issued', ('**%s** warrant for %s\nIssued by %s\n%s'):format(kind, fullName(u), x.getName(), reason), 15105570)
  end
  return { ok = true, id = id, status = st }
end)

rpc('updateWarrant', 'warrant.create', function(src, x, p)
  local row = MySQL.single.await('SELECT * FROM tez_mdt_warrants WHERE id = ?', { tonumber(p.id) or 0 })
  if not row then return { error = 'Warrant not found.' } end
  if row.status ~= 'draft' and row.status ~= 'pending' then return { error = 'Only drafts and pending warrants can be edited.' } end
  if row.issued_by_identifier ~= x.identifier and not T.can(x, 'warrant.approve') then return { error = 'Only the officer who wrote it can edit this.' } end
  local s = stale(row, p)
  if s then return s end
  local reason = clip(p.reason, 1500)
  if #reason < 10 then return { error = 'Write the legal basis for the warrant.' } end
  local kind = row.type
  for _, t in ipairs(Config.WarrantTypes) do if t.id == p.type then kind = t.id end end
  local t = now()
  MySQL.update.await('UPDATE tez_mdt_warrants SET reason = ?, type = ?, report_id = ?, updated_at = ? WHERE id = ?', { reason, kind, validReport(p.report_id), t, row.id })
  T.log(x, 'WARRANT', ('Edited warrant W-%d'):format(row.id), 'warrant', row.id)
  return { ok = true }
end)

rpc('submitWarrant', 'warrant.create', function(src, x, p)
  local row = MySQL.single.await('SELECT * FROM tez_mdt_warrants WHERE id = ?', { tonumber(p.id) or 0 })
  if not row or row.status ~= 'draft' then return { error = 'Only drafts can be submitted.' } end
  if row.issued_by_identifier ~= x.identifier then return { error = 'Only the officer who wrote it can submit this.' } end
  local st = warrantStatusFor(x, false)
  local t = now()
  MySQL.update.await('UPDATE tez_mdt_warrants SET status = ?, approved_by = ?, approved_at = ?, expires_at = ?, updated_at = ? WHERE id = ?',
    { st, st == 'active' and x.getName() or nil, st == 'active' and t or nil, st == 'active' and expiryFor(p.days) or nil, t, row.id })
  T.log(x, 'WARRANT', ('Submitted warrant W-%d (%s)'):format(row.id, st), 'warrant', row.id)
  if st == 'pending' then
    T.notify({ type = 'warrant', title = 'Warrant needs approval', body = ('%s for %s'):format(row.type, row.citizen_name), perm = 'warrant.approve', page = 'warrants', id = row.id })
  end
  return { ok = true, status = st }
end)

rpc('approveWarrant', 'warrant.approve', function(src, x, p)
  local row = MySQL.single.await('SELECT * FROM tez_mdt_warrants WHERE id = ?', { tonumber(p.id) or 0 })
  if not row or row.status ~= 'pending' then return { error = 'This warrant is not waiting for approval.' } end
  local s = stale(row, p)
  if s then return s end
  local t = now()
  MySQL.update.await("UPDATE tez_mdt_warrants SET status = 'active', approved_by = ?, approved_at = ?, expires_at = ?, updated_at = ? WHERE id = ?",
    { x.getName(), t, expiryFor(p.days), t, row.id })
  T.log(x, 'WARRANT', ('Approved warrant W-%d for %s'):format(row.id, row.citizen_name), 'warrant', row.id)
  if row.issued_by_identifier then
    T.notify({ type = 'warrant', title = 'Warrant approved', body = ('W-%d for %s'):format(row.id, row.citizen_name), target = row.issued_by_identifier, page = 'warrants', id = row.id })
  end
  T.webhook('Warrant issued', ('**%s** warrant for %s\nApproved by %s'):format(row.type, row.citizen_name, x.getName()), 15105570)
  return { ok = true }
end)

rpc('denyWarrant', 'warrant.approve', function(src, x, p)
  local row = MySQL.single.await('SELECT * FROM tez_mdt_warrants WHERE id = ?', { tonumber(p.id) or 0 })
  if not row or row.status ~= 'pending' then return { error = 'This warrant is not waiting for approval.' } end
  local why = clip(p.reason, 200)
  if #why < 3 then return { error = 'Say why it was denied so the officer can fix it.' } end
  MySQL.update.await("UPDATE tez_mdt_warrants SET status = 'denied', note = ?, approved_by = ?, approved_at = ?, updated_at = ? WHERE id = ?", { why, x.getName(), now(), now(), row.id })
  T.log(x, 'WARRANT', ('Denied warrant W-%d: %s'):format(row.id, why), 'warrant', row.id)
  if row.issued_by_identifier then
    T.notify({ type = 'warrant', title = 'Warrant denied', body = ('W-%d: %s'):format(row.id, why), target = row.issued_by_identifier, page = 'warrants', id = row.id })
  end
  return { ok = true }
end)

rpc('recallWarrant', 'warrant.recall', function(src, x, p)
  local row = MySQL.single.await('SELECT * FROM tez_mdt_warrants WHERE id = ?', { tonumber(p.id) or 0 })
  if not row or row.status ~= 'active' then return { error = 'Only active warrants can be recalled.' } end
  local why = clip(p.reason, 200)
  if #why < 3 then return { error = 'Say why the warrant is being recalled.' } end
  MySQL.update.await("UPDATE tez_mdt_warrants SET status = 'recalled', note = ?, updated_at = ? WHERE id = ?", { why, now(), row.id })
  T.log(x, 'WARRANT', ('Recalled warrant W-%d: %s'):format(row.id, why), 'warrant', row.id)
  return { ok = true }
end)

rpc('serveWarrant', 'person.edit', function(src, x, p)
  local row = MySQL.single.await('SELECT * FROM tez_mdt_warrants WHERE id = ?', { tonumber(p.id) or 0 })
  if not row or row.status ~= 'active' then return { error = 'Only active warrants can be served.' } end
  local out = clip(p.outcome, 400)
  if #out < 3 then return { error = 'Write how the warrant was served.' } end
  MySQL.update.await("UPDATE tez_mdt_warrants SET status = 'served', outcome = ?, updated_at = ? WHERE id = ?", { out, now(), row.id })
  T.log(x, 'WARRANT', ('Served warrant W-%d'):format(row.id), 'warrant', row.id)
  return { ok = true }
end)

CreateThread(function()
  Wait(15000)
  while true do
    MySQL.update("UPDATE tez_mdt_warrants SET status = 'expired', updated_at = ? WHERE status = 'active' AND expires_at IS NOT NULL AND expires_at < ?", { now(), now() })
    Wait(60000)
  end
end)

-- ============================================================
--  money and jail helpers used by citations and bookings
-- ============================================================
local function chargeOnline(identifier, fine)
  local target = ESX.GetPlayerFromIdentifier(identifier)
  if not target or fine <= 0 then return false, target end
  if not Config.AutoFine then return false, target end
  local bank = target.getAccount('bank').money
  if bank >= fine then
    target.removeAccountMoney('bank', fine)
    target.showNotification(('You have been fined $%d.'):format(fine))
    return true, target
  end
  target.showNotification(('You owe a fine of $%d. You could not pay it right now.'):format(fine))
  return false, target
end

local function checkSuspension(identifier, addedPoints, target)
  local total = pointsOf(identifier)
  local was = total - addedPoints < Config.SuspendPoints
  if addedPoints > 0 and total >= Config.SuspendPoints and was and target then
    target.showNotification('Your driving licence has been suspended.')
  end
  return total >= Config.SuspendPoints
end

-- ============================================================
--  CITATIONS
-- ============================================================
local CITE_SORT = { id = 'c.id', name = 'c.person_name', fine = 'c.fine', status = 'c.status', created = 'c.created_at' }

rpc('listCitations', 'person.view', function(src, x, p)
  local per, off, order, page = T.paging(p, CITE_SORT, 'created')
  local w = T.Where()
  local st = tostring(p.status or 'all')
  if st ~= 'all' then w:add('c.status = ?', st) end
  local q = clip(p.q, 40)
  if #q >= 1 then
    local n = tonumber((q:gsub('^[Cc]%-?', '')))
    if n then w:add('(c.id = ? OR c.person_name LIKE ? OR c.plate LIKE ?)', n, like(q), like(normPlate(q))) else w:add('(c.person_name LIKE ? OR c.plate LIKE ?)', like(q), like(normPlate(q))) end
  end
  if p.person then w:add('c.person_identifier = ?', tostring(p.person)) end
  local total = MySQL.scalar.await('SELECT COUNT(*) FROM tez_mdt_citations c' .. w:sql(), w:with()) or 0
  local rows = MySQL.query.await('SELECT c.id, c.person_identifier, c.person_name, c.violations, c.fine, c.points, c.status, c.plate, c.location, c.officer_name, c.created_at FROM tez_mdt_citations c' .. w:sql() .. ' ' .. order .. ' LIMIT ? OFFSET ?', w:with(per, off)) or {}
  for _, r in ipairs(rows) do r.violations = decode(r.violations, {}) end
  return T.pageResult(rows, total, page)
end)

rpc('getCitation', 'person.view', function(src, x, p)
  local c = MySQL.single.await('SELECT * FROM tez_mdt_citations WHERE id = ?', { tonumber(p.id) or 0 })
  if not c then return { error = 'Citation not found.' } end
  T.logView(x, 'citation', c.id)
  c.violations = decode(c.violations, {})
  c.history = MySQL.query.await("SELECT officer, action, details, at FROM tez_mdt_log WHERE entity = 'citation' AND entity_id = ? ORDER BY id DESC LIMIT 20", { tostring(c.id) }) or {}
  return c
end)

rpc('createCitation', 'citation.create', function(src, x, p)
  local u = getUser(p.identifier)
  if not u then return { error = 'Pick the person being cited.' } end
  local fine, _, points, labels, used = chargeTotals(p.charges, true)
  if #labels == 0 then return { error = 'Pick at least one violation.' } end
  local narrative = clip(p.narrative, 2000)
  if #narrative < 5 then return { error = 'Add a short narrative of what happened.' } end
  local plate = normPlate(p.plate):sub(1, 12)
  if plate == '' then plate = nil end
  local ids = {}
  for k in pairs(used) do ids[#ids + 1] = k end
  local t = now()
  local id = MySQL.insert.await('INSERT INTO tez_mdt_citations (person_identifier, person_name, officer_identifier, officer_name, violations, charge_ids, fine, points, narrative, location, plate, report_id, call_id, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
    { u.identifier, fullName(u), x.identifier, x.getName(), json.encode(labels), json.encode(ids), fine, points, narrative, clip(p.location, 120), plate, validReport(p.report_id), intOrNil(p.call_id), 'unpaid', t, t })
  MySQL.insert.await('INSERT INTO tez_mdt_records (citizen_identifier, type, title, details, charges, fine, jail, points, officer_identifier, officer_name, created_at, ref_type, ref_id, location) VALUES (?, ?, ?, ?, ?, ?, 0, ?, ?, ?, ?, ?, ?, ?)',
    { u.identifier, 'citation', ('Citation C-%d'):format(id), narrative, json.encode(labels), fine, points, x.identifier, x.getName(), t, 'citation', id, clip(p.location, 120) })
  local paid, target = chargeOnline(u.identifier, fine)
  if paid then MySQL.update.await("UPDATE tez_mdt_citations SET status = 'paid', paid_at = ? WHERE id = ?", { t, id }) end
  local suspended = checkSuspension(u.identifier, points, target)
  T.log(x, 'CITATION', ('Issued citation C-%d to %s: %s'):format(id, fullName(u), table.concat(labels, ', ')), 'citation', id)
  T.log(x, 'CITATION', ('Citation C-%d issued'):format(id), 'person', u.identifier)
  return { ok = true, id = id, fine = fine, points = points, paid = paid, suspended = suspended }
end)

rpc('voidCitation', 'citation.void', function(src, x, p)
  local c = MySQL.single.await('SELECT * FROM tez_mdt_citations WHERE id = ?', { tonumber(p.id) or 0 })
  if not c then return { error = 'Citation not found.' } end
  if c.status == 'voided' then return { error = 'This citation is already void.' } end
  local why = clip(p.reason, 200)
  if #why < 5 then return { error = 'Write the reason for voiding this citation.' } end
  local t = now()
  MySQL.update.await("UPDATE tez_mdt_citations SET status = 'voided', void_by = ?, void_reason = ?, void_at = ?, updated_at = ? WHERE id = ?", { x.getName(), why, t, t, c.id })
  MySQL.update.await("UPDATE tez_mdt_records SET voided = 1 WHERE ref_type = 'citation' AND ref_id = ?", { c.id })
  local refunded = false
  if c.status == 'paid' and c.fine > 0 then
    local target = ESX.GetPlayerFromIdentifier(c.person_identifier)
    if target then
      target.addAccountMoney('bank', c.fine)
      target.showNotification(('A citation was voided and $%d was returned to you.'):format(c.fine))
      refunded = true
    end
  end
  T.log(x, 'VOID', ('Voided citation C-%d: %s'):format(c.id, why), 'citation', c.id)
  return { ok = true, refunded = refunded, refundDue = (c.status == 'paid' and not refunded) }
end)

rpc('setCitationPayment', 'citation.payment', function(src, x, p)
  local c = MySQL.single.await('SELECT * FROM tez_mdt_citations WHERE id = ?', { tonumber(p.id) or 0 })
  if not c or c.status ~= 'unpaid' then return { error = 'Only unpaid citations can be changed.' } end
  local st = (p.status == 'waived') and 'waived' or 'paid'
  MySQL.update.await('UPDATE tez_mdt_citations SET status = ?, paid_at = ?, updated_at = ? WHERE id = ?', { st, now(), now(), c.id })
  T.log(x, 'CITATION', ('Citation C-%d marked %s'):format(c.id, st), 'citation', c.id)
  return { ok = true }
end)

-- ============================================================
--  ARRESTS AND BOOKING
-- ============================================================
local BOOK_SORT = { id = 'b.id', name = 'b.person_name', status = 'b.status', created = 'b.created_at', fine = 'b.fine' }

local function applyBooking(b)
  local t = now()
  local labels = decode(b.charges, {})
  MySQL.insert.await('INSERT INTO tez_mdt_records (citizen_identifier, type, title, details, charges, fine, jail, points, officer_identifier, officer_name, created_at, ref_type, ref_id, location) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
    { b.person_identifier, 'arrest', ('Booking B-%d'):format(b.id), b.narrative, json.encode(labels), b.fine, b.jail, b.points, b.officer_identifier, b.officer_name, t, 'booking', b.id, b.location })
  MySQL.update.await("UPDATE tez_mdt_warrants SET status = 'served', outcome = ?, updated_at = ? WHERE citizen_identifier = ? AND status = 'active' AND type = 'arrest'",
    { ('Served at booking B-%d'):format(b.id), t, b.person_identifier })
  MySQL.update.await('UPDATE tez_mdt_bookings SET applied = 1, updated_at = ? WHERE id = ?', { t, b.id })
  local _, target = chargeOnline(b.person_identifier, b.fine)
  if target and b.jail > 0 then Config.OnJail(target.source, b.jail, target) end
  checkSuspension(b.person_identifier, b.points, target)
end

rpc('listBookings', 'person.view', function(src, x, p)
  local per, off, order, page = T.paging(p, BOOK_SORT, 'created')
  local w = T.Where()
  local st = tostring(p.status or 'all')
  if st ~= 'all' then w:add('b.status = ?', st) end
  local q = clip(p.q, 40)
  if #q >= 1 then
    local n = tonumber((q:gsub('^[Bb]%-?', '')))
    if n then w:add('(b.id = ? OR b.person_name LIKE ?)', n, like(q)) else w:add('b.person_name LIKE ?', like(q)) end
  end
  if p.person then w:add('b.person_identifier = ?', tostring(p.person)) end
  local total = MySQL.scalar.await('SELECT COUNT(*) FROM tez_mdt_bookings b' .. w:sql(), w:with()) or 0
  local rows = MySQL.query.await('SELECT b.id, b.person_identifier, b.person_name, b.charges, b.fine, b.jail, b.status, b.disposition, b.officer_name, b.created_at FROM tez_mdt_bookings b' .. w:sql() .. ' ' .. order .. ' LIMIT ? OFFSET ?', w:with(per, off)) or {}
  for _, r in ipairs(rows) do r.charges = decode(r.charges, {}) end
  return T.pageResult(rows, total, page)
end)

rpc('getBooking', 'person.view', function(src, x, p)
  local b = MySQL.single.await('SELECT * FROM tez_mdt_bookings WHERE id = ?', { tonumber(p.id) or 0 })
  if not b then return { error = 'Booking not found.' } end
  T.logView(x, 'booking', b.id)
  b.charges = decode(b.charges, {})
  b.evidence = decode(b.evidence, {})
  b.history = MySQL.query.await("SELECT officer, action, details, at FROM tez_mdt_log WHERE entity = 'booking' AND entity_id = ? ORDER BY id DESC LIMIT 20", { tostring(b.id) }) or {}
  return b
end)

local function evidenceIds(text)
  local ev = {}
  for n in tostring(text or ''):gmatch('%d+') do
    local id = tonumber(n)
    if MySQL.scalar.await('SELECT id FROM tez_mdt_evidence WHERE id = ?', { id }) then ev[#ev + 1] = id end
  end
  return ev
end
T.evidenceIds = evidenceIds

local function validDisposition(d)
  for _, v in ipairs(Config.BookingDispositions) do if v == d then return v end end
  return Config.BookingDispositions[1]
end

rpc('createBooking', 'booking.create', function(src, x, p)
  local u = getUser(p.identifier)
  if not u then return { error = 'Pick the person being booked.' } end
  local fine, jail, points, labels, used = chargeTotals(p.charges, false)
  if #labels == 0 then return { error = 'Pick at least one charge.' } end
  local narrative = clip(p.narrative, 4000)
  if #narrative < 10 then return { error = 'Write a narrative of the arrest (at least a sentence).' } end
  local ids = {}
  for k in pairs(used) do ids[#ids + 1] = k end
  local status = Config.RequireBookingReview and 'pending' or 'approved'
  local t = now()
  local id = MySQL.insert.await('INSERT INTO tez_mdt_bookings (person_identifier, person_name, officer_identifier, officer_name, assisting, charges, charge_ids, fine, jail, points, narrative, location, report_id, evidence, image, disposition, status, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
    { u.identifier, fullName(u), x.identifier, x.getName(), clip(p.assisting, 200), json.encode(labels), json.encode(ids), fine, jail, points, narrative, clip(p.location, 120), validReport(p.report_id), json.encode(evidenceIds(p.evidence)), clip(p.image, 255), validDisposition(p.disposition), status, t, t })
  T.log(x, 'ARREST', ('Booked %s (B-%d): %s'):format(fullName(u), id, table.concat(labels, ', ')), 'booking', id)
  T.log(x, 'ARREST', ('Booking B-%d created'):format(id), 'person', u.identifier)
  if status == 'approved' then
    local b = MySQL.single.await('SELECT * FROM tez_mdt_bookings WHERE id = ?', { id })
    applyBooking(b)
    T.webhook('Arrest', ('**%s** arrested by %s\nCharges: %s'):format(fullName(u), x.getName(), table.concat(labels, ', ')), 3447003)
  else
    T.notify({ type = 'booking', title = 'Booking needs review', body = ('%s, %s'):format(fullName(u), table.concat(labels, ', ')), perm = 'booking.review', page = 'bookings', id = id })
  end
  return { ok = true, id = id, status = status, fine = fine, jail = jail, points = points }
end)

rpc('updateBooking', 'booking.create', function(src, x, p)
  local b = MySQL.single.await('SELECT * FROM tez_mdt_bookings WHERE id = ?', { tonumber(p.id) or 0 })
  if not b then return { error = 'Booking not found.' } end
  if b.status ~= 'returned' or b.officer_identifier ~= x.identifier then return { error = 'Only the arresting officer can fix a booking that was returned.' } end
  local s = stale(b, p)
  if s then return s end
  local narrative = clip(p.narrative, 4000)
  if #narrative < 10 then return { error = 'Write a narrative of the arrest.' } end
  MySQL.update.await("UPDATE tez_mdt_bookings SET narrative = ?, disposition = ?, evidence = ?, status = 'pending', updated_at = ? WHERE id = ?",
    { narrative, validDisposition(p.disposition), json.encode(evidenceIds(p.evidence)), now(), b.id })
  T.log(x, 'ARREST', ('Resubmitted booking B-%d'):format(b.id), 'booking', b.id)
  T.notify({ type = 'booking', title = 'Booking resubmitted', body = b.person_name, perm = 'booking.review', page = 'bookings', id = b.id })
  return { ok = true }
end)

rpc('reviewBooking', 'booking.review', function(src, x, p)
  local b = MySQL.single.await('SELECT * FROM tez_mdt_bookings WHERE id = ?', { tonumber(p.id) or 0 })
  if not b or b.status ~= 'pending' then return { error = 'This booking is not waiting for review.' } end
  local s = stale(b, p)
  if s then return s end
  local note = clip(p.note, 200)
  local t = now()
  if p.decision == 'approve' then
    MySQL.update.await("UPDATE tez_mdt_bookings SET status = 'approved', reviewed_by = ?, review_note = ?, updated_at = ? WHERE id = ?", { x.getName(), note, t, b.id })
    b.status = 'approved'
    if b.applied == 0 then applyBooking(b) end
    T.log(x, 'REVIEW', ('Approved booking B-%d'):format(b.id), 'booking', b.id)
    T.notify({ type = 'booking', title = 'Booking approved', body = b.person_name, target = b.officer_identifier, page = 'bookings', id = b.id })
  else
    if #note < 3 then return { error = 'Tell the officer what to fix.' } end
    MySQL.update.await("UPDATE tez_mdt_bookings SET status = 'returned', reviewed_by = ?, review_note = ?, updated_at = ? WHERE id = ?", { x.getName(), note, t, b.id })
    T.log(x, 'REVIEW', ('Returned booking B-%d: %s'):format(b.id, note), 'booking', b.id)
    T.notify({ type = 'booking', title = 'Booking returned', body = note, target = b.officer_identifier, page = 'bookings', id = b.id })
  end
  return { ok = true }
end)

rpc('voidBooking', 'booking.review', function(src, x, p)
  local b = MySQL.single.await('SELECT * FROM tez_mdt_bookings WHERE id = ?', { tonumber(p.id) or 0 })
  if not b or b.status == 'voided' then return { error = 'Booking not found or already void.' } end
  local why = clip(p.reason, 200)
  if #why < 5 then return { error = 'Write the reason for voiding this booking.' } end
  MySQL.update.await("UPDATE tez_mdt_bookings SET status = 'voided', review_note = ?, reviewed_by = ?, updated_at = ? WHERE id = ?", { why, x.getName(), now(), b.id })
  MySQL.update.await("UPDATE tez_mdt_records SET voided = 1 WHERE ref_type = 'booking' AND ref_id = ?", { b.id })
  T.log(x, 'VOID', ('Voided booking B-%d: %s'):format(b.id, why), 'booking', b.id)
  return { ok = true }
end)
