-- Tez MDT v3 - crime scene evidence on the ground, 911 calls, panic button
-- Made by Tez Development

local ESX = exports['es_extended']:getSharedObject()
local T = TezMDT
local now, clip = T.now, T.clip

local Scene, SceneId, SceneCount = {}, 0, 0
local LastShot, LastBlood, LastPrint, LastCall = {}, {}, {}, {}
local RecentAuto = {}
T.LastFired = {}

local function validCoords(src, c, maxDist)
  if type(c) ~= 'vector3' then return false end
  local ped = GetPlayerPed(src)
  if ped == 0 then return false end
  return #(GetEntityCoords(ped) - c) <= (maxDist or 10.0)
end

local function addScene(kind, details, coords)
  SceneId = SceneId + 1
  Scene[SceneId] = { type = kind, details = details, coords = coords, at = now() }
  SceneCount = SceneCount + 1
  if SceneCount > Config.MaxSceneEvidence then
    local oldest, oldestId
    for id, e in pairs(Scene) do
      if not oldest or e.at < oldest then oldest, oldestId = e.at, id end
    end
    if oldestId then Scene[oldestId] = nil; SceneCount = SceneCount - 1 end
  end
end

CreateThread(function()
  while true do
    Wait(60000)
    local limit = now() - Config.EvidenceLifetimeMinutes * 60
    for id, e in pairs(Scene) do
      if e.at < limit then Scene[id] = nil; SceneCount = SceneCount - 1 end
    end
  end
end)

-- ------------------------------------------------------------
--  911
-- ------------------------------------------------------------
local TYPE_WORDS = {
  { 'shots', 'shots' }, { 'shooting', 'shots' }, { 'gun', 'shots' }, { 'robbery', 'robbery' }, { 'robbing', 'robbery' },
  { 'crash', 'traffic' }, { 'collision', 'traffic' }, { 'accident', 'traffic' }, { 'stolen', 'theft' }, { 'theft', 'theft' },
  { 'burglar', 'theft' }, { 'break', 'theft' }, { 'fight', 'assault' }, { 'assault', 'assault' }, { 'stab', 'assault' },
  { 'noise', 'disturbance' }, { 'loud', 'disturbance' }, { 'suspicious', 'suspicious' }, { 'welfare', 'welfare' },
}
local function guessType(msg)
  local m = msg:lower()
  for _, w in ipairs(TYPE_WORDS) do
    if m:find(w[1], 1, true) then return w[2] end
  end
  return 'other'
end

local function guessPriority(msg)
  local m = msg:lower()
  for _, k in ipairs(Config.PriorityOneWords) do
    if m:find(k, 1, true) then return 1 end
  end
  return 2
end
T.guessType, T.guessPriority = guessType, guessPriority

RegisterNetEvent('tez_mdt:server:call', function(msg, coords, anon, location)
  local src = source
  local x = ESX.GetPlayerFromId(src)
  if not x then return end
  msg = clip(msg, 200)
  if #msg < 3 then return x.showNotification('Say what is happening. Example: /911 shots fired outside the bank') end
  if not validCoords(src, coords, 25.0) then return end
  local t = now()
  if LastCall[src] and t - LastCall[src] < Config.CallCooldown then
    return x.showNotification('Wait a moment before calling again.')
  end
  LastCall[src] = t
  local who = anon and 'Anonymous caller' or x.getName()
  T.createCall({ kind = 'call', type = guessType(msg), msg = msg, coords = coords, caller = who, priority = guessPriority(msg), location = type(location) == 'string' and location or '' })
  if #T.officers() == 0 then
    x.showNotification('Your call was logged, but no units are on duty right now.')
  else
    x.showNotification('Emergency services have been notified.')
  end
end)

RegisterNetEvent('tez_mdt:server:panic', function()
  local src = source
  local x = ESX.GetPlayerFromId(src)
  if not T.canUse(x) then return end
  T.panic(src, x)
end)

-- ------------------------------------------------------------
--  evidence being left behind
-- ------------------------------------------------------------
RegisterNetEvent('tez_mdt:server:casing', function(weapon, coords)
  local src = source
  local x = ESX.GetPlayerFromId(src)
  if not x or not Config.Weapons[weapon] then return end
  if not validCoords(src, coords) then return end
  local t = GetGameTimer()
  if LastShot[src] and t - LastShot[src] < 400 then return end
  LastShot[src] = t
  T.LastFired[src] = now()
  addScene('casing', { weapon = weapon, weaponLabel = Config.Weapons[weapon], ballistic = T.balCode(x.identifier, weapon) }, coords)

  if Config.AutoShotsCall and not T.canUse(x) then
    local n = now()
    for i = #RecentAuto, 1, -1 do
      if n - RecentAuto[i].at > 90 then table.remove(RecentAuto, i) end
    end
    for _, r in ipairs(RecentAuto) do
      if #(r.coords - coords) < 80.0 then return end
    end
    RecentAuto[#RecentAuto + 1] = { coords = coords, at = n }
    T.createCall({ kind = 'shots', type = 'shots', msg = 'Shots fired reported', coords = coords, caller = 'Gunshot detection', priority = 1 })
  end
end)

RegisterNetEvent('tez_mdt:server:blood', function(coords)
  local src = source
  local x = ESX.GetPlayerFromId(src)
  if not x or not validCoords(src, coords) then return end
  local t = GetGameTimer()
  if LastBlood[src] and t - LastBlood[src] < 3500 then return end
  LastBlood[src] = t
  addScene('blood', { dna = T.dnaCode(x.identifier) }, coords)
end)

RegisterNetEvent('tez_mdt:server:print', function(coords)
  local src = source
  local x = ESX.GetPlayerFromId(src)
  if not x or not validCoords(src, coords, 15.0) then return end
  local t = GetGameTimer()
  if LastPrint[src] and t - LastPrint[src] < 8000 then return end
  LastPrint[src] = t
  addScene('print', { code = T.fngCode(x.identifier) }, coords)
end)

AddEventHandler('esx:playerDropped', function(src)
  LastShot[src], LastBlood[src], LastPrint[src], LastCall[src] = nil, nil, nil, nil
  T.LastFired[src] = nil
end)

-- ------------------------------------------------------------
--  scanning and bagging
-- ------------------------------------------------------------
ESX.RegisterServerCallback('tez_mdt:scan', function(src, cb)
  local x = ESX.GetPlayerFromId(src)
  if not T.can(x, 'evidence.collect') then return cb(nil) end
  local c = GetEntityCoords(GetPlayerPed(src))
  local out = {}
  for id, e in pairs(Scene) do
    if #(c - e.coords) <= Config.ScanRadius then
      out[#out + 1] = { id = id, type = e.type, x = e.coords.x, y = e.coords.y, z = e.coords.z }
      if #out >= Config.MaxPerScan then break end
    end
  end
  cb(out)
end)

local SCENE_LABEL = { casing = 'Shell casing', blood = 'Blood sample', print = 'Fingerprint' }

RegisterNetEvent('tez_mdt:server:collect', function(id)
  local src = source
  local x = ESX.GetPlayerFromId(src)
  if not T.can(x, 'evidence.collect') then return end
  local e = Scene[tonumber(id) or -1]
  if not e then return x.showNotification('That evidence is gone.') end
  if #(GetEntityCoords(GetPlayerPed(src)) - e.coords) > Config.CollectDistance + 2.0 then return end
  Scene[tonumber(id)] = nil
  SceneCount = SceneCount - 1
  local t = now()
  local newId = MySQL.insert.await(
    'INSERT INTO tez_mdt_evidence (type, details, x, y, z, collected_by_identifier, collected_by_name, collected_at, status, category, description, custodian, disposition, updated_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
    { e.type, json.encode(e.details), e.coords.x, e.coords.y, e.coords.z, x.identifier, x.getName(), t, 'collected', 'Forensic', SCENE_LABEL[e.type] or e.type, x.getName(), 'Stored', t })
  MySQL.insert('INSERT INTO tez_mdt_custody (evidence_id, event, by_name, detail, at) VALUES (?, ?, ?, ?, ?)',
    { newId, 'collected', x.getName(), 'Collected at the scene', t })
  T.log(x, 'EVIDENCE', ('Bagged evidence #%d (%s)'):format(newId, e.type), 'evidence', newId)
  x.showNotification(('Evidence bagged and logged as #%d.'):format(newId))
end)
