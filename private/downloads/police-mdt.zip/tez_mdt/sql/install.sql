CREATE TABLE IF NOT EXISTS `tez_mdt_records` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `citizen_identifier` VARCHAR(60) NOT NULL,
  `type` VARCHAR(16) NOT NULL,
  `title` VARCHAR(120) NOT NULL,
  `details` TEXT,
  `charges` TEXT,
  `fine` INT NOT NULL DEFAULT 0,
  `jail` INT NOT NULL DEFAULT 0,
  `points` INT NOT NULL DEFAULT 0,
  `officer_identifier` VARCHAR(60) NOT NULL,
  `officer_name` VARCHAR(80) NOT NULL,
  `created_at` INT NOT NULL,
  PRIMARY KEY (`id`),
  KEY `citizen` (`citizen_identifier`)
);

CREATE TABLE IF NOT EXISTS `tez_mdt_warrants` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `citizen_identifier` VARCHAR(60) NOT NULL,
  `citizen_name` VARCHAR(80) NOT NULL,
  `type` VARCHAR(12) NOT NULL DEFAULT 'arrest',
  `reason` TEXT NOT NULL,
  `issued_by` VARCHAR(80) NOT NULL,
  `status` VARCHAR(12) NOT NULL DEFAULT 'active',
  `created_at` INT NOT NULL,
  `closed_at` INT DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `citizen` (`citizen_identifier`),
  KEY `status` (`status`)
);

CREATE TABLE IF NOT EXISTS `tez_mdt_reports` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `type` VARCHAR(16) NOT NULL DEFAULT 'incident',
  `title` VARCHAR(120) NOT NULL,
  `narrative` TEXT NOT NULL,
  `involved` TEXT,
  `evidence` TEXT,
  `author_identifier` VARCHAR(60) NOT NULL,
  `author_name` VARCHAR(80) NOT NULL,
  `created_at` INT NOT NULL,
  PRIMARY KEY (`id`)
);

CREATE TABLE IF NOT EXISTS `tez_mdt_evidence` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `type` VARCHAR(16) NOT NULL,
  `details` TEXT NOT NULL,
  `x` FLOAT NOT NULL,
  `y` FLOAT NOT NULL,
  `z` FLOAT NOT NULL,
  `collected_by_identifier` VARCHAR(60) NOT NULL,
  `collected_by_name` VARCHAR(80) NOT NULL,
  `collected_at` INT NOT NULL,
  `status` VARCHAR(12) NOT NULL DEFAULT 'collected',
  `analysis_ready_at` INT DEFAULT NULL,
  `result` TEXT,
  PRIMARY KEY (`id`)
);

CREATE TABLE IF NOT EXISTS `tez_mdt_weapons` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `owner_identifier` VARCHAR(60) NOT NULL,
  `weapon` VARCHAR(40) NOT NULL,
  `label` VARCHAR(60) NOT NULL,
  `code` VARCHAR(20) NOT NULL,
  `registered_by` VARCHAR(80) NOT NULL,
  `created_at` INT NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `owner_weapon` (`owner_identifier`, `weapon`),
  KEY `code` (`code`)
);

CREATE TABLE IF NOT EXISTS `tez_mdt_dna` (
  `identifier` VARCHAR(60) NOT NULL,
  `code` VARCHAR(20) NOT NULL,
  `taken_by` VARCHAR(80) NOT NULL,
  `taken_at` INT NOT NULL,
  PRIMARY KEY (`identifier`),
  KEY `code` (`code`)
);

CREATE TABLE IF NOT EXISTS `tez_mdt_prints` (
  `identifier` VARCHAR(60) NOT NULL,
  `code` VARCHAR(20) NOT NULL,
  `taken_by` VARCHAR(80) NOT NULL,
  `taken_at` INT NOT NULL,
  PRIMARY KEY (`identifier`),
  KEY `code` (`code`)
);

CREATE TABLE IF NOT EXISTS `tez_mdt_flags` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `citizen_identifier` VARCHAR(60) NOT NULL,
  `flag` VARCHAR(24) NOT NULL,
  `note` VARCHAR(160) DEFAULT NULL,
  `by_name` VARCHAR(80) NOT NULL,
  `created_at` INT NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `citizen_flag` (`citizen_identifier`, `flag`)
);

CREATE TABLE IF NOT EXISTS `tez_mdt_vflags` (
  `plate` VARCHAR(12) NOT NULL,
  `flag` VARCHAR(24) NOT NULL,
  `note` VARCHAR(160) DEFAULT NULL,
  `by_name` VARCHAR(80) NOT NULL,
  `created_at` INT NOT NULL,
  PRIMARY KEY (`plate`)
);

CREATE TABLE IF NOT EXISTS `tez_mdt_bolos` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `kind` VARCHAR(10) NOT NULL,
  `title` VARCHAR(120) NOT NULL,
  `description` TEXT,
  `plate` VARCHAR(12) DEFAULT NULL,
  `issued_by` VARCHAR(80) NOT NULL,
  `created_at` INT NOT NULL,
  `expires_at` INT NOT NULL,
  `status` VARCHAR(12) NOT NULL DEFAULT 'active',
  PRIMARY KEY (`id`),
  KEY `status` (`status`),
  KEY `plate` (`plate`)
);

CREATE TABLE IF NOT EXISTS `tez_mdt_officers` (
  `identifier` VARCHAR(60) NOT NULL,
  `callsign` VARCHAR(12) NOT NULL,
  PRIMARY KEY (`identifier`)
);

CREATE TABLE IF NOT EXISTS `tez_mdt_log` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `officer` VARCHAR(80) NOT NULL,
  `action` VARCHAR(24) NOT NULL,
  `details` VARCHAR(200) NOT NULL,
  `at` INT NOT NULL,
  PRIMARY KEY (`id`)
);

-- =====================================================================
--  TEZ MDT v3 upgrade. Safe to run on a fresh database AND on top of v2.
--  Needs MariaDB (XAMPP) because of "ADD COLUMN IF NOT EXISTS".
-- =====================================================================

ALTER TABLE `tez_mdt_records`
  ADD COLUMN IF NOT EXISTS `ref_type` VARCHAR(12) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `ref_id` INT DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `voided` TINYINT NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS `location` VARCHAR(120) DEFAULT NULL;

ALTER TABLE `tez_mdt_warrants`
  ADD COLUMN IF NOT EXISTS `issued_by_identifier` VARCHAR(60) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `approved_by` VARCHAR(80) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `approved_at` INT DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `expires_at` INT DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `report_id` INT DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `outcome` TEXT,
  ADD COLUMN IF NOT EXISTS `note` TEXT,
  ADD COLUMN IF NOT EXISTS `updated_at` INT NOT NULL DEFAULT 0;
UPDATE `tez_mdt_warrants` SET `status` = 'recalled' WHERE `status` = 'cancelled';

ALTER TABLE `tez_mdt_reports`
  ADD COLUMN IF NOT EXISTS `status` VARCHAR(12) NOT NULL DEFAULT 'approved',
  ADD COLUMN IF NOT EXISTS `people` TEXT,
  ADD COLUMN IF NOT EXISTS `vehicles` TEXT,
  ADD COLUMN IF NOT EXISTS `witnesses` TEXT,
  ADD COLUMN IF NOT EXISTS `attachments` TEXT,
  ADD COLUMN IF NOT EXISTS `assisting` VARCHAR(200) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `location` VARCHAR(120) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `call_id` INT DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `occurred_at` INT DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `submitted_at` INT DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `reviewed_by` VARCHAR(80) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `version` INT NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS `updated_at` INT NOT NULL DEFAULT 0;
ALTER TABLE `tez_mdt_reports` ADD INDEX IF NOT EXISTS `rstatus` (`status`);
ALTER TABLE `tez_mdt_reports` ADD INDEX IF NOT EXISTS `rcall` (`call_id`);

ALTER TABLE `tez_mdt_evidence`
  ADD COLUMN IF NOT EXISTS `category` VARCHAR(20) NOT NULL DEFAULT 'Forensic',
  ADD COLUMN IF NOT EXISTS `description` VARCHAR(200) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `report_id` INT DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `storage` VARCHAR(120) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `custodian` VARCHAR(80) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `disposition` VARCHAR(24) NOT NULL DEFAULT 'Stored',
  ADD COLUMN IF NOT EXISTS `attachments` TEXT,
  ADD COLUMN IF NOT EXISTS `updated_at` INT NOT NULL DEFAULT 0;
ALTER TABLE `tez_mdt_evidence` MODIFY `x` FLOAT NOT NULL DEFAULT 0, MODIFY `y` FLOAT NOT NULL DEFAULT 0, MODIFY `z` FLOAT NOT NULL DEFAULT 0;
ALTER TABLE `tez_mdt_evidence` MODIFY `details` TEXT;
ALTER TABLE `tez_mdt_evidence` ADD INDEX IF NOT EXISTS `estatus` (`status`);

ALTER TABLE `tez_mdt_bolos`
  ADD COLUMN IF NOT EXISTS `priority` TINYINT NOT NULL DEFAULT 2,
  ADD COLUMN IF NOT EXISTS `location` VARCHAR(120) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `image` VARCHAR(255) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `report_id` INT DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `updates` TEXT,
  ADD COLUMN IF NOT EXISTS `updated_at` INT NOT NULL DEFAULT 0;
ALTER TABLE `tez_mdt_bolos` MODIFY `kind` VARCHAR(12) NOT NULL;

ALTER TABLE `tez_mdt_officers` MODIFY `callsign` VARCHAR(12) NOT NULL DEFAULT '';
ALTER TABLE `tez_mdt_officers`
  ADD COLUMN IF NOT EXISTS `badge` VARCHAR(12) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `division` VARCHAR(40) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `supervisor` VARCHAR(80) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `certs` VARCHAR(200) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `role` VARCHAR(16) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `active` TINYINT NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS `note` VARCHAR(200) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `last_notif` INT NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS `last_seen` INT DEFAULT NULL;

ALTER TABLE `tez_mdt_log` MODIFY `details` VARCHAR(255) NOT NULL;
ALTER TABLE `tez_mdt_log` MODIFY `action` VARCHAR(32) NOT NULL;
ALTER TABLE `tez_mdt_log`
  ADD COLUMN IF NOT EXISTS `officer_identifier` VARCHAR(60) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `entity` VARCHAR(16) DEFAULT NULL,
  ADD COLUMN IF NOT EXISTS `entity_id` VARCHAR(60) DEFAULT NULL;
ALTER TABLE `tez_mdt_log` ADD INDEX IF NOT EXISTS `lentity` (`entity`, `entity_id`);
ALTER TABLE `tez_mdt_log` ADD INDEX IF NOT EXISTS `lat` (`at`);

CREATE TABLE IF NOT EXISTS `tez_mdt_calls` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `kind` VARCHAR(10) NOT NULL DEFAULT 'call',
  `type` VARCHAR(24) NOT NULL DEFAULT 'other',
  `priority` TINYINT NOT NULL DEFAULT 2,
  `msg` VARCHAR(255) NOT NULL,
  `location` VARCHAR(120) DEFAULT NULL,
  `x` FLOAT NOT NULL DEFAULT 0,
  `y` FLOAT NOT NULL DEFAULT 0,
  `caller` VARCHAR(80) NOT NULL,
  `status` VARCHAR(10) NOT NULL DEFAULT 'open',
  `units` TEXT,
  `timeline` TEXT,
  `report_id` INT DEFAULT NULL,
  `created_at` INT NOT NULL,
  `closed_at` INT DEFAULT NULL,
  `closed_by` VARCHAR(80) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cstatus` (`status`),
  KEY `ccreated` (`created_at`)
);

CREATE TABLE IF NOT EXISTS `tez_mdt_citations` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `person_identifier` VARCHAR(60) NOT NULL,
  `person_name` VARCHAR(80) NOT NULL,
  `officer_identifier` VARCHAR(60) NOT NULL,
  `officer_name` VARCHAR(80) NOT NULL,
  `violations` TEXT NOT NULL,
  `charge_ids` TEXT,
  `fine` INT NOT NULL DEFAULT 0,
  `points` INT NOT NULL DEFAULT 0,
  `narrative` TEXT,
  `location` VARCHAR(120) DEFAULT NULL,
  `plate` VARCHAR(12) DEFAULT NULL,
  `report_id` INT DEFAULT NULL,
  `call_id` INT DEFAULT NULL,
  `status` VARCHAR(10) NOT NULL DEFAULT 'unpaid',
  `paid_at` INT DEFAULT NULL,
  `void_by` VARCHAR(80) DEFAULT NULL,
  `void_reason` VARCHAR(200) DEFAULT NULL,
  `void_at` INT DEFAULT NULL,
  `created_at` INT NOT NULL,
  `updated_at` INT NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `cperson` (`person_identifier`),
  KEY `cstatus` (`status`),
  KEY `cplate` (`plate`)
);

CREATE TABLE IF NOT EXISTS `tez_mdt_bookings` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `person_identifier` VARCHAR(60) NOT NULL,
  `person_name` VARCHAR(80) NOT NULL,
  `officer_identifier` VARCHAR(60) NOT NULL,
  `officer_name` VARCHAR(80) NOT NULL,
  `assisting` VARCHAR(200) DEFAULT NULL,
  `charges` TEXT NOT NULL,
  `charge_ids` TEXT,
  `fine` INT NOT NULL DEFAULT 0,
  `jail` INT NOT NULL DEFAULT 0,
  `points` INT NOT NULL DEFAULT 0,
  `narrative` TEXT,
  `location` VARCHAR(120) DEFAULT NULL,
  `report_id` INT DEFAULT NULL,
  `evidence` TEXT,
  `image` VARCHAR(255) DEFAULT NULL,
  `disposition` VARCHAR(40) DEFAULT NULL,
  `status` VARCHAR(10) NOT NULL DEFAULT 'approved',
  `applied` TINYINT NOT NULL DEFAULT 0,
  `reviewed_by` VARCHAR(80) DEFAULT NULL,
  `review_note` VARCHAR(200) DEFAULT NULL,
  `created_at` INT NOT NULL,
  `updated_at` INT NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `bperson` (`person_identifier`),
  KEY `bstatus` (`status`)
);

CREATE TABLE IF NOT EXISTS `tez_mdt_report_versions` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `report_id` INT NOT NULL,
  `version` INT NOT NULL,
  `title` VARCHAR(120) NOT NULL,
  `narrative` TEXT NOT NULL,
  `edited_by` VARCHAR(80) NOT NULL,
  `at` INT NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rid` (`report_id`)
);

CREATE TABLE IF NOT EXISTS `tez_mdt_report_comments` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `report_id` INT NOT NULL,
  `by_name` VARCHAR(80) NOT NULL,
  `kind` VARCHAR(10) NOT NULL DEFAULT 'comment',
  `text` VARCHAR(500) NOT NULL,
  `at` INT NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rid` (`report_id`)
);

CREATE TABLE IF NOT EXISTS `tez_mdt_custody` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `evidence_id` INT NOT NULL,
  `event` VARCHAR(20) NOT NULL,
  `by_name` VARCHAR(80) NOT NULL,
  `detail` VARCHAR(200) DEFAULT NULL,
  `at` INT NOT NULL,
  PRIMARY KEY (`id`),
  KEY `eid` (`evidence_id`)
);

CREATE TABLE IF NOT EXISTS `tez_mdt_impounds` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `plate` VARCHAR(12) NOT NULL,
  `model` BIGINT DEFAULT NULL,
  `owner_identifier` VARCHAR(60) DEFAULT NULL,
  `owner_name` VARCHAR(80) DEFAULT NULL,
  `reason` VARCHAR(200) NOT NULL,
  `location` VARCHAR(120) DEFAULT NULL,
  `officer_name` VARCHAR(80) NOT NULL,
  `fee` INT NOT NULL DEFAULT 0,
  `report_id` INT DEFAULT NULL,
  `status` VARCHAR(12) NOT NULL DEFAULT 'impounded',
  `released_by` VARCHAR(80) DEFAULT NULL,
  `released_at` INT DEFAULT NULL,
  `created_at` INT NOT NULL,
  PRIMARY KEY (`id`),
  KEY `iplate` (`plate`),
  KEY `istatus` (`status`)
);

CREATE TABLE IF NOT EXISTS `tez_mdt_cases` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `title` VARCHAR(120) NOT NULL,
  `status` VARCHAR(12) NOT NULL DEFAULT 'open',
  `parties` TEXT,
  `judge` VARCHAR(80) DEFAULT NULL,
  `prosecutor` VARCHAR(80) DEFAULT NULL,
  `defense` VARCHAR(80) DEFAULT NULL,
  `links` TEXT,
  `hearings` TEXT,
  `outcome` TEXT,
  `sentence` TEXT,
  `appeals` TEXT,
  `created_by` VARCHAR(80) NOT NULL,
  `created_at` INT NOT NULL,
  `updated_at` INT NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  KEY `kstatus` (`status`)
);

CREATE TABLE IF NOT EXISTS `tez_mdt_announcements` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `title` VARCHAR(120) NOT NULL,
  `body` TEXT NOT NULL,
  `by_name` VARCHAR(80) NOT NULL,
  `pinned` TINYINT NOT NULL DEFAULT 0,
  `created_at` INT NOT NULL,
  `expires_at` INT DEFAULT NULL,
  PRIMARY KEY (`id`)
);

CREATE TABLE IF NOT EXISTS `tez_mdt_notifs` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `type` VARCHAR(16) NOT NULL,
  `title` VARCHAR(120) NOT NULL,
  `body` VARCHAR(255) DEFAULT NULL,
  `perm` VARCHAR(32) DEFAULT NULL,
  `target` VARCHAR(60) DEFAULT NULL,
  `link_page` VARCHAR(16) DEFAULT NULL,
  `link_id` VARCHAR(20) DEFAULT NULL,
  `created_at` INT NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ncreated` (`created_at`)
);

CREATE TABLE IF NOT EXISTS `tez_mdt_person_meta` (
  `identifier` VARCHAR(60) NOT NULL,
  `phone` VARCHAR(24) DEFAULT NULL,
  `address` VARCHAR(160) DEFAULT NULL,
  `aliases` VARCHAR(200) DEFAULT NULL,
  `note` TEXT,
  `updated_by` VARCHAR(80) DEFAULT NULL,
  `updated_at` INT NOT NULL DEFAULT 0,
  PRIMARY KEY (`identifier`)
);

CREATE TABLE IF NOT EXISTS `tez_mdt_vehicle_meta` (
  `plate` VARCHAR(12) NOT NULL,
  `registration` VARCHAR(12) NOT NULL DEFAULT 'valid',
  `insurance` VARCHAR(12) NOT NULL DEFAULT 'valid',
  `note` TEXT,
  `updated_by` VARCHAR(80) DEFAULT NULL,
  `updated_at` INT NOT NULL DEFAULT 0,
  PRIMARY KEY (`plate`)
);
