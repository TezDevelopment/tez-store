Config = {}

-- ==========================================================
--  TEZ MDT v3  -  Made by Tez Development
-- ==========================================================

Config.Brand = { name = 'TEZ POLICE', sub = 'Mobile Data Terminal', maker = 'Tez Development' }

-- ESX job names allowed to use the MDT and collect evidence.
-- Use the ON-duty job names only. Off-duty jobs (like offpolice) are locked out on purpose.
Config.Jobs = { police = true, sheriff = true }

-- CHANGE THIS to any long random text. It scrambles DNA and ballistic codes so players cannot work them out.
Config.Salt = 'x7Kp29qLmZ84vT3rBw'

Config.OpenKey = 'F7'   -- players can rebind this in FiveM keybind settings

-- ==========  ROLES AND PERMISSIONS  ==========
-- Every action is checked on the server. A role lists what it may do. 'inherit' copies another role first.
-- Use '*' to allow everything. Add your own roles or edit these freely.
Config.Roles = {
  officer = { label = 'Officer', perms = {
    'person.view', 'person.edit', 'vehicle.view', 'vehicle.edit', 'call.create', 'call.respond',
    'bolo.create', 'warrant.create', 'report.create', 'citation.create', 'booking.create',
    'evidence.collect', 'evidence.view', 'impound.create', 'case.view', 'officers.view',
  } },
  dispatcher = { label = 'Dispatcher', inherit = 'officer', perms = { 'call.manage', 'bolo.manage' } },
  records = { label = 'Records clerk', inherit = 'officer', perms = {
    'citation.void', 'citation.payment', 'case.manage', 'report.review', 'warrant.recall',
  } },
  supervisor = { label = 'Supervisor', inherit = 'dispatcher', perms = {
    'warrant.approve', 'warrant.recall', 'report.review', 'citation.void', 'citation.payment',
    'booking.review', 'evidence.transfer', 'impound.release', 'audit.view', 'case.manage',
  } },
  command = { label = 'Command', inherit = 'supervisor', perms = {
    'officers.manage', 'dept.manage', 'record.delete', 'evidence.dispose', 'settings.view',
  } },
  admin = { label = 'Administrator', perms = { '*' } },
}
-- Which role each job grade gets. Grades not listed get 'officer'.
Config.GradeRoles = { [0] = 'officer', [1] = 'officer', [2] = 'officer', [3] = 'supervisor', [4] = 'command' }
-- ESX groups that always count as administrator in the MDT
Config.AdminGroups = { admin = true, superadmin = true }
-- A grade at or above this number counts as senior for the old SeniorGrade checks
Config.SeniorGrade = 3

-- ==========  DISPATCH  ==========
Config.CallCooldown        = 20     -- seconds between 911 calls from one player
Config.CallLifetimeMinutes = 45     -- open calls close by themselves after this long
Config.DispatchBlipSeconds = 180
Config.AutoShotsCall       = true   -- gunfire from non-police creates a "shots fired" call by itself
Config.PanicCooldown       = 30
Config.PlateKey            = 'PAGEDOWN'  -- run the plate of the nearest vehicle
-- calls containing these words are marked priority 1
Config.PriorityOneWords = { 'shots', 'shooting', 'officer down', 'kidnap', 'robbery', 'murder', 'stabbing', 'hostage', 'bomb', 'armed', 'gun', 'dead' }

-- Unit status codes. Change the labels and codes to match your department. 'id' must stay the same.
Config.Statuses = {
  { id = 'available', label = 'Available',      code = '10-8'  },
  { id = 'enroute',   label = 'En route',       code = '10-76' },
  { id = 'onscene',   label = 'On scene',       code = '10-23' },
  { id = 'busy',      label = 'Busy',           code = '10-6'  },
  { id = 'emergency', label = 'Emergency',      code = '10-33' },
  { id = 'out',       label = 'Out of service', code = '10-7'  },
}
Config.CallTypes = {
  { id = 'traffic',     label = 'Traffic collision' },
  { id = 'disturbance', label = 'Disturbance' },
  { id = 'welfare',     label = 'Welfare check' },
  { id = 'theft',       label = 'Theft or burglary' },
  { id = 'robbery',     label = 'Robbery' },
  { id = 'shots',       label = 'Shots fired' },
  { id = 'assault',     label = 'Assault' },
  { id = 'suspicious',  label = 'Suspicious activity' },
  { id = 'traffic_stop',label = 'Traffic stop' },
  { id = 'other',       label = 'Other' },
}

-- ==========  RECORDS  ==========
Config.WarrantApproval  = true   -- officers without warrant.approve send warrants to a supervisor first
Config.WarrantDays      = 14     -- default warrant lifetime (days)
Config.WarrantTypes     = { { id = 'arrest', label = 'Arrest' }, { id = 'search', label = 'Search' }, { id = 'bench', label = 'Bench' } }
Config.RequireBookingReview = false  -- true = fines and jail only apply after a supervisor approves the booking
Config.BookingDispositions = { 'Held in custody', 'Released on bail', 'Released, no charges', 'Transferred to another agency', 'Sentenced' }
Config.ReportTypes = {
  { id = 'incident', label = 'Incident' }, { id = 'arrest', label = 'Arrest' }, { id = 'traffic', label = 'Traffic' },
  { id = 'force', label = 'Use of force' }, { id = 'death', label = 'Death' }, { id = 'other', label = 'Other' },
}
Config.BoloTypes = {
  { id = 'person', label = 'Person' }, { id = 'vehicle', label = 'Vehicle' }, { id = 'missing', label = 'Missing person' },
  { id = 'stolen', label = 'Stolen vehicle' }, { id = 'other', label = 'Other' },
}
Config.BoloHours = 24
Config.EvidenceCategories = { 'Forensic', 'Weapon', 'Drugs', 'Money', 'Document', 'Digital', 'Clothing', 'Other' }
Config.EvidenceDispositions = { 'Stored', 'In lab', 'Released to owner', 'Sent to court', 'Destroyed' }
Config.Court = { enabled = true }   -- set enabled = false if your server does not roleplay courts
Config.VehicleFlags = {
  { id = 'stolen',     label = 'Stolen' },
  { id = 'wanted',     label = 'Wanted' },
  { id = 'suspicious', label = 'Suspicious' },
  { id = 'uninsured',  label = 'No insurance' },
  { id = 'expired',    label = 'Registration expired' },
}
Config.CitizenFlags = {
  { id = 'armed',     label = 'Armed' },
  { id = 'dangerous', label = 'Violent' },
  { id = 'flight',    label = 'Flight risk' },
  { id = 'gang',      label = 'Gang affiliated' },
  { id = 'mental',    label = 'Mental health' },
  { id = 'medical',   label = 'Medical alert' },
}
Config.SuspendPoints = 12   -- licence points that suspend a licence
Config.GSRMinutes    = 15   -- gunshot residue test stays positive this long after firing
Config.PerPage       = 12   -- rows per page in tables

-- How long old data is kept (days). Set a value to 0 to keep it forever.
Config.Retention = { calls = 90, log = 180, notifications = 14 }

-- optional Discord webhook for arrests, warrants, BOLOs and panic alerts (leave empty to turn off)
Config.Webhook = ''

-- ==========  FINES / JAIL  ==========
Config.AutoFine = true  -- take the fine from the citizen's bank when they are online
-- Called when a booking with jail time is applied to an online citizen.
-- Hook your jail script in here. Example for a script that has a server event:
--   TriggerEvent('your_jail:sendToJail', targetSrc, minutes)
Config.OnJail = function(targetSrc, minutes, xTarget)
  xTarget.showNotification(('You have been sentenced to %d months.'):format(minutes))
end
-- Called when a vehicle is impounded. Hook your garage or impound script in here.
Config.OnImpound = function(plate) end

-- ==========  EVIDENCE  ==========
Config.EvidenceLifetimeMinutes = 60   -- crime-scene evidence disappears after this long
Config.MaxSceneEvidence        = 250  -- oldest is removed beyond this
Config.ScanRadius              = 15.0
Config.ScanSeconds             = 30   -- how long scanned evidence stays marked
Config.MaxPerScan              = 40
Config.CollectDistance         = 2.0
Config.LabMinutes              = 10   -- analysis time
-- Lab analysis can only be started when standing at the lab. Set required = false to allow it anywhere.
Config.Lab = { required = false, coords = vec3(441.2, -982.1, 30.7), radius = 20.0 }

-- ==========  WEAPONS (casings are only left by these) ==========
Config.Weapons = {
  WEAPON_PISTOL = 'Pistol', WEAPON_COMBATPISTOL = 'Combat Pistol', WEAPON_APPISTOL = 'AP Pistol',
  WEAPON_PISTOL50 = 'Pistol .50', WEAPON_SNSPISTOL = 'SNS Pistol', WEAPON_HEAVYPISTOL = 'Heavy Pistol',
  WEAPON_VINTAGEPISTOL = 'Vintage Pistol', WEAPON_REVOLVER = 'Revolver', WEAPON_MACHINEPISTOL = 'Machine Pistol',
  WEAPON_MICROSMG = 'Micro SMG', WEAPON_SMG = 'SMG', WEAPON_ASSAULTSMG = 'Assault SMG', WEAPON_MINISMG = 'Mini SMG',
  WEAPON_ASSAULTRIFLE = 'Assault Rifle', WEAPON_CARBINERIFLE = 'Carbine Rifle', WEAPON_ADVANCEDRIFLE = 'Advanced Rifle',
  WEAPON_SPECIALCARBINE = 'Special Carbine', WEAPON_BULLPUPRIFLE = 'Bullpup Rifle', WEAPON_COMPACTRIFLE = 'Compact Rifle',
  WEAPON_PUMPSHOTGUN = 'Pump Shotgun', WEAPON_SAWNOFFSHOTGUN = 'Sawed-Off Shotgun', WEAPON_ASSAULTSHOTGUN = 'Assault Shotgun',
  WEAPON_DBSHOTGUN = 'Double Barrel Shotgun', WEAPON_MG = 'MG', WEAPON_COMBATMG = 'Combat MG', WEAPON_GUSENBERG = 'Gusenberg',
  WEAPON_SNIPERRIFLE = 'Sniper Rifle', WEAPON_MARKSMANRIFLE = 'Marksman Rifle',
}

-- ==========  CHARGES  ==========
-- id (unique), label, fine, jail (months), points (licence points), cite = true means it can be used on a citation
Config.Charges = {
  { id = 'speeding',        label = 'Speeding',                        fine = 250,   jail = 0,  points = 2, cite = true },
  { id = 'reckless',        label = 'Reckless driving',                fine = 600,   jail = 0,  points = 4, cite = true },
  { id = 'no_license',      label = 'Driving without a license',       fine = 800,   jail = 0, cite = true },
  { id = 'dui',             label = 'Driving under the influence',     fine = 1500,  jail = 5,  points = 6 },
  { id = 'evading',         label = 'Evading police',                  fine = 2000,  jail = 10, points = 6 },
  { id = 'hit_run',         label = 'Hit and run',                     fine = 1800,  jail = 8,  points = 6 },
  { id = 'gta',             label = 'Grand theft auto',                fine = 2500,  jail = 12 },
  { id = 'petty_theft',     label = 'Petty theft',                     fine = 500,   jail = 3 },
  { id = 'burglary',        label = 'Burglary',                        fine = 3000,  jail = 15 },
  { id = 'robbery',         label = 'Robbery',                         fine = 4500,  jail = 20 },
  { id = 'armed_robbery',   label = 'Armed robbery',                   fine = 7000,  jail = 30 },
  { id = 'assault',         label = 'Assault',                         fine = 1500,  jail = 8 },
  { id = 'agg_assault',     label = 'Aggravated assault',              fine = 4000,  jail = 20 },
  { id = 'brandishing',     label = 'Brandishing a weapon',            fine = 1200,  jail = 6 },
  { id = 'illegal_weapon',  label = 'Unlicensed weapon possession',    fine = 3500,  jail = 15 },
  { id = 'discharge',       label = 'Discharging a firearm in public', fine = 2800,  jail = 12 },
  { id = 'kidnapping',      label = 'Kidnapping',                      fine = 8000,  jail = 35 },
  { id = 'attempted_murder',label = 'Attempted murder',                fine = 12000, jail = 50 },
  { id = 'murder',          label = 'Murder',                          fine = 25000, jail = 90 },
  { id = 'drug_possession', label = 'Drug possession',                 fine = 1000,  jail = 5 },
  { id = 'drug_dealing',    label = 'Drug distribution',               fine = 5000,  jail = 25 },
  { id = 'obstruction',     label = 'Obstruction of justice',          fine = 1800,  jail = 8 },
  { id = 'resisting',       label = 'Resisting arrest',                fine = 1500,  jail = 6 },
  { id = 'assault_officer', label = 'Assault on an officer',          fine = 6000,  jail = 25 },
  { id = 'vandalism',       label = 'Vandalism',                       fine = 800,   jail = 3 },
  { id = 'trespass',        label = 'Trespassing',                     fine = 600,   jail = 2, cite = true },
  { id = 'fraud',           label = 'Fraud',                           fine = 3500,  jail = 15 },
  { id = 'bribery',         label = 'Bribery',                         fine = 5000,  jail = 20 },
  { id = 'conspiracy',      label = 'Conspiracy',                      fine = 4500,  jail = 20 },
  { id = 'weapon_traffic',  label = 'Weapons trafficking',             fine = 9000,  jail = 35 },
  { id = 'stolen_property', label = 'Possession of stolen property',   fine = 2000,  jail = 8 },
  { id = 'false_report',    label = 'Filing a false report',           fine = 900,   jail = 3 },
  -- traffic and minor infractions (citations only)
  { id = 'red_light',       label = 'Running a red light',             fine = 200,   jail = 0,  points = 2, cite = true },
  { id = 'illegal_park',    label = 'Illegal parking',                 fine = 100,   jail = 0,  cite = true },
  { id = 'no_plates',       label = 'Missing or hidden plates',        fine = 350,   jail = 0,  points = 1, cite = true },
  { id = 'tint',            label = 'Illegal window tint',             fine = 200,   jail = 0,  cite = true },
  { id = 'noise',           label = 'Noise disturbance',               fine = 250,   jail = 0,  cite = true },
  { id = 'jaywalk',         label = 'Jaywalking',                      fine = 75,    jail = 0,  cite = true },
  { id = 'seatbelt',        label = 'No seatbelt',                     fine = 100,   jail = 0,  points = 1, cite = true },
  { id = 'no_insurance',    label = 'No insurance',                    fine = 500,   jail = 0,  cite = true },
}
