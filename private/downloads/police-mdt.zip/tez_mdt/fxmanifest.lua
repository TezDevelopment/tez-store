fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'tez_mdt'
author 'Tez Development'
description 'Tez MDT v3: CAD dispatch, records, warrants, reports, evidence custody, court and department tools (ESX Legacy)'
version '3.0.0'

shared_scripts { 'config.lua' }
server_scripts { '@oxmysql/lib/MySQL.lua', 'server/core.lua', 'server/scene.lua', 'server/people.lua', 'server/ops.lua', 'server/admin.lua' }
client_scripts { 'client/main.lua' }

ui_page 'html/index.html'
files { 'html/index.html', 'html/style.css', 'html/js/*.js' }

dependencies { 'es_extended', 'oxmysql' }
