Locales = Locales or {}

function L(key, ...)
    local pack = Locales[Config.Locale] or Locales.en or {}
    local s = pack[key] or (Locales.en and Locales.en[key]) or key
    if select('#', ...) > 0 then
        local ok, r = pcall(string.format, s, ...)
        if ok then return r end
    end
    return s
end

-- "glam_silk:3" -> "glam_silk", 3
function SplitItem(s)
    local name, n = tostring(s):match('^%s*([^:%s]+)%s*:?%s*(%d*)')
    return name, tonumber(n) or 1
end

Boards = { 'sold', 'crafted', 'earned', 'streak' }
Periods = { 'day', 'week', 'month', 'all' }

function hexToRgb(hex)
    if type(hex) ~= 'string' then return 236, 72, 153 end
    local r, g, b = hex:match('^#(%x%x)(%x%x)(%x%x)$')
    if not r then return 236, 72, 153 end
    return tonumber(r, 16), tonumber(g, 16), tonumber(b, 16)
end
