-- Every setting the admin panel can change.
-- t = bool, int, float, string, secret, color, select, list (list of strings), objects (list of records, see `sub`)
-- Values are validated on the server with Schema.validate before they are saved.

Schema = { pages = {}, fields = {}, byKey = {} }

local function page(id, label) Schema.pages[#Schema.pages + 1] = { id = id, label = label } end

local function add(p, k, t, d, label, o)
    o = o or {}
    local f = { k = k, p = p, t = t, d = d, l = label, h = o.help, min = o.min, max = o.max, opts = o.opts, secret = (t == 'secret'),
                sub = o.sub, item = o.item, restart = o.restart, place = o.place }
    Schema.fields[#Schema.fields + 1] = f
    Schema.byKey[k] = f
end

-- sub-field helper for records
local function sf(k, t, d, l, o)
    o = o or {}
    return { k = k, t = t, d = d, l = l, min = o.min, max = o.max, opts = o.opts, help = o.help, item = o.item }
end

page('general', 'General')
page('access', 'Access & Staff')
page('hub', 'Hub & Peds')
page('jobs', 'Jobs')
page('products', 'Products')
page('shop', 'Beauty Shop')
page('crafting', 'Crafting')
page('selling', 'Customers')
page('thieves', 'Thieves')
page('zones', 'Zones')
page('career', 'Career & Levels')
page('tasks', 'Tasks & Streaks')
page('boards', 'Leaderboard Prizes')
page('starter', 'Starter Pack')
page('social', 'Chat & Gallery')
page('moderation', 'Moderation')
page('logs', 'Logs')

-- ------------------------------------------------------------------ General
add('general', 'hubName', 'string', 'Glam Hub', 'Hub name', { max = 30 })
add('general', 'themeColor', 'color', '#ec4899', 'Theme colour', { help = 'Main colour for everyone (players can pick their own).' })
add('general', 'defaultMode', 'select', 'dark', 'Default mode', { opts = { 'dark', 'light' } })
add('general', 'currency', 'string', '$', 'Currency symbol', { max = 4 })
add('general', 'currencyAfter', 'bool', false, 'Put the symbol after the number')
add('general', 'payAccount', 'select', 'cash', 'Pay players into', { opts = { 'cash', 'bank' }, help = 'Where sales, salaries, rewards and prizes are paid.' })
add('general', 'shopAccount', 'select', 'cash', 'Players pay the shop from', { opts = { 'cash', 'bank' } })
add('general', 'hubCommand', 'string', 'glamhub', 'Hub command', { max = 20, help = 'Players type /<command> to open the hub.' })
add('general', 'sellCommand', 'string', 'glamsell', 'Sell command', { max = 20, help = 'Players type /<command> to start selling.' })
add('general', 'interact', 'select', 'prompt', 'How players interact', { opts = { 'prompt', 'target' }, help = 'prompt = press E near things. target = use ox_target / qb-target.' })
add('general', 'framework', 'select', 'auto', 'Framework', { opts = { 'auto', 'esx', 'qb', 'qbox' }, restart = true, help = 'Applies after the next restart.' })
add('general', 'inventory', 'select', 'auto', 'Inventory', { opts = { 'auto', 'ox', 'qb', 'qs', 'esx' }, restart = true, help = 'Applies after the next restart.' })
add('general', 'targetResource', 'select', 'auto', 'Target resource', { opts = { 'auto', 'ox_target', 'qb-target' }, restart = true })
add('general', 'tourEnabled', 'bool', true, 'Welcome tour for new players')

-- ------------------------------------------------------------------ Access
add('access', 'adminGroups', 'list', { 'admin', 'god', 'superadmin', 'owner' }, 'Admin groups', { help = 'Can open /glamadmin. Framework groups.' })
add('access', 'adminRoles', 'list', {}, 'Admin Discord role IDs')
add('access', 'staffGroups', 'list', { 'admin', 'god', 'superadmin', 'owner', 'mod' }, 'Staff groups', { help = 'Staff can always open the hub, mute players and delete photos.' })
add('access', 'staffRoles', 'list', {}, 'Staff Discord role IDs')
add('access', 'verifierGroups', 'list', { 'admin', 'god', 'superadmin', 'owner' }, 'Verifier groups', { help = 'Can give the verified badge.' })
add('access', 'verifierRoles', 'list', {}, 'Verifier Discord role IDs')
add('access', 'discordGuild', 'string', '', 'Discord server ID', { max = 40 })
add('access', 'discordToken', 'secret', '', 'Discord bot token', { max = 200, help = 'Used for role checks. Never leaves the server.' })
add('access', 'accessMode', 'select', 'everyone', 'Who can open the hub', { opts = { 'everyone', 'hubjob', 'job', 'discord' }, help = 'hubjob = players who hold one of the hub jobs. job = a framework job. discord = Discord roles.' })
add('access', 'accessJob', 'string', 'beauty', 'Access framework job', { max = 40 })
add('access', 'accessGrade', 'int', 0, 'Minimum grade', { min = 0, max = 100 })
add('access', 'accessRoles', 'list', {}, 'Access Discord roles')
add('access', 'requireTablet', 'bool', false, 'Players need the tablet item to open the hub')
add('access', 'tabletItem', 'string', 'glam_tablet', 'Tablet item', { max = 50, item = true })

-- ------------------------------------------------------------------ Hub & peds
add('hub', 'hubPeds', 'objects', {
    { label = 'Glam Hub', model = 's_f_y_shop_mid', x = 195.6, y = -934.4, z = 30.7, h = 150.0, blip = true },
}, 'Hub peds', { max = 20, help = 'Talk to a hub ped to open the hub.', place = true, sub = {
    sf('label', 'string', 'Glam Hub', 'Name', { max = 30 }),
    sf('model', 'string', 's_f_y_shop_mid', 'Ped model', { max = 50 }),
    sf('x', 'float', 0.0, 'X'), sf('y', 'float', 0.0, 'Y'), sf('z', 'float', 0.0, 'Z'), sf('h', 'float', 0.0, 'Heading'),
    sf('blip', 'bool', true, 'Map blip'),
} })
add('hub', 'blipSprite', 'int', 71, 'Hub blip icon', { min = 1, max = 900 })
add('hub', 'blipColour', 'int', 8, 'Hub blip colour', { min = 0, max = 85 })
add('hub', 'pedDistance', 'float', 2.5, 'Interact distance (m)', { min = 1, max = 10 })

-- ------------------------------------------------------------------ Jobs
add('jobs', 'jobs', 'objects', {
    { id = 'assistant', label = 'Beauty Assistant', salary = 120, level = 1, bonus = 0, products = { 'glam_lipstick', 'glam_lipgloss' } },
    { id = 'lash', label = 'Lash Technician', salary = 160, level = 2, bonus = 3, products = { 'glam_lipstick', 'glam_lipgloss', 'glam_lashes', 'glam_mascara' } },
    { id = 'nail', label = 'Nail Technician', salary = 200, level = 3, bonus = 4, products = { 'glam_lipstick', 'glam_lipgloss', 'glam_lashes', 'glam_mascara', 'glam_nailpolish', 'glam_blush' } },
    { id = 'makeup', label = 'Makeup Artist', salary = 260, level = 4, bonus = 6, products = { 'glam_lipstick', 'glam_lipgloss', 'glam_lashes', 'glam_mascara', 'glam_nailpolish', 'glam_blush', 'glam_eyeshadow', 'glam_foundation', 'glam_facemask' } },
    { id = 'wig', label = 'Wig Stylist', salary = 340, level = 6, bonus = 8, products = { 'glam_lipstick', 'glam_lipgloss', 'glam_lashes', 'glam_mascara', 'glam_nailpolish', 'glam_blush', 'glam_eyeshadow', 'glam_foundation', 'glam_facemask', 'glam_extensions', 'glam_wig' } },
    { id = 'manager', label = 'Salon Manager', salary = 450, level = 8, bonus = 10, products = { 'glam_lipstick', 'glam_lipgloss', 'glam_lashes', 'glam_mascara', 'glam_nailpolish', 'glam_blush', 'glam_eyeshadow', 'glam_foundation', 'glam_facemask', 'glam_extensions', 'glam_wig', 'glam_perfume' } },
}, 'Salon jobs', { max = 20, help = 'Up to 20 jobs. Each job pays a salary, unlocks products and adds a bonus to every sale.', sub = {
    sf('id', 'string', 'newjob', 'Job name (no spaces)', { max = 30 }),
    sf('label', 'string', 'New job', 'Label', { max = 40 }),
    sf('salary', 'int', 100, 'Salary per pay time', { min = 0, max = 1000000 }),
    sf('level', 'int', 1, 'Career level needed', { min = 1, max = 20 }),
    sf('bonus', 'float', 0.0, 'Sales bonus (%)', { min = 0, max = 100 }),
    sf('products', 'list', {}, 'Products it can make (item names)', { item = true }),
} })
add('jobs', 'salaryMinutes', 'int', 15, 'Salary every (minutes)', { min = 1, max = 240 })
add('jobs', 'salaryEnabled', 'bool', true, 'Pay salaries')
add('jobs', 'syncFrameworkJobs', 'bool', true, 'Add hub jobs to the framework (ESX)', { help = 'ESX only. Missing jobs are added when the resource starts.' })

-- ------------------------------------------------------------------ Products
local prod = function(id, label, price, xp, level, time, ingr)
    return { id = id, label = label, price = price, xp = xp, level = level, time = time, ingredients = ingr, animDict = '', animClip = '', prop = '' }
end
add('products', 'products', 'objects', {
    prod('glam_lipstick', 'Lipstick', 60, 5, 1, 6, { 'glam_pigment:1', 'glam_beeswax:1' }),
    prod('glam_lipgloss', 'Lip Gloss', 55, 5, 1, 6, { 'glam_beeswax:1', 'glam_rose_oil:1' }),
    prod('glam_lashes', 'Lash Set', 90, 7, 2, 8, { 'glam_silk:2', 'glam_lash_glue:1' }),
    prod('glam_nailpolish', 'Nail Polish', 75, 6, 2, 7, { 'glam_pigment:1', 'glam_glass_bottle:1' }),
    prod('glam_eyeshadow', 'Eyeshadow Palette', 110, 9, 3, 9, { 'glam_pigment:3', 'glam_beeswax:1' }),
    prod('glam_blush', 'Blush', 95, 8, 3, 8, { 'glam_pigment:2', 'glam_rose_oil:1' }),
    prod('glam_foundation', 'Foundation', 120, 10, 4, 10, { 'glam_pigment:2', 'glam_glass_bottle:1', 'glam_beeswax:1' }),
    prod('glam_mascara', 'Mascara', 85, 7, 4, 8, { 'glam_silk:1', 'glam_pigment:1', 'glam_glass_bottle:1' }),
    prod('glam_facemask', 'Face Mask', 100, 9, 5, 10, { 'glam_rose_oil:2', 'glam_silk:1' }),
    prod('glam_extensions', 'Hair Extensions', 180, 14, 6, 14, { 'glam_hair:3', 'glam_lash_glue:1' }),
    prod('glam_wig', 'Wig', 320, 22, 8, 20, { 'glam_hair:6', 'glam_silk:2' }),
    prod('glam_perfume', 'Signature Perfume', 450, 30, 9, 25, { 'glam_rose_oil:3', 'glam_glass_bottle:2', 'glam_pigment:1' }),
}, 'Products', { max = 40, help = 'Item name = the item in your inventory. Ingredients look like item:amount.', sub = {
    sf('id', 'string', 'glam_item', 'Item name', { max = 50, item = true }),
    sf('label', 'string', 'Product', 'Label', { max = 40 }),
    sf('price', 'int', 50, 'Base sell price', { min = 1, max = 10000000 }),
    sf('xp', 'int', 5, 'XP per product (craft and sale)', { min = 0, max = 100000 }),
    sf('level', 'int', 1, 'Career level needed', { min = 1, max = 20 }),
    sf('time', 'int', 6, 'Seconds to make one', { min = 1, max = 600 }),
    sf('ingredients', 'list', {}, 'Ingredients (item:amount)', { item = true }),
    sf('animDict', 'string', '', 'Animation dictionary (optional)', { max = 60 }),
    sf('animClip', 'string', '', 'Animation clip (optional)', { max = 60 }),
    sf('prop', 'string', '', 'Hand prop model (optional)', { max = 60 }),
} })

-- ------------------------------------------------------------------ Shop
add('shop', 'ingredients', 'objects', {
    { item = 'glam_silk', label = 'Silk Fibers', price = 18 },
    { item = 'glam_lash_glue', label = 'Lash Glue', price = 14 },
    { item = 'glam_pigment', label = 'Pigment', price = 12 },
    { item = 'glam_beeswax', label = 'Beeswax', price = 10 },
    { item = 'glam_rose_oil', label = 'Rose Oil', price = 22 },
    { item = 'glam_glass_bottle', label = 'Glass Bottle', price = 8 },
    { item = 'glam_hair', label = 'Hair Bundle', price = 30 },
}, 'Shop ingredients', { max = 40, sub = {
    sf('item', 'string', 'glam_item', 'Item name', { max = 50, item = true }),
    sf('label', 'string', 'Ingredient', 'Label', { max = 40 }),
    sf('price', 'int', 10, 'Price', { min = 0, max = 10000000 }),
} })
add('shop', 'tablePrice', 'int', 500, 'Beauty table price', { min = 0, max = 10000000 })
add('shop', 'quickSellEnabled', 'bool', true, 'Quick Sell tab in the shop')
add('shop', 'quickSellRate', 'float', 0.6, 'Quick Sell pays (share of base price)', { min = 0.05, max = 2 })
add('shop', 'maxCartItems', 'int', 99, 'Largest amount per item', { min = 1, max = 999 })

-- ------------------------------------------------------------------ Crafting
add('crafting', 'tableItem', 'string', 'glam_table', 'Beauty table item', { max = 50, item = true })
add('crafting', 'tableModel', 'string', 'prop_table_03', 'Table prop model', { max = 60, help = 'Any valid prop model name.' })
add('crafting', 'tableDistance', 'float', 2.5, 'Distance to use your table (m)', { min = 1, max = 10 })
add('crafting', 'maxCraft', 'int', 20, 'Most products per craft', { min = 1, max = 100 })
add('crafting', 'backgroundCraft', 'bool', true, 'Allow crafting in the background')
add('crafting', 'craftAnimDict', 'string', 'mp_prison_break', 'Default animation dictionary', { max = 60 })
add('crafting', 'craftAnimClip', 'string', 'hack_loop', 'Default animation clip', { max = 60 })
add('crafting', 'tableBlip', 'bool', true, 'Show your table on the map')

-- ------------------------------------------------------------------ Customers
add('selling', 'customerMin', 'int', 8, 'Shortest wait for a customer (s)', { min = 3, max = 600 })
add('selling', 'customerMax', 'int', 20, 'Longest wait for a customer (s)', { min = 3, max = 600 })
add('selling', 'customerModels', 'list', { 'a_f_y_hipster_01', 'a_f_y_bevhills_01', 'a_f_y_vinewood_01', 'a_f_y_tourist_01', 'a_f_m_fatwhite_01', 'a_f_y_fitness_01' }, 'Customer ped models')
add('selling', 'walkUpBonus', 'float', 20.0, 'Walk-up bonus over a quick sale (%)', { min = 0, max = 500 })
add('selling', 'priceVariation', 'float', 8.0, 'Price changes between customers (+/- %)', { min = 0, max = 50 })
add('selling', 'customerExpire', 'int', 45, 'Customer waits this long (s)', { min = 10, max = 300 })
add('selling', 'spawnDistance', 'float', 28.0, 'Customers appear this far away (m)', { min = 10, max = 80 })
add('selling', 'sellDistance', 'float', 3.0, 'Distance to sell (m)', { min = 1, max = 10 })
add('selling', 'sellOnFoot', 'bool', true, 'Only sell while on foot')

-- ------------------------------------------------------------------ Thieves
add('thieves', 'thievesEnabled', 'bool', true, 'Thieves enabled')
add('thieves', 'theftChance', 'float', 10.0, 'Chance a customer steals (%)', { min = 0, max = 100 })
add('thieves', 'theftTime', 'int', 60, 'Time to catch the thief (s)', { min = 10, max = 600 })
add('thieves', 'theftProducts', 'list', { 'glam_wig', 'glam_perfume', 'glam_extensions' }, 'Products thieves take', { item = true, help = 'Empty = any product.' })
add('thieves', 'theftFightBack', 'bool', false, 'Thieves fight back')
add('thieves', 'theftReturnMoney', 'bool', true, 'Recovering also pays the sale')
add('thieves', 'theftMaxStrength', 'int', 3, 'Max thefts at the same time', { min = 1, max = 10 })

-- ------------------------------------------------------------------ Zones
add('zones', 'boostZones', 'objects', {
    { label = 'Legion Square', x = 195.0, y = -934.0, z = 30.7, radius = 90.0, bonus = 20.0, blip = true },
    { label = 'Vespucci Beach', x = -1340.0, y = -1590.0, z = 4.4, radius = 100.0, bonus = 15.0, blip = true },
    { label = 'Rockford Plaza', x = -170.0, y = -160.0, z = 43.6, radius = 80.0, bonus = 25.0, blip = true },
}, 'Boost zones', { max = 40, place = true, help = 'Sales inside pay extra.', sub = {
    sf('label', 'string', 'Zone', 'Name', { max = 30 }),
    sf('x', 'float', 0.0, 'X'), sf('y', 'float', 0.0, 'Y'), sf('z', 'float', 0.0, 'Z'),
    sf('radius', 'float', 50.0, 'Radius (m)', { min = 5, max = 500 }),
    sf('bonus', 'float', 10.0, 'Bonus (%)', { min = 1, max = 500 }),
    sf('blip', 'bool', true, 'Map blip'),
} })
add('zones', 'boostDaily', 'int', 0, 'Zones active each day', { min = 0, max = 40, help = '0 = all zones all the time. Otherwise a different few are picked each day.' })
add('zones', 'noSellZones', 'objects', {
    { label = 'Mission Row Police', x = 441.0, y = -982.0, z = 30.7, radius = 70.0 },
    { label = 'Pillbox Hospital', x = 298.0, y = -584.0, z = 43.3, radius = 70.0 },
}, 'No-sell zones', { max = 40, place = true, help = 'Nobody buys here, for example near police stations or hospitals.', sub = {
    sf('label', 'string', 'Zone', 'Name', { max = 30 }),
    sf('x', 'float', 0.0, 'X'), sf('y', 'float', 0.0, 'Y'), sf('z', 'float', 0.0, 'Z'),
    sf('radius', 'float', 50.0, 'Radius (m)', { min = 5, max = 500 }),
} })

-- ------------------------------------------------------------------ Career
local lv = function(name, xp, boost, cash, item, count)
    return { name = name, xp = xp, boost = boost, cash = cash or 0, item = item or '', count = count or 0 }
end
add('career', 'levels', 'objects', {
    lv('New Face', 0, 0), lv('Apprentice', 200, 3, 300), lv('Stylist', 500, 6, 0, 'glam_pigment', 5),
    lv('Specialist', 1000, 9, 800), lv('Artist', 1800, 12, 0, 'glam_rose_oil', 5),
    lv('Expert', 3000, 15, 1500), lv('Professional', 4800, 18, 0, 'glam_hair', 5),
    lv('Icon', 7500, 22, 3000), lv('Legend', 11000, 26, 0, 'glam_perfume', 2), lv('Beauty Mogul', 16000, 30, 8000),
}, 'Career levels', { max = 20, help = 'Level 1 must need 0 XP. Boost is the extra % on every sale.', sub = {
    sf('name', 'string', 'Level', 'Level name', { max = 30 }),
    sf('xp', 'int', 0, 'Total XP needed', { min = 0, max = 100000000 }),
    sf('boost', 'float', 0.0, 'Sales boost (%)', { min = 0, max = 100 }),
    sf('cash', 'int', 0, 'Reward money', { min = 0, max = 10000000 }),
    sf('item', 'string', '', 'Reward item', { max = 50, item = true }),
    sf('count', 'int', 0, 'Reward item amount', { min = 0, max = 1000 }),
} })
add('career', 'xpEnabled', 'bool', true, 'XP and levels enabled')
add('career', 'saleXpMultiplier', 'float', 1.0, 'XP multiplier for sales', { min = 0, max = 20 })
add('career', 'craftXpMultiplier', 'float', 1.0, 'XP multiplier for crafting', { min = 0, max = 20 })

-- ------------------------------------------------------------------ Tasks
add('tasks', 'tasksEnabled', 'bool', true, 'Daily tasks enabled')
add('tasks', 'tasksPerDay', 'int', 3, 'Tasks per day', { min = 1, max = 8 })
add('tasks', 'taskPool', 'objects', {
    { id = 'craft10', type = 'craft', goal = 10, cash = 250, xp = 40 },
    { id = 'craft25', type = 'craft', goal = 25, cash = 600, xp = 90 },
    { id = 'sell8', type = 'sell', goal = 8, cash = 300, xp = 50 },
    { id = 'sell20', type = 'sell', goal = 20, cash = 750, xp = 110 },
    { id = 'earn2000', type = 'earn', goal = 2000, cash = 400, xp = 60 },
    { id = 'earn5000', type = 'earn', goal = 5000, cash = 900, xp = 120 },
    { id = 'post1', type = 'post', goal = 1, cash = 200, xp = 30 },
    { id = 'chat5', type = 'chat', goal = 5, cash = 150, xp = 20 },
}, 'Task pool', { max = 30, help = 'Types: craft, sell, earn, post, chat.', sub = {
    sf('id', 'string', 'task', 'Task name', { max = 30 }),
    sf('type', 'select', 'craft', 'Type', { opts = { 'craft', 'sell', 'earn', 'post', 'chat' } }),
    sf('goal', 'int', 10, 'Goal', { min = 1, max = 10000000 }),
    sf('cash', 'int', 100, 'Reward money', { min = 0, max = 10000000 }),
    sf('xp', 'int', 20, 'Reward XP', { min = 0, max = 1000000 }),
} })
add('tasks', 'completionCash', 'int', 500, 'Bonus for finishing all tasks', { min = 0, max = 10000000 })
add('tasks', 'completionXp', 'int', 100, 'Bonus XP for finishing all tasks', { min = 0, max = 1000000 })
add('tasks', 'streakRewards', 'objects', {
    { days = 3, cash = 500 }, { days = 7, cash = 1500 }, { days = 14, cash = 4000 }, { days = 30, cash = 10000 },
}, 'Streak rewards', { max = 12, sub = {
    sf('days', 'int', 3, 'Streak days', { min = 2, max = 365 }),
    sf('cash', 'int', 500, 'Reward money', { min = 0, max = 10000000 }),
} })

-- ------------------------------------------------------------------ Boards
add('boards', 'prizesEnabled', 'bool', true, 'Pay leaderboard prizes automatically')
add('boards', 'prizes', 'objects', {
    { period = 'day', rank = 1, cash = 1000 }, { period = 'day', rank = 2, cash = 600 }, { period = 'day', rank = 3, cash = 300 },
    { period = 'week', rank = 1, cash = 5000 }, { period = 'week', rank = 2, cash = 3000 }, { period = 'week', rank = 3, cash = 1500 },
    { period = 'month', rank = 1, cash = 20000 }, { period = 'month', rank = 2, cash = 12000 }, { period = 'month', rank = 3, cash = 6000 },
}, 'Prizes', { max = 30, help = 'Paid on all four boards when the day, week or month ends.', sub = {
    sf('period', 'select', 'day', 'Period', { opts = { 'day', 'week', 'month' } }),
    sf('rank', 'int', 1, 'Place', { min = 1, max = 3 }),
    sf('cash', 'int', 100, 'Prize money', { min = 0, max = 100000000 }),
} })

-- ------------------------------------------------------------------ Starter pack
add('starter', 'starterEnabled', 'bool', true, 'Starter pack enabled')
add('starter', 'starterItems', 'list', { 'glam_silk:3', 'glam_pigment:3', 'glam_beeswax:3', 'glam_rose_oil:2', 'glam_glass_bottle:3', 'glam_table:1' }, 'Starter items (item:amount)', { item = true })
add('starter', 'starterCars', 'objects', {
    { model = 'faggio', label = 'Faggio Scooter' },
}, 'Starter cars', { max = 20, sub = {
    sf('model', 'string', 'faggio', 'Vehicle model', { max = 40 }),
    sf('label', 'string', 'Car', 'Label', { max = 40 }),
} })
add('starter', 'starterCarPicks', 'int', 1, 'Cars each player can pick', { min = 0, max = 5 })
add('starter', 'plateFormat', 'string', 'GLAM####', 'Plate format', { max = 8, help = '# = number, A = letter.' })
add('starter', 'garage', 'string', 'pillboxgarage', 'Garage name (QBCore / Qbox)', { max = 40 })

-- ------------------------------------------------------------------ Chat & gallery
add('social', 'chatEnabled', 'bool', true, 'Global Chat enabled')
add('social', 'chatMaxLength', 'int', 200, 'Longest message', { min = 20, max = 600 })
add('social', 'chatCooldown', 'int', 800, 'Wait between messages (ms)', { min = 0, max = 10000 })
add('social', 'chatHistory', 'int', 80, 'Messages kept in Global Chat', { min = 10, max = 300 })
add('social', 'friendsEnabled', 'bool', true, 'Friends and private messages')
add('social', 'groupsEnabled', 'bool', true, 'Group chats')
add('social', 'groupMax', 'int', 10, 'Members per group chat', { min = 3, max = 30 })
add('social', 'imagesEnabled', 'bool', true, 'Images in chats and comments')
add('social', 'gifsEnabled', 'bool', true, 'GIF picker')
add('social', 'gifKey', 'secret', '', 'GIF key (Giphy)', { max = 100, help = 'Get a free key at developers.giphy.com. Never leaves the server.' })
add('social', 'gifRating', 'select', 'pg', 'GIF content filter', { opts = { 'g', 'pg', 'pg-13', 'r' } })
add('social', 'emojisEnabled', 'bool', true, 'Emoji picker')
add('social', 'galleryEnabled', 'bool', true, 'Gallery enabled')
add('social', 'galleryPerDay', 'int', 10, 'Photos per player per day', { min = 1, max = 100 })
add('social', 'commentMax', 'int', 160, 'Longest comment', { min = 10, max = 500 })
add('social', 'bioMax', 'int', 200, 'Longest bio', { min = 10, max = 500 })
add('social', 'popupTime', 'int', 6, 'Message pop-up time (s)', { min = 2, max = 30 })

-- ------------------------------------------------------------------ Moderation
add('moderation', 'blockedWords', 'list', {}, 'Blocked words', { help = 'Checked in everything players type.' })
add('moderation', 'blockMode', 'select', 'censor', 'When a blocked word is used', { opts = { 'censor', 'stop' } })
add('moderation', 'imageSites', 'list', { 'cdn.discordapp.com', 'media.discordapp.net', 'i.imgur.com', 'r2.fivemanage.com', 'media.giphy.com', 'i.giphy.com' }, 'Image and GIF sites', { help = 'Players can only paste https links from these sites.' })

-- ------------------------------------------------------------------ Logs
add('logs', 'logWebhook', 'secret', '', 'Discord webhook URL', { max = 300, help = 'Never leaves the server.' })
add('logs', 'logToWebhook', 'bool', false, 'Log to Discord')
add('logs', 'fivemanageKey', 'secret', '', 'Fivemanage API key', { max = 200, help = 'Never leaves the server.' })
add('logs', 'logToFivemanage', 'bool', false, 'Log to Fivemanage')
add('logs', 'logSales', 'bool', true, 'Sales')
add('logs', 'logCrafting', 'bool', false, 'Crafting')
add('logs', 'logTheft', 'bool', true, 'Thefts')
add('logs', 'logGallery', 'bool', true, 'Gallery posts')
add('logs', 'logChat', 'bool', false, 'Chat messages')
add('logs', 'logStaff', 'bool', true, 'Staff actions')
add('logs', 'logPrizes', 'bool', true, 'Prizes')
add('logs', 'logAdminChanges', 'bool', true, 'Admin panel changes (old and new value)')

-- ====================================================================== helpers

local function deepcopy(v)
    if type(v) ~= 'table' then return v end
    local out = {}
    for k, x in pairs(v) do out[k] = deepcopy(x) end
    return out
end
Schema.deepcopy = deepcopy

function Schema.defaults()
    local out = {}
    for _, f in ipairs(Schema.fields) do out[f.k] = deepcopy(f.d) end
    return out
end

-- returns ok, cleanedValue
function Schema.validate(f, v)
    local t = f.t
    if t == 'bool' then
        if type(v) ~= 'boolean' then return false end
        return true, v
    elseif t == 'int' or t == 'float' then
        v = tonumber(v)
        if not v or v ~= v or v == math.huge or v == -math.huge then return false end
        if t == 'int' then v = math.floor(v + 0.5) end
        if (f.min and v < f.min) or (f.max and v > f.max) then return false end
        return true, v
    elseif t == 'string' or t == 'secret' then
        if type(v) ~= 'string' then return false end
        v = v:gsub('[%c]', ''):sub(1, f.max or 200)
        return true, v
    elseif t == 'color' then
        if type(v) ~= 'string' then return false end
        if v == '' and f.d == '' then return true, '' end
        if not v:match('^#%x%x%x%x%x%x$') then return false end
        return true, v:lower()
    elseif t == 'select' then
        for _, o in ipairs(f.opts or {}) do if o == v then return true, v end end
        return false
    elseif t == 'list' then
        if type(v) ~= 'table' or #v > 200 then return false end
        local out = {}
        for _, s in ipairs(v) do
            if type(s) ~= 'string' then return false end
            s = s:gsub('[%c]', ''):sub(1, 80)
            if s ~= '' then out[#out + 1] = s end
        end
        return true, out
    elseif t == 'objects' then
        if type(v) ~= 'table' or #v > (f.max or 100) then return false end
        local out = {}
        for _, rec in ipairs(v) do
            if type(rec) ~= 'table' then return false end
            local clean = {}
            for _, s in ipairs(f.sub) do
                local val = rec[s.k]
                if val == nil then val = deepcopy(s.d) end
                local ok, c = Schema.validate(s, val)
                if not ok then return false end
                clean[s.k] = c
            end
            out[#out + 1] = clean
        end
        return true, out
    end
    return false
end

-- Records that list item names, so setup warnings can check them
function Schema.itemNames(settings)
    local names = {}
    local function add(n) if type(n) == 'string' and n ~= '' then names[n] = true end end
    local function split(s) return (tostring(s):match('^([^:]+)')) end
    for _, p in ipairs(settings.products or {}) do
        add(p.id)
        for _, i in ipairs(p.ingredients or {}) do add(split(i)) end
    end
    for _, i in ipairs(settings.ingredients or {}) do add(i.item) end
    for _, i in ipairs(settings.starterItems or {}) do add(split(i)) end
    for _, l in ipairs(settings.levels or {}) do add(l.item) end
    add(settings.tableItem) add(settings.tabletItem)
    return names
end
