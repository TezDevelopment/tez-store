# Glam Hub 1.0 (Tez Development)

A beauty business and social app for FiveM. Players take a salon job, craft beauty products at a table they place
themselves, sell them to customers who walk up on the street, level up a career, finish daily tasks, climb leaderboards
and talk to each other through chat, friends, group chats and a photo gallery. Everything is set up in game.

Works with ESX, QBCore and Qbox, and with ox_inventory, qb-inventory, qs-inventory or the ESX inventory.

## Requirements
- oxmysql
- ESX, QBCore or Qbox
- One of the inventories above
- ox_target or qb-target is optional (an E prompt is used otherwise)

## Install
1. Put the `glam_hub` folder in `resources` and add `ensure glam_hub` to `server.cfg` after your framework, inventory and oxmysql.
2. Add the items. Use the file in `install/` that matches your inventory:
   - `ox_inventory_items.lua` (also copy `html/items/*.png` into `ox_inventory/web/images`)
   - `esx_items.sql` (run it once in your database)
   - `qb_qs_items.lua` (also copy the pictures into your inventory's images folder)
3. Restart the server. The database tables are created automatically.
4. In game type **/glamadmin**. The Status page lists anything still missing.

Give yourself admin with a framework group (admin, god, superadmin, owner by default) or in `server.cfg`:
```
add_ace group.admin glam.admin allow
add_ace group.mod glam.staff allow
add_ace group.admin glam.verify allow
```

## Commands
| Command | Who | What |
| --- | --- | --- |
| /glamhub | players | open the hub (name can be changed in the admin panel) |
| /glamsell | players | start or stop selling (G pauses, X stops) |
| /glamadmin | admins | open the admin panel |
| /glammute id minutes, /glamunmute id | staff | mute or unmute a player |
| /glamverify id [remove] | verifiers | give or remove the verified badge |

Players can also open the hub by talking to a hub ped or by using the tablet item.

## The admin panel
Seventeen pages hold every setting: jobs, products, shop, crafting, customers, thieves, zones, career levels, tasks,
leaderboard prizes, the starter pack, chat and gallery limits, moderation, logs and permissions. Press Save (or Ctrl+S)
and the change is live for every player. Peds and zones are placed in game with **Use my position**, **Pick in game**
(scroll to change a zone's size) and **Go there**. Every change is kept in the change history, with the old and new value.

## Optional
- GIF picker: add a free Giphy key on the Chat & Gallery page and press Test.
- Logs: add a Discord webhook or Fivemanage key on the Logs page and press Test.
- Discord roles: add a bot token and server ID on the Access & Staff page.
- Your own code: `bridge/hooks.lua` runs after sales, crafts, posts, staff actions and prizes, and lets you block the hub (for example while cuffed) or plug in your own notifications.
- Translating: copy `locales/en.lua` and set `Config.Locale`.

## Notes
- Hub jobs are kept by Glam Hub itself. On ESX they are also added to the framework's job list so other scripts can see the names.
- Salaries are paid by Glam Hub every few minutes while the player holds a job.
- Starter cars are added to the garage table of ESX (`owned_vehicles`) and QBCore / Qbox (`player_vehicles`). Plates come from `Hooks.plate` in `bridge/hooks.lua`.
