-- The social hub: Global Chat, friends, private and group messages, gallery, profiles, GIFs and moderation

local function now() return GH.now() end

-- who the other player sees: a public id, never the real identifier
local function personOf(identifier, name)
    local pd = GH.pd[identifier]
    local prof = pd and pd.profile
    local online = GH.bySrc[identifier] ~= nil
    local status = 'offline'
    if online then status = prof and prof.status or 'online'; if status == 'invisible' then status = 'offline' end end
    return {
        pub = GH.pubOf(identifier), name = name or (pd and pd.name) or '?', picture = prof and prof.picture or '', status = status,
        verified = prof and prof.verified == true or false,
    }
end

-- profile data for people who are offline
local function profileRow(identifier)
    local pd = GH.pd[identifier]
    if pd then return pd end
    local row = MySQL.single.await('SELECT identifier, name, xp, crafted, sold, earned, best_streak, job, profile FROM glam_players WHERE identifier = ?', { identifier })
    if not row then return nil end
    return { identifier = identifier, name = row.name, xp = row.xp, crafted = row.crafted, sold = row.sold, earned = row.earned,
             bestStreak = row.best_streak, job = row.job ~= '' and row.job or nil, profile = GH.jdec(row.profile, {}) }
end

local function peopleByIds(ids)
    local out = {}
    for _, id in ipairs(ids) do
        local pd = profileRow(id)
        if pd then out[id] = personOf(id, pd.name) out[id].picture = pd.profile.picture or '' out[id].verified = pd.profile.verified == true end
    end
    return out
end

-- ============================================================ relationships

function GH.areFriends(a, b)
    return MySQL.scalar.await("SELECT 1 FROM glam_friends WHERE status = 'accepted' AND ((a = ? AND b = ?) OR (a = ? AND b = ?))", { a, b, b, a }) ~= nil
end

function GH.isBlocked(a, b)
    return MySQL.scalar.await('SELECT 1 FROM glam_blocks WHERE (identifier = ? AND blocked = ?) OR (identifier = ? AND blocked = ?)', { a, b, b, a }) ~= nil
end

local function relation(me, other)
    if me == other then return 'me' end
    if MySQL.scalar.await('SELECT 1 FROM glam_blocks WHERE identifier = ? AND blocked = ?', { me, other }) then return 'blocked' end
    local row = MySQL.single.await('SELECT a, status FROM glam_friends WHERE (a = ? AND b = ?) OR (a = ? AND b = ?)', { me, other, other, me })
    if not row then return 'none' end
    if row.status == 'accepted' then return 'friends' end
    return row.a == me and 'pending_out' or 'pending_in'
end

local function enabled(key) return GH.get(key) ~= false end

-- ============================================================== profiles

local statuses = { online = true, idle = true, dnd = true, invisible = true }
local privMsg = { everyone = true, friends = true, nobody = true }
local privStats = { everyone = true, friends = true, me = true }

function GH.profileView(src, pub)
    local me = GH.idOf(src)
    local identifier = pub and pub ~= '' and GH.fromPub(pub) or me
    if not identifier then return nil end
    local pd = profileRow(identifier)
    if not pd then return nil end
    local isMe = identifier == me
    local rel = relation(me, identifier)
    if rel ~= 'me' and GH.isBlocked(me, identifier) and rel ~= 'blocked' then return nil end
    local prof = pd.profile
    local lvlIdx, lvl = GH.levelOf(pd.xp)
    local showStats = isMe or prof.privStats == nil or prof.privStats == 'everyone' or (prof.privStats == 'friends' and rel == 'friends')
    local job = pd.job and GH.jobById(pd.job)
    local person = personOf(identifier, pd.name)
    return {
        pub = person.pub, name = person.name, picture = prof.picture or '', banner = prof.banner or '', bio = prof.bio or '',
        photos = prof.photos or {}, status = person.status, ownStatus = isMe and (prof.status or 'online') or nil, verified = prof.verified == true,
        job = job and job.label or nil, level = lvlIdx, levelName = lvl.name, isMe = isMe, relation = rel,
        stats = showStats and { crafted = pd.crafted, sold = pd.sold, earned = math.floor(pd.earned), best = pd.bestStreak } or nil,
        privMsg = isMe and (prof.privMsg or 'everyone') or nil, privStats = isMe and (prof.privStats or 'everyone') or nil,
    }
end

function GH.profileSave(src, d)
    local pd = GH.pdOf(src)
    if not pd or type(d) ~= 'table' then return false, L('err.badvalue') end
    local prof = pd.profile
    if d.bio ~= nil then
        local ok, bio = GH.filter(tostring(d.bio):sub(1, GH.get('bioMax')))
        if not ok then return false, L('err.blocked') end
        prof.bio = bio
    end
    for _, key in ipairs({ 'picture', 'banner' }) do
        if d[key] ~= nil then
            local ok, url = GH.validImage(d[key])
            if not ok then return false, L('err.badimage') end
            prof[key] = url
        end
    end
    if d.photos ~= nil then
        if type(d.photos) ~= 'table' or #d.photos > 9 then return false, L('err.gallery9') end
        local out = {}
        for _, url in ipairs(d.photos) do
            local ok, clean = GH.validImage(url)
            if not ok then return false, L('err.badimage') end
            if clean ~= '' then out[#out + 1] = clean end
        end
        prof.photos = out
    end
    if d.status ~= nil then
        if not statuses[d.status] then return false, L('err.badvalue') end
        prof.status = d.status
    end
    if d.privMsg ~= nil then
        if not privMsg[d.privMsg] then return false, L('err.badvalue') end
        prof.privMsg = d.privMsg
    end
    if d.privStats ~= nil then
        if not privStats[d.privStats] then return false, L('err.badvalue') end
        prof.privStats = d.privStats
    end
    pd.dirty = true
    return true
end

function GH.setVerified(src, pub, value)
    local identifier = GH.fromPub(pub)
    if not identifier then return false, L('err.gone') end
    local pd = GH.pd[identifier]
    if pd then
        pd.profile.verified = value == true
        pd.dirty = true
    else
        local row = MySQL.single.await('SELECT profile FROM glam_players WHERE identifier = ?', { identifier })
        if not row then return false, L('err.gone') end
        local prof = GH.jdec(row.profile, {})
        prof.verified = value == true
        MySQL.update('UPDATE glam_players SET profile = ? WHERE identifier = ?', { GH.jenc(prof), identifier })
    end
    GH.log('staff', ('%s verified badge %s for %s'):format(GH.players[src] and GH.players[src].name or 'console', value and 'given' or 'removed', pub), src)
    Hooks.onStaffAction(src, 'verify', identifier)
    return true
end

-- =============================================================== chat

local function checkText(text, image, maxLen)
    text = GH.trim(text or '')
    if #text > maxLen then text = text:sub(1, maxLen) end
    local imgOk, img = true, ''
    if image and image ~= '' then
        if not enabled('imagesEnabled') and not enabled('gifsEnabled') then return false, L('err.disabled') end
        imgOk, img = GH.validImage(image)
        if not imgOk then return false, L('err.badimage') end
    end
    if text == '' and img == '' then return false, L('err.badvalue') end
    local ok, clean = GH.filter(text)
    if not ok then return false, L('err.blocked') end
    return true, clean, img
end

function GH.chatHistory()
    if #GH.chat == 0 then
        local rows = MySQL.query.await('SELECT id, identifier, name, text, image, created FROM glam_chat WHERE deleted = 0 ORDER BY id DESC LIMIT ?', { GH.get('chatHistory') }) or {}
        for i = #rows, 1, -1 do
            local r = rows[i]
            GH.chat[#GH.chat + 1] = { id = r.id, author = r.identifier, name = r.name, text = r.text, image = r.image, created = r.created }
        end
    end
    return GH.chat
end

local function chatOut(m)
    local who = personOf(m.author, m.name)
    return { id = m.id, pub = who.pub, name = m.name, picture = who.picture, verified = who.verified, text = m.text, image = m.image, created = m.created }
end

function GH.chatList(src)
    local out = {}
    local me = GH.idOf(src)
    for _, m in ipairs(GH.chatHistory()) do
        if m.author == me or not GH.isBlocked(me, m.author) then out[#out + 1] = chatOut(m) end
    end
    return out
end

function GH.chatSend(src, text, image)
    if not enabled('chatEnabled') then return false, L('err.disabled') end
    local p = GH.players[src]
    if not p then return false, L('err.notloaded') end
    if GH.isMuted(p.id) then return false, L('err.muted') end
    if not GH.rate(src, 'chat', GH.get('chatCooldown')) then return false, L('err.slowdown') end
    local ok, clean, img = checkText(text, image, GH.get('chatMaxLength'))
    if not ok then return false, clean end
    local id = MySQL.insert.await('INSERT INTO glam_chat (identifier, name, text, image, created) VALUES (?,?,?,?,?)', { p.id, p.name, clean, img, now() })
    local m = { id = id, author = p.id, name = p.name, text = clean, image = img, created = now() }
    local list = GH.chatHistory()
    list[#list + 1] = m
    while #list > GH.get('chatHistory') do table.remove(list, 1) end
    local out = chatOut(m)
    for s, pl in pairs(GH.players) do
        if GH.open[s] and (pl.id == p.id or not GH.isBlocked(pl.id, p.id)) then TriggerClientEvent('glam:chat', s, out) end
    end
    GH.taskProgress(src, 'chat', 1)
    GH.log('chat', ('%s: %s'):format(p.name, clean), src)
    return true
end

function GH.chatDelete(src, id)
    id = tonumber(id)
    local p = GH.players[src]
    if not p or not id then return false, L('err.badvalue') end
    local row = MySQL.single.await('SELECT identifier FROM glam_chat WHERE id = ?', { id })
    if not row then return false, L('err.gone') end
    if row.identifier ~= p.id and not GH.isStaff(src) then return false, L('err.noperm') end
    MySQL.update('UPDATE glam_chat SET deleted = 1 WHERE id = ?', { id })
    local list = GH.chatHistory()
    for i = #list, 1, -1 do if list[i].id == id then table.remove(list, i) end end
    for s in pairs(GH.open) do TriggerClientEvent('glam:chatDeleted', s, id) end
    if row.identifier ~= p.id then GH.log('staff', ('%s deleted a chat message'):format(p.name), src) end
    return true
end

-- ================================================================ moderation

function GH.mute(src, pub, minutes)
    if not GH.isStaff(src) then return false, L('err.noperm') end
    local identifier = GH.fromPub(pub)
    minutes = math.floor(tonumber(minutes) or 0)
    if not identifier or minutes < 1 or minutes > 60 * 24 * 365 then return false, L('err.badvalue') end
    local until_ts = now() + minutes * 60
    GH.mutes[identifier] = until_ts
    MySQL.update('REPLACE INTO glam_mutes (identifier, until_ts, by_name) VALUES (?,?,?)', { identifier, until_ts, GH.players[src] and GH.players[src].name or 'console' })
    local target = GH.bySrc[identifier]
    if target then GH.notify(target, L('note.muted'), 'warn') end
    GH.log('staff', ('%s muted %s for %d minutes'):format(GH.players[src] and GH.players[src].name or 'console', pub, minutes), src)
    Hooks.onStaffAction(src, 'mute', identifier)
    return true
end

function GH.unmute(src, pub)
    if not GH.isStaff(src) then return false, L('err.noperm') end
    local identifier = GH.fromPub(pub)
    if not identifier then return false, L('err.gone') end
    GH.mutes[identifier] = nil
    MySQL.update('DELETE FROM glam_mutes WHERE identifier = ?', { identifier })
    GH.log('staff', ('%s unmuted %s'):format(GH.players[src] and GH.players[src].name or 'console', pub), src)
    Hooks.onStaffAction(src, 'unmute', identifier)
    return true
end

-- ================================================================ friends

function GH.friendsView(src)
    local me = GH.idOf(src)
    local rows = MySQL.query.await('SELECT a, b, status FROM glam_friends WHERE a = ? OR b = ?', { me, me }) or {}
    local ids, kind = {}, {}
    for _, r in ipairs(rows) do
        local other = r.a == me and r.b or r.a
        ids[#ids + 1] = other
        kind[other] = r.status == 'accepted' and 'friend' or (r.a == me and 'out' or 'in')
    end
    local blockedRows = MySQL.query.await('SELECT blocked FROM glam_blocks WHERE identifier = ?', { me }) or {}
    for _, r in ipairs(blockedRows) do ids[#ids + 1] = r.blocked kind[r.blocked] = 'blocked' end
    local people = peopleByIds(ids)
    local out = { friends = {}, incoming = {}, outgoing = {}, blocked = {} }
    for id, k in pairs(kind) do
        local p = people[id]
        if p then
            local bucket = k == 'friend' and out.friends or k == 'in' and out.incoming or k == 'out' and out.outgoing or out.blocked
            bucket[#bucket + 1] = p
        end
    end
    for _, list in pairs(out) do table.sort(list, function(a, b) return a.name:lower() < b.name:lower() end) end
    return out
end

local function candidate(me, identifier, name)
    local p = personOf(identifier, name)
    p.relation = relation(me, identifier)
    return p
end

function GH.friendSearch(src, q)
    local me = GH.idOf(src)
    q = GH.trim(tostring(q or ''))
    if #q < 1 then return {} end
    local out, seen = {}, {}
    local num = tonumber(q)
    if num and GH.players[num] and num ~= src then
        local pl = GH.players[num]
        if not GH.isBlocked(me, pl.id) then out[#out + 1] = candidate(me, pl.id, pl.name) seen[pl.id] = true end
    end
    local rows = MySQL.query.await("SELECT identifier, name FROM glam_players WHERE name LIKE ? AND identifier <> ? LIMIT 12", { '%' .. q:gsub('[%%_]', '') .. '%', me }) or {}
    for _, r in ipairs(rows) do
        if not seen[r.identifier] and not GH.isBlocked(me, r.identifier) and GH.pubOf(r.identifier) then
            out[#out + 1] = candidate(me, r.identifier, r.name)
        end
    end
    for _, p in ipairs(out) do p.src = nil end
    return out
end

function GH.friendNearby(src)
    local me = GH.idOf(src)
    local out = {}
    for s, pl in pairs(GH.players) do
        if s ~= src and GH.distance(src, s) <= 30.0 and not GH.isBlocked(me, pl.id) then out[#out + 1] = candidate(me, pl.id, pl.name) end
    end
    return out
end

function GH.friendRequest(src, pub)
    if not enabled('friendsEnabled') then return false, L('err.disabled') end
    local me, other = GH.idOf(src), GH.fromPub(pub)
    if not other or other == me then return false, L('err.badvalue') end
    if GH.isBlocked(me, other) then return false, L('err.blockedplayer') end
    local rel = relation(me, other)
    if rel ~= 'none' then return false, L('err.alreadyfriends') end
    if not GH.rate(src, 'friendreq', 1000) then return false, L('err.slowdown') end
    MySQL.insert.await("INSERT INTO glam_friends (a, b, status, created) VALUES (?,?, 'pending', ?)", { me, other, now() })
    GH.notif(other, 'friend', L('note.friendreq', GH.players[src].name), { pub = GH.pubOf(me) })
    return true
end

function GH.friendAnswer(src, pub, accept)
    local me, other = GH.idOf(src), GH.fromPub(pub)
    if not other then return false, L('err.gone') end
    local row = MySQL.single.await("SELECT 1 AS x FROM glam_friends WHERE a = ? AND b = ? AND status = 'pending'", { other, me })
    if not row then return false, L('err.gone') end
    if accept then
        MySQL.update("UPDATE glam_friends SET status = 'accepted' WHERE a = ? AND b = ?", { other, me })
        GH.notif(other, 'friend', L('note.friendok', GH.players[src].name), { pub = GH.pubOf(me) })
    else
        MySQL.update('DELETE FROM glam_friends WHERE a = ? AND b = ?', { other, me })
    end
    return true
end

function GH.friendRemove(src, pub)
    local me, other = GH.idOf(src), GH.fromPub(pub)
    if not other then return false, L('err.gone') end
    MySQL.update('DELETE FROM glam_friends WHERE (a = ? AND b = ?) OR (a = ? AND b = ?)', { me, other, other, me })
    return true
end

function GH.block(src, pub, on)
    local me, other = GH.idOf(src), GH.fromPub(pub)
    if not other or other == me then return false, L('err.badvalue') end
    if on then
        MySQL.update('DELETE FROM glam_friends WHERE (a = ? AND b = ?) OR (a = ? AND b = ?)', { me, other, other, me })
        MySQL.update('INSERT IGNORE INTO glam_blocks (identifier, blocked) VALUES (?,?)', { me, other })
    else
        MySQL.update('DELETE FROM glam_blocks WHERE identifier = ? AND blocked = ?', { me, other })
    end
    return true
end

-- ============================================================ private messages

local function pushDm(receiver, msg)
    local s = GH.bySrc[receiver]
    if s then TriggerClientEvent('glam:dm', s, msg) end
end

function GH.dmList(src)
    local me = GH.idOf(src)
    local rows = MySQL.query.await(
        [[SELECT CASE WHEN sender = ? THEN receiver ELSE sender END AS partner, MAX(id) AS last_id,
          SUM(CASE WHEN receiver = ? AND seen = 0 THEN 1 ELSE 0 END) AS unread
          FROM glam_messages WHERE sender = ? OR receiver = ? GROUP BY partner ORDER BY last_id DESC LIMIT 40]], { me, me, me, me }) or {}
    local ids = {}
    for _, r in ipairs(rows) do ids[#ids + 1] = r.partner end
    local people = peopleByIds(ids)
    local out = {}
    for _, r in ipairs(rows) do
        local p = people[r.partner]
        if p and not GH.isBlocked(me, r.partner) then
            local m = MySQL.single.await('SELECT text, image, created, sender FROM glam_messages WHERE id = ?', { r.last_id })
            p.last = m and { text = m.text, image = m.image ~= '', created = m.created, mine = m.sender == me } or nil
            p.unread = tonumber(r.unread) or 0
            out[#out + 1] = p
        end
    end
    return out
end

function GH.dmThread(src, pub)
    local me, other = GH.idOf(src), GH.fromPub(pub)
    if not other or GH.isBlocked(me, other) then return nil end
    local rows = MySQL.query.await(
        'SELECT id, sender, text, image, created FROM glam_messages WHERE (sender = ? AND receiver = ?) OR (sender = ? AND receiver = ?) ORDER BY id DESC LIMIT 60',
        { me, other, other, me }) or {}
    MySQL.update('UPDATE glam_messages SET seen = 1 WHERE sender = ? AND receiver = ? AND seen = 0', { other, me })
    local list = {}
    for i = #rows, 1, -1 do local r = rows[i] list[#list + 1] = { id = r.id, mine = r.sender == me, text = r.text, image = r.image, created = r.created } end
    local pd = profileRow(other)
    return { person = personOf(other, pd and pd.name), messages = list }
end

function GH.dmSend(src, pub, text, image)
    if not enabled('friendsEnabled') then return false, L('err.disabled') end
    local p = GH.players[src]
    local other = GH.fromPub(pub)
    if not p or not other or other == p.id then return false, L('err.badvalue') end
    if GH.isMuted(p.id) then return false, L('err.muted') end
    if GH.isBlocked(p.id, other) then return false, L('err.blockedplayer') end
    local target = profileRow(other)
    if not target then return false, L('err.gone') end
    local rule = target.profile.privMsg or 'everyone'
    if rule == 'nobody' or (rule == 'friends' and not GH.areFriends(p.id, other)) then return false, L('err.privacy') end
    if not GH.rate(src, 'dm', GH.get('chatCooldown')) then return false, L('err.slowdown') end
    local ok, clean, img = checkText(text, image, GH.get('chatMaxLength'))
    if not ok then return false, clean end
    local t = now()
    local id = MySQL.insert.await('INSERT INTO glam_messages (sender, receiver, text, image, created) VALUES (?,?,?,?,?)', { p.id, other, clean, img, t })
    pushDm(other, { kind = 'dm', pub = GH.pubOf(p.id), name = p.name, picture = personOf(p.id).picture, text = clean, image = img ~= '', created = t, id = id })
    return true, { id = id, mine = true, text = clean, image = img, created = t }
end

-- ============================================================ group chats

local function inGroup(identifier, gid)
    return MySQL.scalar.await('SELECT 1 FROM glam_group_members WHERE group_id = ? AND identifier = ?', { gid, identifier }) ~= nil
end

local function groupMembers(gid)
    local rows = MySQL.query.await('SELECT identifier, name FROM glam_group_members WHERE group_id = ?', { gid }) or {}
    return rows
end

function GH.groupList(src)
    local me = GH.idOf(src)
    local rows = MySQL.query.await(
        [[SELECT g.id, g.name, g.owner, m.last_seen,
          (SELECT COUNT(*) FROM glam_group_members WHERE group_id = g.id) AS members,
          (SELECT COUNT(*) FROM glam_group_messages WHERE group_id = g.id AND created > m.last_seen AND identifier <> ?) AS unread,
          (SELECT text FROM glam_group_messages WHERE group_id = g.id ORDER BY id DESC LIMIT 1) AS last
          FROM glam_groups g JOIN glam_group_members m ON m.group_id = g.id AND m.identifier = ? ORDER BY g.id DESC]], { me, me }) or {}
    local out = {}
    for _, r in ipairs(rows) do out[#out + 1] = { id = r.id, name = r.name, members = tonumber(r.members), unread = tonumber(r.unread) or 0, last = r.last, owner = r.owner == me } end
    return out
end

function GH.groupCreate(src, name, pubs)
    if not enabled('groupsEnabled') then return false, L('err.disabled') end
    local p = GH.players[src]
    name = GH.trim(name or '')
    if not p or #name < 2 or #name > 30 or type(pubs) ~= 'table' then return false, L('err.badvalue') end
    local ok, clean = GH.filter(name)
    if not ok then return false, L('err.blocked') end
    if #pubs + 1 > GH.get('groupMax') then return false, L('err.groupfull', GH.get('groupMax')) end
    if not GH.rate(src, 'group', 2000) then return false, L('err.slowdown') end
    local members = {}
    for _, pub in ipairs(pubs) do
        local id = GH.fromPub(pub)
        if not id or id == p.id or not GH.areFriends(p.id, id) then return false, L('err.notfriend') end
        members[#members + 1] = id
    end
    local gid = MySQL.insert.await('INSERT INTO glam_groups (name, owner, created) VALUES (?,?,?)', { clean, p.id, now() })
    MySQL.insert.await('INSERT INTO glam_group_members (group_id, identifier, name, last_seen) VALUES (?,?,?,?)', { gid, p.id, p.name, now() })
    for _, id in ipairs(members) do
        local pd = profileRow(id)
        MySQL.insert.await('INSERT INTO glam_group_members (group_id, identifier, name, last_seen) VALUES (?,?,?,0)', { gid, id, pd and pd.name or '' })
        GH.notif(id, 'group', L('note.groupadded', p.name, clean))
    end
    return true, gid
end

function GH.groupThread(src, gid)
    local me = GH.idOf(src)
    gid = math.floor(tonumber(gid) or 0)
    if not inGroup(me, gid) then return nil end
    local g = MySQL.single.await('SELECT id, name, owner FROM glam_groups WHERE id = ?', { gid })
    if not g then return nil end
    local rows = MySQL.query.await('SELECT id, identifier, name, text, image, created FROM glam_group_messages WHERE group_id = ? ORDER BY id DESC LIMIT 60', { gid }) or {}
    MySQL.update('UPDATE glam_group_members SET last_seen = ? WHERE group_id = ? AND identifier = ?', { now(), gid, me })
    local list = {}
    for i = #rows, 1, -1 do
        local r = rows[i]
        if r.identifier == me or not GH.isBlocked(me, r.identifier) then
            list[#list + 1] = { id = r.id, mine = r.identifier == me, pub = GH.pubOf(r.identifier), name = r.name, text = r.text, image = r.image, created = r.created }
        end
    end
    local members = {}
    for _, m in ipairs(groupMembers(gid)) do members[#members + 1] = personOf(m.identifier, m.name) end
    return { id = g.id, name = g.name, owner = g.owner == me, members = members, messages = list }
end

function GH.groupSend(src, gid, text, image)
    if not enabled('groupsEnabled') then return false, L('err.disabled') end
    local p = GH.players[src]
    gid = math.floor(tonumber(gid) or 0)
    if not p or not inGroup(p.id, gid) then return false, L('err.gone') end
    if GH.isMuted(p.id) then return false, L('err.muted') end
    if not GH.rate(src, 'gmsg', GH.get('chatCooldown')) then return false, L('err.slowdown') end
    local ok, clean, img = checkText(text, image, GH.get('chatMaxLength'))
    if not ok then return false, clean end
    local t = now()
    local id = MySQL.insert.await('INSERT INTO glam_group_messages (group_id, identifier, name, text, image, created) VALUES (?,?,?,?,?,?)', { gid, p.id, p.name, clean, img, t })
    local g = MySQL.single.await('SELECT name FROM glam_groups WHERE id = ?', { gid })
    for _, m in ipairs(groupMembers(gid)) do
        if m.identifier ~= p.id and not GH.isBlocked(m.identifier, p.id) then
            local s = GH.bySrc[m.identifier]
            if s then TriggerClientEvent('glam:dm', s, { kind = 'group', gid = gid, group = g and g.name or '', pub = GH.pubOf(p.id), name = p.name, text = clean, image = img ~= '', created = t, id = id }) end
        end
    end
    return true, { id = id, mine = true, pub = GH.pubOf(p.id), name = p.name, text = clean, image = img, created = t }
end

function GH.groupAdd(src, gid, pub)
    local me = GH.idOf(src)
    gid = math.floor(tonumber(gid) or 0)
    local other = GH.fromPub(pub)
    if not inGroup(me, gid) or not other then return false, L('err.gone') end
    if inGroup(other, gid) then return false, L('err.alreadyin') end
    if not GH.areFriends(me, other) then return false, L('err.notfriend') end
    if #groupMembers(gid) >= GH.get('groupMax') then return false, L('err.groupfull', GH.get('groupMax')) end
    local pd = profileRow(other)
    MySQL.insert.await('INSERT INTO glam_group_members (group_id, identifier, name, last_seen) VALUES (?,?,?,0)', { gid, other, pd and pd.name or '' })
    local g = MySQL.single.await('SELECT name FROM glam_groups WHERE id = ?', { gid })
    GH.notif(other, 'group', L('note.groupadded', GH.players[src].name, g and g.name or ''))
    return true
end

function GH.groupLeave(src, gid)
    local me = GH.idOf(src)
    gid = math.floor(tonumber(gid) or 0)
    if not inGroup(me, gid) then return false, L('err.gone') end
    MySQL.update('DELETE FROM glam_group_members WHERE group_id = ? AND identifier = ?', { gid, me })
    local left = MySQL.scalar.await('SELECT COUNT(*) FROM glam_group_members WHERE group_id = ?', { gid })
    if (tonumber(left) or 0) == 0 then
        MySQL.update('DELETE FROM glam_groups WHERE id = ?', { gid })
        MySQL.update('DELETE FROM glam_group_messages WHERE group_id = ?', { gid })
    else
        local g = MySQL.single.await('SELECT owner FROM glam_groups WHERE id = ?', { gid })
        if g and g.owner == me then
            local first = MySQL.single.await('SELECT identifier FROM glam_group_members WHERE group_id = ? LIMIT 1', { gid })
            if first then MySQL.update('UPDATE glam_groups SET owner = ? WHERE id = ?', { first.identifier, gid }) end
        end
    end
    return true
end

-- ================================================================ gallery

local function photoRows(me, where, params, order, page)
    local per = 12
    local sql = ([[SELECT ph.id, ph.identifier, ph.name, ph.url, ph.description, ph.location, ph.created,
        (SELECT COUNT(*) FROM glam_photo_likes WHERE photo_id = ph.id) AS likes,
        (SELECT COUNT(*) FROM glam_photo_comments WHERE photo_id = ph.id AND deleted = 0) AS comments,
        (SELECT COUNT(*) FROM glam_photo_likes WHERE photo_id = ph.id AND identifier = ?) AS liked,
        (SELECT COUNT(*) FROM glam_photo_saves WHERE photo_id = ph.id AND identifier = ?) AS saved
        FROM glam_photos ph WHERE ph.deleted = 0 %s
        AND ph.identifier NOT IN (SELECT blocked FROM glam_blocks WHERE identifier = ?)
        AND ph.identifier NOT IN (SELECT identifier FROM glam_blocks WHERE blocked = ?)
        ORDER BY %s LIMIT %d OFFSET %d]]):format(where, order, per, (page - 1) * per)
    local args = { me, me }
    for _, v in ipairs(params) do args[#args + 1] = v end
    args[#args + 1] = me args[#args + 1] = me
    local rows = MySQL.query.await(sql, args) or {}
    local out = {}
    for _, r in ipairs(rows) do
        local person = personOf(r.identifier, r.name)
        out[#out + 1] = { id = r.id, pub = person.pub, name = r.name, picture = person.picture, verified = person.verified, url = r.url,
            description = r.description, location = r.location, created = r.created, likes = tonumber(r.likes), comments = tonumber(r.comments),
            liked = tonumber(r.liked) > 0, saved = tonumber(r.saved) > 0, mine = r.identifier == me }
    end
    return out, per
end

function GH.galleryList(src, tab, page)
    if not enabled('galleryEnabled') then return nil end
    local me = GH.idOf(src)
    page = math.max(1, math.floor(tonumber(page) or 1))
    local list
    if tab == 'popular' then list = photoRows(me, '', {}, 'likes DESC, ph.id DESC', page)
    elseif tab == 'saved' then list = photoRows(me, 'AND ph.id IN (SELECT photo_id FROM glam_photo_saves WHERE identifier = ?)', { me }, 'ph.id DESC', page)
    elseif tab == 'mine' then list = photoRows(me, 'AND ph.identifier = ?', { me }, 'ph.id DESC', page)
    else list = photoRows(me, '', {}, 'ph.id DESC', page) end
    return { list = list, page = page, more = #list >= 12 }
end

function GH.photoPost(src, d)
    if not enabled('galleryEnabled') then return false, L('err.disabled') end
    local pd = GH.pdOf(src)
    if not pd or type(d) ~= 'table' then return false, L('err.badvalue') end
    if GH.isMuted(pd.identifier) then return false, L('err.muted') end
    local ok, url = GH.validImage(d.url)
    if not ok or url == '' then return false, L('err.badimage') end
    local today = MySQL.scalar.await('SELECT COUNT(*) FROM glam_photos WHERE identifier = ? AND created >= ?', { pd.identifier, now() - 86400 }) or 0
    if tonumber(today) >= GH.get('galleryPerDay') then return false, L('err.galleryday', GH.get('galleryPerDay')) end
    local okd, desc = GH.filter(tostring(d.description or ''):sub(1, 300))
    local okl, loc = GH.filter(tostring(d.location or ''):sub(1, 100))
    if not okd or not okl then return false, L('err.blocked') end
    if not GH.rate(src, 'photo', 3000) then return false, L('err.slowdown') end
    local id = MySQL.insert.await('INSERT INTO glam_photos (identifier, name, url, description, location, created) VALUES (?,?,?,?,?,?)',
        { pd.identifier, pd.name, url, desc, loc, now() })
    pd.profile.posted = (pd.profile.posted or 0) + 1
    pd.dirty = true
    GH.taskProgress(src, 'post', 1)
    GH.log('gallery', ('%s posted photo #%d'):format(pd.name, id), src)
    Hooks.onPost(src, id)
    return true, id
end

function GH.photoLike(src, id)
    local me = GH.idOf(src)
    id = math.floor(tonumber(id) or 0)
    local ph = MySQL.single.await('SELECT identifier FROM glam_photos WHERE id = ? AND deleted = 0', { id })
    if not ph then return false, L('err.gone') end
    if GH.isBlocked(me, ph.identifier) then return false, L('err.blockedplayer') end
    local had = MySQL.scalar.await('SELECT 1 FROM glam_photo_likes WHERE photo_id = ? AND identifier = ?', { id, me })
    if had then MySQL.update('DELETE FROM glam_photo_likes WHERE photo_id = ? AND identifier = ?', { id, me })
    else
        MySQL.update('INSERT IGNORE INTO glam_photo_likes (photo_id, identifier) VALUES (?,?)', { id, me })
        if ph.identifier ~= me then GH.notif(ph.identifier, 'like', L('note.liked', GH.players[src].name), { photo = id }) end
    end
    return true, { liked = not had }
end

function GH.photoSave(src, id)
    local me = GH.idOf(src)
    id = math.floor(tonumber(id) or 0)
    local had = MySQL.scalar.await('SELECT 1 FROM glam_photo_saves WHERE photo_id = ? AND identifier = ?', { id, me })
    if had then MySQL.update('DELETE FROM glam_photo_saves WHERE photo_id = ? AND identifier = ?', { id, me })
    else MySQL.update('INSERT IGNORE INTO glam_photo_saves (photo_id, identifier) VALUES (?,?)', { id, me }) end
    return true, { saved = not had }
end

function GH.photoComments(src, id)
    local me = GH.idOf(src)
    id = math.floor(tonumber(id) or 0)
    local rows = MySQL.query.await('SELECT id, identifier, name, text, image, created FROM glam_photo_comments WHERE photo_id = ? AND deleted = 0 ORDER BY id LIMIT 100', { id }) or {}
    local out = {}
    for _, r in ipairs(rows) do
        if r.identifier == me or not GH.isBlocked(me, r.identifier) then
            local person = personOf(r.identifier, r.name)
            out[#out + 1] = { id = r.id, pub = person.pub, name = r.name, picture = person.picture, verified = person.verified, text = r.text, image = r.image, created = r.created, mine = r.identifier == me }
        end
    end
    return out
end

function GH.commentAdd(src, id, text, image)
    local p = GH.players[src]
    id = math.floor(tonumber(id) or 0)
    if not p then return false, L('err.notloaded') end
    if GH.isMuted(p.id) then return false, L('err.muted') end
    local ph = MySQL.single.await('SELECT identifier FROM glam_photos WHERE id = ? AND deleted = 0', { id })
    if not ph then return false, L('err.gone') end
    if GH.isBlocked(p.id, ph.identifier) then return false, L('err.blockedplayer') end
    if not GH.rate(src, 'comment', GH.get('chatCooldown')) then return false, L('err.slowdown') end
    local ok, clean, img = checkText(text, image, GH.get('commentMax'))
    if not ok then return false, clean end
    MySQL.insert.await('INSERT INTO glam_photo_comments (photo_id, identifier, name, text, image, created) VALUES (?,?,?,?,?,?)', { id, p.id, p.name, clean, img, now() })
    if ph.identifier ~= p.id then GH.notif(ph.identifier, 'comment', L('note.commented', p.name), { photo = id }) end
    return true
end

function GH.photoDelete(src, id)
    local me = GH.idOf(src)
    id = math.floor(tonumber(id) or 0)
    local ph = MySQL.single.await('SELECT identifier FROM glam_photos WHERE id = ?', { id })
    if not ph then return false, L('err.gone') end
    if ph.identifier ~= me and not GH.isStaff(src) then return false, L('err.noperm') end
    MySQL.update('UPDATE glam_photos SET deleted = 1 WHERE id = ?', { id })
    if ph.identifier ~= me then GH.log('staff', ('%s deleted photo #%d'):format(GH.players[src].name, id), src) Hooks.onStaffAction(src, 'deletePhoto', ph.identifier) end
    return true
end

function GH.commentDelete(src, id)
    local me = GH.idOf(src)
    id = math.floor(tonumber(id) or 0)
    local c = MySQL.single.await('SELECT identifier FROM glam_photo_comments WHERE id = ?', { id })
    if not c then return false, L('err.gone') end
    if c.identifier ~= me and not GH.isStaff(src) then return false, L('err.noperm') end
    MySQL.update('UPDATE glam_photo_comments SET deleted = 1 WHERE id = ?', { id })
    if c.identifier ~= me then GH.log('staff', ('%s deleted a comment'):format(GH.players[src].name), src) end
    return true
end

-- ================================================================== GIFs

local function gifList(pd, key) pd.settings[key] = pd.settings[key] or {} return pd.settings[key] end

function GH.gifSearch(src, tab, q)
    if not enabled('gifsEnabled') then return false, L('err.disabled') end
    local pd = GH.pdOf(src)
    if not pd then return false, L('err.notloaded') end
    if tab == 'favorites' then return true, { list = gifList(pd, 'gifFav') } end
    if tab == 'recent' then return true, { list = gifList(pd, 'gifRecent') } end
    local key = GH.secrets.gifKey
    if not key or key == '' then return false, L('err.nogifkey') end
    if not GH.rate(src, 'gif', 700) then return false, L('err.slowdown') end
    q = GH.trim(tostring(q or '')):sub(1, 60)
    local url
    if q ~= '' and tab == 'search' then
        url = ('https://api.giphy.com/v1/gifs/search?api_key=%s&q=%s&limit=24&rating=%s'):format(key, GH.urlEncode(q), GH.get('gifRating'))
    else
        url = ('https://api.giphy.com/v1/gifs/trending?api_key=%s&limit=24&rating=%s'):format(key, GH.get('gifRating'))
    end
    local res = GH.httpRequest(url, 'GET', '', {})
    if res.status ~= 200 then return false, L('err.gifdown') end
    local data = GH.jdec(res.body, {})
    local list = {}
    for _, g in ipairs(data.data or {}) do
        local imgs = g.images or {}
        local full = imgs.fixed_height and imgs.fixed_height.url
        local small = imgs.fixed_width_small and imgs.fixed_width_small.url or full
        if full then list[#list + 1] = { url = full:gsub('%?.*$', ''), preview = small:gsub('%?.*$', '') } end
    end
    return true, { list = list }
end

function GH.urlEncode(s)
    return (s:gsub('[^%w%-_%.~]', function(c) return ('%%%02X'):format(c:byte()) end))
end

function GH.gifMark(src, url, kind)
    local pd = GH.pdOf(src)
    local ok, clean = GH.validImage(url)
    if not pd or not ok or clean == '' then return false, L('err.badimage') end
    local key = kind == 'fav' and 'gifFav' or 'gifRecent'
    local list = gifList(pd, key)
    for i = #list, 1, -1 do if list[i].url == clean then table.remove(list, i) end end
    if kind == 'unfav' then
        pd.dirty = true
        return true
    end
    if kind == 'fav' or kind == 'recent' then
        table.insert(list, 1, { url = clean, preview = clean })
        while #list > 30 do table.remove(list) end
    end
    pd.dirty = true
    return true
end

-- ============================================================ notifications

function GH.notifsSeen(src)
    local me = GH.idOf(src)
    MySQL.update('UPDATE glam_notifs SET seen = 1 WHERE identifier = ?', { me })
    return true
end

function GH.unreadNotifs(identifier)
    return tonumber(MySQL.scalar.await('SELECT COUNT(*) FROM glam_notifs WHERE identifier = ? AND seen = 0', { identifier })) or 0
end

-- ================================================================= home

function GH.homeView(src)
    local pd = GH.pdOf(src)
    if not pd then return nil end
    local job = pd.job and GH.jobById(pd.job)
    local idx, lvl, nextLvl = GH.levelOf(pd.xp)
    local products = {}
    for _, p in ipairs(GH.get('products')) do
        local n = Bridge.itemCount(src, p.id)
        if n > 0 then products[#products + 1] = { id = p.id, label = p.label, count = n, price = p.price } end
    end
    local chat = {}
    if enabled('chatEnabled') then
        local list = GH.chatList(src)
        for i = math.max(1, #list - 2), #list do chat[#chat + 1] = list[i] end
    end
    return {
        name = pd.name, job = job and { id = job.id, label = job.label, bonus = job.bonus } or nil,
        level = idx, levelName = lvl.name, xp = math.floor(pd.xp), thisXp = lvl.xp, nextXp = nextLvl and nextLvl.xp or nil, boost = GH.saleBoost(pd),
        products = products, chat = chat, messages = enabled('friendsEnabled') and GH.dmList(src) or {}, online = GH.count(GH.players),
        unread = GH.unreadNotifs(pd.identifier), starter = GH.get('starterEnabled') and not pd.starter,
        crafting = pd.craftq and { product = pd.craftq.product, label = (GH.productById(pd.craftq.product) or {}).label or pd.craftq.product, finishAt = pd.craftq.finishAt, now = now() } or nil,
        streak = pd.streak,
    }
end
