-- Admin access, logging and everything behind /glamadmin

GH.roleCache = {}

local function httpRequest(url, method, body, headers)
    local p = promise.new()
    PerformHttpRequest(url, function(status, text) p:resolve({ status = status, body = text }) end, method, body or '', headers or {})
    return Citizen.Await(p)
end
GH.httpRequest = httpRequest

-- ---------------------------------------------------------------- access

local function discordRoles(src, allowFetch)
    local token, guild = GH.secrets.discordToken, GH.get('discordGuild')
    if not token or token == '' or not guild or guild == '' then return nil end
    local c = GH.roleCache[src]
    local now = GH.now()
    if c and c.exp > now then return c.roles end
    if not allowFetch then return c and c.roles or nil end
    local did = GetPlayerIdentifierByType(src, 'discord')
    if not did then return nil end
    did = did:gsub('discord:', '')
    local res = httpRequest(('https://discord.com/api/v10/guilds/%s/members/%s'):format(guild, did), 'GET', '',
        { Authorization = 'Bot ' .. token })
    local data = res.status == 200 and GH.jdec(res.body, nil) or nil
    local roles = data and data.roles or {}
    GH.roleCache[src] = { roles = roles, exp = now + 60 }
    return roles
end

function GH.hasDiscordRole(src, wanted, cachedOnly)
    if not wanted or #wanted == 0 then return false end
    local roles = discordRoles(src, not cachedOnly)
    if not roles then return false end
    for _, w in ipairs(wanted) do
        for _, r in ipairs(roles) do if tostring(r) == tostring(w) then return true end end
    end
    return false
end

-- each of the three permissions can come from a framework group, a Discord role or an ace
local function permission(src, ace, groupKey, roleKey, cachedOnly)
    if src == 0 then return true end
    if IsPlayerAceAllowed(src, ace) then return true end
    if Bridge.inGroup(src, GH.get(groupKey)) then return true end
    local roles = GH.get(roleKey)
    if roles and #roles > 0 and GH.hasDiscordRole(src, roles, cachedOnly) then return true end
    return false
end

function GH.isAdmin(src, cachedOnly) return permission(src, 'glam.admin', 'adminGroups', 'adminRoles', cachedOnly) end
function GH.isStaff(src, cachedOnly) return GH.isAdmin(src, cachedOnly) or permission(src, 'glam.staff', 'staffGroups', 'staffRoles', cachedOnly) end
function GH.isVerifier(src, cachedOnly) return GH.isAdmin(src, cachedOnly) or permission(src, 'glam.verify', 'verifierGroups', 'verifierRoles', cachedOnly) end

-- ------------------------------------------------------------------ logging

local logCount = 0
local categorySetting = {
    sale = 'logSales', craft = 'logCrafting', theft = 'logTheft', gallery = 'logGallery', chat = 'logChat',
    staff = 'logStaff', prize = 'logPrizes', settings = 'logAdminChanges',
}

function GH.log(category, message, actorSrc)
    local flag = categorySetting[category]
    if flag and not GH.get(flag) then return end
    local actor = ''
    if actorSrc and GH.players[actorSrc] then actor = GH.players[actorSrc].name end
    MySQL.insert('INSERT INTO glam_logs (category, message, actor, created) VALUES (?,?,?,?)',
        { category, tostring(message):sub(1, 500), actor, GH.now() })
    logCount = logCount + 1
    if logCount % 200 == 0 then
        MySQL.update('DELETE FROM glam_logs WHERE id < (SELECT m FROM (SELECT MAX(id) - 3000 AS m FROM glam_logs) t)')
    end

    local text = actor ~= '' and (actor .. ': ' .. message) or message
    local hook, key = GH.secrets.logWebhook, GH.secrets.fivemanageKey
    if GH.get('logToWebhook') and hook and hook ~= '' then
        PerformHttpRequest(hook, function() end, 'POST', json.encode({
            username = GH.get('hubName'),
            embeds = { { title = category, description = text:sub(1, 1900), color = 15551641, timestamp = os.date('!%Y-%m-%dT%H:%M:%SZ') } },
        }), { ['Content-Type'] = 'application/json' })
    end
    if GH.get('logToFivemanage') and key and key ~= '' then
        PerformHttpRequest('https://api.fivemanage.com/api/logs', function() end, 'POST', json.encode({
            level = 'info', message = text, metadata = { category = category, resource = GetCurrentResourceName() },
        }), { ['Content-Type'] = 'application/json', Authorization = key })
    end
end

-- ------------------------------------------------------------------- status

-- item names used in the settings that the inventory does not know yet
function GH.missingItems()
    local missing = {}
    if not Bridge.hasInventory() then return missing end
    for name in pairs(Schema.itemNames(GH.S)) do
        if Bridge.itemExists(name) == false then missing[#missing + 1] = name end
    end
    table.sort(missing)
    return missing
end

function GH.status()
    local warnings = {}
    if not Bridge.hasMoney() then warnings[#warnings + 1] = L('warn.nomoney') end
    if not Bridge.hasInventory() then warnings[#warnings + 1] = L('warn.noinventory') end
    if GH.get('logToWebhook') and (GH.secrets.logWebhook or '') == '' then warnings[#warnings + 1] = L('warn.nowebhook') end
    if GH.get('logToFivemanage') and (GH.secrets.fivemanageKey or '') == '' then warnings[#warnings + 1] = L('warn.nofivemanage') end
    local usesRoles = #(GH.get('adminRoles') or {}) > 0 or #(GH.get('staffRoles') or {}) > 0 or #(GH.get('verifierRoles') or {}) > 0
        or #(GH.get('accessRoles') or {}) > 0
    if usesRoles and ((GH.secrets.discordToken or '') == '' or GH.get('discordGuild') == '') then warnings[#warnings + 1] = L('warn.nodiscord') end
    if GH.get('gifsEnabled') and (GH.secrets.gifKey or '') == '' then warnings[#warnings + 1] = L('warn.nogifkey') end
    if GH.get('interact') == 'target' and GetResourceState('ox_target') ~= 'started' and GetResourceState('qb-target') ~= 'started' then
        warnings[#warnings + 1] = L('warn.notarget')
    end
    if #(GH.get('blockedWords') or {}) == 0 then warnings[#warnings + 1] = L('warn.noblocked') end
    if #GH.get('hubPeds') == 0 and GH.get('accessMode') ~= 'everyone' then warnings[#warnings + 1] = L('warn.nopeds') end
    local missing = GH.missingItems()
    if #missing > 0 then warnings[#warnings + 1] = L('warn.items', #missing, table.concat(missing, ', ', 1, math.min(#missing, 6))) end
    if GH.latestVersion and GH.latestVersion ~= GH.version then warnings[#warnings + 1] = L('warn.update', GH.latestVersion) end
    return {
        framework = Bridge.framework, inventory = Bridge.inventory, version = GH.version, warnings = warnings, missing = missing,
        online = GH.count(GH.players),
    }
end

function GH.checkVersion()
    GH.version = GetResourceMetadata(GetCurrentResourceName(), 'version', 0) or '1.0.0'
    if not Config.VersionUrl or Config.VersionUrl == '' then return end
    PerformHttpRequest(Config.VersionUrl, function(status, body)
        if status == 200 and body then
            local v = body:match('[%d%.]+')
            if v then GH.latestVersion = v end
        end
    end, 'GET')
end

-- ------------------------------------------------------------------ the panel

function GH.adminPayload()
    local values, secretSet = {}, {}
    for _, f in ipairs(Schema.fields) do
        if f.secret then
            secretSet[f.k] = (GH.secrets[f.k] or '') ~= ''
            values[f.k] = ''
        else
            values[f.k] = GH.S[f.k]
        end
    end
    local fields = {}
    for _, f in ipairs(Schema.fields) do
        fields[#fields + 1] = { k = f.k, p = f.p, t = f.t, d = f.d, l = f.l, h = f.h, min = f.min, max = f.max, opts = f.opts,
            secret = f.secret, sub = f.sub, item = f.item, restart = f.restart, place = f.place }
    end
    local items = {}
    for name in pairs(Schema.itemNames(GH.S)) do items[#items + 1] = name end
    table.sort(items)
    return { pages = Schema.pages, fields = fields, values = values, secretSet = secretSet, status = GH.status(), last = GH.last, items = items }
end

local function others(src, event, payload)
    for s in pairs(GH.panel) do
        if s ~= src and GH.players[s] then TriggerClientEvent(event, s, payload) end
    end
end

-- Every admin action goes through here so each one is checked and logged
GH.AdminActions = {
    open = function(src)
        GH.panel[src] = true
        return true, GH.adminPayload()
    end,

    close = function(src) GH.panel[src] = nil return true end,

    save = function(src, d)
        local ok, err, changed, diffs = GH.saveSettings(src, d.values, d.clear)
        if not ok then return false, err end
        if #changed > 0 then
            local who = GH.players[src] and GH.players[src].name or 'console'
            for _, x in ipairs(diffs) do GH.log('settings', ('%s changed %s: %s -> %s'):format(who, x.k, x.old, x.new), src) end
            others(src, 'glam:adminSaved', { by = who, keys = changed, payload = GH.adminPayload() })
        end
        return true, GH.adminPayload()
    end,

    history = function(src, d) return true, GH.history(type(d.key) == 'string' and d.key or nil, 40) end,

    logs = function(src, d)
        local page = math.max(1, math.floor(tonumber(d.page) or 1))
        local per = 20
        local rows = MySQL.query.await('SELECT category, message, actor, created FROM glam_logs ORDER BY id DESC LIMIT ? OFFSET ?',
            { per, (page - 1) * per }) or {}
        local total = MySQL.scalar.await('SELECT COUNT(*) FROM glam_logs') or 0
        return true, { rows = rows, page = page, per = per, total = total }
    end,

    players = function(src)
        local list = {}
        for s, p in pairs(GH.players) do
            local pd = GH.pd[p.id]
            list[#list + 1] = {
                src = s, id = p.id, pub = GH.pubOf(p.id), name = p.name, verified = pd and pd.profile.verified == true or false,
                muted = GH.isMuted(p.id), job = pd and pd.job or '', level = pd and GH.levelOf(pd.xp) or 1,
            }
        end
        table.sort(list, function(a, b) return a.name:lower() < b.name:lower() end)
        return true, list
    end,

    items = function(src) return true, { missing = GH.missingItems(), known = Bridge.hasInventory() } end,

    -- where the admin is standing (for "Use my position")
    here = function(src)
        local c = GH.coords(src)
        local ped = GetPlayerPed(src)
        if not c then return false, L('err.badvalue') end
        return true, { x = c.x, y = c.y, z = c.z, h = GetEntityHeading(ped) }
    end,

    test = function(src, d)
        local kind = d.kind
        local msg = L('admin.testmessage')
        if kind == 'webhook' then
            local hook = GH.secrets.logWebhook
            if not hook or hook == '' then return false, L('err.nowebhook') end
            local res = httpRequest(hook, 'POST', json.encode({ username = GH.get('hubName'), content = msg }), { ['Content-Type'] = 'application/json' })
            if res.status and res.status >= 200 and res.status < 300 then return true, { text = L('admin.testok') } end
            return false, L('admin.testfail', tostring(res.status))
        elseif kind == 'fivemanage' then
            local key = GH.secrets.fivemanageKey
            if not key or key == '' then return false, L('err.nofivemanage') end
            local res = httpRequest('https://api.fivemanage.com/api/logs', 'POST',
                json.encode({ level = 'info', message = msg, metadata = { category = 'test' } }),
                { ['Content-Type'] = 'application/json', Authorization = key })
            if res.status and res.status >= 200 and res.status < 300 then return true, { text = L('admin.testok') } end
            return false, L('admin.testfail', tostring(res.status))
        elseif kind == 'gif' then
            local key = GH.secrets.gifKey
            if not key or key == '' then return false, L('err.nogifkey') end
            local res = httpRequest(('https://api.giphy.com/v1/gifs/trending?api_key=%s&limit=1'):format(key), 'GET', '', {})
            if res.status == 200 then return true, { text = L('admin.testok') } end
            return false, L('admin.testfail', tostring(res.status))
        end
        return false, L('err.badvalue')
    end,
}
