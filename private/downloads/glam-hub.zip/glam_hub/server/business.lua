-- The beauty business: jobs, shop, beauty tables, crafting, selling, thieves and the starter pack

-- =========================================================== beauty tables

function GH.loadTables()
    GH.tables = {}
    for _, r in ipairs(MySQL.query.await('SELECT * FROM glam_tables') or {}) do
        GH.tables[r.identifier] = { x = r.x, y = r.y, z = r.z, h = r.h }
    end
end

function GH.pushTables(target)
    local function listFor(identifier)
        local list = {}
        for owner, t in pairs(GH.tables) do
            list[#list + 1] = { x = t.x, y = t.y, z = t.z, h = t.h, mine = owner == identifier }
        end
        return list
    end
    if target then
        TriggerClientEvent('glam:tables', target, listFor(GH.idOf(target)))
    else
        for src, p in pairs(GH.players) do TriggerClientEvent('glam:tables', src, listFor(p.id)) end
    end
end

function GH.placeTable(src, d)
    local p = GH.players[src]
    if not p or type(d) ~= 'table' then return false, L('err.badvalue') end
    if GH.tables[p.id] then return false, L('err.hastable') end
    local x, y, z, h = tonumber(d.x), tonumber(d.y), tonumber(d.z), tonumber(d.h) or 0
    if not x or not y or not z then return false, L('err.badvalue') end
    local c = GH.coords(src)
    if not c or #(c - vector3(x, y, z)) > 12.0 then return false, L('err.toofar') end
    if not GH.rate(src, 'table', 1500) then return false, L('err.slowdown') end
    if not Bridge.removeItem(src, GH.get('tableItem'), 1) then return false, L('err.notable') end
    GH.tables[p.id] = { x = x, y = y, z = z, h = h }
    DB.saveTable(p.id, GH.tables[p.id])
    GH.pushTables()
    GH.notify(src, L('note.tableplaced'), 'success')
    return true
end

function GH.pickupTable(src)
    local p = GH.players[src]
    local t = p and GH.tables[p.id]
    if not t then return false, L('err.notable2') end
    local c = GH.coords(src)
    if not c or #(c - vector3(t.x, t.y, t.z)) > GH.get('tableDistance') + 3.0 then return false, L('err.toofar') end
    local item = GH.get('tableItem')
    if not Bridge.canCarry(src, item, 1) then return false, L('err.full') end
    if not Bridge.addItem(src, item, 1) then return false, L('err.full') end
    GH.tables[p.id] = nil
    DB.deleteTable(p.id)
    GH.pushTables()
    return true
end

local function nearTable(src)
    local p = GH.players[src]
    local t = p and GH.tables[p.id]
    if not t then return false, L('err.notable2') end
    local c = GH.coords(src)
    if not c or #(c - vector3(t.x, t.y, t.z)) > GH.get('tableDistance') + 2.0 then return false, L('err.fartable') end
    return true
end

-- ================================================================== jobs

local function jobView(pd, j)
    local labels = {}
    for _, id in ipairs(j.products) do
        local pr = GH.productById(id)
        if pr then labels[#labels + 1] = pr.label end
    end
    local lvl = GH.levelOf(pd.xp)
    return { id = j.id, label = j.label, salary = j.salary, level = j.level, bonus = j.bonus, products = labels,
             canTake = lvl >= j.level, current = pd.job == j.id }
end

function GH.jobsView(src)
    local pd = GH.pdOf(src)
    if not pd then return nil end
    local list = {}
    for _, j in ipairs(GH.get('jobs')) do list[#list + 1] = jobView(pd, j) end
    return { jobs = list, current = pd.job, salaryMinutes = GH.get('salaryMinutes'), salaryEnabled = GH.get('salaryEnabled') }
end

function GH.setJob(src, id)
    local pd = GH.pdOf(src)
    if not pd then return false, L('err.notloaded') end
    if id == nil or id == '' then
        pd.job = nil pd.dirty = true
        return true
    end
    local j = GH.jobById(id)
    if not j then return false, L('err.gone') end
    if GH.levelOf(pd.xp) < j.level then return false, L('err.joblevel', j.level) end
    pd.job = j.id
    pd.nextPay = GH.now() + GH.get('salaryMinutes') * 60
    pd.dirty = true
    GH.notify(src, L('note.jobset', j.label), 'success')
    return true
end

function GH.salaryTick()
    if not GH.get('salaryEnabled') then return end
    local now = GH.now()
    for src, p in pairs(GH.players) do
        local pd = GH.pd[p.id]
        if pd and pd.job then
            local j = GH.jobById(pd.job)
            if j then
                pd.nextPay = pd.nextPay or (now + GH.get('salaryMinutes') * 60)
                if now >= pd.nextPay then
                    pd.nextPay = now + GH.get('salaryMinutes') * 60
                    if j.salary > 0 and Bridge.addMoney(src, GH.get('payAccount'), j.salary, 'glam salary') then
                        GH.notify(src, L('note.salary', GH.money(j.salary)), 'success')
                    end
                end
            end
        end
    end
end

-- can this player make this product right now?
function GH.unlocked(pd, product)
    if not pd.job then return false, L('err.needjob') end
    local j = GH.jobById(pd.job)
    if not j then return false, L('err.needjob') end
    local ok = false
    for _, id in ipairs(j.products) do if id == product.id then ok = true end end
    if not ok then return false, L('err.jobnoproduct') end
    if GH.levelOf(pd.xp) < product.level then return false, L('err.productlevel', product.level) end
    return true
end

-- ================================================================= shop

function GH.shopView(src)
    local pd = GH.pdOf(src)
    if not pd then return nil end
    local items = {}
    for _, i in ipairs(GH.get('ingredients')) do items[#items + 1] = { item = i.item, label = i.label, price = i.price, owned = Bridge.itemCount(src, i.item) } end
    local quick = {}
    if GH.get('quickSellEnabled') then
        for _, p in ipairs(GH.get('products')) do
            local n = Bridge.itemCount(src, p.id)
            if n > 0 then quick[#quick + 1] = { item = p.id, label = p.label, price = math.floor(p.price * GH.get('quickSellRate')), owned = n } end
        end
    end
    return { items = items, quick = quick, table = { item = GH.get('tableItem'), price = GH.get('tablePrice'), owned = Bridge.itemCount(src, GH.get('tableItem')), placed = GH.tables[pd.identifier] ~= nil },
             quickEnabled = GH.get('quickSellEnabled'), money = Bridge.hasMoney() and Bridge.getMoney(src, GH.get('shopAccount')) or 0 }
end

function GH.shopBuy(src, cart)
    if not Bridge.hasMoney() or not Bridge.hasInventory() then return false, L('err.nomoneysystem') end
    local pd = GH.pdOf(src)
    if not pd or type(cart) ~= 'table' then return false, L('err.badvalue') end
    if not GH.rate(src, 'buy', 800) then return false, L('err.slowdown') end
    local lines, total = {}, 0
    local maxQty = GH.get('maxCartItems')
    for item, qty in pairs(cart) do
        qty = math.floor(tonumber(qty) or 0)
        if qty > 0 then
            if qty > maxQty then return false, L('err.badvalue') end
            local price
            if item == GH.get('tableItem') then price = GH.get('tablePrice')
            else for _, i in ipairs(GH.get('ingredients')) do if i.item == item then price = i.price end end end
            if not price then return false, L('err.badvalue') end
            lines[#lines + 1] = { item = item, qty = qty, price = price }
            total = total + price * qty
        end
    end
    if #lines == 0 then return false, L('err.emptycart') end
    for _, l in ipairs(lines) do
        if not Bridge.canCarry(src, l.item, l.qty) then return false, L('err.full') end
    end
    if not Bridge.removeMoney(src, GH.get('shopAccount'), total, 'glam shop') then return false, L('err.nomoney') end
    for _, l in ipairs(lines) do
        if not Bridge.addItem(src, l.item, l.qty) then
            Bridge.addMoney(src, GH.get('shopAccount'), l.price * l.qty, 'glam refund')
            GH.notify(src, L('err.full'), 'error')
        end
    end
    GH.notify(src, L('note.bought', GH.money(total)), 'success')
    return true
end

function GH.quickSell(src, productId, qty)
    if not GH.get('quickSellEnabled') then return false, L('err.disabled') end
    local pd = GH.pdOf(src)
    local product = GH.productById(productId)
    qty = math.floor(tonumber(qty) or 0)
    if not pd or not product or qty < 1 or qty > 500 then return false, L('err.badvalue') end
    if not GH.rate(src, 'quick', 600) then return false, L('err.slowdown') end
    if not Bridge.removeItem(src, product.id, qty) then return false, L('err.noproduct') end
    local pay = math.floor(product.price * GH.get('quickSellRate')) * qty
    Bridge.addMoney(src, GH.get('payAccount'), pay, 'glam quick sell')
    GH.recordSale(src, pd, product, qty, pay, 0.5)
    GH.notify(src, L('note.sold', qty, product.label, GH.money(pay)), 'success')
    return true
end

-- stats, XP, tasks and logs for any sale
function GH.recordSale(src, pd, product, qty, pay, xpShare)
    pd.sold = pd.sold + qty
    pd.earned = pd.earned + pay
    local day = GH.dayOf(pd)
    day.sold = day.sold + qty
    day.earned = day.earned + pay
    pd.dirty = true
    GH.addXp(src, product.xp * qty * (xpShare or 1), 'saleXpMultiplier')
    GH.taskProgress(src, 'sell', qty)
    GH.taskProgress(src, 'earn', pay)
    GH.log('sale', ('%s sold %dx %s for %s'):format(pd.name, qty, product.label, GH.money(pay)), src)
    Hooks.onSale(src, product.id, qty, pay, false)
end

-- ============================================================== crafting

function GH.recipesView(src)
    local pd = GH.pdOf(src)
    if not pd then return nil end
    local list = {}
    for _, p in ipairs(GH.get('products')) do
        local ok, why = GH.unlocked(pd, p)
        local ingr, can = {}, 999
        for _, s in ipairs(p.ingredients) do
            local item, need = SplitItem(s)
            local have = Bridge.itemCount(src, item)
            local label = item
            for _, i in ipairs(GH.get('ingredients')) do if i.item == item then label = i.label end end
            ingr[#ingr + 1] = { item = item, label = label, need = need, have = have }
            can = math.min(can, math.floor(have / math.max(need, 1)))
        end
        if #ingr == 0 then can = 0 end
        list[#list + 1] = { id = p.id, label = p.label, price = p.price, time = p.time, level = p.level, xp = p.xp,
            animDict = p.animDict, animClip = p.animClip, prop = p.prop,
            unlocked = ok, reason = why, ingredients = ingr, canMake = ok and math.min(can, GH.get('maxCraft')) or 0 }
    end
    local held = {}
    for item, n in pairs(pd.held or {}) do
        local p = GH.productById(item)
        if p and n > 0 then held[#held + 1] = { id = item, label = p.label, count = n } end
    end
    local q = pd.craftq
    return {
        list = list, held = held, maxCraft = GH.get('maxCraft'), background = GH.get('backgroundCraft'),
        queue = q and { product = q.product, qty = q.qty, finishAt = q.finishAt, startAt = q.startAt, label = (GH.productById(q.product) or {}).label or q.product } or nil,
        now = GH.now(), hasTable = GH.tables[pd.identifier] ~= nil,
    }
end

function GH.craft(src, productId, qty, background)
    local pd = GH.pdOf(src)
    local product = GH.productById(productId)
    qty = math.floor(tonumber(qty) or 0)
    if not pd or not product then return false, L('err.badvalue') end
    if qty < 1 or qty > GH.get('maxCraft') then return false, L('err.badvalue') end
    local near, why = nearTable(src)
    if not near then return false, why end
    if pd.craftq then return false, L('err.crafting') end
    local ok, reason = GH.unlocked(pd, product)
    if not ok then return false, reason end
    if not GH.rate(src, 'craft', 700) then return false, L('err.slowdown') end
    -- ingredients, all or nothing
    local needs = {}
    for _, s in ipairs(product.ingredients) do
        local item, need = SplitItem(s)
        needs[#needs + 1] = { item = item, count = need * qty }
        if Bridge.itemCount(src, item) < need * qty then return false, L('err.noingredients') end
    end
    local taken = {}
    for _, n in ipairs(needs) do
        if Bridge.removeItem(src, n.item, n.count) then taken[#taken + 1] = n
        else
            for _, t in ipairs(taken) do Bridge.addItem(src, t.item, t.count) end
            return false, L('err.noingredients')
        end
    end
    local now = GH.now()
    local bg = background == true and GH.get('backgroundCraft')
    pd.craftq = { product = product.id, qty = qty, startAt = now, finishAt = now + product.time * qty, bg = bg, needs = needs }
    pd.dirty = true
    return true, { finishAt = pd.craftq.finishAt, time = product.time * qty, bg = bg, now = now }
end

function GH.craftCancel(src)
    local pd = GH.pdOf(src)
    if not pd or not pd.craftq then return false, L('err.nocraft') end
    for _, n in ipairs(pd.craftq.needs or {}) do GH.giveItemOrKeep(src, pd.identifier, n.item, n.count) end
    pd.craftq = nil
    pd.dirty = true
    return true
end

local function deliver(src, pd)
    local q = pd.craftq
    local product = q and GH.productById(q.product)
    pd.craftq = nil
    pd.dirty = true
    if not product then return end
    if Bridge.canCarry(src, product.id, q.qty) and Bridge.addItem(src, product.id, q.qty) then
        GH.notify(src, L('note.crafted', q.qty, product.label), 'success')
    else
        pd.held[product.id] = (pd.held[product.id] or 0) + q.qty
        GH.notify(src, L('note.craftheld', q.qty, product.label), 'warn')
    end
    pd.crafted = pd.crafted + q.qty
    GH.dayOf(pd).crafted = GH.dayOf(pd).crafted + q.qty
    GH.addXp(src, product.xp * q.qty, 'craftXpMultiplier')
    GH.taskProgress(src, 'craft', q.qty)
    GH.log('craft', ('%s crafted %dx %s'):format(pd.name, q.qty, product.label), src)
    Hooks.onCraft(src, product.id, q.qty)
    TriggerClientEvent('glam:craftDone', src, { product = product.id, qty = q.qty })
end

function GH.craftTick()
    local now = GH.now()
    for src, p in pairs(GH.players) do
        local pd = GH.pd[p.id]
        if pd and pd.craftq and now >= pd.craftq.finishAt then deliver(src, pd) end
    end
end

function GH.claimHeld(src, productId)
    local pd = GH.pdOf(src)
    local n = pd and pd.held[productId]
    if not n or n < 1 then return false, L('err.gone') end
    local give = n
    while give > 0 and not Bridge.canCarry(src, productId, give) do give = give - 1 end
    if give < 1 then return false, L('err.full') end
    if not Bridge.addItem(src, productId, give) then return false, L('err.full') end
    pd.held[productId] = n - give > 0 and (n - give) or nil
    pd.dirty = true
    return true
end

-- ================================================================ selling

local function sellCheck(src)
    local pd = GH.pdOf(src)
    if not pd then return nil, L('err.notloaded') end
    local c = GH.coords(src)
    if not c then return nil, L('err.badvalue') end
    local blocked, name = GH.inNoSell(c)
    if blocked then return nil, L('err.nosellzone', name) end
    if GH.get('sellOnFoot') then
        local ped = GetPlayerPed(src)
        if GetVehiclePedIsIn(ped, false) ~= 0 then return nil, L('err.onfoot') end
    end
    return pd, c
end

local function ownedProducts(src)
    local list = {}
    for _, p in ipairs(GH.get('products')) do
        local n = Bridge.itemCount(src, p.id)
        if n > 0 then list[#list + 1] = { product = p, count = n } end
    end
    return list
end

function GH.sellStart(src)
    local pd, c = sellCheck(src)
    if not pd then return false, c end
    local ok, why = GH.canOpen(src)
    if not ok then return false, why end
    if not pd.job then return false, L('err.needjob') end
    if #ownedProducts(src) == 0 then return false, L('err.noproducts') end
    GH.selling[src] = true
    GH.customers[src] = {}
    return true, { distance = GH.get('spawnDistance'), models = GH.get('customerModels'), expire = GH.get('customerExpire') }
end

function GH.sellStop(src)
    GH.selling[src] = nil
    GH.customers[src] = nil
    return true
end

function GH.customerNext(src)
    if not GH.selling[src] then return false, L('err.notselling') end
    local pd, c = sellCheck(src)
    if not pd then return false, c end
    if not GH.rate(src, 'customer', 3500) then return false, L('err.slowdown') end
    local pending = GH.customers[src] or {}
    local now = GH.now()
    local n = 0
    for id, cu in pairs(pending) do
        if cu.expires < now then pending[id] = nil else n = n + 1 end
    end
    if n >= 2 then return false, L('err.slowdown') end
    local owned = ownedProducts(src)
    if #owned == 0 then GH.sellStop(src) return false, L('err.noproducts') end
    local pick = owned[math.random(1, #owned)].product
    local variation = 1 + (math.random(-100, 100) / 100) * (GH.get('priceVariation') / 100)
    local zone = GH.zoneBonusAt(c)
    local boost = GH.saleBoost(pd)
    local price = math.floor(pick.price * (1 + GH.get('walkUpBonus') / 100) * variation * (1 + (boost + zone) / 100))
    local thief = false
    if GH.get('thievesEnabled') and math.random() * 100 < GH.get('theftChance') then
        local allowed = GH.get('theftProducts')
        local ok = #allowed == 0
        for _, id in ipairs(allowed) do if id == pick.id then ok = true end end
        local active = 0
        for _ in pairs(GH.thefts[src] or {}) do active = active + 1 end
        thief = ok and active < GH.get('theftMaxStrength')
    end
    local id = GH.uid()
    pending[id] = { product = pick.id, price = price, thief = thief, expires = now + GH.get('customerExpire') }
    GH.customers[src] = pending
    local model = GH.get('customerModels')
    return true, { id = id, product = pick.id, label = pick.label, price = price, zone = zone > 0 and zone or nil,
                   model = model[#model > 0 and math.random(1, #model) or 1], expire = GH.get('customerExpire') }
end

function GH.customerAnswer(src, id, sell)
    local pending = GH.customers[src]
    local cu = pending and pending[id]
    if not cu then return false, L('err.gone') end
    pending[id] = nil
    if not sell then return true, { sent = true } end
    if cu.expires < GH.now() then return false, L('err.gone') end
    local pd, c = sellCheck(src)
    if not pd then return false, c end
    local product = GH.productById(cu.product)
    if not product then return false, L('err.gone') end
    if not Bridge.removeItem(src, product.id, 1) then return false, L('err.noproduct') end
    if cu.thief then
        local id2 = GH.uid()
        GH.thefts[src] = GH.thefts[src] or {}
        GH.thefts[src][id2] = { product = product.id, price = cu.price, expires = GH.now() + GH.get('theftTime') }
        GH.log('theft', ('%s was robbed of %s'):format(pd.name, product.label), src)
        return true, { thief = true, theftId = id2, time = GH.get('theftTime'), fight = GH.get('theftFightBack') }
    end
    Bridge.addMoney(src, GH.get('payAccount'), cu.price, 'glam sale')
    GH.recordSale(src, pd, product, 1, cu.price, 1)
    GH.notify(src, L('note.sold', 1, product.label, GH.money(cu.price)), 'success')
    return true, { sold = true, paid = cu.price, remaining = #ownedProducts(src) }
end

function GH.theftRecover(src, id)
    local list = GH.thefts[src]
    local th = list and list[id]
    if not th then return false, L('err.gone') end
    list[id] = nil
    if th.expires < GH.now() then return false, L('err.escaped') end
    local pd = GH.pdOf(src)
    local product = GH.productById(th.product)
    if not pd or not product then return false, L('err.gone') end
    GH.giveItemOrKeep(src, pd.identifier, product.id, 1)
    if GH.get('theftReturnMoney') then
        Bridge.addMoney(src, GH.get('payAccount'), th.price, 'glam sale')
        GH.recordSale(src, pd, product, 1, th.price, 1)
        GH.notify(src, L('note.recovered', GH.money(th.price)), 'success')
    else
        GH.notify(src, L('note.recoveredItem', product.label), 'success')
    end
    return true
end

function GH.theftTick()
    local now = GH.now()
    for src, list in pairs(GH.thefts) do
        for id, th in pairs(list) do
            if th.expires < now then
                list[id] = nil
                GH.notify(src, L('note.escaped'), 'warn')
                TriggerClientEvent('glam:theftEnd', src, id)
            end
        end
    end
end

-- ============================================================ starter pack

local function checklist(pd)
    return {
        { id = 'job', label = L('check.job'), done = pd.job ~= nil },
        { id = 'table', label = L('check.table'), done = GH.tables[pd.identifier] ~= nil },
        { id = 'craft', label = L('check.craft'), done = pd.crafted > 0 },
        { id = 'sell', label = L('check.sell'), done = pd.sold > 0 },
        { id = 'post', label = L('check.post'), done = (pd.profile.posted or 0) > 0 },
    }
end

function GH.starterView(src)
    local pd = GH.pdOf(src)
    if not pd then return nil end
    local items = {}
    for _, s in ipairs(GH.get('starterItems')) do
        local item, n = SplitItem(s)
        local label = item
        for _, i in ipairs(GH.get('ingredients')) do if i.item == item then label = i.label end end
        if item == GH.get('tableItem') then label = L('ui.beautytable') end
        items[#items + 1] = { item = item, label = label, count = n }
    end
    return { enabled = GH.get('starterEnabled'), claimed = pd.starter, items = items, cars = GH.get('starterCars'),
             picks = Bridge.framework == 'standalone' and 0 or GH.get('starterCarPicks'), steps = checklist(pd) }
end

function GH.starterClaim(src, carIdx)
    if not GH.get('starterEnabled') then return false, L('err.disabled') end
    local pd = GH.pdOf(src)
    if not pd then return false, L('err.notloaded') end
    if pd.starter then return false, L('err.claimed') end
    if not Bridge.hasInventory() then return false, L('err.nomoneysystem') end
    carIdx = type(carIdx) == 'table' and carIdx or {}
    local cars = GH.get('starterCars')
    local picks = GH.get('starterCarPicks')
    if #carIdx > picks then return false, L('err.toomanycars', picks) end
    local chosen, seen = {}, {}
    for _, i in ipairs(carIdx) do
        i = math.floor(tonumber(i) or 0)
        if not cars[i] or seen[i] then return false, L('err.badvalue') end
        seen[i] = true
        chosen[#chosen + 1] = cars[i]
    end
    if not GH.rate(src, 'starter', 3000) then return false, L('err.slowdown') end
    for _, s in ipairs(GH.get('starterItems')) do
        local item, n = SplitItem(s)
        if not Bridge.canCarry(src, item, n) then return false, L('err.full') end
    end
    pd.starter = true
    pd.dirty = true
    DB.savePlayer(pd)
    for _, s in ipairs(GH.get('starterItems')) do
        local item, n = SplitItem(s)
        GH.giveItemOrKeep(src, pd.identifier, item, n)
    end
    for _, car in ipairs(chosen) do
        local plate = Hooks.plate(src, GH.get('plateFormat'))
        if Bridge.giveVehicle(src, car.model, plate) then
            GH.notify(src, L('note.car', car.label, plate), 'success')
        else
            GH.notify(src, L('err.carfail'), 'error')
        end
    end
    GH.notify(src, L('note.starter'), 'success')
    return true
end

-- ================================================================== career

function GH.careerView(src)
    local pd = GH.pdOf(src)
    if not pd then return nil end
    local idx, lvl, nextLvl = GH.levelOf(pd.xp)
    local levels = {}
    for i, l in ipairs(GH.get('levels')) do
        levels[#levels + 1] = { n = i, name = l.name, xp = l.xp, boost = l.boost, cash = l.cash, item = l.item, count = l.count,
            reached = idx >= i, claimed = pd.claimed[tostring(i)] == true, claimable = idx >= i and pd.claimed[tostring(i)] ~= true and (l.cash > 0 or (l.item ~= '' and l.count > 0)) }
    end
    -- the last 14 days for the charts
    local rows = MySQL.query.await('SELECT day, xp, earned FROM glam_daily WHERE identifier = ? AND day >= ? ORDER BY day', { pd.identifier, GH.dayKey(GH.now() - 13 * 86400) }) or {}
    local byDay = {}
    for _, r in ipairs(rows) do byDay[r.day] = r end
    local d = GH.dayOf(pd)
    byDay[d.day] = { xp = d.xp, earned = d.earned }
    local chart = {}
    for i = 13, 0, -1 do
        local key = GH.dayKey(GH.now() - i * 86400)
        local r = byDay[key]
        chart[#chart + 1] = { day = key:sub(6), xp = r and r.xp or 0, earned = r and tonumber(r.earned) or 0 }
    end
    local weekStart = GH.periodStart('week')
    local weekXp = 0
    for k, r in pairs(byDay) do if k >= weekStart then weekXp = weekXp + (r.xp or 0) end end
    return {
        xp = math.floor(pd.xp), level = idx, name = lvl.name, nextXp = nextLvl and nextLvl.xp or nil, thisXp = lvl.xp, boost = GH.saleBoost(pd),
        crafted = pd.crafted, sold = pd.sold, earned = math.floor(pd.earned), weekXp = weekXp, levels = levels, chart = chart,
    }
end

function GH.claimLevel(src, n)
    local pd = GH.pdOf(src)
    n = math.floor(tonumber(n) or 0)
    local l = GH.get('levels')[n]
    if not pd or not l then return false, L('err.badvalue') end
    if GH.levelOf(pd.xp) < n then return false, L('err.notdone') end
    if pd.claimed[tostring(n)] then return false, L('err.claimed') end
    pd.claimed[tostring(n)] = true
    pd.dirty = true
    if l.cash > 0 then GH.pay(pd.identifier, l.cash, 'level reward') end
    if l.item ~= '' and l.count > 0 then GH.giveItemOrKeep(src, pd.identifier, l.item, l.count) end
    GH.notify(src, L('note.levelreward', l.name), 'success')
    return true
end
