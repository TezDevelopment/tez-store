GH = {
    players = {},         -- src -> { id = identifier, name = name }
    bySrc = {},           -- identifier -> src
    pd = {},              -- identifier -> player data
    tables = {},          -- identifier -> placed beauty table { x, y, z, h }
    customers = {},       -- src -> { [customerId] = customer }
    thefts = {},          -- src -> { [theftId] = theft }
    selling = {},         -- src -> true while selling
    open = {},            -- src -> true while the hub is open
    panel = {},           -- src -> true while the admin panel is open
    mutes = {},           -- identifier -> until
    chat = {},            -- recent Global Chat messages
    S = {},               -- current settings
    secrets = {},         -- secret values (never sent to clients)
    last = {},            -- setting key -> { by, at }
    nextId = 1,
    version = '1.0.0',
}

function GH.now() return os.time() end

function GH.clamp(v, a, b)
    if v < a then return a end
    if v > b then return b end
    return v
end

function GH.trim(s)
    if type(s) ~= 'string' then return '' end
    return (s:gsub('^%s+', ''):gsub('%s+$', ''):gsub('%c', ''))
end

function GH.get(key)
    local v = GH.S[key]
    if v == nil and Schema.byKey[key] then return Schema.byKey[key].d end
    return v
end

function GH.count(t)
    local n = 0
    for _ in pairs(t) do n = n + 1 end
    return n
end

function GH.uid()
    GH.nextId = GH.nextId + 1
    return GH.nextId * 1000 + math.random(100, 999)
end

function GH.money(n)
    n = math.floor((tonumber(n) or 0) + 0.5)
    local s = tostring(n):reverse():gsub('(%d%d%d)', '%1,'):reverse():gsub('^,', '')
    local c = GH.get('currency') or '$'
    if GH.get('currencyAfter') then return s .. c end
    return c .. s
end

-- ----------------------------------------------------------------- dates (server time)

function GH.dayKey(t) return os.date('%Y-%m-%d', t or os.time()) end

-- first day of the current day / week (Monday) / month, or nil for all time
function GH.periodStart(period, t)
    t = t or os.time()
    if period == 'day' then return GH.dayKey(t) end
    if period == 'week' then
        local d = os.date('*t', t)
        local back = (d.wday + 5) % 7
        return GH.dayKey(t - back * 86400)
    end
    if period == 'month' then return os.date('%Y-%m-01', t) end
    return nil
end

-- the same period, one step back (used for prizes)
function GH.previousPeriod(period, t)
    t = t or os.time()
    if period == 'day' then local y = GH.dayKey(t - 86400) return y, y end
    if period == 'week' then
        local start = GH.periodStart('week', t)
        local y, m, d = start:match('(%d+)-(%d+)-(%d+)')
        local s = os.time({ year = y, month = m, day = d, hour = 12 })
        return GH.dayKey(s - 7 * 86400), GH.dayKey(s - 86400)
    end
    local d = os.date('*t', t)
    local first = os.time({ year = d.year, month = d.month, day = 1, hour = 12 })
    local lastPrev = first - 86400
    return os.date('%Y-%m-01', lastPrev), GH.dayKey(lastPrev)
end

function GH.secondsToMidnight()
    local d = os.date('*t')
    return 86400 - (d.hour * 3600 + d.min * 60 + d.sec)
end

-- ---------------------------------------------------------------- blocked words

local leet = { ['0'] = 'o', ['1'] = 'i', ['3'] = 'e', ['4'] = 'a', ['5'] = 's', ['7'] = 't', ['@'] = 'a', ['$'] = 's', ['!'] = 'i' }

function GH.normalize(s)
    s = tostring(s or ''):lower()
    s = s:gsub('[0134577@%$!]', function(c) return leet[c] or c end)
    s = s:gsub('[^%a]', '')
    s = s:gsub('(%a)%1+', '%1')
    return s
end

function GH.hasBlocked(text)
    local words = GH.get('blockedWords')
    if not words or #words == 0 then return false end
    local n = GH.normalize(text)
    for _, w in ipairs(words) do
        local nw = GH.normalize(w)
        if #nw >= 2 and n:find(nw, 1, true) then return true end
    end
    return false
end

-- returns ok, text. In "stop" mode a blocked message is refused; in "censor" mode the words are starred out.
function GH.filter(text)
    text = GH.trim(text)
    if not GH.hasBlocked(text) then return true, text end
    if GH.get('blockMode') == 'stop' then return false end
    for _, w in ipairs(GH.get('blockedWords') or {}) do
        local esc = w:gsub('%p', '%%%0')
        text = text:gsub('%f[%w]' .. esc:lower() .. '%f[%W]', function(m) return ('*'):rep(#m) end)
        text = text:gsub('%f[%w]' .. esc:upper() .. '%f[%W]', function(m) return ('*'):rep(#m) end)
    end
    if GH.hasBlocked(text) then text = ('*'):rep(math.min(#text, 12)) end
    return true, text
end

-- Only https links from approved hosts
function GH.validImage(url)
    if url == nil or url == '' then return true, '' end
    if type(url) ~= 'string' or #url > 400 then return false end
    if url:find('[%s"\'<>]') then return false end
    local host = url:match('^https://([^/%?#:]+)')
    if not host then return false end
    host = host:lower()
    if GH.get('gifsEnabled') and (host == 'giphy.com' or host:match('%.giphy%.com$')) then return true, url end
    for _, h in ipairs(GH.get('imageSites') or {}) do
        if host == h:lower() then return true, url end
    end
    return false
end

-- ------------------------------------------------------------------ rate limits

local buckets, flood = {}, {}

function GH.rate(src, key, ms)
    local t = GetGameTimer()
    buckets[src] = buckets[src] or {}
    local last = buckets[src][key] or -100000
    if t - last < ms then return false end
    buckets[src][key] = t
    return true
end

-- at most 40 requests per 5 seconds per player
function GH.floodOk(src)
    local t = GetGameTimer()
    local f = flood[src]
    if not f or t - f.start > 5000 then flood[src] = { start = t, n = 1 } return true end
    f.n = f.n + 1
    return f.n <= 40
end

function GH.clearLimits(src) buckets[src] = nil flood[src] = nil end

-- --------------------------------------------------------------------- positions

function GH.coords(src)
    local ped = GetPlayerPed(src)
    if not ped or ped == 0 then return nil end
    return GetEntityCoords(ped)
end

function GH.distance(a, b)
    local ca, cb = GH.coords(a), GH.coords(b)
    if not ca or not cb then return 99999.0 end
    return #(ca - cb)
end

function GH.inZone(c, z)
    return #(c - vector3(z.x, z.y, z.z)) <= z.radius
end

-- --------------------------------------------------------------------- messaging

function GH.notify(src, msg, kind)
    if not src then return end
    if Hooks and Hooks.notify and Hooks.notify(src, msg, kind) then return end
    TriggerClientEvent('glam:toast', src, msg, kind or 'info')
end

function GH.jenc(v) return json.encode(v) end
function GH.jdec(s, fallback)
    if type(s) ~= 'string' or s == '' then return fallback end
    local ok, r = pcall(json.decode, s)
    if ok and r ~= nil then return r end
    return fallback
end

-- Public ids: other players only ever see these, never the real identifier
GH.pubToId, GH.idToPub = {}, {}
function GH.setPub(identifier, pub) GH.pubToId[pub] = identifier GH.idToPub[identifier] = pub end
function GH.pubOf(identifier) return GH.idToPub[identifier] end
function GH.fromPub(pub) return type(pub) == 'string' and GH.pubToId[pub] or nil end
function GH.newPub()
    local chars = 'abcdefghjkmnpqrstuvwxyz23456789'
    for _ = 1, 20 do
        local t = {}
        for i = 1, 10 do local r = math.random(1, #chars) t[i] = chars:sub(r, r) end
        local pub = table.concat(t)
        if not GH.pubToId[pub] then return pub end
    end
    return tostring(GH.uid())
end
function GH.loadPubs()
    for _, r in ipairs(MySQL.query.await("SELECT identifier, pub FROM glam_players WHERE pub <> ''") or {}) do GH.setPub(r.identifier, r.pub) end
end

function GH.debug(...)
    if Config.Debug then print('[glam_hub]', ...) end
end

-- lookups into the editable lists
function GH.productById(id)
    for _, p in ipairs(GH.get('products') or {}) do if p.id == id then return p end end
end
function GH.jobById(id)
    for _, j in ipairs(GH.get('jobs') or {}) do if j.id == id then return j end end
end
