-- Players, access, XP and levels, daily tasks and streaks, leaderboards, prizes, notifications and payouts

-- ================================================================== players

function GH.pdOf(src)
    local p = GH.players[src]
    return p and GH.pd[p.id] or nil
end

function GH.idOf(src) return GH.players[src] and GH.players[src].id or nil end

local function defaultPlayerSettings() return { mode = nil, menuColor = nil, tourDone = false, popupPos = 3, dnd = false } end

function GH.playerSettings(pd)
    local s = defaultPlayerSettings()
    for k, v in pairs(pd.settings or {}) do s[k] = v end
    s.mode = s.mode or GH.get('defaultMode')
    s.menuColor = s.menuColor or GH.get('themeColor')
    return s
end

local settingRules = {
    mode = function(v) return v == 'dark' or v == 'light' end,
    menuColor = function(v) return type(v) == 'string' and v:match('^#%x%x%x%x%x%x$') ~= nil end,
    tourDone = function(v) return type(v) == 'boolean' end,
    dnd = function(v) return type(v) == 'boolean' end,
    popupPos = function(v) return type(v) == 'number' and v >= 1 and v <= 8 end,
}

function GH.savePlayerSettings(src, d)
    local pd = GH.pdOf(src)
    if not pd or type(d) ~= 'table' then return false, L('err.badvalue') end
    for k, v in pairs(d) do
        if settingRules[k] and settingRules[k](v) then
            pd.settings[k] = v
            pd.dirty = true
        end
    end
    return true
end

function GH.saveAll()
    for _, pd in pairs(GH.pd) do DB.savePlayer(pd) end
end

-- keeps the "today" row right when midnight passes while the player is online
function GH.dayOf(pd)
    local today = GH.dayKey()
    if pd.day.day ~= today then
        pd.dirty = true
        DB.savePlayer(pd)
        pd.day = { day = today, crafted = 0, sold = 0, earned = 0, xp = 0, streak = pd.streak }
        pd.dirty = true
    end
    return pd.day
end

-- ============================================================ levels and XP

function GH.levelOf(xp)
    local levels = GH.get('levels')
    local idx = 1
    for i, l in ipairs(levels) do if (xp or 0) >= l.xp then idx = i end end
    return idx, levels[idx], levels[idx + 1]
end

-- extra % on every sale from the player's level and job
function GH.saleBoost(pd)
    local _, lvl = GH.levelOf(pd.xp)
    local boost = lvl and lvl.boost or 0
    local job = pd.job and GH.jobById(pd.job)
    if job then boost = boost + job.bonus end
    return boost
end

function GH.addXp(src, amount, multiplierKey)
    local pd = GH.pdOf(src)
    if not pd or not GH.get('xpEnabled') then return 0 end
    amount = math.floor((amount or 0) * (multiplierKey and GH.get(multiplierKey) or 1) + 0.5)
    if amount <= 0 then return 0 end
    local before = GH.levelOf(pd.xp)
    pd.xp = pd.xp + amount
    GH.dayOf(pd).xp = GH.dayOf(pd).xp + amount
    pd.dirty = true
    local after, lvl = GH.levelOf(pd.xp)
    if after > before then
        GH.notify(src, L('note.levelup', lvl.name), 'success')
        GH.notif(pd.identifier, 'level', L('note.levelup', lvl.name))
        TriggerClientEvent('glam:level', src, { level = after, name = lvl.name })
    end
    return amount
end

-- ============================================================== payouts

function GH.pay(identifier, amount, reason)
    amount = math.floor(amount or 0)
    if amount <= 0 then return true end
    local src = GH.bySrc[identifier]
    if src and Bridge.addMoney(src, GH.get('payAccount'), amount, reason or 'glam_hub') then return true end
    MySQL.insert('INSERT INTO glam_pending (identifier, account, amount, reason) VALUES (?,?,?,?)',
        { identifier, GH.get('payAccount'), amount, reason or '' })
    return false
end

function GH.payPending(src, identifier)
    local rows = MySQL.query.await('SELECT id, account, amount, item, count FROM glam_pending WHERE identifier = ?', { identifier }) or {}
    local total = 0
    for _, r in ipairs(rows) do
        if r.item and r.item ~= '' and r.count > 0 then
            if Bridge.canCarry(src, r.item, r.count) and Bridge.addItem(src, r.item, r.count) then
                MySQL.update('DELETE FROM glam_pending WHERE id = ?', { r.id })
            end
        elseif r.amount > 0 and Bridge.addMoney(src, r.account, r.amount, 'glam_hub') then
            total = total + r.amount
            MySQL.update('DELETE FROM glam_pending WHERE id = ?', { r.id })
        end
    end
    if total > 0 then GH.notify(src, L('note.owed', GH.money(total)), 'success') end
end

function GH.giveItemOrKeep(src, identifier, item, count)
    if item == '' or count <= 0 then return true end
    if Bridge.canCarry(src, item, count) and Bridge.addItem(src, item, count) then return true end
    MySQL.insert('INSERT INTO glam_pending (identifier, item, count, reason) VALUES (?,?,?,?)', { identifier, item, count, 'reward' })
    GH.notify(src, L('note.itemheld'), 'warn')
    return false
end

-- ========================================================== notifications

function GH.notif(identifier, kind, text, data)
    local now = GH.now()
    local id = MySQL.insert.await('INSERT INTO glam_notifs (identifier, kind, text, data, created) VALUES (?,?,?,?,?)',
        { identifier, kind, text:sub(1, 300), data and GH.jenc(data) or nil, now })
    local src = GH.bySrc[identifier]
    if src then TriggerClientEvent('glam:notif', src, { id = id, kind = kind, text = text, created = now, seen = false, data = data }) end
end

function GH.notifList(identifier)
    local rows = MySQL.query.await('SELECT id, kind, text, data, created, seen FROM glam_notifs WHERE identifier = ? ORDER BY id DESC LIMIT 40', { identifier }) or {}
    for _, r in ipairs(rows) do r.seen = r.seen == 1 or r.seen == true r.data = GH.jdec(r.data, nil) end
    return rows
end

-- =============================================================== mutes

function GH.isMuted(identifier)
    local until_ts = GH.mutes[identifier]
    if until_ts and until_ts > GH.now() then return true end
    if until_ts then GH.mutes[identifier] = nil end
    return false
end

-- ============================================================ hub access

function GH.canOpen(src)
    if Hooks.canOpen and Hooks.canOpen(src) == false then return false, L('err.cannotopen') end
    if GH.isStaff(src, true) then return true end
    if GH.get('requireTablet') and Bridge.itemCount(src, GH.get('tabletItem')) < 1 then return false, L('err.needtablet') end
    local mode = GH.get('accessMode')
    if mode == 'everyone' then return true end
    if mode == 'hubjob' then
        local pd = GH.pdOf(src)
        if pd and pd.job and GH.jobById(pd.job) then return true end
        local fw = Bridge.getJob(src)
        if fw and GH.jobById(fw) then return true end
        return false, L('err.noaccess')
    end
    if mode == 'job' then
        local name, grade = Bridge.getJob(src)
        if name == GH.get('accessJob') and (tonumber(grade) or 0) >= GH.get('accessGrade') then return true end
        return false, L('err.noaccess')
    end
    if mode == 'discord' then
        if GH.hasDiscordRole(src, GH.get('accessRoles'), true) then return true end
        return false, L('err.noaccess')
    end
    return true
end

-- ============================================================ daily tasks

local function seeded(identifier, day)
    local seed = 7
    for c in (identifier .. day):gmatch('.') do seed = (seed * 31 + c:byte()) % 2147483647 end
    return function(n)
        seed = (seed * 1103515245 + 12345) % 2147483648
        return (seed % n) + 1
    end
end

function GH.dailyOf(pd)
    local today = GH.dayKey()
    local d = pd.daily
    if d.date == today and d.ids then return d end
    -- a new day: the streak survives only if every task was finished yesterday
    local yesterday = GH.dayKey(GH.now() - 86400)
    if d.doneDate ~= yesterday and d.doneDate ~= today then pd.streak = 0 end
    local pool = GH.get('taskPool')
    local rnd = seeded(pd.identifier, today)
    local ids, copy = {}, {}
    for _, t in ipairs(pool) do copy[#copy + 1] = t.id end
    for _ = 1, math.min(GH.get('tasksPerDay'), #copy) do
        local i = rnd(#copy)
        ids[#ids + 1] = table.remove(copy, i)
    end
    pd.daily = { date = today, ids = ids, prog = {}, paid = {}, bonus = false, doneDate = d.doneDate }
    pd.dirty = true
    return pd.daily
end

local function taskDef(id)
    for _, t in ipairs(GH.get('taskPool')) do if t.id == id then return t end end
end

function GH.taskProgress(src, kind, n)
    if not GH.get('tasksEnabled') then return end
    local pd = GH.pdOf(src)
    if not pd then return end
    local d = GH.dailyOf(pd)
    local touched = false
    for _, id in ipairs(d.ids) do
        local def = taskDef(id)
        if def and def.type == kind and not d.paid[id] then
            d.prog[id] = (d.prog[id] or 0) + n
            touched = true
            if d.prog[id] >= def.goal then
                d.paid[id] = true
                GH.pay(pd.identifier, def.cash, 'daily task')
                GH.addXp(src, def.xp)
                GH.notify(src, L('note.taskdone', GH.money(def.cash)), 'success')
                GH.notif(pd.identifier, 'task', L('note.taskdone', GH.money(def.cash)))
            end
        end
    end
    if not touched then return end
    pd.dirty = true
    -- every task finished: bonus, streak and streak rewards
    local all = #d.ids > 0
    for _, id in ipairs(d.ids) do if not d.paid[id] then all = false end end
    if all and not d.bonus then
        d.bonus = true
        d.doneDate = GH.dayKey()
        pd.streak = pd.streak + 1
        if pd.streak > pd.bestStreak then pd.bestStreak = pd.streak end
        GH.dayOf(pd).streak = pd.streak
        GH.pay(pd.identifier, GH.get('completionCash'), 'daily bonus')
        GH.addXp(src, GH.get('completionXp'))
        GH.notify(src, L('note.allTasks', GH.money(GH.get('completionCash'))), 'success')
        for _, r in ipairs(GH.get('streakRewards')) do
            if r.days == pd.streak then
                GH.pay(pd.identifier, r.cash, 'streak')
                GH.notify(src, L('note.streak', r.days, GH.money(r.cash)), 'success')
                GH.notif(pd.identifier, 'streak', L('note.streak', r.days, GH.money(r.cash)))
            end
        end
    end
end

function GH.tasksView(src)
    local pd = GH.pdOf(src)
    if not pd then return nil end
    local d = GH.dailyOf(pd)
    local list = {}
    for _, id in ipairs(d.ids) do
        local def = taskDef(id)
        if def then
            list[#list + 1] = { id = def.id, type = def.type, goal = def.goal, cash = def.cash, xp = def.xp,
                progress = math.min(d.prog[id] or 0, def.goal), done = d.paid[id] == true }
        end
    end
    local rewards = {}
    for _, r in ipairs(GH.get('streakRewards')) do rewards[#rewards + 1] = { days = r.days, cash = r.cash, reached = pd.streak >= r.days } end
    table.sort(rewards, function(a, b) return a.days < b.days end)
    return {
        enabled = GH.get('tasksEnabled'), tasks = list,
        bonus = { cash = GH.get('completionCash'), xp = GH.get('completionXp'), done = d.bonus == true },
        streak = pd.streak, best = pd.bestStreak, rewards = rewards, resetIn = GH.secondsToMidnight(),
    }
end

-- ============================================================== leaderboards

local boardSql = { sold = 'SUM(d.sold)', crafted = 'SUM(d.crafted)', earned = 'SUM(d.earned)', streak = 'MAX(d.streak)' }
local boardCache = {}

local function boardRows(board, period, limit)
    local col = boardSql[board]
    local from = GH.periodStart(period)
    local where, params = '', {}
    if from then where = 'WHERE d.day >= ?' params[1] = from end
    local rows = MySQL.query.await(
        ('SELECT d.identifier AS id, p.name AS name, p.profile AS profile, %s AS v FROM glam_daily d JOIN glam_players p ON p.identifier = d.identifier %s GROUP BY d.identifier, p.name, p.profile HAVING v > 0 ORDER BY v DESC LIMIT %d')
            :format(col, where, limit), params) or {}
    local out = {}
    for i, r in ipairs(rows) do
        local prof = GH.jdec(r.profile, {})
        out[i] = { id = r.id, pub = GH.pubOf(r.id), name = r.name, value = tonumber(r.v) or 0, picture = prof.picture or '', verified = prof.verified == true }
    end
    return out
end

function GH.boardView(src, board, period)
    if not boardSql[board] then return nil end
    local ok = false
    for _, p in ipairs(Periods) do if p == period then ok = true end end
    if not ok then return nil end
    local key, now = board .. ':' .. period, GH.now()
    local c = boardCache[key]
    if not c or now - c.at > 8 then
        GH.saveAll()
        c = { at = now, rows = boardRows(board, period, 25) }
        boardCache[key] = c
    end
    local me = GH.idOf(src)
    local mine
    if me then
        local col = boardSql[board]
        local from = GH.periodStart(period)
        local where, params = '', {}
        if from then where = 'WHERE d.day >= ?' params[1] = from end
        local v = MySQL.scalar.await(('SELECT %s FROM glam_daily d WHERE d.identifier = ?%s'):format(col, from and ' AND d.day >= ?' or ''),
            from and { me, from } or { me }) or 0
        v = tonumber(v) or 0
        local rank
        for i, r in ipairs(c.rows) do if r.id == me then rank = i end end
        if not rank then
            local above = MySQL.scalar.await(
                ('SELECT COUNT(*) FROM (SELECT %s AS v FROM glam_daily d %s GROUP BY d.identifier HAVING v > ?) t'):format(col, where),
                from and { from, v } or { v }) or 0
            rank = v > 0 and (tonumber(above) + 1) or nil
        end
        mine = { rank = rank, value = v }
    end
    local prizes = {}
    for _, pz in ipairs(GH.get('prizes')) do if pz.period == period then prizes[#prizes + 1] = { rank = pz.rank, cash = pz.cash } end end
    local rows = {}
    for i, r in ipairs(c.rows) do rows[i] = { pub = r.pub, name = r.name, value = r.value, picture = r.picture, verified = r.verified } end
    return { rows = rows, me = mine, prizes = prizes, board = board, period = period }
end

-- pays the top three of every board when a day, week or month has finished
function GH.checkPrizes()
    if not GH.get('prizesEnabled') then return end
    for _, period in ipairs({ 'day', 'week', 'month' }) do
        local from, to = GH.previousPeriod(period)
        local key = 'prize_' .. period .. '_' .. from
        if not DB.meta(key) then
            DB.setMeta(key, GH.now())
            GH.saveAll()
            for _, board in ipairs(Boards) do
                local col = boardSql[board]
                local rows = MySQL.query.await(
                    ('SELECT d.identifier AS id, p.name AS name, %s AS v FROM glam_daily d JOIN glam_players p ON p.identifier = d.identifier WHERE d.day >= ? AND d.day <= ? GROUP BY d.identifier, p.name HAVING v > 0 ORDER BY v DESC LIMIT 3')
                        :format(col), { from, to }) or {}
                for place, r in ipairs(rows) do
                    for _, pz in ipairs(GH.get('prizes')) do
                        if pz.period == period and pz.rank == place and pz.cash > 0 then
                            GH.pay(r.id, pz.cash, 'prize')
                            local txt = L('note.prize', place, L('board.' .. board), L('period.' .. period), GH.money(pz.cash))
                            GH.notif(r.id, 'prize', txt)
                            local s = GH.bySrc[r.id]
                            if s then GH.notify(s, txt, 'success') end
                            GH.log('prize', ('%s won place %d on %s (%s): %s'):format(r.name, place, board, period, GH.money(pz.cash)))
                            Hooks.onPrize(r.id, board, period, place, pz.cash)
                        end
                    end
                end
            end
        end
    end
end

-- =========================================================== boost zones

-- which boost zones are active today (all, or a different few each day)
function GH.activeZones()
    local today = GH.dayKey()
    if GH.zonesToday and GH.zonesToday.day == today then return GH.zonesToday.list end
    local zones = GH.get('boostZones')
    local n = GH.get('boostDaily')
    local list = {}
    if n <= 0 or n >= #zones then
        for i = 1, #zones do list[i] = i end
    else
        local rnd = seeded('zones', today)
        local pool = {}
        for i = 1, #zones do pool[i] = i end
        for _ = 1, n do list[#list + 1] = table.remove(pool, rnd(#pool)) end
        table.sort(list)
    end
    GH.zonesToday = { day = today, list = list }
    return list
end

function GH.zoneBonusAt(c)
    local zones, best = GH.get('boostZones'), 0
    for _, i in ipairs(GH.activeZones()) do
        local z = zones[i]
        if z and GH.inZone(c, z) and z.bonus > best then best = z.bonus end
    end
    return best
end

function GH.inNoSell(c)
    for _, z in ipairs(GH.get('noSellZones')) do
        if GH.inZone(c, z) then return true, z.label end
    end
    return false
end
