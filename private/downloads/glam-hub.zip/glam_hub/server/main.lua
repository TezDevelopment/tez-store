-- Start up, player join and leave, the request router, background timers and commands

GH.ready = false

-- ================================================================ start up

CreateThread(function()
    while GetResourceState('oxmysql') ~= 'started' do Wait(200) end
    DB.migrate()
    GH.loadSettings()
    GH.checkVersion()
    Bridge.init()
    GH.loadPubs()
    GH.loadTables()
    for _, r in ipairs(MySQL.query.await('SELECT identifier, until_ts FROM glam_mutes WHERE until_ts > ?', { GH.now() }) or {}) do GH.mutes[r.identifier] = r.until_ts end
    if GH.get('syncFrameworkJobs') then Bridge.syncJobs(GH.get('jobs')) end
    Bridge.registerUsable(GH.get('tableItem'), function(src) TriggerClientEvent('glam:useTable', src) end)
    Bridge.registerUsable(GH.get('tabletItem'), function(src) TriggerClientEvent('glam:useTablet', src) end)
    GH.ready = true
    print(('[glam_hub] ready. Framework: %s, inventory: %s'):format(Bridge.framework, Bridge.inventory))
    -- players already online when the resource was restarted
    for _, id in ipairs(GetPlayers()) do GH.onJoin(tonumber(id)) end
end)

-- ================================================================== players

function GH.initPayload(src)
    local p = GH.players[src]
    local pd = GH.pd[p.id]
    local idx = GH.levelOf(pd.xp)
    local canOpen = GH.canOpen(src)
    return {
        settings = GH.publicSettings(),
        me = {
            pub = pd.pub, name = p.name, src = src, xp = math.floor(pd.xp), level = idx, job = pd.job,
            prefs = GH.playerSettings(pd), isStaff = GH.isStaff(src), isAdmin = GH.isAdmin(src), isVerifier = GH.isVerifier(src),
            money = Bridge.hasMoney() and Bridge.hasInventory(), canOpen = canOpen, unread = GH.unreadNotifs(p.id),
        },
        zones = GH.activeZones(),
        ui = Locales[Config.Locale] and Locales[Config.Locale].ui or {},
    }
end

function GH.onJoin(src)
    src = tonumber(src)
    if not GH.ready or not src or not GetPlayerName(src) then return end
    if GH.players[src] then return end
    local identifier = Bridge.identifier(src)
    if not identifier then return end
    local name = Bridge.name(src)
    GH.players[src] = { id = identifier, name = name }
    GH.bySrc[identifier] = src
    local pd = DB.loadPlayer(identifier, name)
    pd.name = name
    GH.pd[identifier] = pd
    GH.dayOf(pd)
    GH.payPending(src, identifier)
    TriggerClientEvent('glam:init', src, GH.initPayload(src))
    GH.pushTables(src)
end

AddEventHandler('glam_hub:internalLoaded', function(src) SetTimeout(2000, function() GH.onJoin(src) end) end)
RegisterNetEvent('glam:ready', function() GH.onJoin(source) end)

AddEventHandler('playerDropped', function()
    local src = source
    local p = GH.players[src]
    if p then
        local pd = GH.pd[p.id]
        if pd then pd.dirty = true DB.savePlayer(pd) end
        GH.pd[p.id] = nil
        GH.bySrc[p.id] = nil
    end
    GH.players[src], GH.customers[src], GH.thefts[src], GH.selling[src] = nil, nil, nil, nil
    GH.open[src], GH.panel[src], GH.roleCache[src] = nil, nil, nil
    GH.clearLimits(src)
end)

AddEventHandler('onResourceStop', function(name)
    if name ~= GetCurrentResourceName() then return end
    for _, pd in pairs(GH.pd) do pd.dirty = true DB.savePlayer(pd) end
end)

-- ============================================================ request router

local A = {}

-- the hub itself
A.hubState = function(src, d) GH.open[src] = d.open == true return true end
A.home = function(src) return true, GH.homeView(src) end
A.career = function(src) return true, GH.careerView(src) end
A.levelClaim = function(src, d) return GH.claimLevel(src, d.n) end
A.tasks = function(src) local t = GH.tasksView(src) if not t then return false, L('err.notloaded') end return true, t end
A.boards = function(src, d)
    local v = GH.boardView(src, tostring(d.board), tostring(d.period))
    if not v then return false, L('err.badvalue') end
    return true, v
end
A.settingsSave = function(src, d) return GH.savePlayerSettings(src, d) end
A.notifs = function(src) return true, GH.notifList(GH.idOf(src)) end
A.notifsSeen = function(src) return GH.notifsSeen(src) end

-- jobs, shop, crafting
A.jobs = function(src) return true, GH.jobsView(src) end
A.jobSet = function(src, d) return GH.setJob(src, d.id) end
A.shop = function(src) return true, GH.shopView(src) end
A.shopBuy = function(src, d) return GH.shopBuy(src, d.cart) end
A.quickSell = function(src, d) return GH.quickSell(src, tostring(d.product), d.qty) end
A.recipes = function(src) return true, GH.recipesView(src) end
A.craft = function(src, d) return GH.craft(src, tostring(d.product), d.qty, d.bg == true) end
A.craftCancel = function(src) return GH.craftCancel(src) end
A.claimHeld = function(src, d) return GH.claimHeld(src, tostring(d.product)) end
A.tablePickup = function(src) return GH.pickupTable(src) end
A.starter = function(src) return true, GH.starterView(src) end
A.starterClaim = function(src, d) return GH.starterClaim(src, d.cars) end

-- selling
A.sellStart = function(src) return GH.sellStart(src) end
A.sellStop = function(src) return GH.sellStop(src) end
A.customerNext = function(src) return GH.customerNext(src) end
A.customerAnswer = function(src, d) return GH.customerAnswer(src, tonumber(d.id), d.sell == true) end
A.theftRecover = function(src, d) return GH.theftRecover(src, tonumber(d.id)) end

-- profiles and social
A.profile = function(src, d)
    local v = GH.profileView(src, d.pub)
    if not v then return false, L('err.gone') end
    return true, v
end
A.profileSave = function(src, d)
    local ok, err = GH.profileSave(src, d)
    if not ok then return false, err end
    return true, GH.profileView(src)
end
A.chatList = function(src) return true, { list = GH.chatList(src), online = GH.count(GH.players), muted = GH.isMuted(GH.idOf(src)) } end
A.chatSend = function(src, d) return GH.chatSend(src, d.text, d.image) end
A.chatDelete = function(src, d) return GH.chatDelete(src, d.id) end
A.friends = function(src) return true, GH.friendsView(src) end
A.friendSearch = function(src, d) return true, GH.friendSearch(src, d.q) end
A.friendNearby = function(src) return true, GH.friendNearby(src) end
A.friendRequest = function(src, d) return GH.friendRequest(src, d.pub) end
A.friendAnswer = function(src, d) return GH.friendAnswer(src, d.pub, d.accept == true) end
A.friendRemove = function(src, d) return GH.friendRemove(src, d.pub) end
A.block = function(src, d) return GH.block(src, d.pub, d.on == true) end
A.dmList = function(src) return true, GH.dmList(src) end
A.dmThread = function(src, d)
    local t = GH.dmThread(src, d.pub)
    if not t then return false, L('err.gone') end
    return true, t
end
A.dmSend = function(src, d) return GH.dmSend(src, d.pub, d.text, d.image) end
A.groupList = function(src) return true, GH.groupList(src) end
A.groupCreate = function(src, d) return GH.groupCreate(src, d.name, d.members) end
A.groupThread = function(src, d)
    local t = GH.groupThread(src, d.id)
    if not t then return false, L('err.gone') end
    return true, t
end
A.groupSend = function(src, d) return GH.groupSend(src, d.id, d.text, d.image) end
A.groupAdd = function(src, d) return GH.groupAdd(src, d.id, d.pub) end
A.groupLeave = function(src, d) return GH.groupLeave(src, d.id) end
A.gallery = function(src, d)
    local v = GH.galleryList(src, tostring(d.tab), d.page)
    if not v then return false, L('err.disabled') end
    return true, v
end
A.photoPost = function(src, d) return GH.photoPost(src, d) end
A.photoLike = function(src, d) return GH.photoLike(src, d.id) end
A.photoSave = function(src, d) return GH.photoSave(src, d.id) end
A.photoComments = function(src, d) return true, GH.photoComments(src, d.id) end
A.commentAdd = function(src, d) return GH.commentAdd(src, d.id, d.text, d.image) end
A.photoDelete = function(src, d) return GH.photoDelete(src, d.id) end
A.commentDelete = function(src, d) return GH.commentDelete(src, d.id) end
A.gifSearch = function(src, d) return GH.gifSearch(src, tostring(d.tab), d.q) end
A.gifMark = function(src, d) return GH.gifMark(src, d.url, tostring(d.kind)) end

-- staff
A.mute = function(src, d) return GH.mute(src, d.pub, d.minutes) end
A.unmute = function(src, d) return GH.unmute(src, d.pub) end
A.verify = function(src, d)
    if not GH.isVerifier(src) then return false, L('err.noperm') end
    return GH.setVerified(src, d.pub, d.value == true)
end

local noAccessNeeded = { hubState = true, settingsSave = true, sellStop = true, notifsSeen = true }

local accessCache = {}
local function access(src)
    local c = accessCache[src]
    if c and c.exp > GH.now() then return c.ok, c.why end
    local ok, why = GH.canOpen(src)
    accessCache[src] = { ok = ok, why = why, exp = GH.now() + 20 }
    return ok, why
end

local function reply(src, rid, good, payload)
    TriggerClientEvent('glam:res', src, rid, good == true, payload)
end

RegisterNetEvent('glam:req', function(rid, action, data)
    local src = source
    if type(rid) ~= 'number' or type(action) ~= 'string' then return end
    if not GH.ready then return reply(src, rid, false, L('err.starting')) end
    if not GH.floodOk(src) then return reply(src, rid, false, L('err.slowdown')) end
    if type(data) ~= 'table' then data = {} end

    local handler
    if action:sub(1, 6) == 'admin.' then
        if not GH.isAdmin(src) then
            GH.log('staff', ('Blocked admin request "%s" from %s'):format(action, GetPlayerName(src) or src), src)
            return reply(src, rid, false, L('err.noperm'))
        end
        handler = GH.AdminActions[action:sub(7)]
    else
        if not GH.players[src] then
            GH.onJoin(src)
            if not GH.players[src] then return reply(src, rid, false, L('err.notloaded')) end
        end
        if not noAccessNeeded[action] then
            local ok, why = access(src)
            if not ok then return reply(src, rid, false, why or L('err.noaccess')) end
        end
        handler = A[action]
    end
    if not handler then return reply(src, rid, false, L('err.badvalue')) end

    local good, a, b = pcall(handler, src, data)
    if not good then
        print(('[glam_hub] error in "%s": %s'):format(action, tostring(a)))
        return reply(src, rid, false, L('err.internal'))
    end
    reply(src, rid, a, b)
end)

-- the client wants to open the hub (ped, command or tablet)
RegisterNetEvent('glam:requestOpen', function(page)
    local src = source
    if not GH.players[src] then return end
    accessCache[src] = nil
    local ok, why = GH.canOpen(src)
    if not ok then return GH.notify(src, why or L('err.noaccess'), 'error') end
    TriggerClientEvent('glam:open', src, type(page) == 'string' and page or nil, GH.initPayload(src))
end)

RegisterNetEvent('glam:placeTable', function(d)
    local src = source
    if type(d) ~= 'table' then return end
    local ok, err = GH.placeTable(src, d)
    if not ok then GH.notify(src, err, 'error') end
    TriggerClientEvent('glam:tablePlaced', src, ok == true)
end)

-- ================================================================ timers

CreateThread(function()
    while not GH.ready do Wait(500) end
    local n = 0
    while true do
        Wait(1000)
        n = n + 1
        GH.craftTick()
        GH.theftTick()
        if n % 30 == 0 then
            GH.saveAll()
            for _, p in pairs(GH.players) do local pd = GH.pd[p.id] if pd then GH.dayOf(pd) end end
        end
        if n % 60 == 0 then
            GH.salaryTick()
            GH.checkPrizes()
            local zones = GH.activeZones()
            for src in pairs(GH.players) do TriggerClientEvent('glam:zones', src, zones) end
        end
        if n % 3600 == 0 then
            MySQL.update('DELETE FROM glam_notifs WHERE created < ?', { GH.now() - 30 * 86400 })
        end
    end
end)

-- ============================================================== commands

local function targetPub(src, arg)
    local id = tonumber(arg)
    local p = id and GH.players[id]
    if not p then GH.notify(src, L('err.noplayer'), 'error') return nil end
    return GH.pubOf(p.id)
end

local function say(src, ok, err)
    if src == 0 then print(ok and 'done' or tostring(err)) else GH.notify(src, ok and L('note.done') or err, ok and 'success' or 'error') end
end

RegisterCommand('glammute', function(src, args)
    local pub = targetPub(src, args[1])
    if pub then say(src, GH.mute(src, pub, args[2] or 60)) end
end, false)

RegisterCommand('glamunmute', function(src, args)
    local pub = targetPub(src, args[1])
    if pub then say(src, GH.unmute(src, pub)) end
end, false)

RegisterCommand('glamverify', function(src, args)
    if not GH.isVerifier(src) then return say(src, false, L('err.noperm')) end
    local pub = targetPub(src, args[1])
    if pub then say(src, GH.setVerified(src, pub, args[2] ~= 'remove')) end
end, false)

-- ================================================================ exports

exports('GetHubJob', function(src) local pd = GH.pdOf(src) return pd and pd.job or nil end)
exports('GetCareerLevel', function(src) local pd = GH.pdOf(src) return pd and GH.levelOf(pd.xp) or 0 end)
exports('AddCareerXp', function(src, amount) return GH.addXp(src, tonumber(amount) or 0) end)
