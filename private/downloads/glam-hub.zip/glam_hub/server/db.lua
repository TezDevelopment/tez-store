-- Tables are created and updated automatically every time the resource starts.

DB = {}

local VERSION = 1

local create = {
    [[CREATE TABLE IF NOT EXISTS glam_meta (k VARCHAR(60) NOT NULL PRIMARY KEY, v VARCHAR(255) NOT NULL)]],
    [[CREATE TABLE IF NOT EXISTS glam_settings (k VARCHAR(40) NOT NULL PRIMARY KEY, v LONGTEXT NOT NULL)]],
    [[CREATE TABLE IF NOT EXISTS glam_history (
        id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
        k VARCHAR(40) NOT NULL, old_v TEXT NULL, new_v TEXT NULL,
        admin VARCHAR(80) NOT NULL DEFAULT '', created INT NOT NULL, INDEX (k)
    )]],
    [[CREATE TABLE IF NOT EXISTS glam_players (
        identifier VARCHAR(80) NOT NULL PRIMARY KEY,
        name VARCHAR(80) NOT NULL DEFAULT '',
        xp BIGINT NOT NULL DEFAULT 0,
        crafted INT NOT NULL DEFAULT 0, sold INT NOT NULL DEFAULT 0, earned BIGINT NOT NULL DEFAULT 0,
        streak INT NOT NULL DEFAULT 0, best_streak INT NOT NULL DEFAULT 0,
        job VARCHAR(40) NOT NULL DEFAULT '',
        profile LONGTEXT NULL, settings LONGTEXT NULL, daily LONGTEXT NULL, claimed LONGTEXT NULL,
        craftq LONGTEXT NULL, held LONGTEXT NULL,
        starter TINYINT(1) NOT NULL DEFAULT 0, pub VARCHAR(12) NOT NULL DEFAULT '',
        created INT NOT NULL DEFAULT 0, updated INT NOT NULL DEFAULT 0, INDEX (pub)
    )]],
    [[CREATE TABLE IF NOT EXISTS glam_daily (
        identifier VARCHAR(80) NOT NULL, day VARCHAR(10) NOT NULL,
        crafted INT NOT NULL DEFAULT 0, sold INT NOT NULL DEFAULT 0, earned BIGINT NOT NULL DEFAULT 0,
        xp INT NOT NULL DEFAULT 0, streak INT NOT NULL DEFAULT 0,
        PRIMARY KEY (identifier, day), INDEX (day)
    )]],
    [[CREATE TABLE IF NOT EXISTS glam_tables (
        identifier VARCHAR(80) NOT NULL PRIMARY KEY, x DOUBLE NOT NULL, y DOUBLE NOT NULL, z DOUBLE NOT NULL, h DOUBLE NOT NULL DEFAULT 0
    )]],
    [[CREATE TABLE IF NOT EXISTS glam_pending (
        id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, identifier VARCHAR(80) NOT NULL,
        account VARCHAR(10) NOT NULL DEFAULT 'cash', amount INT NOT NULL DEFAULT 0,
        item VARCHAR(60) NOT NULL DEFAULT '', count INT NOT NULL DEFAULT 0,
        reason VARCHAR(80) NOT NULL DEFAULT '', INDEX (identifier)
    )]],
    [[CREATE TABLE IF NOT EXISTS glam_notifs (
        id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, identifier VARCHAR(80) NOT NULL,
        kind VARCHAR(20) NOT NULL, text VARCHAR(300) NOT NULL, data VARCHAR(300) NULL,
        created INT NOT NULL, seen TINYINT(1) NOT NULL DEFAULT 0, INDEX (identifier)
    )]],
    [[CREATE TABLE IF NOT EXISTS glam_chat (
        id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, identifier VARCHAR(80) NOT NULL, name VARCHAR(80) NOT NULL,
        text VARCHAR(700) NOT NULL DEFAULT '', image VARCHAR(400) NOT NULL DEFAULT '',
        created INT NOT NULL, deleted TINYINT(1) NOT NULL DEFAULT 0
    )]],
    [[CREATE TABLE IF NOT EXISTS glam_friends (
        a VARCHAR(80) NOT NULL, b VARCHAR(80) NOT NULL, status VARCHAR(10) NOT NULL DEFAULT 'pending',
        created INT NOT NULL DEFAULT 0, PRIMARY KEY (a, b), INDEX (b)
    )]],
    [[CREATE TABLE IF NOT EXISTS glam_blocks (
        identifier VARCHAR(80) NOT NULL, blocked VARCHAR(80) NOT NULL, PRIMARY KEY (identifier, blocked)
    )]],
    [[CREATE TABLE IF NOT EXISTS glam_messages (
        id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, sender VARCHAR(80) NOT NULL, receiver VARCHAR(80) NOT NULL,
        text VARCHAR(700) NOT NULL DEFAULT '', image VARCHAR(400) NOT NULL DEFAULT '',
        created INT NOT NULL, seen TINYINT(1) NOT NULL DEFAULT 0, INDEX (sender), INDEX (receiver)
    )]],
    [[CREATE TABLE IF NOT EXISTS glam_groups (
        id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, name VARCHAR(40) NOT NULL, owner VARCHAR(80) NOT NULL, created INT NOT NULL
    )]],
    [[CREATE TABLE IF NOT EXISTS glam_group_members (
        group_id INT NOT NULL, identifier VARCHAR(80) NOT NULL, name VARCHAR(80) NOT NULL DEFAULT '',
        last_seen INT NOT NULL DEFAULT 0, PRIMARY KEY (group_id, identifier), INDEX (identifier)
    )]],
    [[CREATE TABLE IF NOT EXISTS glam_group_messages (
        id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, group_id INT NOT NULL, identifier VARCHAR(80) NOT NULL, name VARCHAR(80) NOT NULL,
        text VARCHAR(700) NOT NULL DEFAULT '', image VARCHAR(400) NOT NULL DEFAULT '', created INT NOT NULL, INDEX (group_id)
    )]],
    [[CREATE TABLE IF NOT EXISTS glam_photos (
        id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, identifier VARCHAR(80) NOT NULL, name VARCHAR(80) NOT NULL,
        url VARCHAR(400) NOT NULL, description VARCHAR(300) NOT NULL DEFAULT '', location VARCHAR(100) NOT NULL DEFAULT '',
        created INT NOT NULL, deleted TINYINT(1) NOT NULL DEFAULT 0, INDEX (identifier)
    )]],
    [[CREATE TABLE IF NOT EXISTS glam_photo_likes (photo_id INT NOT NULL, identifier VARCHAR(80) NOT NULL, PRIMARY KEY (photo_id, identifier))]],
    [[CREATE TABLE IF NOT EXISTS glam_photo_saves (photo_id INT NOT NULL, identifier VARCHAR(80) NOT NULL, PRIMARY KEY (photo_id, identifier))]],
    [[CREATE TABLE IF NOT EXISTS glam_photo_comments (
        id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, photo_id INT NOT NULL, identifier VARCHAR(80) NOT NULL, name VARCHAR(80) NOT NULL,
        text VARCHAR(600) NOT NULL DEFAULT '', image VARCHAR(400) NOT NULL DEFAULT '', created INT NOT NULL, deleted TINYINT(1) NOT NULL DEFAULT 0, INDEX (photo_id)
    )]],
    [[CREATE TABLE IF NOT EXISTS glam_mutes (identifier VARCHAR(80) NOT NULL PRIMARY KEY, until_ts INT NOT NULL, by_name VARCHAR(80) NOT NULL DEFAULT '')]],
    [[CREATE TABLE IF NOT EXISTS glam_logs (
        id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, category VARCHAR(20) NOT NULL, message VARCHAR(500) NOT NULL,
        actor VARCHAR(80) NOT NULL DEFAULT '', created INT NOT NULL
    )]],
}

function DB.migrate()
    for _, q in ipairs(create) do MySQL.query.await(q) end
    local row = MySQL.single.await('SELECT v FROM glam_meta WHERE k = ?', { 'version' })
    local current = row and tonumber(row.v) or 0
    -- future updates go here, e.g. if current < 2 then ALTER TABLE ... end
    if current < VERSION then
        MySQL.query.await('REPLACE INTO glam_meta (k, v) VALUES (?, ?)', { 'version', tostring(VERSION) })
    end
end

function DB.meta(k) local r = MySQL.single.await('SELECT v FROM glam_meta WHERE k = ?', { k }) return r and r.v end
function DB.setMeta(k, v) MySQL.query('REPLACE INTO glam_meta (k, v) VALUES (?, ?)', { k, tostring(v) }) end

-- ------------------------------------------------------------------ players

function DB.loadPlayer(identifier, name)
    local row = MySQL.single.await('SELECT * FROM glam_players WHERE identifier = ?', { identifier })
    local now = GH.now()
    if not row then
        MySQL.insert.await('INSERT INTO glam_players (identifier, name, created, updated) VALUES (?,?,?,?)', { identifier, name or '', now, now })
        row = { xp = 0, crafted = 0, sold = 0, earned = 0, streak = 0, best_streak = 0, job = '', starter = 0, pub = '' }
    end
    local pub = row.pub
    if not pub or pub == '' then
        pub = GH.newPub()
        MySQL.update.await('UPDATE glam_players SET pub = ? WHERE identifier = ?', { pub, identifier })
    end
    GH.setPub(identifier, pub)
    local today = GH.dayKey()
    local day = MySQL.single.await('SELECT * FROM glam_daily WHERE identifier = ? AND day = ?', { identifier, today })
    return {
        identifier = identifier, pub = pub, name = name or row.name,
        xp = row.xp or 0, crafted = row.crafted or 0, sold = row.sold or 0, earned = row.earned or 0,
        streak = row.streak or 0, bestStreak = row.best_streak or 0, job = row.job ~= '' and row.job or nil,
        profile = GH.jdec(row.profile, {}), settings = GH.jdec(row.settings, {}), daily = GH.jdec(row.daily, {}),
        claimed = GH.jdec(row.claimed, {}), craftq = GH.jdec(row.craftq, nil), held = GH.jdec(row.held, {}),
        starter = row.starter == 1 or row.starter == true,
        day = day and { day = today, crafted = day.crafted, sold = day.sold, earned = day.earned, xp = day.xp, streak = day.streak }
              or { day = today, crafted = 0, sold = 0, earned = 0, xp = 0, streak = row.streak or 0 },
        dirty = false,
    }
end

function DB.savePlayer(p)
    if not p or not p.dirty then return end
    p.dirty = false
    MySQL.update(
        [[UPDATE glam_players SET name=?, xp=?, crafted=?, sold=?, earned=?, streak=?, best_streak=?, job=?, profile=?, settings=?,
          daily=?, claimed=?, craftq=?, held=?, starter=?, updated=? WHERE identifier=?]],
        { p.name or '', math.floor(p.xp), p.crafted, p.sold, math.floor(p.earned), p.streak, p.bestStreak, p.job or '',
          GH.jenc(p.profile), GH.jenc(p.settings), GH.jenc(p.daily), GH.jenc(p.claimed), p.craftq and GH.jenc(p.craftq) or '',
          GH.jenc(p.held), p.starter and 1 or 0, GH.now(), p.identifier })
    local d = p.day
    MySQL.update(
        [[INSERT INTO glam_daily (identifier, day, crafted, sold, earned, xp, streak) VALUES (?,?,?,?,?,?,?)
          ON DUPLICATE KEY UPDATE crafted=VALUES(crafted), sold=VALUES(sold), earned=VALUES(earned), xp=VALUES(xp), streak=VALUES(streak)]],
        { p.identifier, d.day, d.crafted, d.sold, math.floor(d.earned), math.floor(d.xp), d.streak })
end

-- ------------------------------------------------------------------ tables

function DB.saveTable(identifier, t)
    MySQL.update('REPLACE INTO glam_tables (identifier, x, y, z, h) VALUES (?,?,?,?,?)', { identifier, t.x, t.y, t.z, t.h })
end
function DB.deleteTable(identifier) MySQL.update('DELETE FROM glam_tables WHERE identifier = ?', { identifier }) end
