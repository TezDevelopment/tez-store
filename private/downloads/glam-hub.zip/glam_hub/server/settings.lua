-- Loading, validating and saving the settings edited in /glamadmin

function GH.loadSettings()
    GH.S = Schema.defaults()
    GH.secrets = {}
    local row = MySQL.single.await('SELECT v FROM glam_settings WHERE k = ?', { 'config' })
    local saved = row and GH.jdec(row.v, {}) or {}
    for k, v in pairs(saved) do
        local f = Schema.byKey[k]
        if f then
            local ok, clean = Schema.validate(f, v)
            if ok then
                if f.secret then GH.secrets[k] = clean else GH.S[k] = clean end
            end
        end
    end
    local last = MySQL.single.await('SELECT v FROM glam_settings WHERE k = ?', { 'last' })
    GH.last = last and GH.jdec(last.v, {}) or {}
end

function GH.persistSettings()
    local blob = {}
    for _, f in ipairs(Schema.fields) do
        if f.secret then blob[f.k] = GH.secrets[f.k] or '' else blob[f.k] = GH.S[f.k] end
    end
    MySQL.query('REPLACE INTO glam_settings (k, v) VALUES (?, ?)', { 'config', GH.jenc(blob) })
    MySQL.query('REPLACE INTO glam_settings (k, v) VALUES (?, ?)', { 'last', GH.jenc(GH.last) })
end

-- Everything that is safe to show every player (secrets are never included)
function GH.publicSettings()
    local out = {}
    for _, f in ipairs(Schema.fields) do
        if not f.secret then out[f.k] = GH.S[f.k] end
    end
    return out
end

local function summary(f, v)
    if f.secret then return v and '(changed)' or '' end
    local s = json.encode(v)
    if #s > 600 then s = s:sub(1, 600) .. '...' end
    return s
end

-- rules that involve more than one setting or one list
local function crossCheck()
    local S = GH.S
    if S.customerMin > S.customerMax then return false, L('err.rule.customers') end
    local seen = {}
    for _, j in ipairs(S.jobs) do
        if j.id:find('[^%w_%-]') or j.id == '' then return false, L('err.rule.jobid', j.id) end
        if seen[j.id] then return false, L('err.rule.dupjob', j.id) end
        seen[j.id] = true
    end
    seen = {}
    for _, p in ipairs(S.products) do
        if p.id == '' or seen[p.id] then return false, L('err.rule.dupproduct', p.id) end
        seen[p.id] = true
    end
    if #S.levels < 1 or S.levels[1].xp ~= 0 then return false, L('err.rule.level1') end
    for i = 2, #S.levels do
        if S.levels[i].xp <= S.levels[i - 1].xp then return false, L('err.rule.levelorder') end
    end
    return true
end

-- values = { key = value }, clear = { 'secretKey', ... }
-- Returns ok, errorText, listOfChangedKeys
function GH.saveSettings(src, values, clear)
    if type(values) ~= 'table' then return false, L('err.badvalue') end

    local backupS, backupSecrets, backupLast = {}, {}, {}
    for k, v in pairs(GH.S) do backupS[k] = v end
    for k, v in pairs(GH.secrets) do backupSecrets[k] = v end
    for k, v in pairs(GH.last) do backupLast[k] = v end

    local changed, diffs = {}, {}
    local function revert()
        GH.S, GH.secrets, GH.last = backupS, backupSecrets, backupLast
    end

    local who = (src and GH.players[src] and GH.players[src].name) or 'console'
    local now = GH.now()

    for k, v in pairs(values) do
        local f = Schema.byKey[k]
        if not f then revert() return false, L('err.unknownsetting', tostring(k)) end
        if f.secret then
            if type(v) == 'string' and v ~= '' then
                local ok, clean = Schema.validate(f, v)
                if not ok then revert() return false, L('err.badsetting', f.l) end
                GH.secrets[k] = clean
                changed[#changed + 1] = k
                diffs[#diffs + 1] = { k = k, old = '(secret)', new = '(changed)' }
                GH.last[k] = { by = who, at = now }
            end
        else
            local ok, clean = Schema.validate(f, v)
            if not ok then revert() return false, L('err.badsetting', f.l) end
            if json.encode(clean) ~= json.encode(GH.S[k]) then
                diffs[#diffs + 1] = { k = k, old = summary(f, GH.S[k]), new = summary(f, clean) }
                changed[#changed + 1] = k
                GH.last[k] = { by = who, at = now }
            end
            GH.S[k] = clean
        end
    end

    if type(clear) == 'table' then
        for _, k in ipairs(clear) do
            local f = Schema.byKey[k]
            if f and f.secret and (GH.secrets[k] or '') ~= '' then
                GH.secrets[k] = ''
                changed[#changed + 1] = k
                diffs[#diffs + 1] = { k = k, old = '(secret)', new = '(removed)' }
                GH.last[k] = { by = who, at = now }
            end
        end
    end

    local ok, err = crossCheck()
    if not ok then revert() return false, err end

    -- the admin may not lock themselves out
    if src and src > 0 and not GH.isAdmin(src, true) then
        revert()
        return false, L('err.lockout')
    end

    for _, d in ipairs(diffs) do
        MySQL.insert('INSERT INTO glam_history (k, old_v, new_v, admin, created) VALUES (?,?,?,?,?)', { d.k, d.old, d.new, who, now })
    end
    GH.persistSettings()
    TriggerClientEvent('glam:settings', -1, GH.publicSettings())
    GH.afterSettings(changed)
    return true, nil, changed, diffs
end

-- things that have to follow a settings change right away
function GH.afterSettings(changed)
    local set = {}
    for _, k in ipairs(changed) do set[k] = true end
    if set.jobs and GH.get('syncFrameworkJobs') then Bridge.syncJobs(GH.get('jobs')) end
    if set.tableItem then Bridge.registerUsable(GH.get('tableItem'), function(src) TriggerClientEvent('glam:useTable', src) end) end
    if set.tabletItem then Bridge.registerUsable(GH.get('tabletItem'), function(src) TriggerClientEvent('glam:useTablet', src) end) end
    if set.boostDaily or set.boostZones then GH.zonesToday = nil end
end

function GH.history(key, limit)
    if key and key ~= '' then
        return MySQL.query.await('SELECT k, old_v, new_v, admin, created FROM glam_history WHERE k = ? ORDER BY id DESC LIMIT ?', { key, limit or 30 }) or {}
    end
    return MySQL.query.await('SELECT k, old_v, new_v, admin, created FROM glam_history ORDER BY id DESC LIMIT ?', { limit or 60 }) or {}
end
