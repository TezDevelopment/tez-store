fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'glam_hub'
author 'Tez Development'
description 'Beauty business and social hub: jobs, crafting, walk-up customers, career levels, daily tasks, leaderboards, chat, friends, gallery and a full in-game admin panel'
version '1.0.0'

dependencies { 'oxmysql' }

shared_scripts {
    'config.lua',
    'locales/*.lua',
    'shared/shared.lua',
    'shared/schema.lua',
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'bridge/hooks.lua',
    'server/util.lua',
    'bridge/server.lua',
    'server/db.lua',
    'server/settings.lua',
    'server/core.lua',
    'server/admin.lua',
    'server/business.lua',
    'server/social.lua',
    'server/main.lua',
}

client_scripts {
    'bridge/client.lua',
    'client/main.lua',
    'client/world.lua',
    'client/selling.lua',
}

ui_page 'html/index.html'

files {
    'html/index.html',
    'html/style.css',
    'html/core.js',
    'html/overlays.js',
    'html/menu.js',
    'html/hub1.js',
    'html/hub2.js',
    'html/hub3.js',
    'html/admin.js',
    'html/items/*.png',
}

provide 'glam_hub_api'
