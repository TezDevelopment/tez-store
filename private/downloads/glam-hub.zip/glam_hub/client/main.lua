-- Client core: state, requests to the server, the NUI bridge, commands, the tablet and admin helpers

C = {
    ready = false,
    settings = {},
    me = nil,
    tables = {},
    zones = {},
    open = false,        -- the hub window is open
    focusMode = nil,
    tabletMode = false,
    selling = false,
}

-- ------------------------------------------------------------------ requests

local pending, nextRid = {}, 0

function C.req(action, data)
    nextRid = nextRid + 1
    local rid = nextRid
    local p = promise.new()
    pending[rid] = p
    TriggerServerEvent('glam:req', rid, action, data or {})
    SetTimeout(10000, function()
        if pending[rid] then
            pending[rid] = nil
            p:resolve({ ok = false, payload = L('err.noanswer') })
        end
    end)
    return Citizen.Await(p)
end

RegisterNetEvent('glam:res', function(rid, ok, payload)
    local p = pending[rid]
    if p then
        pending[rid] = nil
        p:resolve({ ok = ok, payload = payload })
    end
end)

-- -------------------------------------------------------------------- NUI

function C.nui(a, data)
    data = data or {}
    data.a = a
    SendNUIMessage(data)
end

function C.toast(message, kind)
    C.nui('toast', { message = message, kind = kind or 'info' })
end
RegisterNetEvent('glam:toast', function(message, kind) C.toast(message, kind) end)

function C.focus(mode)
    C.focusMode = mode
    if mode == 'hub' then
        SetNuiFocus(true, true)
        SetNuiFocusKeepInput(false)
    else
        SetNuiFocus(false, false)
        SetNuiFocusKeepInput(false)
    end
end

-- ---------------------------------------------------------------- tablet

local tabletProp

local function startTablet()
    if tabletProp then return end
    local ped = PlayerPedId()
    local model = joaat('prop_cs_tablet')
    RequestModel(model)
    local t = GetGameTimer() + 3000
    while not HasModelLoaded(model) and GetGameTimer() < t do Wait(10) end
    tabletProp = CreateObject(model, 0.0, 0.0, 0.0, true, true, false)
    AttachEntityToEntity(tabletProp, ped, GetPedBoneIndex(ped, 28422), 0.0, 0.0, 0.03, 0.0, 0.0, 0.0, true, true, false, true, 1, true)
    RequestAnimDict('amb@code_human_in_bus_passenger_idles@female@tablet@base')
    t = GetGameTimer() + 3000
    while not HasAnimDictLoaded('amb@code_human_in_bus_passenger_idles@female@tablet@base') and GetGameTimer() < t do Wait(10) end
    TaskPlayAnim(ped, 'amb@code_human_in_bus_passenger_idles@female@tablet@base', 'base', 3.0, 3.0, -1, 49, 0, false, false, false)
end

local function stopTablet()
    if not tabletProp then return end
    ClearPedTasks(PlayerPedId())
    DeleteEntity(tabletProp)
    tabletProp = nil
end

-- ---------------------------------------------------------------- hub window

function C.openHub(page, payload)
    if not C.ready or C.open then return end
    if Bridge.isBusy() then return C.toast(L('err.busy'), 'error') end
    if payload then
        C.settings, C.me = payload.settings, payload.me
    end
    C.open = true
    C.focus('hub')
    C.nui('open', { page = page, init = payload })
    C.req('hubState', { open = true })
    if C.tabletMode then startTablet() end
end

function C.closeHub()
    if not C.open then return end
    C.open = false
    C.focus(nil)
    C.nui('close', {})
    C.req('hubState', { open = false })
    stopTablet()
    C.tabletMode = false
end

-- the server answers a request to open
RegisterNetEvent('glam:open', function(page, payload) C.openHub(page, payload) end)

-- asked by a ped, a command or a table
function C.requestOpen(page)
    if not C.ready then return end
    TriggerServerEvent('glam:requestOpen', page)
end

RegisterNetEvent('glam:useTablet', function()
    C.tabletMode = true
    C.requestOpen(nil)
end)

-- --------------------------------------------------------------------- events

RegisterNetEvent('glam:init', function(payload)
    C.settings, C.me = payload.settings, payload.me
    C.zones = payload.zones or {}
    C.ready = true
    C.registerCommands()
    C.nui('init', payload)
    if C.syncWorld then C.syncWorld() end
end)

RegisterNetEvent('glam:settings', function(settings)
    C.settings = settings
    C.registerCommands()
    C.nui('settings', { settings = settings })
    if C.syncWorld then C.syncWorld() end
end)

RegisterNetEvent('glam:zones', function(list)
    C.zones = list
    if C.syncWorld then C.syncWorld() end
end)

RegisterNetEvent('glam:notif', function(n) C.nui('notif', { n = n }) end)
RegisterNetEvent('glam:chat', function(m) C.nui('chat', { m = m }) end)
RegisterNetEvent('glam:chatDeleted', function(id) C.nui('chatDeleted', { id = id }) end)
RegisterNetEvent('glam:level', function(d) C.nui('level', d) PlaySoundFrontend(-1, 'RANK_UP', 'HUD_AWARDS', true) end)
RegisterNetEvent('glam:craftDone', function(d) C.nui('craftDone', d or {}) end)
RegisterNetEvent('glam:tablePlaced', function() end)
RegisterNetEvent('glam:adminSaved', function(d) C.nui('adminSaved', d) end)

RegisterNetEvent('glam:dm', function(m)
    C.nui('popup', { m = m, open = C.open })
    if C.me and C.me.prefs and not C.me.prefs.dnd then PlaySoundFrontend(-1, 'Text_Arrive_Tone', 'Phone_SoundSet_Default', true) end
end)

-- -------------------------------------------------------------- NUI callbacks

RegisterNUICallback('close', function(_, cb) C.closeHub() cb({}) end)

RegisterNUICallback('req', function(d, cb)
    if type(d) ~= 'table' or type(d.action) ~= 'string' then return cb({ ok = false, payload = 'Bad request' }) end
    local res = C.req(d.action, d.data)
    cb(res)
end)

RegisterNUICallback('prefs', function(d, cb)
    if C.me and type(d) == 'table' then
        for k, v in pairs(d) do C.me.prefs[k] = v end
    end
    cb({})
end)

-- plays the crafting animation with a progress bar; the player can walk away when background crafting is on
RegisterNUICallback('craftAnim', function(d, cb)
    cb({})
    local time = tonumber(d.time) or 0
    if time <= 0 then return end
    C.closeHub()
    CreateThread(function()
        local ped = PlayerPedId()
        local dict, clip = d.dict ~= '' and d.dict or C.settings.craftAnimDict, d.clip ~= '' and d.clip or C.settings.craftAnimClip
        local t = GetGameTimer() + 2500
        while dict and dict ~= '' and not HasAnimDictLoaded(dict) and GetGameTimer() < t do RequestAnimDict(dict) Wait(10) end
        if dict and dict ~= '' and HasAnimDictLoaded(dict) then
            TaskPlayAnim(ped, dict, clip, 3.0, 3.0, -1, 1, 0, false, false, false)
        end
        local prop
        if d.prop and d.prop ~= '' then
            local hash = joaat(d.prop)
            RequestModel(hash)
            local w = GetGameTimer() + 2000
            while not HasModelLoaded(hash) and GetGameTimer() < w do Wait(10) end
            if HasModelLoaded(hash) then
                prop = CreateObject(hash, 0.0, 0.0, 0.0, true, true, false)
                AttachEntityToEntity(prop, ped, GetPedBoneIndex(ped, 57005), 0.12, 0.02, -0.02, 0.0, 0.0, 0.0, true, true, false, true, 1, true)
            end
        end
        local endAt = GetGameTimer() + time * 1000
        local cancelled = false
        C.nui('progress', { on = true, label = d.label or '', time = time })
        while GetGameTimer() < endAt do
            Wait(0)
            DisableControlAction(0, 21, true)
            if IsControlJustPressed(0, 73) then cancelled = true break end
            if IsEntityDead(ped) then cancelled = true break end
        end
        C.nui('progress', { on = false })
        ClearPedTasks(ped)
        if prop then DeleteEntity(prop) end
        if cancelled then
            local r = C.req('craftCancel', {})
            if r.ok then C.toast(L('note.craftcancel'), 'warn') end
        end
    end)
end)

-- ----------------------------------------------------- admin: place things in the world

local picking = false

RegisterNUICallback('goto', function(d, cb)
    cb({})
    local x, y, z = tonumber(d.x), tonumber(d.y), tonumber(d.z)
    if not x or not y or not z then return end
    local ped = PlayerPedId()
    SetEntityCoords(ped, x + 0.0, y + 0.0, z + 0.0, false, false, false, false)
end)

-- "Pick": hide the panel, walk to the right place and press E. For zones the scroll wheel changes the size.
RegisterNUICallback('pick', function(d, cb)
    cb({})
    if picking then return end
    picking = true
    local withRadius = d.radius ~= nil
    local radius = tonumber(d.radius) or 10.0
    C.nui('pickState', { hidden = true })
    C.focus(nil)
    CreateThread(function()
        local result
        while true do
            Wait(0)
            local ped = PlayerPedId()
            local c = GetEntityCoords(ped)
            if withRadius then
                DrawMarker(1, c.x, c.y, c.z - 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, radius * 2.0, radius * 2.0, 1.5, 236, 72, 153, 90, false, false, 2, false, nil, nil, false)
                if IsControlJustPressed(0, 241) then radius = math.min(500.0, radius + 2.0) end
                if IsControlJustPressed(0, 242) then radius = math.max(5.0, radius - 2.0) end
            else
                DrawMarker(1, c.x, c.y, c.z - 1.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 0.8, 0.8, 1.2, 236, 72, 153, 120, false, false, 2, false, nil, nil, false)
            end
            BeginTextCommandDisplayHelp('STRING')
            AddTextComponentSubstringPlayerName(withRadius and L('pick.zone', math.floor(radius)) or L('pick.point'))
            EndTextCommandDisplayHelp(0, false, false, -1)
            if IsControlJustPressed(0, 38) then
                result = { x = c.x, y = c.y, z = c.z, h = GetEntityHeading(ped), radius = withRadius and radius or nil }
                break
            end
            if IsControlJustPressed(0, 177) or IsControlJustPressed(0, 194) then break end
        end
        picking = false
        C.focus('hub')
        C.nui('pickState', { hidden = false, result = result })
    end)
end)

-- while the player is placing a zone with the wheel, the panel can ask for a preview ring
RegisterNUICallback('streetName', function(_, cb)
    local c = GetEntityCoords(PlayerPedId())
    local s, cross = GetStreetNameAtCoord(c.x, c.y, c.z)
    local name = GetStreetNameFromHashKey(s)
    local zone = GetLabelText(GetNameOfZone(c.x, c.y, c.z))
    cb({ name = (name ~= '' and name or zone) .. (zone ~= 'NULL' and name ~= '' and (', ' .. zone) or '') })
end)

-- ---------------------------------------------------------------- commands

local registered = {}
local function registerOnce(name, fn)
    if not name or name == '' or registered[name] then return end
    registered[name] = true
    RegisterCommand(name, fn, false)
end

function C.registerCommands()
    registerOnce(C.settings.hubCommand, function() C.requestOpen(nil) end)
    registerOnce(C.settings.sellCommand, function() if C.toggleSelling then C.toggleSelling() end end)
end

RegisterCommand(Config.AdminCommand, function()
    if not C.ready then return end
    if not C.me.isAdmin then return C.toast(L('err.noperm'), 'error') end
    C.openHub('admin', nil)
end, false)

-- ------------------------------------------------------------------ start

CreateThread(function()
    Bridge.waitLoaded()
    Wait(1500)
    TriggerServerEvent('glam:ready')
end)

AddEventHandler('onResourceStop', function(name)
    if name ~= GetCurrentResourceName() then return end
    SetNuiFocus(false, false)
    stopTablet()
end)

-- the hub closes if the player dies or gets cuffed
CreateThread(function()
    while true do
        Wait(500)
        if C.open and Bridge.isBusy() then C.closeHub() end
    end
end)
