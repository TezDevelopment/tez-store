-- Selling to walk-up customers, the hand-over, thieves and the chase

local session           -- { sold, earned, paused }
local customer          -- the customer being served
local thieves = {}      -- theftId -> { ped, blip, endsAt }
local cam

local function setting(k) return C.settings and C.settings[k] end

local function loadModel(name)
    local hash = joaat(name)
    if not IsModelInCdimage(hash) then hash = joaat('a_f_y_hipster_01') end
    RequestModel(hash)
    local t = GetGameTimer() + 4000
    while not HasModelLoaded(hash) and GetGameTimer() < t do Wait(10) end
    return HasModelLoaded(hash) and hash or nil
end

local function loadAnim(dict)
    RequestAnimDict(dict)
    local t = GetGameTimer() + 2000
    while not HasAnimDictLoaded(dict) and GetGameTimer() < t do Wait(10) end
    return HasAnimDictLoaded(dict)
end

local function display()
    C.nui('sellDisplay', { on = session ~= nil, sold = session and session.sold or 0, earned = session and session.earned or 0, paused = session and session.paused or false })
end

-- ------------------------------------------------------------------ camera

local function startCam(ped)
    local me = PlayerPedId()
    local pos = GetOffsetFromEntityInWorldCoords(me, 0.9, -1.4, 0.8)
    cam = CreateCamWithParams('DEFAULT_SCRIPTED_CAMERA', pos.x, pos.y, pos.z, 0.0, 0.0, 0.0, 45.0, false, 0)
    PointCamAtEntity(cam, ped, 0.0, 0.0, 0.45, true)
    SetCamActive(cam, true)
    RenderScriptCams(true, true, 700, true, false)
end

local function stopCam()
    if cam then
        RenderScriptCams(false, true, 600, true, false)
        DestroyCam(cam, false)
        cam = nil
    end
end

-- ----------------------------------------------------------------- customers

local function safeSpawn()
    local me = PlayerPedId()
    local c = GetEntityCoords(me)
    local dist = setting('spawnDistance') or 28.0
    for _ = 1, 12 do
        local a = math.rad(math.random(0, 359))
        local x, y = c.x + math.cos(a) * dist, c.y + math.sin(a) * dist
        local ok, safe = GetSafeCoordForPed(x, y, c.z, true, 16)
        if ok then return safe end
    end
    return nil
end

local function cleanupCustomer(ped, walkAway)
    if not ped or not DoesEntityExist(ped) then return end
    if walkAway then
        ClearPedTasks(ped)
        TaskWanderStandard(ped, 10.0, 10)
        SetPedAsNoLongerNeeded(ped)
    else
        DeleteEntity(ped)
    end
end

local function handOver(ped)
    local me = PlayerPedId()
    if loadAnim('mp_common') then
        TaskPlayAnim(me, 'mp_common', 'givetake1_a', 8.0, -8.0, 1500, 48, 0, false, false, false)
        TaskPlayAnim(ped, 'mp_common', 'givetake1_b', 8.0, -8.0, 1500, 48, 0, false, false, false)
    end
    Wait(1500)
end

-- a thief runs: blip, timer and the chase
local function startChase(ped, theftId, seconds, fight)
    local blip = AddBlipForEntity(ped)
    SetBlipSprite(blip, 1)
    SetBlipColour(blip, 1)
    SetBlipFlashes(blip, true)
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentSubstringPlayerName(L('hud.thief'))
    EndTextCommandSetBlipName(blip)
    thieves[theftId] = { ped = ped, blip = blip, endsAt = GetGameTimer() + seconds * 1000, fight = fight }
    SetBlockingOfNonTemporaryEvents(ped, true)
    SetPedFleeAttributes(ped, 0, false)
    TaskSmartFleePed(ped, PlayerPedId(), 500.0, -1, false, false)
    SetPedMoveRateOverride(ped, 1.15)
    C.toast(L('note.thief', seconds), 'warn')
end

local function endChase(theftId, caught)
    local t = thieves[theftId]
    if not t then return end
    if t.blip and DoesBlipExist(t.blip) then RemoveBlip(t.blip) end
    if DoesEntityExist(t.ped) then
        if caught then DeleteEntity(t.ped) else SetPedAsNoLongerNeeded(t.ped) TaskWanderStandard(t.ped, 10.0, 10) end
    end
    thieves[theftId] = nil
    C.nui('chase', { on = next(thieves) ~= nil })
end

RegisterNetEvent('glam:theftEnd', function(id) endChase(id, false) end)

CreateThread(function()
    while true do
        local wait = 600
        if next(thieves) then
            wait = 0
            local me = PlayerPedId()
            local mc = GetEntityCoords(me)
            for id, t in pairs(thieves) do
                if not DoesEntityExist(t.ped) then endChase(id, false) break end
                local pc = GetEntityCoords(t.ped)
                local d = #(mc - pc)
                local left = math.max(0, math.ceil((t.endsAt - GetGameTimer()) / 1000))
                C.nui('chase', { on = true, left = left, dist = math.floor(d) })
                local downed = IsPedRagdoll(t.ped) or IsEntityDead(t.ped) or GetEntityHealth(t.ped) < 110
                local close = d < 2.6
                -- fighting thieves turn on the player when caught and must be put down first
                if t.fight and d < 4.0 and not downed and not t.fighting then
                    t.fighting = true
                    ClearPedTasks(t.ped)
                    SetPedCombatAttributes(t.ped, 46, true)
                    TaskCombatPed(t.ped, me, 0, 16)
                end
                if close and (not t.fight or downed) then
                    BeginTextCommandDisplayHelp('STRING')
                    AddTextComponentSubstringPlayerName(L('prompt.search'))
                    EndTextCommandDisplayHelp(0, false, false, -1)
                    if IsControlJustPressed(0, 38) then
                        ClearPedTasksImmediately(t.ped)
                        if loadAnim('mp_common') then TaskPlayAnim(me, 'mp_common', 'givetake1_a', 8.0, -8.0, 1200, 48, 0, false, false, false) end
                        Wait(1200)
                        local r = C.req('theftRecover', { id = id })
                        if r.ok then
                            endChase(id, true)
                        else
                            C.toast(r.payload, 'error')
                            endChase(id, false)
                        end
                        break
                    end
                end
            end
        end
        Wait(wait)
    end
end)

-- one customer: walk up, ask, wait for the player's answer
local function serveCustomer(data)
    local hash = loadModel(data.model)
    if not hash then return end
    local spawn = safeSpawn()
    if not spawn then return end
    local me = PlayerPedId()
    local ped = CreatePed(4, hash, spawn.x, spawn.y, spawn.z, 0.0, false, true)
    SetModelAsNoLongerNeeded(hash)
    SetBlockingOfNonTemporaryEvents(ped, true)
    SetEntityAsMissionEntity(ped, true, true)
    TaskGoToEntity(ped, me, -1, 2.2, 1.0, 1073741824, 0)
    customer = { ped = ped, data = data }
    local timeout = GetGameTimer() + 40000
    -- walk up
    while session and DoesEntityExist(ped) and #(GetEntityCoords(ped) - GetEntityCoords(PlayerPedId())) > (setting('sellDistance') or 3.0) do
        Wait(200)
        if GetGameTimer() > timeout or IsEntityDead(PlayerPedId()) then break end
        if not session or session.stopping then break end
    end
    if not session or not DoesEntityExist(ped) or #(GetEntityCoords(ped) - GetEntityCoords(PlayerPedId())) > (setting('sellDistance') or 3.0) + 2.0 then
        C.req('customerAnswer', { id = data.id, sell = false })
        cleanupCustomer(ped, false)
        customer = nil
        return
    end
    ClearPedTasks(ped)
    TaskTurnPedToFaceEntity(ped, PlayerPedId(), 1500)
    TaskTurnPedToFaceEntity(PlayerPedId(), ped, 1500)
    startCam(ped)
    C.nui('customer', { on = true, product = data.product, label = data.label, price = data.price, zone = data.zone, expire = data.expire })

    local answer
    local endAt = GetGameTimer() + data.expire * 1000
    while GetGameTimer() < endAt and session do
        Wait(0)
        DisableControlAction(0, 24, true)
        DisableControlAction(0, 25, true)
        if IsControlJustPressed(0, 38) then answer = true break end   -- E
        if IsControlJustPressed(0, 73) then answer = false break end  -- X
        if IsEntityDead(PlayerPedId()) then break end
    end
    C.nui('customer', { on = false })

    if answer then
        local r = C.req('customerAnswer', { id = data.id, sell = true })
        if not r.ok then
            C.toast(r.payload, 'error')
            stopCam()
            cleanupCustomer(ped, true)
        elseif r.payload.thief then
            handOver(ped)
            stopCam()
            startChase(ped, r.payload.theftId, r.payload.time, r.payload.fight)
        else
            handOver(ped)
            stopCam()
            session.sold = session.sold + 1
            session.earned = session.earned + (r.payload.paid or 0)
            display()
            cleanupCustomer(ped, true)
            if r.payload.remaining == 0 then
                C.toast(L('note.outofstock'), 'warn')
                C.stopSelling()
            end
        end
    else
        C.req('customerAnswer', { id = data.id, sell = false })
        stopCam()
        cleanupCustomer(ped, true)
    end
    customer = nil
end

-- ------------------------------------------------------------------- session

function C.stopSelling(silent)
    if not session then return end
    session = nil
    C.selling = false
    C.req('sellStop', {})
    display()
    stopCam()
    C.nui('customer', { on = false })
    if customer and customer.ped then cleanupCustomer(customer.ped, false) customer = nil end
    if not silent then C.toast(L('note.sellstop'), 'info') end
end

function C.toggleSelling()
    if not C.ready then return end
    if session then return C.stopSelling() end
    if Bridge.isBusy() then return C.toast(L('err.busy'), 'error') end
    local r = C.req('sellStart', {})
    if not r.ok then return C.toast(r.payload, 'error') end
    session = { sold = 0, earned = 0, paused = false }
    C.selling = true
    display()
    C.toast(L('note.sellstart'), 'success')
    -- key presses are read every frame, the customer timer ticks slower
    CreateThread(function()
        while session do
            Wait(0)
            if not customer then
                if IsControlJustPressed(0, 47) then session.pressG = true end    -- G pauses
                if IsControlJustPressed(0, 73) then session.pressX = true end    -- X stops
            end
        end
    end)
    CreateThread(function()
        local nextAt = GetGameTimer() + 4000
        local lastNote = 0
        while session do
            Wait(200)
            if session.pressG then
                session.pressG = false
                session.paused = not session.paused
                display()
                if not session.paused then nextAt = GetGameTimer() + 3000 end
            end
            if session.pressX then
                session.pressX = false
                if not session.paused then C.stopSelling() break end
            end
            if IsEntityDead(PlayerPedId()) then C.stopSelling() break end
            if not customer and not session.paused and GetGameTimer() >= nextAt and not Bridge.isBusy() then
                local res = C.req('customerNext', {})
                if res.ok then
                    serveCustomer(res.payload)
                else
                    if res.payload == L('err.noproducts') then
                        C.toast(res.payload, 'warn')
                        C.stopSelling()
                        break
                    end
                    if GetGameTimer() - lastNote > 20000 and res.payload ~= L('err.slowdown') then
                        lastNote = GetGameTimer()
                        C.toast(res.payload, 'warn')
                    end
                end
                local lo, hi = setting('customerMin') or 8, setting('customerMax') or 20
                nextAt = GetGameTimer() + math.random(lo, math.max(lo, hi)) * 1000
            end
        end
    end)
end

AddEventHandler('onResourceStop', function(name)
    if name ~= GetCurrentResourceName() then return end
    stopCam()
    if customer and customer.ped and DoesEntityExist(customer.ped) then DeleteEntity(customer.ped) end
    for id in pairs(thieves) do endChase(id, false) end
end)
