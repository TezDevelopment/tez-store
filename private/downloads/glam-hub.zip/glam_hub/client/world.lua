-- In-world parts: interaction points (E prompt or target), hub peds, beauty tables, placement and zone blips

local points = {}          -- id -> { x, y, z, dist, label, icon, use, can }
local targetZones = {}     -- id -> zone handle / name
local peds = {}            -- index -> ped
local pedBlips = {}
local tableObjects = {}    -- index -> object
local tableBlips = {}
local zoneBlips = {}
local lastWorldKey = ''

local function setting(k) return C.settings and C.settings[k] end
local function useTarget()
    if setting('interact') ~= 'target' then return nil end
    local want = setting('targetResource')
    if want == 'ox_target' or (want == 'auto' and GetResourceState('ox_target') == 'started') then
        if GetResourceState('ox_target') == 'started' then return 'ox' end
    end
    if want == 'qb-target' or want == 'auto' then
        if GetResourceState('qb-target') == 'started' then return 'qb' end
    end
    return nil
end

-- ------------------------------------------------------------ interaction points

local function removeTargets()
    local kind = useTarget()
    for id, handle in pairs(targetZones) do
        pcall(function()
            if kind == 'ox' then exports.ox_target:removeZone(handle)
            elseif kind == 'qb' then exports['qb-target']:RemoveZone(handle) end
        end)
        targetZones[id] = nil
    end
end

local function addTarget(id, pt)
    local kind = useTarget()
    if not kind then return end
    pcall(function()
        if kind == 'ox' then
            targetZones[id] = exports.ox_target:addSphereZone({
                coords = vec3(pt.x, pt.y, pt.z), radius = pt.dist,
                options = { { name = 'glam_' .. id, icon = pt.icon or 'fa-solid fa-sparkles', label = pt.label, distance = pt.dist,
                    canInteract = function() return not pt.can or pt.can() end, onSelect = function() pt.use() end } },
            })
        else
            local name = 'glam_' .. id
            exports['qb-target']:AddCircleZone(name, vector3(pt.x, pt.y, pt.z), pt.dist, { name = name, debugPoly = false, useZ = true }, {
                options = { { type = 'client', icon = pt.icon or 'fas fa-star', label = pt.label, canInteract = function() return not pt.can or pt.can() end, action = function() pt.use() end } },
                distance = pt.dist,
            })
            targetZones[id] = name
        end
    end)
end

local function setPoints(newPoints)
    removeTargets()
    points = newPoints
    for id, pt in pairs(points) do addTarget(id, pt) end
end

-- the E prompt
CreateThread(function()
    while true do
        local wait = 500
        if C.ready and not C.open and next(points) and not useTarget() and not C.selling then
            local c = GetEntityCoords(PlayerPedId())
            local best, bestD
            for id, pt in pairs(points) do
                local d = #(c - vector3(pt.x, pt.y, pt.z))
                if d <= pt.dist and (not pt.can or pt.can()) and (not bestD or d < bestD) then best, bestD = pt, d end
            end
            if best then
                wait = 0
                BeginTextCommandDisplayHelp('STRING')
                AddTextComponentSubstringPlayerName(L('prompt.press', best.label))
                EndTextCommandDisplayHelp(0, false, false, -1)
                if IsControlJustPressed(0, 38) and not Bridge.isBusy() then best.use() end
            end
        end
        Wait(wait)
    end
end)

-- ----------------------------------------------------------------- hub peds

local function clearPeds()
    for i, ped in pairs(peds) do if DoesEntityExist(ped) then DeleteEntity(ped) end peds[i] = nil end
    for i, b in pairs(pedBlips) do if DoesBlipExist(b) then RemoveBlip(b) end pedBlips[i] = nil end
end

local function loadModel(name)
    local hash = joaat(name)
    if not IsModelInCdimage(hash) then return nil end
    RequestModel(hash)
    local t = GetGameTimer() + 4000
    while not HasModelLoaded(hash) and GetGameTimer() < t do Wait(10) end
    return HasModelLoaded(hash) and hash or nil
end

local function spawnPeds()
    clearPeds()
    for i, def in ipairs(setting('hubPeds') or {}) do
        local hash = loadModel(def.model)
        if hash then
            local z = def.z
            local ped = CreatePed(4, hash, def.x, def.y, z, def.h, false, true)
            SetEntityInvincible(ped, true)
            SetBlockingOfNonTemporaryEvents(ped, true)
            FreezeEntityPosition(ped, true)
            SetPedCanRagdoll(ped, false)
            TaskStartScenarioInPlace(ped, 'WORLD_HUMAN_STAND_IMPATIENT', 0, true)
            SetModelAsNoLongerNeeded(hash)
            peds[i] = ped
        end
        if def.blip then
            local b = AddBlipForCoord(def.x, def.y, def.z)
            SetBlipSprite(b, setting('blipSprite') or 71)
            SetBlipColour(b, setting('blipColour') or 8)
            SetBlipScale(b, 0.85)
            SetBlipAsShortRange(b, true)
            BeginTextCommandSetBlipName('STRING')
            AddTextComponentSubstringPlayerName(def.label)
            EndTextCommandSetBlipName(b)
            pedBlips[i] = b
        end
    end
end

-- ------------------------------------------------------------------- tables

local function clearTables()
    for i, o in pairs(tableObjects) do if DoesEntityExist(o) then DeleteEntity(o) end tableObjects[i] = nil end
    for i, b in pairs(tableBlips) do if DoesBlipExist(b) then RemoveBlip(b) end tableBlips[i] = nil end
end

RegisterNetEvent('glam:tables', function(list)
    C.tables = list
    clearTables()
    if C.syncWorld then C.syncWorld() end
end)

-- tables are spawned only while the player is close
CreateThread(function()
    while true do
        Wait(1500)
        if C.ready and C.tables then
            local c = GetEntityCoords(PlayerPedId())
            local model = joaat(setting('tableModel') or 'prop_table_03')
            for i, t in ipairs(C.tables) do
                local near = #(c - vector3(t.x, t.y, t.z)) < 90.0
                local o = tableObjects[i]
                if near and (not o or not DoesEntityExist(o)) then
                    if IsModelInCdimage(model) then
                        RequestModel(model)
                        local w = GetGameTimer() + 3000
                        while not HasModelLoaded(model) and GetGameTimer() < w do Wait(10) end
                        if HasModelLoaded(model) then
                            local obj = CreateObjectNoOffset(model, t.x, t.y, t.z, false, false, false)
                            SetEntityHeading(obj, t.h)
                            PlaceObjectOnGroundProperly(obj)
                            FreezeEntityPosition(obj, true)
                            tableObjects[i] = obj
                        end
                    end
                elseif not near and o and DoesEntityExist(o) then
                    DeleteEntity(o)
                    tableObjects[i] = nil
                end
                if t.mine and setting('tableBlip') and not tableBlips[i] then
                    local b = AddBlipForCoord(t.x, t.y, t.z)
                    SetBlipSprite(b, 569)
                    SetBlipColour(b, setting('blipColour') or 8)
                    SetBlipScale(b, 0.7)
                    SetBlipAsShortRange(b, true)
                    BeginTextCommandSetBlipName('STRING')
                    AddTextComponentSubstringPlayerName(L('ui.beautytable'))
                    EndTextCommandSetBlipName(b)
                    tableBlips[i] = b
                end
            end
        end
    end
end)

-- placing a table: a ghost follows the crosshair. E places, Backspace cancels, arrow keys / wheel turn it.
local placing = false

RegisterNetEvent('glam:useTable', function()
    if placing or not C.ready or Bridge.isBusy() then return end
    local model = joaat(setting('tableModel') or 'prop_table_03')
    if not IsModelInCdimage(model) then return C.toast(L('err.badmodel'), 'error') end
    placing = true
    CreateThread(function()
        RequestModel(model)
        while not HasModelLoaded(model) do Wait(10) end
        local ghost = CreateObjectNoOffset(model, 0.0, 0.0, 0.0, false, false, false)
        SetEntityAlpha(ghost, 150, false)
        SetEntityCollision(ghost, false, false)
        local heading = GetEntityHeading(PlayerPedId())
        local confirmed
        while true do
            Wait(0)
            local ped = PlayerPedId()
            local pos = GetOffsetFromEntityInWorldCoords(ped, 0.0, 1.8, 0.0)
            local found, z = GetGroundZFor_3dCoord(pos.x, pos.y, pos.z + 1.0, false)
            SetEntityCoordsNoOffset(ghost, pos.x, pos.y, found and z or pos.z - 1.0, false, false, false)
            SetEntityHeading(ghost, heading)
            if IsControlPressed(0, 174) or IsControlPressed(0, 241) then heading = heading + 1.5 end
            if IsControlPressed(0, 175) or IsControlPressed(0, 242) then heading = heading - 1.5 end
            DisableControlAction(0, 24, true)
            BeginTextCommandDisplayHelp('STRING')
            AddTextComponentSubstringPlayerName(L('place.help'))
            EndTextCommandDisplayHelp(0, false, false, -1)
            if IsControlJustPressed(0, 38) then
                local gc = GetEntityCoords(ghost)
                confirmed = { x = gc.x, y = gc.y, z = gc.z, h = heading }
                break
            end
            if IsControlJustPressed(0, 177) or IsControlJustPressed(0, 194) or Bridge.isBusy() then break end
        end
        DeleteEntity(ghost)
        SetModelAsNoLongerNeeded(model)
        placing = false
        if confirmed then TriggerServerEvent('glam:placeTable', confirmed) end
    end)
end)

-- ---------------------------------------------------------------- zone blips

local function clearZoneBlips()
    for _, b in pairs(zoneBlips) do if DoesBlipExist(b) then RemoveBlip(b) end end
    zoneBlips = {}
end

local function syncZones()
    clearZoneBlips()
    local zones = setting('boostZones') or {}
    for _, i in ipairs(C.zones or {}) do
        local z = zones[i]
        if z and z.blip then
            local r = AddBlipForRadius(z.x, z.y, z.z, z.radius + 0.0)
            SetBlipColour(r, 8)
            SetBlipAlpha(r, 70)
            zoneBlips[#zoneBlips + 1] = r
            local b = AddBlipForCoord(z.x, z.y, z.z)
            SetBlipSprite(b, 617)
            SetBlipColour(b, 8)
            SetBlipScale(b, 0.75)
            SetBlipAsShortRange(b, true)
            BeginTextCommandSetBlipName('STRING')
            AddTextComponentSubstringPlayerName(('%s +%d%%'):format(z.label, math.floor(z.bonus)))
            EndTextCommandSetBlipName(b)
            zoneBlips[#zoneBlips + 1] = b
        end
    end
end

-- ------------------------------------------------------------------ sync

function C.syncWorld()
    local key = json.encode({ setting('hubPeds'), setting('interact'), setting('targetResource'), setting('tableModel'), setting('boostZones'), setting('blipSprite'), setting('blipColour'), C.zones, C.tables })
    local newPoints = {}
    for i, def in ipairs(setting('hubPeds') or {}) do
        newPoints['ped' .. i] = { x = def.x, y = def.y, z = def.z, dist = setting('pedDistance') or 2.5, label = def.label, icon = 'fa-solid fa-spa',
            use = function() C.requestOpen(nil) end }
    end
    for i, t in ipairs(C.tables or {}) do
        if t.mine then
            newPoints['craft' .. i] = { x = t.x, y = t.y, z = t.z, dist = setting('tableDistance') or 2.5, label = L('prompt.craft'), icon = 'fa-solid fa-wand-magic-sparkles',
                use = function() C.requestOpen('craft') end }
            newPoints['pickup' .. i] = { x = t.x, y = t.y, z = t.z + 0.3, dist = (setting('tableDistance') or 2.5) - 0.5, label = L('prompt.pickup'), icon = 'fa-solid fa-hand',
                use = function()
                    local r = C.req('tablePickup', {})
                    if r.ok then C.toast(L('note.tablepicked'), 'success') else C.toast(r.payload, 'error') end
                end }
        end
    end
    if key == lastWorldKey then return end
    local pedsChanged = json.encode({ setting('hubPeds'), setting('blipSprite'), setting('blipColour') }) ~= (C._pedKey or '')
    lastWorldKey = key
    setPoints(newPoints)
    if pedsChanged then C._pedKey = json.encode({ setting('hubPeds'), setting('blipSprite'), setting('blipColour') }) CreateThread(spawnPeds) end
    syncZones()
    clearTables()
end

AddEventHandler('onResourceStop', function(name)
    if name ~= GetCurrentResourceName() then return end
    removeTargets()
    clearPeds()
    clearTables()
    clearZoneBlips()
end)
