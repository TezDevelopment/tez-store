-- Framework, inventory and vehicle bridge (server). Edit this file to connect your own framework.
-- Every function the rest of the resource needs from your framework is here.

Bridge = { framework = 'standalone', inventory = 'none', ready = false }

local ESX, QBCore, Qbox

local function started(name) return GetResourceState(name) == 'started' end

local function account(a)
    if a == 'cash' then return Config.Accounts.cash end
    return Config.Accounts.bank
end

function Bridge.init()
    local fw = GH.get('framework')
    if fw == 'auto' then
        for _ = 1, 40 do
            if started('es_extended') then fw = 'esx' break end
            if started('qbx_core') then fw = 'qbox' break end
            if started('qb-core') then fw = 'qb' break end
            Wait(500)
        end
        if fw == 'auto' then fw = 'standalone' end
    end
    Bridge.framework = fw
    if fw == 'esx' then
        ESX = exports['es_extended']:getSharedObject()
        Config.Accounts.cash = 'money'
    elseif fw == 'qb' then
        QBCore = exports['qb-core']:GetCoreObject()
        Config.Accounts.cash = 'cash'
    elseif fw == 'qbox' then
        Qbox = exports.qbx_core
        QBCore = nil
        Config.Accounts.cash = 'cash'
    end

    local inv = GH.get('inventory')
    if inv == 'auto' then
        if started('ox_inventory') then inv = 'ox'
        elseif started('qs-inventory') then inv = 'qs'
        elseif started('qb-inventory') then inv = 'qb'
        elseif fw == 'esx' then inv = 'esx'
        else inv = 'none' end
    end
    Bridge.inventory = inv
    Bridge.ready = true
end

function Bridge.hasMoney() return Bridge.framework ~= 'standalone' end
function Bridge.hasInventory() return Bridge.inventory ~= 'none' end

-- ---------------------------------------------------------------- players

function Bridge.player(src)
    if Bridge.framework == 'esx' then return ESX.GetPlayerFromId(src) end
    if Bridge.framework == 'qb' then return QBCore.Functions.GetPlayer(src) end
    if Bridge.framework == 'qbox' then return Qbox:GetPlayer(src) end
    return GetPlayerName(src) and { standalone = true } or nil
end

function Bridge.identifier(src)
    local p = Bridge.player(src)
    if not p then return nil end
    if Bridge.framework == 'esx' then return p.identifier end
    if Bridge.framework == 'qb' or Bridge.framework == 'qbox' then return p.PlayerData.citizenid end
    return GetPlayerIdentifierByType(src, 'license')
end

function Bridge.name(src)
    local p = Bridge.player(src)
    if not p then return GetPlayerName(src) or ('Player ' .. tostring(src)) end
    if Bridge.framework == 'esx' then
        local ok, n = pcall(function() return p.getName() end)
        if ok and n and n ~= '' then return n end
    elseif Bridge.framework == 'qb' or Bridge.framework == 'qbox' then
        local ci = p.PlayerData.charinfo
        if ci then return (ci.firstname or '') .. ' ' .. (ci.lastname or '') end
    end
    return GetPlayerName(src) or ('Player ' .. tostring(src))
end

function Bridge.getJob(src)
    local p = Bridge.player(src)
    if not p then return nil, 0 end
    if Bridge.framework == 'esx' then return p.job and p.job.name, p.job and p.job.grade or 0 end
    if Bridge.framework == 'qb' or Bridge.framework == 'qbox' then
        local j = p.PlayerData.job
        return j and j.name, j and j.grade and (j.grade.level or j.grade) or 0
    end
    return nil, 0
end

function Bridge.inGroup(src, groups)
    if not groups or #groups == 0 then return false end
    if Bridge.framework == 'esx' then
        local p = Bridge.player(src)
        local g = p and p.getGroup and p.getGroup()
        for _, name in ipairs(groups) do if g == name then return true end end
    elseif Bridge.framework == 'qb' then
        for _, name in ipairs(groups) do
            if QBCore.Functions.HasPermission(src, name) then return true end
        end
    end
    for _, name in ipairs(groups) do
        if IsPlayerAceAllowed(src, 'group.' .. name) then return true end
    end
    return false
end

-- ------------------------------------------------------------------ money

function Bridge.getMoney(src, acct)
    local p = Bridge.player(src)
    if not p then return 0 end
    local a = account(acct)
    if Bridge.framework == 'esx' then
        local acc = p.getAccount(a)
        return acc and acc.money or 0
    elseif Bridge.framework == 'qb' or Bridge.framework == 'qbox' then
        return p.PlayerData.money[a] or 0
    end
    return 0
end

function Bridge.addMoney(src, acct, amount, reason)
    local p = Bridge.player(src)
    amount = math.floor(amount or 0)
    if not p or amount <= 0 or not Bridge.hasMoney() then return false end
    local a = account(acct)
    if Bridge.framework == 'esx' then
        p.addAccountMoney(a, amount, reason or 'glam_hub')
        return true
    end
    return p.Functions.AddMoney(a, amount, reason or 'glam_hub') ~= false
end

function Bridge.removeMoney(src, acct, amount, reason)
    local p = Bridge.player(src)
    amount = math.floor(amount or 0)
    if not p or amount <= 0 or not Bridge.hasMoney() then return false end
    if Bridge.getMoney(src, acct) < amount then return false end
    local a = account(acct)
    if Bridge.framework == 'esx' then
        p.removeAccountMoney(a, amount, reason or 'glam_hub')
        return true
    end
    return p.Functions.RemoveMoney(a, amount, reason or 'glam_hub') ~= false
end

-- ---------------------------------------------------------------- inventory

function Bridge.itemCount(src, item)
    local inv = Bridge.inventory
    local ok, n = pcall(function()
        if inv == 'ox' then return exports.ox_inventory:GetItemCount(src, item) end
        if inv == 'qs' then return exports['qs-inventory']:GetItemTotalAmount(src, item) end
        if inv == 'qb' then
            local p = Bridge.player(src)
            local total = 0
            for _, it in pairs(p and p.PlayerData.items or {}) do
                if it and it.name == item then total = total + (it.amount or it.count or 0) end
            end
            return total
        end
        if inv == 'esx' then
            local p = Bridge.player(src)
            local i = p and p.getInventoryItem(item)
            return i and i.count or 0
        end
        return 0
    end)
    return ok and tonumber(n) or 0
end

function Bridge.canCarry(src, item, count)
    local inv = Bridge.inventory
    local ok, res = pcall(function()
        if inv == 'ox' then return exports.ox_inventory:CanCarryItem(src, item, count) end
        if inv == 'qs' then return exports['qs-inventory']:CanCarryItem(src, item, count) end
        if inv == 'qb' then return exports['qb-inventory']:CanAddItem(src, item, count) end
        if inv == 'esx' then
            local p = Bridge.player(src)
            return p.canCarryItem(item, count)
        end
        return false
    end)
    if ok then return res and true or false end
    return true   -- when the inventory cannot say, let the add decide
end

function Bridge.addItem(src, item, count)
    count = math.floor(count or 0)
    if count <= 0 then return true end
    local inv = Bridge.inventory
    local ok, res = pcall(function()
        if inv == 'ox' then return exports.ox_inventory:AddItem(src, item, count) end
        if inv == 'qs' then return exports['qs-inventory']:AddItem(src, item, count) end
        if inv == 'qb' then return exports['qb-inventory']:AddItem(src, item, count, false, {}, 'glam_hub') end
        if inv == 'esx' then
            local p = Bridge.player(src)
            p.addInventoryItem(item, count)
            return true
        end
        return false
    end)
    return ok and res and true or false
end

function Bridge.removeItem(src, item, count)
    count = math.floor(count or 0)
    if count <= 0 then return true end
    if Bridge.itemCount(src, item) < count then return false end
    local inv = Bridge.inventory
    local ok, res = pcall(function()
        if inv == 'ox' then return exports.ox_inventory:RemoveItem(src, item, count) end
        if inv == 'qs' then return exports['qs-inventory']:RemoveItem(src, item, count) end
        if inv == 'qb' then return exports['qb-inventory']:RemoveItem(src, item, count, false, 'glam_hub') end
        if inv == 'esx' then
            local p = Bridge.player(src)
            p.removeInventoryItem(item, count)
            return true
        end
        return false
    end)
    return ok and res and true or false
end

-- true / false when the inventory can say whether an item is registered, nil when it cannot
function Bridge.itemExists(name)
    local inv = Bridge.inventory
    local ok, res = pcall(function()
        if inv == 'ox' then return exports.ox_inventory:Items(name) ~= nil end
        if inv == 'esx' then return MySQL.scalar.await('SELECT 1 FROM items WHERE name = ?', { name }) ~= nil end
        if inv == 'qb' or inv == 'qs' then
            local shared = Bridge.framework == 'qbox' and exports.qbx_core:GetItems() or (QBCore and QBCore.Shared.Items)
            if shared then return shared[name] ~= nil end
        end
        return nil
    end)
    if ok then return res end
    return nil
end

-- Called when a player uses one of these items (ESX and QBCore register them here;
-- with ox_inventory the item has a client event, see install/ox_items.lua)
function Bridge.registerUsable(item, fn)
    pcall(function()
        if Bridge.framework == 'esx' and Bridge.inventory ~= 'ox' then
            ESX.RegisterUsableItem(item, function(src) fn(src) end)
        elseif (Bridge.framework == 'qb' or Bridge.framework == 'qbox') and Bridge.inventory ~= 'ox' then
            local core = QBCore or exports['qb-core']:GetCoreObject()
            core.Functions.CreateUseableItem(item, function(src) fn(src) end)
        end
    end)
end

-- ---------------------------------------------------------------- jobs and vehicles

-- ESX only: makes sure every hub job exists as a framework job
function Bridge.syncJobs(jobs)
    if Bridge.framework ~= 'esx' then return end
    pcall(function()
        for _, j in ipairs(jobs) do
            local exists = MySQL.scalar.await('SELECT 1 FROM jobs WHERE name = ?', { j.id })
            if not exists then
                MySQL.query.await('INSERT INTO jobs (name, label) VALUES (?, ?)', { j.id, j.label })
                MySQL.query.await("INSERT INTO job_grades (job_name, grade, name, label, salary, skin_male, skin_female) VALUES (?, 0, 'employee', 'Employee', ?, '{}', '{}')",
                    { j.id, 0 })
            end
        end
        if ESX.RefreshJobs then ESX.RefreshJobs() end
    end)
end

function Bridge.givePlate(format)
    format = format ~= '' and format or 'GLAM####'
    local out = format:gsub('[#A]', function(c)
        if c == '#' then return tostring(math.random(0, 9)) end
        return string.char(math.random(65, 90))
    end)
    return out:sub(1, 8):upper()
end

-- Puts a vehicle in the player's garage. Returns the plate, or nil when it could not.
function Bridge.giveVehicle(src, model, plate)
    local id = Bridge.identifier(src)
    if not id then return nil end
    local hash = joaat(model)
    local ok, res = pcall(function()
        if Bridge.framework == 'esx' then
            MySQL.insert.await('INSERT INTO owned_vehicles (owner, plate, vehicle, stored) VALUES (?, ?, ?, 1)',
                { id, plate, json.encode({ model = hash, plate = plate }) })
            return plate
        elseif Bridge.framework == 'qb' or Bridge.framework == 'qbox' then
            local license = GetPlayerIdentifierByType(src, 'license') or ''
            MySQL.insert.await(
                'INSERT INTO player_vehicles (license, citizenid, vehicle, hash, mods, plate, garage, state) VALUES (?, ?, ?, ?, ?, ?, ?, 1)',
                { license, id, model, tostring(hash), '{}', plate, GH.get('garage') })
            return plate
        end
        return nil
    end)
    if ok then return res end
    print('[glam_hub] could not add the starter car: ' .. tostring(res))
    return nil
end

-- ------------------------------------------------------------------ loaded events

AddEventHandler('esx:playerLoaded', function(playerId)
    TriggerEvent('glam_hub:internalLoaded', playerId)
end)
AddEventHandler('QBCore:Server:PlayerLoaded', function(player)
    local id = player and player.PlayerData and player.PlayerData.source
    if id then TriggerEvent('glam_hub:internalLoaded', id) end
end)
RegisterNetEvent('qbx_core:server:playerLoaded', function()
    TriggerEvent('glam_hub:internalLoaded', source)
end)
