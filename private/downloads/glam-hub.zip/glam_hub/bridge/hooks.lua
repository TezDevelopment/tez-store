-- Open hooks. Put your own code here: it runs after the matching thing happened.
-- Every function can be left empty.

Hooks = {}

-- player = source id, product = item name, count, total = money paid, thief = bool
function Hooks.onSale(player, product, count, total, thief) end
function Hooks.onCraft(player, product, count) end
function Hooks.onPost(player, photoId) end
function Hooks.onStaffAction(staffSource, action, targetIdentifier) end
function Hooks.onPrize(identifier, board, period, place, cash) end

-- Return false to stop the hub from opening for this player (for example while cuffed or downed)
function Hooks.canOpen(player)
    return true
end

-- Your own notification system. Return true if you showed it, false to use the built-in one.
function Hooks.notify(player, message, kind)
    return false
end

-- Plate for starter cars
function Hooks.plate(player, format)
    return Bridge.givePlate(format)
end
