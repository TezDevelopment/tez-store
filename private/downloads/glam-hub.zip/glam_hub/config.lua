Config = {}

-- Almost everything is changed IN GAME with /glamadmin (saved in the database).
-- This file only holds what has to be known before the database loads.

Config.Locale = 'en'        -- file in /locales
Config.Debug  = false
Config.AdminCommand = 'glamadmin'

-- Account names used by your framework (the resource fills these in automatically)
Config.Accounts = {
    bank = 'bank',
    cash = 'money',            -- ESX 'money', QBCore 'cash'
}

-- Optional: URL of a text file that contains only the newest version number (e.g. 1.0.1)
Config.VersionUrl = ''
