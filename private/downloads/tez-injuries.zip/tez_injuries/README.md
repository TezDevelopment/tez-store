# tez_injuries
Realistic gunshot injuries for ESX Legacy. Made by Tez Development.

## What it does
- **Shot in a leg** (thigh, calf or foot): you limp with the injured walk, move slower, and cannot run or jump.
  The injury screen shows a body figure with a glowing spot on every wound and says where you were shot.
- **Shot in the stomach**: you are knocked down, get up limping and hold your stomach until you are patched.
- **Shot in the shoulder**: you are knocked to the ground (ragdoll), pushed away from the shooter, and you get up limping.
- Your free hand holds an arm wound until you are patched.
- **Shot in the shoulder**: you cannot fire your gun until you use a bandage.
- **Hit feed at the top of the screen** for every bullet: "Shot in the left calf", with a small body
  diagram showing the exact spot. Same spot twice shows x2.
- The limp stays until the leg is patched. It is saved, so it survives logging out.
- **Patching**: use a bandage item on yourself (takes about 9 seconds, press X to cancel), or an EMS
  player stands next to you and presses E (free, takes about 7 seconds).
- **Buying**: bandage desks at Pillbox, Sandy Shores and Paleto (edit in `config.lua`).

## Install (ESX Legacy + oxmysql)
1. Put the `tez_injuries` folder in your `resources` folder.
2. Run `sql/install.sql` on your database (it makes the table and the `bandage` item).
3. Add `ensure tez_injuries` to `server.cfg` (after `es_extended` and `oxmysql`).
4. Restart the server, or run `ensure tez_injuries`.

### Using ox_inventory
Set `Config.Inventory = 'ox'` in `config.lua`, do not run the `items` line of the SQL, and add this to
`ox_inventory/data/items.lua`:

```lua
['bandage'] = {
    label = 'Bandage',
    weight = 100,
    stack = true,
    close = true,
    client = { event = 'tez_injuries:useBandage' },
},
```

## Config
Everything is in `config.lua`: EMS job names, bandage price, shop places, limp speed, how often a
back or shoulder hit knocks you down, how long you stay down, and all the text.

## Notes
- Only the legs, shoulders and stomach count. Arms, hands, head, neck, chest and back shots do nothing special.
- **Bleeding out**: the first wound starts a 10 minute clock (`Config.Bleed.minutes`). A bandage or EMS stops it. If it runs out you die. The clock is saved and does not run while you are dead.
- Only **bullet** hits from another person count. Cars, falls, fists, explosions and fire do nothing.
- A client can only add an injury, never remove one. Removing is done by the server after the item is
  used or EMS finishes patching.
- Set `Config.ClearOnRevive = true` if you want an EMS revive to also heal the legs.
