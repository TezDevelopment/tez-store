local ESX = exports['es_extended']:getSharedObject()

local injury = { left = false, right = false, arm = false, limp = false, wounds = {} }
local treating = false       -- bandaging in progress (self, EMS or being treated)
local lastFall = 0
local appliedSet = nil       -- clipset currently applied by us
local lastHit = {}           -- debounce [zone key] = game timer
local wasInVehicle = false

local function T(key, ...) local s = Config.Text[key] or key; if select('#', ...) > 0 then return s:format(...) end return s end
local function limping() return injury.left or injury.right or injury.limp end
local function hurt() return injury.left or injury.right or injury.arm or injury.limp end

-- ------------------------------------------------------------------ bones -> body zones
-- only these three zones do anything: leg (thigh, calf, foot) | shoulder | stomach
local B = {}
local function add(ids, part, side, label) for _, id in ipairs(ids) do B[id] = { part = part, side = side, label = label } end end
add({ 58271 }, 'leg', 'left', 'left thigh')
add({ 63931 }, 'leg', 'left', 'left calf')
add({ 14201, 2108 }, 'leg', 'left', 'left foot')
add({ 51826 }, 'leg', 'right', 'right thigh')
add({ 36864 }, 'leg', 'right', 'right calf')
add({ 52301, 20781 }, 'leg', 'right', 'right foot')
add({ 64729, 45509 }, 'shoulder', 'left', 'left shoulder')
add({ 10706, 40269 }, 'shoulder', 'right', 'right shoulder')
-- stomach = the lower spine / pelvis bones, shot from any direction. Chest, upper back, head and neck are ignored.
local STOMACH = { [23553] = true, [24816] = true, [57597] = true, [11816] = true, [0] = true }

local function classify(bone)
    local z = B[bone]
    if z then return z end
    if STOMACH[bone] then return { part = 'stomach', label = 'stomach' } end
    return nil
end

-- ------------------------------------------------------------------ UI
local function ui(data) SendNUIMessage(data) end

local function refreshBanner()
    if not hurt() then ui({ action = 'status', visible = false }) return end
    local w = injury.wounds
    local title
    if #w == 1 then title = T('shotIn', w[1])
    elseif #w > 1 then title = T('shotMany', #w)
    else title = T('hurtTitle') end
    local chips = {}
    if limping() then chips[#chips + 1] = T('chipLimp') end
    if injury.arm then chips[#chips + 1] = T('chipArm') end
    for _, wl in ipairs(w) do
        if Config.Shoulder.noFire and wl:find('shoulder') then chips[#chips + 1] = T('chipNoFire') break end
    end
    ui({ action = 'status', visible = true, title = title, wounds = w, chips = chips, hint = T('hint') })
end

-- ------------------------------------------------------------------ limp
local function loadSet(set)
    if HasAnimSetLoaded(set) then return true end
    RequestAnimSet(set)
    local t = GetGameTimer() + 4000
    while not HasAnimSetLoaded(set) and GetGameTimer() < t do Wait(10) end
    return HasAnimSetLoaded(set)
end

local function applyLimp()
    local ped = PlayerPedId()
    if loadSet(Config.Limp.clipset) then
        SetPedMovementClipset(ped, Config.Limp.clipset, Config.Limp.blend)
        appliedSet = Config.Limp.clipset
    end
end

local function removeLimp()
    local ped = PlayerPedId()
    if appliedSet then ResetPedMovementClipset(ped, 0.5) end
    SetPedMoveRateOverride(ped, 1.0)
    appliedSet = nil
end

local function setInjury(left, right, arm, limp, wounds)
    local was = limping()
    injury.left, injury.right, injury.arm, injury.limp = left and true or false, right and true or false, arm and true or false, limp and true or false
    injury.wounds = type(wounds) == 'table' and wounds or {}
    if limping() then applyLimp() elseif was then removeLimp() end
    refreshBanner()
end

local function showBleed(left)
    ui({ action = 'bleed', left = Config.Bleed.enabled and left or 0, total = (Config.Bleed.minutes or 10) * 60, label = T('bleeding') })
end

RegisterNetEvent('tez_injuries:set', function(left, right, arm, limp, wounds, bleed)
    setInjury(left, right, arm, limp, wounds)
    showBleed(bleed)
end)

-- the server sends the time left every few seconds so the countdown stays honest
RegisterNetEvent('tez_injuries:bleed', function(left) showBleed(left) end)

-- time ran out
RegisterNetEvent('tez_injuries:bleedOut', function()
    local ped = PlayerPedId()
    ESX.ShowNotification(T('bledOut'))
    if not IsEntityDead(ped) then SetEntityHealth(ped, 0) end
end)

-- keep the limp on: movement sets get dropped by vehicles, ragdoll, respawns
CreateThread(function()
    while true do
        if limping() then
            local ped = PlayerPedId()
            local inVeh = IsPedInAnyVehicle(ped, false)
            if wasInVehicle and not inVeh then applyLimp() end
            wasInVehicle = inVeh
            if not inVeh and not IsPedRagdoll(ped) and not IsEntityDead(ped) and appliedSet ~= Config.Limp.clipset then applyLimp() end
            Wait(500)
        else
            wasInVehicle = false
            Wait(1000)
        end
    end
end)

-- every-frame part: slow walking speed and no sprinting or jumping
CreateThread(function()
    while true do
        if limping() then
            local ped = PlayerPedId()
            if not IsPedInAnyVehicle(ped, false) then
                SetPedMoveRateOverride(ped, (injury.left and injury.right) and Config.Limp.speedBothLegs or Config.Limp.speedOneLeg)
                if Config.Limp.noSprint then DisableControlAction(0, 21, true) end
                if Config.Limp.noJump then DisableControlAction(0, 22, true) end
            end
            Wait(0)
        else
            Wait(500)
        end
    end
end)


-- ------------------------------------------------------------------ clutching the shot arm
local function holdClip() return Config.HoldArm.options[1] end

local function stopHold()
    local o = holdClip()
    local ped = PlayerPedId()
    if o and IsEntityPlayingAnim(ped, o.dict, o.clip, 3) then StopAnimTask(ped, o.dict, o.clip, 1.5) end
end

local function playHold()
    local o = holdClip()
    if not o then return false end
    RequestAnimDict(o.dict)
    local t = GetGameTimer() + 3000
    while not HasAnimDictLoaded(o.dict) and GetGameTimer() < t do Wait(10) end
    if not HasAnimDictLoaded(o.dict) then return false end
    -- flag 49 = loop + upper body only + you can still walk
    TaskPlayAnim(PlayerPedId(), o.dict, o.clip, 4.0, -4.0, -1, Config.HoldArm.flags or 49, 0.0, false, false, false)
    return true
end

-- which arm was shot (from the wound list), so the OTHER hand reaches for it
local function woundedSide()
    for i = #injury.wounds, 1, -1 do
        local w = injury.wounds[i]
        if w:find('shoulder') or w:find('forearm') or w:find('hand') then return w:find('left') and 'left' or 'right' end
    end
    return 'right'
end

-- what is being held: the most recent of an arm wound or the stomach
local function holdKind()
    for i = #injury.wounds, 1, -1 do
        local w = injury.wounds[i]
        if w == 'stomach' then return 'stomach' end
        if w:find('shoulder') or w:find('forearm') or w:find('hand') then return 'arm' end
    end
    return 'arm'
end

-- both hands go to the belly
local function reachForStomach(ped)
    local bone = GetPedBoneIndex(ped, 23553)
    SetIkTarget(ped, Config.HoldArm.ikIndex.left, ped, bone, 0.0, 0.0, 0.0, 0, 900, 900)
    SetIkTarget(ped, Config.HoldArm.ikIndex.right, ped, bone, 0.0, 0.0, 0.0, 0, 900, 900)
end

local function reachForWound(ped)
    local side = woundedSide()
    local bone = GetPedBoneIndex(ped, side == 'left' and 45509 or 40269)  -- upper arm of the shot side
    local ik = side == 'left' and Config.HoldArm.ikIndex.right or Config.HoldArm.ikIndex.left
    SetIkTarget(ped, ik, ped, bone, 0.0, 0.0, 0.0, 0, 900, 900)
end

local wasHold = false
CreateThread(function()
    while true do
        local holding = Config.HoldArm.enabled and injury.arm
        if wasHold and not holding then stopHold() end
        wasHold = holding
        if holding then
            local ped = PlayerPedId()
            local busy = IsPedInAnyVehicle(ped, false) or IsPedRagdoll(ped) or IsEntityDead(ped) or treating or IsPlayerFreeAiming(PlayerId()) or IsPedFalling(ped)
            local o = holdClip()
            if holdKind() == 'stomach' then
                if not busy then
                    stopHold()
                    if Config.HoldArm.ik then reachForStomach(ped) end
                end
            else
                if not busy and o and not IsEntityPlayingAnim(ped, o.dict, o.clip, 3) then playHold() end
                if not busy and Config.HoldArm.ik then reachForWound(ped) end
            end
            Wait(400)
        else
            Wait(800)
        end
    end
end)


-- ------------------------------------------------------------------ fall
local function fall(ped, attacker, partKey)
    if IsPedInAnyVehicle(ped, false) or IsPedRagdoll(ped) or treating then return end
    if GetGameTimer() - lastFall < Config.Fall.cooldown * 1000 then return end
    local chance = Config.Fall.chance[partKey] or 0
    if math.random() > chance then return end
    lastFall = GetGameTimer()

    local fx, fy
    if attacker and attacker ~= 0 and DoesEntityExist(attacker) then
        local a, v = GetEntityCoords(attacker), GetEntityCoords(ped)
        local dx, dy = v.x - a.x, v.y - a.y
        local len = math.sqrt(dx * dx + dy * dy)
        if len > 0.01 then fx, fy = dx / len, dy / len end
    end
    if not fx then
        local f = GetEntityForwardVector(ped)
        fx, fy = f.x, f.y
    end

    local t = math.random(Config.Fall.ragdollMin, Config.Fall.ragdollMax)
    SetPedToRagdoll(ped, t, t, 0, false, false, false)
    Wait(0)
    ApplyForceToEntity(ped, 1, fx * Config.Fall.force, fy * Config.Fall.force, 1.5, 0.0, 0.0, 0.0, 0, false, true, true, false, true)
end

-- ------------------------------------------------------------------ taking a hit
-- remember where you were shot, set limp / arm hold, tell the server
local function hasWound(label) for _, w in ipairs(injury.wounds) do if w == label then return true end end return false end

local function applyWound(z)
    local isLeg = z.part == 'leg'
    local isArm = z.part == 'shoulder'
    local isStomach = z.part == 'stomach'
    if not (isLeg or isArm or isStomach) then return false end
    local l, r, a, lp = injury.left, injury.right, injury.arm, injury.limp
    if isLeg then
        l = l or z.side == 'left'
        r = r or z.side == 'right'
    elseif Config.Fall.getUpLimp then
        lp = true                      -- you get up limping
    end
    if (isArm or isStomach) and Config.HoldArm.enabled then a = true end
    local wounds = {}
    for i, w in ipairs(injury.wounds) do wounds[i] = w end
    if not hasWound(z.label) then
        wounds[#wounds + 1] = z.label
        while #wounds > 6 do table.remove(wounds, 1) end
    end
    setInjury(l, r, a, lp, wounds)
    TriggerServerEvent('tez_injuries:report', l, r, a, lp, wounds)
    return true
end

local function feed(z, count)
    ui({ action = 'feed', part = z.part, side = z.side, label = z.label, text = T('shotIn', z.label), count = count or 1, seconds = Config.FeedSeconds })
end

local recent = { key = nil, at = 0, n = 0 }

local function onHit(bone, attacker)
    local ped = PlayerPedId()
    local z = classify(bone)
    if not z then return end

    -- stack repeats of the same spot into "x2", "x3"
    local now = GetGameTimer()
    local key = z.label
    if recent.key == key and now - recent.at < 2500 then recent.n = recent.n + 1 else recent.n = 1 end
    recent.key, recent.at = key, now
    feed(z, recent.n)

    if not applyWound(z) then return end
    fall(ped, attacker, z.part)
end

-- Only a bullet from another person counts. Cars, falls, fire, explosions and fists never do.
local function bulletFrom(ped, attacker, weapon)
    if attacker == ped then return false end
    if IsPedPerformingMeleeAction(attacker) then return false end   -- punches, kicks, pistol whips
    if weapon and weapon ~= 0 and IsWeaponValid(weapon) then
        return GetWeaponDamageType(weapon) == 3
    end
    -- weapon not reported: only accept it if the shooter is holding a gun and no vehicle hit us
    if HasEntityBeenDamagedByAnyVehicle(ped) then return false end
    local has, held = GetCurrentPedWeapon(attacker, true)
    return has and held ~= 0 and IsWeaponValid(held) and GetWeaponDamageType(held) == 3
end

AddEventHandler('gameEventTriggered', function(name, args)
    if name ~= 'CEventNetworkEntityDamage' then return end
    local ped = PlayerPedId()
    if args[1] ~= ped or IsEntityDead(ped) then return end
    local attacker = args[2]
    if not attacker or attacker == 0 or not DoesEntityExist(attacker) or not IsEntityAPed(attacker) then return end
    if not bulletFrom(ped, attacker, args[5]) then
        ClearEntityLastDamageEntity(ped)
        return
    end
    local ok, bone = GetPedLastDamageBone(ped)
    if not ok then return end
    ClearPedLastDamageBone(ped)
    onHit(bone, attacker)
end)

-- ------------------------------------------------------------------ shot in the shoulder: no shooting until patched
local function shoulderShot()
    for _, w in ipairs(injury.wounds) do if w:find('shoulder') then return true end end
    return false
end

local lastCantFire = 0
CreateThread(function()
    while true do
        if Config.Shoulder.noFire and shoulderShot() then
            local pid = PlayerId()
            DisablePlayerFiring(pid, true)
            DisableControlAction(0, 24, true)   -- attack
            DisableControlAction(0, 257, true)  -- attack 2
            DisableControlAction(0, 69, true)   -- vehicle attack
            DisableControlAction(0, 70, true)
            DisableControlAction(0, 92, true)   -- passenger / driveby attack
            DisableControlAction(0, 114, true)
            if (IsDisabledControlJustPressed(0, 24) or IsDisabledControlJustPressed(0, 257)) and IsPedArmed(PlayerPedId(), 4) and GetGameTimer() - lastCantFire > 4000 then
                lastCantFire = GetGameTimer()
                ESX.ShowNotification(T('cantFire'))
            end
            Wait(0)
        else
            Wait(400)
        end
    end
end)

-- ------------------------------------------------------------------ progress bar + treatment
local function progress(text, seconds)
    ui({ action = 'progress', visible = true, text = text, seconds = seconds })
end
local function progressOff() ui({ action = 'progress', visible = false }) end

-- using a bandage on yourself
RegisterNetEvent('tez_injuries:useBandage', function()
    if treating then return end
    if not hurt() then return ESX.ShowNotification(T('noInjury')) end
    TriggerServerEvent('tez_injuries:canBandage')
end)

RegisterNetEvent('tez_injuries:beginSelf', function()
    if treating then return end
    local ped = PlayerPedId()
    if IsPedInAnyVehicle(ped, false) or IsPedRagdoll(ped) then return end
    treating = true
    TaskStartScenarioInPlace(ped, 'CODE_HUMAN_MEDIC_TEND_TO_DEAD', 0, true)
    progress(T('treating'), Config.Treat.selfSeconds)
    local endAt = GetGameTimer() + Config.Treat.selfSeconds * 1000
    local ok = true
    while GetGameTimer() < endAt do
        Wait(100)
        if IsEntityDead(ped) or IsPedRagdoll(ped) or IsControlJustPressed(0, 73) then ok = false break end
    end
    ClearPedTasks(ped)
    progressOff()
    treating = false
    if ok then TriggerServerEvent('tez_injuries:consume') end
end)

-- EMS patching someone else
local function closestPlayer()
    local me = PlayerPedId()
    local mc = GetEntityCoords(me)
    local best, bd = nil, Config.Treat.distance
    for _, p in ipairs(GetActivePlayers()) do
        local ped = GetPlayerPed(p)
        if ped ~= me then
            local d = #(GetEntityCoords(ped) - mc)
            if d < bd then best, bd = p, d end
        end
    end
    return best
end

-- EMS: stand next to a wounded player and press E
local function isEmsJob()
    local job = ESX.GetPlayerData().job
    if not job then return false end
    for _, j in ipairs(Config.EmsJobs) do if j == job.name then return true end end
    return false
end

CreateThread(function()
    while true do
        local wait = 700
        if not treating and isEmsJob() then
            local target = closestPlayer()
            if target then
                local sid = GetPlayerServerId(target)
                if Player(sid).state.tezHurt then
                    wait = 0
                    ESX.ShowHelpNotification(T('emsPrompt'))
                    if IsControlJustReleased(0, 38) then
                        TriggerServerEvent('tez_injuries:emsTreat', sid)
                        Wait(800)
                    end
                end
            end
        end
        Wait(wait)
    end
end)

RegisterNetEvent('tez_injuries:emsBegin', function(targetSrc)
    if treating then return end
    local ped = PlayerPedId()
    local tp = GetPlayerPed(GetPlayerFromServerId(targetSrc))
    treating = true
    if tp and tp ~= 0 then TaskTurnPedToFaceEntity(ped, tp, 800) Wait(800) end
    TaskStartScenarioInPlace(ped, 'CODE_HUMAN_MEDIC_TEND_TO_DEAD', 0, true)
    progress(T('treatingEms'), Config.Treat.emsSeconds)
    Wait(Config.Treat.emsSeconds * 1000)
    ClearPedTasks(ped)
    progressOff()
    treating = false
end)

RegisterNetEvent('tez_injuries:beingTreated', function(seconds)
    local ped = PlayerPedId()
    treating = true
    FreezeEntityPosition(ped, true)
    progress(T('treatingEms'), seconds)
    Wait(seconds * 1000)
    FreezeEntityPosition(PlayerPedId(), false)
    progressOff()
    treating = false
end)

-- ------------------------------------------------------------------ death, revive, spawn
AddEventHandler('esx:onPlayerDeath', function() TriggerServerEvent('tez_injuries:died') end)

RegisterNetEvent('esx_ambulancejob:revive', function() TriggerServerEvent('tez_injuries:revived') end)

AddEventHandler('esx:onPlayerSpawn', function()
    TriggerServerEvent('tez_injuries:revived')
    appliedSet = nil
    if limping() then Wait(500) applyLimp() end
end)

-- ------------------------------------------------------------------ shops
CreateThread(function()
    if Config.ShopBlips then
        for _, s in ipairs(Config.Shops) do
            local b = AddBlipForCoord(s.coords.x, s.coords.y, s.coords.z)
            SetBlipSprite(b, 153) SetBlipColour(b, 1) SetBlipScale(b, 0.7) SetBlipAsShortRange(b, true)
            BeginTextCommandSetBlipName('STRING') AddTextComponentString(s.label) EndTextCommandSetBlipName(b)
        end
    end
    while true do
        local wait = 800
        local c = GetEntityCoords(PlayerPedId())
        for _, s in ipairs(Config.Shops) do
            local d = #(c - s.coords)
            if d < 12.0 then
                wait = 0
                DrawMarker(1, s.coords.x, s.coords.y, s.coords.z - 0.95, 0.0, 0.0, 0.0, 0.0, 0.0, 0.0, 1.0, 1.0, 0.6, 220, 50, 50, 120, false, false, 2, false, nil, nil, false)
                if d < 1.5 then
                    ESX.ShowHelpNotification(T('buyPrompt', Config.BandagePrice))
                    if IsControlJustReleased(0, 38) then TriggerServerEvent('tez_injuries:buy') Wait(600) end
                end
            end
        end
        Wait(wait)
    end
end)

-- on resource restart, re-show the banner
AddEventHandler('onClientResourceStart', function(res)
    if res == GetCurrentResourceName() then refreshBanner() end
end)
