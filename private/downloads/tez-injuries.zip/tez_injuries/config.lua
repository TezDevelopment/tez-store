Config = {}

-- ESX job names that count as EMS. They patch other players by standing next to them and pressing E (free, no item used).
Config.EmsJobs = { 'ambulance' }

-- 'esx' = default ESX inventory, 'ox' = ox_inventory
Config.Inventory = 'esx'

-- The item that fixes a leg. Players use it from their inventory.
Config.BandageItem = 'bandage'
Config.BandagePrice = 75
Config.PayWith = 'money' -- 'money' or 'bank'

-- Places where players can buy a bandage (stand in the marker and press E).
Config.Shops = {
    { label = 'Pillbox Medical Supply',  coords = vec3(307.6, -594.9, 43.28) },
    { label = 'Sandy Shores Medical',    coords = vec3(1839.6, 3672.9, 34.28) },
    { label = 'Paleto Bay Medical',      coords = vec3(-247.8, 6331.2, 32.43) },
}
Config.ShopBlips = true

-- LIMP
Config.Limp = {
    clipset      = 'move_m@injured', -- the injured walk that comes with the game
    blend        = 0.6,
    speedOneLeg  = 0.88,             -- walking speed multiplier with one hurt leg
    speedBothLegs = 0.72,            -- with both legs hurt
    noSprint     = true,             -- cannot run
    noJump       = true,
}

-- FALLING when shot in the shoulder, leg or stomach
Config.Fall = {
    chance     = { shoulder = 1.0, leg = 1.0, stomach = 1.0 }, -- 1.0 = always
    ragdollMin = 3500,   -- ms on the ground
    ragdollMax = 6500,
    force      = 7.0,    -- how hard the hit pushes you
    cooldown   = 8,      -- seconds before another fall can happen
    getUpLimp  = true,   -- true = after any fall you get up limping, false = no limp
}

-- TREATMENT
Config.Treat = {
    selfSeconds = 9,     -- using a bandage on yourself
    emsSeconds  = 7,     -- EMS patching someone else
    distance    = 3.0,
}

-- Hit feed at the top of the screen
Config.FeedSeconds = 6

-- If true, a revive from EMS also clears leg injuries. Default false: you still need a bandage.
Config.ClearOnRevive = false

Config.Text = {
    legOne   = 'You have damage to your %s leg',
    legBoth  = 'You have damage to both legs',
    legSub   = 'You are limping and cannot run. Get a bandage from EMS or buy one.',
    bledOut  = 'You bled out.',
    bleeding = 'Bleeding out',
    cantFire = 'Your shoulder is shot. You cannot fire until you use a bandage.',
    chipNoFire = 'Cannot fire',
    emsPrompt = 'Press ~INPUT_CONTEXT~ to patch up the wounded person',
    shotMany = 'Shot in %d places',
    hurtTitle = 'You are wounded',
    chipLimp = 'Limping',
    chipArm  = 'Holding the wound',
    hint     = 'Use a bandage or find EMS to patch up.',
    armHurt  = 'You have a wounded arm',
    armSub   = 'You are holding the wound. Get a bandage from EMS or buy one.',
    bothSub  = 'You are limping and holding a wound. Get a bandage from EMS or buy one.',
    shotIn   = 'Shot in the %s',
    noInjury = 'You are not injured.',
    noBandage = 'You do not have a bandage.',
    treating = 'Bandaging your wound',
    treatingEms = 'Patching the wound',
    healed   = 'You are patched up.',
    emsDone  = 'You patched them up.',
    buyPrompt = 'Press ~INPUT_CONTEXT~ to buy a bandage ($%s)',
    bought   = 'You bought a bandage.',
    noMoney  = 'You cannot afford a bandage.',
    noCarry  = 'You cannot carry a bandage.',
    notEms   = 'Only EMS can do that.',
    nobodyClose = 'There is nobody close enough.',
    notHurt  = 'That person is not injured.',
}

-- CLUTCHING THE SHOT ARM (after a shoulder hit your other hand holds it, until you are treated)
Config.HoldArm = {
    enabled = true,
    flags   = 49,
    ik      = true,     -- the free hand is pulled onto the wound so it matches the side that was shot
    ikIndex = { left = 0, right = 1 }, -- game IK slots for the left / right arm       -- loop + upper body only + keep walking
    options = {         -- the first one is played
        { dict = 'amb@world_human_hang_out_street@female_hold_arm@base',  clip = 'base' },
        { dict = 'amb@world_human_hang_out_street@female_hold_arm@idle_a', clip = 'idle_a' },
        { dict = 'amb@world_human_hang_out_street@female_arms_crossed@base', clip = 'base' },
        { dict = 'combat@damage@injured_pistol@idle', clip = 'idle' },
        { dict = 'anim@heists@heist_corona@single_team', clip = 'single_team_loop_boss' },
    },
}

-- SHOT IN THE SHOULDER: you cannot fire your gun until you use a bandage
Config.Shoulder = { noFire = true }

-- BLEEDING OUT: after you are shot you have this long to get a bandage or EMS, then you die.
-- The clock starts with the first wound and does not run while you are already dead.
Config.Bleed = {
    enabled = true,
    minutes = 10,
}
