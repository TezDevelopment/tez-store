(function () {
  var NS = 'http://www.w3.org/2000/svg';
  var feedEl = document.getElementById('feed');
  var statusEl = document.getElementById('status');
  var MAX_ROWS = 4;

  // Front view of a person, 100 x 220. The person's LEFT is on the viewer's RIGHT.
  var BODY =
    '<ellipse class="skin" cx="50" cy="17" rx="11" ry="13"/>' +
    '<rect class="skin" x="45" y="28" width="10" height="12" rx="4"/>' +
    '<path class="skin" d="M30 44 Q50 36 70 44 L72 112 Q50 120 28 112 Z"/>' +
    '<rect class="skin" x="12" y="44" width="15" height="46" rx="7.5"/>' +
    '<rect class="skin" x="73" y="44" width="15" height="46" rx="7.5"/>' +
    '<rect class="skin" x="13" y="88" width="13" height="38" rx="6.5"/>' +
    '<rect class="skin" x="74" y="88" width="13" height="38" rx="6.5"/>' +
    '<rect class="skin" x="29" y="112" width="19" height="104" rx="9"/>' +
    '<rect class="skin" x="52" y="112" width="19" height="104" rx="9"/>';

  // where each zone sits on that figure. side: left = viewer's right.
  function spot(label) {
    var left = /left/.test(label), right = /right/.test(label);
    var armX = left ? 80 : 20, legX = left ? 61 : 39;
    if (/thigh/.test(label)) return { x: legX, y: 140 };
    if (/calf/.test(label)) return { x: legX, y: 178 };
    if (/foot/.test(label)) return { x: legX, y: 208 };
    if (/shoulder/.test(label)) return { x: left ? 76 : 24, y: 50 };
    if (/forearm/.test(label)) return { x: armX, y: 98 };
    if (/hand/.test(label)) return { x: armX, y: 122 };
    if (/upper back|chest/.test(label)) return { x: 50, y: 64, back: /back/.test(label) };
    if (/lower back|stomach/.test(label)) return { x: 50, y: 92, back: /back/.test(label) };
    if (/neck/.test(label)) return { x: 50, y: 34 };
    if (/head/.test(label)) return { x: 50, y: 17 };
    return { x: 50, y: 70 };
  }

  function marker(p, big) {
    var r = big ? 6 : 5;
    var s = '<circle class="glow" cx="' + p.x + '" cy="' + p.y + '" r="' + (r + 3) + '"/>';
    if (p.back) s += '<circle class="back-ring" cx="' + p.x + '" cy="' + p.y + '" r="' + (r + 3) + '"/>';
    s += '<circle class="ring" cx="' + p.x + '" cy="' + p.y + '" r="' + r + '"/>';
    s += '<circle class="core" cx="' + p.x + '" cy="' + p.y + '" r="' + (r - 2) + '"/>';
    return s;
  }

  function figure(labels, big) {
    var svg = '<svg viewBox="0 0 100 220" xmlns="' + NS + '">' + BODY;
    (labels || []).forEach(function (l) { svg += marker(spot(l), big); });
    return svg + '</svg>';
  }

  function showStatus(d) {
    if (!d.visible) { statusEl.classList.add('hidden'); return; }
    var wounds = d.wounds || [];
    document.getElementById('statusTitle').textContent = d.title || '';
    document.getElementById('statusFig').innerHTML = figure(wounds, true);
    var list = document.getElementById('statusList');
    list.innerHTML = '';
    if (wounds.length > 1) {
      wounds.forEach(function (w) {
        var li = document.createElement('li');
        li.textContent = w.charAt(0).toUpperCase() + w.slice(1);
        list.appendChild(li);
      });
    }
    var chips = document.getElementById('statusChips');
    chips.innerHTML = '';
    (d.chips || []).forEach(function (c, i) {
      var el = document.createElement('span');
      el.className = 'chip' + (i % 2 ? ' amber' : '');
      el.textContent = c;
      chips.appendChild(el);
    });
    document.getElementById('statusHint').textContent = d.hint || '';
    var wasHidden = statusEl.classList.contains('hidden');
    statusEl.classList.remove('hidden');
    if (!wasHidden) { statusEl.classList.remove('flash'); void statusEl.offsetWidth; statusEl.classList.add('flash'); }
  }

  // bleed out clock: the server sends the seconds left, the page counts down smoothly between updates
  var bleedEnd = 0, bleedTotal = 600, bleedTimer = null;
  function pad(n) { return n < 10 ? '0' + n : '' + n; }
  function tickBleed() {
    var left = Math.max(0, Math.round((bleedEnd - Date.now()) / 1000));
    var box = document.getElementById('bleed');
    document.getElementById('bleedTime').textContent = Math.floor(left / 60) + ':' + pad(left % 60);
    document.getElementById('bleedFill').style.width = Math.min(100, (left / bleedTotal) * 100) + '%';
    box.classList.toggle('urgent', left <= 120);
  }
  function showBleed(d) {
    var box = document.getElementById('bleed');
    clearInterval(bleedTimer);
    if (!d.left || d.left <= 0) { box.classList.add('hidden'); return; }
    bleedTotal = d.total || 600;
    bleedEnd = Date.now() + d.left * 1000;
    if (d.label) document.getElementById('bleedLabel').textContent = d.label;
    box.classList.remove('hidden');
    tickBleed();
    bleedTimer = setInterval(tickBleed, 250);
  }

  var lastRow = null;
  function showFeed(d) {
    if (lastRow && lastRow.key === d.label && lastRow.el.parentNode && Date.now() - lastRow.at < 2600) {
      lastRow.at = Date.now();
      var n = lastRow.el.querySelector('.n');
      if (!n) { n = document.createElement('div'); n.className = 'n'; lastRow.el.appendChild(n); }
      n.textContent = 'x' + d.count;
      resetTimer(lastRow, d.seconds);
      return;
    }
    var el = document.createElement('div');
    el.className = 'row';
    el.innerHTML = '<div class="fig">' + figure([d.label || ''], false) + '</div><div class="t"></div>';
    el.querySelector('.t').textContent = d.text || '';
    feedEl.appendChild(el);
    while (feedEl.children.length > MAX_ROWS) feedEl.removeChild(feedEl.firstChild);
    lastRow = { el: el, key: d.label, at: Date.now() };
    resetTimer(lastRow, d.seconds);
  }
  function resetTimer(row, seconds) {
    clearTimeout(row.timer);
    row.timer = setTimeout(function () {
      row.el.classList.add('out');
      setTimeout(function () { if (row.el.parentNode) row.el.parentNode.removeChild(row.el); }, 550);
    }, (seconds || 6) * 1000);
  }

  var progTimer = null;
  function showProgress(d) {
    var box = document.getElementById('progress'), fill = document.getElementById('progressFill');
    clearTimeout(progTimer);
    if (!d.visible) { box.classList.add('hidden'); return; }
    document.getElementById('progressText').textContent = d.text || '';
    fill.style.transition = 'none'; fill.style.width = '0%'; void fill.offsetWidth;
    box.classList.remove('hidden');
    fill.style.transition = 'width ' + (d.seconds || 5) + 's linear';
    fill.style.width = '100%';
    progTimer = setTimeout(function () { box.classList.add('hidden'); }, ((d.seconds || 5) + 1) * 1000);
  }

  window.addEventListener('message', function (e) {
    var d = e.data || {};
    if (d.action === 'status') showStatus(d);
    else if (d.action === 'feed') showFeed(d);
    else if (d.action === 'progress') showProgress(d);
    else if (d.action === 'bleed') showBleed(d);
  });
})();
