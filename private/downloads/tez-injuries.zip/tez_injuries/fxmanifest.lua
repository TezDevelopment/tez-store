fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'tez_injuries'
author 'Tez Development'
description 'Realistic gunshot injuries: leg limp, back and shoulder falls, hit feed, bandages and EMS treatment'
version '1.0.0'

dependencies { 'es_extended', 'oxmysql' }

shared_script 'config.lua'
client_script 'client.lua'
server_scripts { '@oxmysql/lib/MySQL.lua', 'server.lua' }

ui_page 'html/index.html'
files { 'html/index.html', 'html/style.css', 'html/app.js' }
