-- tez_injuries: run once. Safe to run again.
CREATE TABLE IF NOT EXISTS `tez_injuries` (
  `identifier` VARCHAR(60) NOT NULL,
  `left_leg`  TINYINT(1) NOT NULL DEFAULT 0,
  `right_leg` TINYINT(1) NOT NULL DEFAULT 0,
  `arm`       TINYINT(1) NOT NULL DEFAULT 0,
  `limp`      TINYINT(1) NOT NULL DEFAULT 0,
  `wounds`    VARCHAR(160) NOT NULL DEFAULT '',
  `bleed`     INT NOT NULL DEFAULT 0,
  PRIMARY KEY (`identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- for servers that already ran an older version
ALTER TABLE `tez_injuries` ADD COLUMN IF NOT EXISTS `arm` TINYINT(1) NOT NULL DEFAULT 0;

ALTER TABLE `tez_injuries` ADD COLUMN IF NOT EXISTS `limp` TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE `tez_injuries` ADD COLUMN IF NOT EXISTS `wounds` VARCHAR(160) NOT NULL DEFAULT '';
ALTER TABLE `tez_injuries` ADD COLUMN IF NOT EXISTS `bleed` INT NOT NULL DEFAULT 0;

-- Default ESX inventory only. If you use ox_inventory, skip this line and read the README.
INSERT IGNORE INTO `items` (`name`, `label`, `weight`) VALUES ('bandage', 'Bandage', 1);
