local ESX = exports['es_extended']:getSharedObject()

local Injuries = {}   -- [src] = { left, right, arm, limp = bool, wounds = { 'right shoulder', ... }, bleed = seconds left (0 = none) }
local LastReport = {} -- [src] = os.clock of last accepted report
local Died = {}       -- [src] = os.time of last death (for ClearOnRevive)
local Busy = {}       -- [src] = true while EMS is patching them

local function T(key, ...) local s = Config.Text[key] or key; if select('#', ...) > 0 then return s:format(...) end return s end
local function notify(src, msg) TriggerClientEvent('esx:showNotification', src, msg) end

local function inList(list, v) for _, x in ipairs(list) do if x == v then return true end end return false end
local function isEms(xPlayer) return xPlayer and xPlayer.job and inList(Config.EmsJobs, xPlayer.job.name) end

-- ------------------------------------------------------------------ inventory
local function itemCount(src)
    if Config.Inventory == 'ox' then
        return exports.ox_inventory:Search(src, 'count', Config.BandageItem) or 0
    end
    local xp = ESX.GetPlayerFromId(src)
    local it = xp and xp.getInventoryItem(Config.BandageItem)
    return it and it.count or 0
end

local function takeItem(src)
    if Config.Inventory == 'ox' then
        return exports.ox_inventory:RemoveItem(src, Config.BandageItem, 1) and true or false
    end
    local xp = ESX.GetPlayerFromId(src)
    if not xp then return false end
    xp.removeInventoryItem(Config.BandageItem, 1)
    return true
end

local function giveItem(src)
    if Config.Inventory == 'ox' then
        if not exports.ox_inventory:CanCarryItem(src, Config.BandageItem, 1) then return false end
        return exports.ox_inventory:AddItem(src, Config.BandageItem, 1) and true or false
    end
    local xp = ESX.GetPlayerFromId(src)
    if not xp then return false end
    if xp.canCarryItem and not xp.canCarryItem(Config.BandageItem, 1) then return false end
    xp.addInventoryItem(Config.BandageItem, 1)
    return true
end

-- ------------------------------------------------------------------ state
local function identifierOf(src)
    local xp = ESX.GetPlayerFromId(src)
    return xp and xp.identifier or nil
end

local function save(src)
    local id, st = identifierOf(src), Injuries[src]
    if not id or not st then return end
    MySQL.prepare('INSERT INTO tez_injuries (identifier, left_leg, right_leg, arm, limp, wounds, bleed) VALUES (?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE left_leg = VALUES(left_leg), right_leg = VALUES(right_leg), arm = VALUES(arm), limp = VALUES(limp), wounds = VALUES(wounds), bleed = VALUES(bleed)',
        { id, st.left and 1 or 0, st.right and 1 or 0, st.arm and 1 or 0, st.limp and 1 or 0, table.concat(st.wounds or {}, ','), st.bleed or 0 })
end

local function push(src)
    local st = Injuries[src] or { left = false, right = false, arm = false, limp = false, wounds = {}, bleed = 0 }
    TriggerClientEvent('tez_injuries:set', src, st.left, st.right, st.arm, st.limp, st.wounds, st.bleed)
    Player(src).state:set('tezHurt', (st.left or st.right or st.arm or st.limp) and true or false, true)
end

local function isHurt(st) return st and (st.left or st.right or st.arm or st.limp) end

-- only short plain-text labels like "left calf" are accepted from a client, max 6
local function cleanWounds(list)
    local out, seen = {}, {}
    if type(list) ~= 'table' then return out end
    for _, w in ipairs(list) do
        if type(w) == 'string' and #w <= 20 and w:match('^[%a ]+$') and not seen[w] then
            seen[w] = true
            out[#out + 1] = w
            if #out >= 6 then break end
        end
    end
    return out
end

local function setState(src, left, right, arm, limp, wounds, bleed)
    Injuries[src] = { left = left and true or false, right = right and true or false, arm = arm and true or false, limp = limp and true or false, wounds = cleanWounds(wounds), bleed = bleed or 0 }
    save(src)
    push(src)
end

local function clear(src) setState(src, false, false, false, false, {}, 0) end

AddEventHandler('esx:playerLoaded', function(src, xPlayer)
    Injuries[src] = { left = false, right = false, arm = false, limp = false, wounds = {}, bleed = 0 }
    local row = MySQL.single.await('SELECT left_leg, right_leg, arm, limp, wounds, bleed FROM tez_injuries WHERE identifier = ?', { xPlayer.identifier })
    if row then
        local w = {}
        for part in (row.wounds or ''):gmatch('[^,]+') do w[#w + 1] = part end
        Injuries[src] = { left = row.left_leg == 1, right = row.right_leg == 1, arm = row.arm == 1, limp = row.limp == 1, wounds = cleanWounds(w), bleed = tonumber(row.bleed) or 0 }
    end
    push(src)
end)

AddEventHandler('playerDropped', function()
    local src = source
    Injuries[src], LastReport[src], Died[src], Busy[src] = nil, nil, nil, nil
end)

-- Late start (resource restarted while players are online)
AddEventHandler('onResourceStart', function(res)
    if res ~= GetCurrentResourceName() then return end
    Wait(1500)
    for _, src in ipairs(GetPlayers()) do
        src = tonumber(src)
        local xp = ESX.GetPlayerFromId(src)
        if xp then TriggerEvent('esx:playerLoaded', src, xp) end
    end
end)

-- ------------------------------------------------------------------ client reports a new injury
-- A client may only ADD an injury, never remove one. Clearing only happens through the flows below.
RegisterNetEvent('tez_injuries:report', function(left, right, arm, limp, wounds)
    local src = source
    local st = Injuries[src]
    if not st then return end
    local now = os.clock()
    if LastReport[src] and now - LastReport[src] < 0.3 then return end
    LastReport[src] = now
    local nl, nr, na, nlp = st.left or left == true, st.right or right == true, st.arm or arm == true, st.limp or limp == true
    local merged = {}
    for _, w in ipairs(st.wounds or {}) do merged[#merged + 1] = w end
    for _, w in ipairs(cleanWounds(wounds)) do merged[#merged + 1] = w end
    merged = cleanWounds(merged)
    local bleed = st.bleed or 0
    -- the clock starts with the first wound and keeps running (new wounds do not reset it)
    if Config.Bleed.enabled and bleed <= 0 and #merged > #(st.wounds or {}) then bleed = Config.Bleed.minutes * 60 end
    setState(src, nl, nr, na, nlp, merged, bleed)
end)

RegisterNetEvent('tez_injuries:died', function() Died[source] = os.time() end)

RegisterNetEvent('tez_injuries:revived', function()
    local src = source
    local was = Died[src]
    Died[src] = nil                          -- the bleed clock runs again
    if Config.ClearOnRevive and was and os.time() - was < 1800 then clear(src) end
end)

-- bleed clock: counts down once a second, never while the player is dead
CreateThread(function()
    local n = 0
    while true do
        Wait(1000)
        n = n + 1
        for src, st in pairs(Injuries) do
            if st.bleed and st.bleed > 0 and not Died[src] then
                st.bleed = st.bleed - 1
                if st.bleed <= 0 then
                    st.bleed = Config.Bleed.minutes * 60   -- starts again after a revive
                    Died[src] = os.time()                  -- paused until revived
                    save(src)
                    TriggerClientEvent('tez_injuries:bleedOut', src)
                elseif n % 10 == 0 then
                    TriggerClientEvent('tez_injuries:bleed', src, st.bleed)
                    if n % 30 == 0 then save(src) end
                end
            end
        end
    end
end)

-- ------------------------------------------------------------------ bandage (self)
ESX.RegisterUsableItem(Config.BandageItem, function(src)
    TriggerClientEvent('tez_injuries:useBandage', src)
end)

RegisterNetEvent('tez_injuries:consume', function()
    local src = source
    local st = Injuries[src]
    if not st or not isHurt(st) then return notify(src, T('noInjury')) end
    if itemCount(src) < 1 then return notify(src, T('noBandage')) end
    if not takeItem(src) then return notify(src, T('noBandage')) end
    clear(src)
    notify(src, T('healed'))
end)

-- Is the player on the bandage item (used to refuse the client if it has none)
RegisterNetEvent('tez_injuries:canBandage', function()
    local src = source
    local st = Injuries[src]
    if not st or not isHurt(st) then return notify(src, T('noInjury')) end
    if itemCount(src) < 1 then return notify(src, T('noBandage')) end
    TriggerClientEvent('tez_injuries:beginSelf', src)
end)

-- ------------------------------------------------------------------ shop
local function nearShop(src)
    local c = GetEntityCoords(GetPlayerPed(src))
    for _, s in ipairs(Config.Shops) do
        if #(c - s.coords) <= 4.0 then return true end
    end
    return false
end

RegisterNetEvent('tez_injuries:buy', function()
    local src = source
    local xp = ESX.GetPlayerFromId(src)
    if not xp or not nearShop(src) then return end
    local acc = xp.getAccount(Config.PayWith)
    if not acc or acc.money < Config.BandagePrice then return notify(src, T('noMoney')) end
    if not giveItem(src) then return notify(src, T('noCarry')) end
    xp.removeAccountMoney(Config.PayWith, Config.BandagePrice)
    notify(src, T('bought'))
end)

-- ------------------------------------------------------------------ EMS patches someone
RegisterNetEvent('tez_injuries:emsTreat', function(target)
    local src = source
    target = tonumber(target)
    local xp = ESX.GetPlayerFromId(src)
    if not isEms(xp) then return notify(src, T('notEms')) end
    if not target or target == src or not GetPlayerName(target) then return notify(src, T('nobodyClose')) end
    local d = #(GetEntityCoords(GetPlayerPed(src)) - GetEntityCoords(GetPlayerPed(target)))
    if d > Config.Treat.distance + 1.5 then return notify(src, T('nobodyClose')) end
    local st = Injuries[target]
    if not st or not isHurt(st) then return notify(src, T('notHurt')) end
    if Busy[target] then return end
    Busy[target] = true
    TriggerClientEvent('tez_injuries:emsBegin', src, target)
    TriggerClientEvent('tez_injuries:beingTreated', target, Config.Treat.emsSeconds)
    SetTimeout(Config.Treat.emsSeconds * 1000 + 500, function()
        Busy[target] = nil
        if not GetPlayerName(target) or not GetPlayerName(src) then return end
        local d2 = #(GetEntityCoords(GetPlayerPed(src)) - GetEntityCoords(GetPlayerPed(target)))
        if d2 > Config.Treat.distance + 2.5 then return notify(src, T('nobodyClose')) end
        clear(target)
        notify(target, T('healed'))
        notify(src, T('emsDone'))
    end)
end)
